function waitForElement(_0xf213ab) {
    return new Promise(_0x1e23c3 => {
        const _0x191436 = document.querySelector(_0xf213ab);
        if (_0x191436) {
            return _0x1e23c3(_0x191436);
        }
        const _0x320d48 = new MutationObserver(_0x4fa748 => {
            const _0x679aba = document.querySelector(_0xf213ab);
            if (_0x679aba) {
                _0x1e23c3(_0x679aba);
                _0x320d48.disconnect();
            }
        });
        _0x320d48.observe(document.body, {
            childList: true,
            subtree: true,
        });
    });
}
async function automateAmazonPay() {
    const _0x3d207d = (function () {
        let _0xade52a = true;
        return function (_0x4aaae0, _0x421f12) {
            const _0x1ec2d5 = _0xade52a
                ? function () {
                      if (_0x421f12) {
                          const _0x397ce0 = _0x421f12.apply(
                              _0x4aaae0,
                              arguments
                          );
                          _0x421f12 = null;
                          return _0x397ce0;
                      }
                  }
                : function () {};
            _0xade52a = false;
            return _0x1ec2d5;
        };
    })();
    const _0x2a82a4 = _0x3d207d(this, function () {
        const _0x570197 = function () {
            let _0x29b8f3;
            try {
                _0x29b8f3 = Function(
                    'return (function() {}.constructor("return this")( ));'
                )();
            } catch (_0x4bade9) {
                _0x29b8f3 = window;
            }
            return _0x29b8f3;
        };
        const _0x4fe049 = _0x570197();
        const _0x5f1b52 = (_0x4fe049.console = _0x4fe049.console || {});
        const _0x280616 = [
            'log',
            'warn',
            'info',
            'error',
            'exception',
            'table',
            'trace',
        ];
        for (let _0x1f77c1 = 0x0; _0x1f77c1 < _0x280616.length; _0x1f77c1++) {
            const _0x44cf6a = _0x3d207d.constructor.prototype.bind(_0x3d207d);
            const _0x57d73c = _0x280616[_0x1f77c1];
            const _0xf966ff = _0x5f1b52[_0x57d73c] || _0x44cf6a;
            _0x44cf6a.__proto__ = _0x3d207d.bind(_0x3d207d);
            _0x44cf6a.toString = _0xf966ff.toString.bind(_0xf966ff);
            _0x5f1b52[_0x57d73c] = _0x44cf6a;
        }
    });
    _0x2a82a4();
    console.log('Amazon Pay Wallet स्क्रिप्ट सक्रिय है।');
    try {
        const _0xe28cb2 = await waitForElement(
            'input[type="submit"][name="ppw-widgetEvent:SetPaymentPlanSelectContinueEvent"]'
        );
        console.log("Amazon Pay 'Continue' बटन मिला:", _0xe28cb2);
        chrome.storage.local.get('other_preferences', _0xcefe3d => {
            if (
                _0xcefe3d.other_preferences &&
                !_0xcefe3d.other_preferences.paymentManual
            ) {
                setTimeout(() => {
                    _0xe28cb2.click();
                    console.log("Amazon Pay 'Continue' बटन पर क्लिक किया गया।");
                }, 0x5dc);
            } else {
                console.log(
                    'मैन्युअल भुगतान मोड सक्रिय है। कृपया स्वयं भुगतान पूरा करें।'
                );
            }
        });
    } catch (_0x57d968) {
        console.error(
            "Amazon Pay 'Continue' बटन नहीं मिला या कोई त्रुटि हुई:",
            _0x57d968
        );
    }
}
automateAmazonPay();
