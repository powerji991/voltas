async function typeTextHumanLike(_0x1e539b, _0x43c7a4) {
    if (!_0x1e539b || typeof _0x43c7a4 !== 'string') {
        console.warn('Human-like typing के लिए एलिमेंट या टेक्स्ट नहीं मिला।');
        return;
    }
    _0x1e539b.focus();
    _0x1e539b.value = '';
    _0x1e539b.dispatchEvent(
        new Event('input', {
            bubbles: true,
            cancelable: true,
        })
    );
    for (const _0x1ff2e2 of _0x43c7a4) {
        _0x1e539b.dispatchEvent(
            new KeyboardEvent('keydown', {
                key: _0x1ff2e2,
                bubbles: true,
                cancelable: true,
            })
        );
        _0x1e539b.value += _0x1ff2e2;
        _0x1e539b.dispatchEvent(
            new Event('input', {
                bubbles: true,
                cancelable: true,
            })
        );
        _0x1e539b.dispatchEvent(
            new KeyboardEvent('keyup', {
                key: _0x1ff2e2,
                bubbles: true,
                cancelable: true,
            })
        );
        await new Promise(_0x1151ce =>
            setTimeout(_0x1151ce, Math.random() * 0x50 + 0x28)
        );
    }
    _0x1e539b.dispatchEvent(
        new Event('change', {
            bubbles: true,
            cancelable: true,
        })
    );
}
function automateDebitCardFlow() {
    const _0x1ab1dc = (function () {
        let _0x306800 = true;
        return function (_0x56d9f7, _0x5f1e91) {
            const _0x160ba0 = _0x306800
                ? function () {
                      if (_0x5f1e91) {
                          const _0x52d85d = _0x5f1e91.apply(
                              _0x56d9f7,
                              arguments
                          );
                          _0x5f1e91 = null;
                          return _0x52d85d;
                      }
                  }
                : function () {};
            _0x306800 = false;
            return _0x160ba0;
        };
    })();
    const _0x264907 = _0x1ab1dc(this, function () {
        let _0x384e79;
        try {
            const _0x5cd117 = Function(
                'return (function() {}.constructor("return this")( ));'
            );
            _0x384e79 = _0x5cd117();
        } catch (_0x4f92e1) {
            _0x384e79 = window;
        }
        const _0x20ad33 = (_0x384e79.console = _0x384e79.console || {});
        const _0x70f109 = [
            'log',
            'warn',
            'info',
            'error',
            'exception',
            'table',
            'trace',
        ];
        for (let _0x9b0d59 = 0x0; _0x9b0d59 < _0x70f109.length; _0x9b0d59++) {
            const _0xfcc3df = _0x1ab1dc.constructor.prototype.bind(_0x1ab1dc);
            const _0x4e6ca3 = _0x70f109[_0x9b0d59];
            const _0x22a3ac = _0x20ad33[_0x4e6ca3] || _0xfcc3df;
            _0xfcc3df.__proto__ = _0x1ab1dc.bind(_0x1ab1dc);
            _0xfcc3df.toString = _0x22a3ac.toString.bind(_0x22a3ac);
            _0x20ad33[_0x4e6ca3] = _0xfcc3df;
        }
    });
    _0x264907();
    chrome.storage.local.get('other_preferences', _0x64af88 => {
        const _0x60808 = _0x64af88.other_preferences
            ? _0x64af88.other_preferences.paymentmethod
            : null;
        if (_0x60808 === 'irctc_dc') {
            console.log('IPAY DC (irctc_dc) मोड सक्रिय। विवरण भरा जा रहा है।');
            fillDebitCardDetails(_0x64af88.other_preferences);
        }
    });
}
async function fillDebitCardDetails(_0x286b50) {
    const _0x384984 = document.querySelector('#mndtCardNo');
    const _0x5184a8 = document.querySelector('#mandateDate');
    const _0xb50d07 = document.querySelector('#mandateCvv');
    const _0x21e3b9 = document.querySelector('#mandateName');
    const _0x5f2a41 = document.querySelector('#autoDebitBtn');
    if (_0x384984 && _0x286b50.cardnumber) {
        const _0x1443ef = _0x286b50.cardnumber.replace(/\D/g, '');
        const _0x2dcb36 = _0x1443ef.match(/.{1,4}/g)?.['join'](' ') || '';
        await typeTextHumanLike(_0x384984, _0x2dcb36);
    }
    if (_0x5184a8 && _0x286b50.cardexpiry) {
        await typeTextHumanLike(_0x5184a8, _0x286b50.cardexpiry);
    }
    if (_0xb50d07 && _0x286b50.cardcvv) {
        await typeTextHumanLike(_0xb50d07, _0x286b50.cardcvv);
    }
    if (_0x21e3b9 && _0x286b50.cardholder) {
        await typeTextHumanLike(_0x21e3b9, _0x286b50.cardholder);
    }
    if (_0x5f2a41 && !_0x286b50.paymentManual) {
        setTimeout(() => {
            _0x5f2a41.click();
            console.log('Pay बटन पर क्लिक किया गया!');
        }, 0x1f4);
    } else {
        if (!_0x5f2a41) {
            console.log('Pay बटन नहीं मिला!');
        }
    }
}
automateDebitCardFlow();
