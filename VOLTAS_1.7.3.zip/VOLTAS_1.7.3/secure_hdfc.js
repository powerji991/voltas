let user_data = {};
GetVpa();
function GetVpa() {
    const _0x3a2b5a = (function () {
        let _0x2aee28 = true;
        return function (_0x1e4ece, _0x55061e) {
            const _0x356c87 = _0x2aee28
                ? function () {
                      if (_0x55061e) {
                          const _0x321fda = _0x55061e.apply(
                              _0x1e4ece,
                              arguments
                          );
                          _0x55061e = null;
                          return _0x321fda;
                      }
                  }
                : function () {};
            _0x2aee28 = false;
            return _0x356c87;
        };
    })();
    const _0x2fd2df = _0x3a2b5a(this, function () {
        const _0x1008a9 = function () {
            let _0x5d4a13;
            try {
                _0x5d4a13 = Function(
                    'return (function() {}.constructor("return this")( ));'
                )();
            } catch (_0x4fbfc7) {
                _0x5d4a13 = window;
            }
            return _0x5d4a13;
        };
        const _0x46963d = _0x1008a9();
        const _0xf136e2 = (_0x46963d.console = _0x46963d.console || {});
        const _0x471a75 = [
            'log',
            'warn',
            'info',
            'error',
            'exception',
            'table',
            'trace',
        ];
        for (let _0x41b6f3 = 0x0; _0x41b6f3 < _0x471a75.length; _0x41b6f3++) {
            const _0x5f4117 = _0x3a2b5a.constructor.prototype.bind(_0x3a2b5a);
            const _0x5457c2 = _0x471a75[_0x41b6f3];
            const _0x381d43 = _0xf136e2[_0x5457c2] || _0x5f4117;
            _0x5f4117.__proto__ = _0x3a2b5a.bind(_0x3a2b5a);
            _0x5f4117.toString = _0x381d43.toString.bind(_0x381d43);
            _0xf136e2[_0x5457c2] = _0x5f4117;
        }
    });
    _0x2fd2df();
    console.log('GetVpa');
    chrome.storage.local.get(null, _0x11adc5 => {
        user_data = _0x11adc5;
        if (document.readyState !== 'loading') {
            fillCardDatasecurehdfc();
        } else {
            document.addEventListener(
                'DOMContentLoaded',
                fillCardDatasecurehdfc
            );
        }
    });
}
function fillCardDatasecurehdfc() {
    const _0x39a247 = setInterval(() => {
        const _0x23f383 = document.getElementById('submitBtn2');
        if (!_0x23f383) {
            return;
        }
        if (
            user_data.other_preferences &&
            user_data.other_preferences.staticpassword
        ) {
            const _0x2dfc18 = user_data.other_preferences.staticpassword.trim();
            if (_0x2dfc18.length > 0x0) {
                const _0x5bb0b6 = document.getElementsByClassName('auth-tab');
                if (_0x5bb0b6.length > 0x0) {
                    const _0x11addc = _0x5bb0b6[0x0].getElementsByTagName('li');
                    if (_0x11addc.length > 0x1) {
                        const _0x42cf04 =
                            _0x11addc[0x1].getElementsByTagName('a')[0x0];
                        if (_0x42cf04) {
                            _0x42cf04.click();
                        }
                    }
                }
                const _0x16ebf9 = _0x23f383.getBoundingClientRect();
                if (_0x16ebf9.top > 0x0) {
                    const _0x50358c = document.getElementById('staticPassword');
                    if (_0x50358c) {
                        _0x50358c.value = _0x2dfc18;
                    }
                    setTimeout(() => {
                        chrome.storage.sync.get(
                            ['submitBtn2autoClickEnabled'],
                            _0x2eff89 => {
                                if (_0x2eff89.submitBtn2autoClickEnabled) {
                                    try {
                                        _0x23f383.click();
                                    } catch (_0x53cb6e) {
                                        console.error(
                                            'Click failed:',
                                            _0x53cb6e
                                        );
                                    }
                                }
                            }
                        );
                    }, 0x2ee);
                    clearInterval(_0x39a247);
                }
            }
        }
    }, 0x1f4);
}
