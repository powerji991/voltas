// Initialize Voltas Logger for content script
const contentLogger = window.VoltasLogging
    ? window.VoltasLogging.createLogger({
          component: 'content-script',
          level: 'debug',
          enableStorage: true,
          environment: 'development',
      })
    : {
          info: console.log,
          debug: console.log,
          warn: console.warn,
          error: console.error,
      };

// Log content script initialization
contentLogger.info('🔧 Extension Tatkal Content Script initialized', {
    timestamp: new Date().toISOString(),
    url: window.location.href,
    userAgent: navigator.userAgent,
});

const _0x3e051f = (function () {
    let _0x391ecd = true;
    return function (_0x467e9b, _0x21abac) {
        const _0x1b3928 = _0x391ecd
            ? function () {
                  if (_0x21abac) {
                      const _0x577636 = _0x21abac.apply(_0x467e9b, arguments);
                      _0x21abac = null;
                      return _0x577636;
                  }
              }
            : function () {};
        _0x391ecd = false;
        return _0x1b3928;
    };
})();
const _0x46347b = _0x3e051f(this, function () {
    const _0x5730d7 = function () {
        let _0x14c247;
        try {
            _0x14c247 = Function(
                'return (function() {}.constructor("return this")( ));'
            )();
        } catch (_0x5ae981) {
            _0x14c247 = window;
        }
        return _0x14c247;
    };
    const _0x2138b7 = _0x5730d7();
    const _0x2bdbc2 = (_0x2138b7.console = _0x2138b7.console || {});
    const _0x19204d = [
        'log',
        'warn',
        'info',
        'error',
        'exception',
        'table',
        'trace',
    ];
    for (let _0x318a1e = 0x0; _0x318a1e < _0x19204d.length; _0x318a1e++) {
        const _0x1a533d = _0x3e051f.constructor.prototype.bind(_0x3e051f);
        const _0x3ac450 = _0x19204d[_0x318a1e];
        const _0x5ccf02 = _0x2bdbc2[_0x3ac450] || _0x1a533d;
        _0x1a533d.__proto__ = _0x3e051f.bind(_0x3e051f);
        _0x1a533d.toString = _0x5ccf02.toString.bind(_0x5ccf02);
        _0x2bdbc2[_0x3ac450] = _0x1a533d;
    }
});
_0x46347b();
function simulateClick(_0x492b60) {
    contentLogger.debug('🖱️ Simulating click', {
        element: _0x492b60?.tagName || 'unknown',
        id: _0x492b60?.id || 'no-id',
        className: _0x492b60?.className || 'no-class',
        disabled: _0x492b60?.disabled || false,
    });

    if (_0x492b60 && typeof _0x492b60.dispatchEvent === 'function') {
        if (typeof _0x492b60.focus === 'function') {
            try {
                _0x492b60.focus();
            } catch (_0x52fe1f) {
                contentLogger.warn('⚠️ Could not focus element before click', {
                    element: _0x492b60,
                    error: _0x52fe1f.message,
                });
                console.warn(
                    'Could not focus element before click:',
                    _0x492b60,
                    _0x52fe1f.message
                );
            }
        }
        if (_0x492b60.disabled) {
            contentLogger.warn('⚠️ Attempted to click on disabled element', {
                element: _0x492b60?.tagName || 'unknown',
                id: _0x492b60?.id || 'no-id',
                className: _0x492b60?.className || 'no-class',
            });
            console.warn(
                'Attempted to click on a disabled element:',
                _0x492b60
            );
            return;
        }
        const _0x281612 = new MouseEvent('mousedown', {
            bubbles: true,
            cancelable: true,
            view: window,
            button: 0x0,
        });
        const _0x5318db = new MouseEvent('mouseup', {
            bubbles: true,
            cancelable: true,
            view: window,
            button: 0x0,
        });
        const _0x44169d = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
            button: 0x0,
        });
        _0x492b60.dispatchEvent(_0x281612);
        _0x492b60.dispatchEvent(_0x5318db);
        _0x492b60.dispatchEvent(_0x44169d);
    } else {
        console.warn(
            'Attempted to simulate click on an invalid (null, undefined, or no dispatchEvent method) element:',
            _0x492b60
        );
    }
}
async function typeTextHumanLike(_0x292c4c, _0x9d6553) {
    contentLogger.debug('⌨️ Typing text human-like', {
        element: _0x292c4c?.tagName || 'unknown',
        textLength: _0x9d6553?.length || 0,
        text:
            _0x9d6553?.substring(0, 20) + (_0x9d6553?.length > 20 ? '...' : ''),
    });

    if (!_0x292c4c || typeof _0x9d6553 !== 'string') {
        contentLogger.warn('⚠️ Invalid parameters for human-like typing', {
            hasElement: !!_0x292c4c,
            textType: typeof _0x9d6553,
        });
        console.warn(
            'Element not provided or text is not a string for human-like typing.'
        );
        return;
    }
    _0x292c4c.focus();
    _0x292c4c.value = '';
    _0x292c4c.dispatchEvent(
        new Event('input', {
            bubbles: true,
            cancelable: true,
        })
    );
    for (const _0x240edf of _0x9d6553) {
        _0x292c4c.dispatchEvent(
            new KeyboardEvent('keydown', {
                key: _0x240edf,
                bubbles: true,
                cancelable: true,
            })
        );
        _0x292c4c.value += _0x240edf;
        _0x292c4c.dispatchEvent(
            new Event('input', {
                bubbles: true,
                cancelable: true,
            })
        );
        _0x292c4c.dispatchEvent(
            new KeyboardEvent('keyup', {
                key: _0x240edf,
                bubbles: true,
                cancelable: true,
            })
        );
        await new Promise(_0x5f1c5c =>
            setTimeout(_0x5f1c5c, Math.random() * 0x64 + 0x32)
        );
    }
    _0x292c4c.dispatchEvent(
        new Event('change', {
            bubbles: true,
            cancelable: true,
        })
    );
}
function showCustomAlert(_0x57b469) {
    alert(_0x57b469);
}
function showCustomConfirm(_0x185865, _0x4ea304, _0x4fa07) {
    if (confirm(_0x185865)) {
        if (_0x4ea304) {
            _0x4ea304();
        }
    } else {
        if (_0x4fa07) {
            _0x4fa07();
        }
    }
}
let user_data = {};
function getMsg(_0x2750b1, _0x4181af) {
    return {
        msg: {
            type: _0x4181af,
            data: _0x2750b1,
        },
        sender: 'content_script',
        id: 'irctc',
    };
}
function statusUpdate(_0x5bad7e) {
    contentLogger.info('📊 Status update', {
        status: _0x5bad7e,
        timestamp: new Date().toISOString(),
        url: window.location.href,
    });

    chrome.runtime.sendMessage({
        msg: {
            type: {
                status: _0x5bad7e,
                time: new Date().toString().split(' ')[0x4],
            },
            data: 'status_update',
        },
        sender: 'content_script',
        id: 'irctc',
    });
}
function classTranslator(_0x3d84a1) {
    let _0x39878b;
    _0x39878b =
        '1A' === _0x3d84a1
            ? 'AC First Class (1A)'
            : 'EV' === _0x3d84a1
              ? 'Vistadome AC (EV)'
              : 'EC' === _0x3d84a1
                ? 'Exec. Chair Car (EC)'
                : '2A' === _0x3d84a1
                  ? 'AC 2 Tier (2A)'
                  : '3A' === _0x3d84a1
                    ? 'AC 3 Tier (3A)'
                    : '3E' === _0x3d84a1
                      ? 'AC 3 Economy (3E)'
                      : 'CC' === _0x3d84a1
                        ? 'AC Chair car (CC)'
                        : 'SL' === _0x3d84a1
                          ? 'Sleeper (SL)'
                          : '2S' === _0x3d84a1
                            ? 'Second Sitting (2S)'
                            : 'None';
    return _0x39878b;
}
function quotaTranslator(_0x377b87) {
    let _0x1b5f55 = '';
    if ('GN' === _0x377b87) {
        _0x1b5f55 = 'GENERAL';
    } else if ('TQ' === _0x377b87) {
        _0x1b5f55 = 'TATKAL';
    } else if ('PT' === _0x377b87) {
        _0x1b5f55 = 'PREMIUM TATKAL';
    } else if ('LD' === _0x377b87) {
        _0x1b5f55 = 'LADIES';
    } else if ('SR' === _0x377b87) {
        _0x1b5f55 = 'LOWER BERTH/SR.CITIZEN';
    } else {
        _0x1b5f55 = _0x1b5f55;
    }
    return _0x1b5f55;
}
function addDelay(_0x3cab14) {
    const _0x3cc1c5 = Date.now();
    let _0x4e8dc8 = null;
    do {
        _0x4e8dc8 = Date.now();
    } while (_0x4e8dc8 - _0x3cc1c5 < _0x3cab14);
}
function showPnrAnimation(_0xafa5a9) {
    console.log(
        '🎯 [Voltas-TATKAL] ===== showPnrAnimation FUNCTION START ====='
    );

    contentLogger.info('🎉 Showing Voltas congratulation message', {
        triggeredBy: !!_0xafa5a9,
        timestamp: new Date().toISOString(),
    });

    // Check if congratulation element already exists
    if (document.getElementById('Voltas-congratulation')) {
        console.log(
            '🎯 [Voltas-TATKAL] Congratulation message already displayed, exiting'
        );
        return;
    }

    // Create the congratulatory element with Voltas Extension styling
    const congratulationDiv = document.createElement('div');
    congratulationDiv.id = 'Voltas-congratulation';
    congratulationDiv.style.cssText = `
    position: relative !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: auto !important;
    width: 100% !important;
    max-width: 100% !important;
    margin: 20px auto !important;
    padding: 20px !important;
    background: linear-gradient(135deg, #4CAF50, #45a049) !important;
    color: white !important;
    border-radius: 12px !important;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3) !important;
    font-family: 'Arial', sans-serif !important;
    font-size: 16px !important;
    text-align: center !important;
    z-index: 999999 !important;
    animation: slideInFromTop 0.8s ease-out !important;
    border: 3px solid #2E7D32 !important;
    backdrop-filter: blur(10px) !important;
    transform: none !important;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
  `;

    congratulationDiv.innerHTML = `
    <style>
      @keyframes slideInFromTop {
        0% { transform: translateY(-100px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
      }
      @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
      }
      #Voltas-congratulation-close {
        position: absolute !important;
        top: 10px !important;
        right: 15px !important;
        background: rgba(255,255,255,0.2) !important;
        border: none !important;
        color: white !important;
        font-size: 24px !important;
        font-weight: bold !important;
        cursor: pointer !important;
        border-radius: 50% !important;
        width: 35px !important;
        height: 35px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        transition: all 0.3s ease !important;
      }
      #Voltas-congratulation-close:hover {
        background: rgba(255,255,255,0.3) !important;
        transform: scale(1.1) !important;
      }
    </style>
    <button id="Voltas-congratulation-close" onclick="this.parentElement.remove()">&times;</button>
    <div style="font-size: 28px; font-weight: bold; margin-bottom: 15px; animation: pulse 2s infinite;">
      🎉 CONGRATULATIONS! 🎉
    </div>
    <div style="font-size: 18px; margin-bottom: 10px;">
      Your train ticket has been successfully booked!
    </div>
    <div style="font-size: 14px; opacity: 0.9;">
      Thank you for using Voltas IRCTC Tatkal Extension
    </div>
  `;

    // Find the best insertion point - prioritize div with id "text"
    let insertionTarget = null;
    let insertionMethod = '';

    // First, try to find div with id "text"
    const textDiv = document.getElementById('text');
    if (textDiv) {
        insertionTarget = textDiv;
        insertionMethod = 'text-div';
        console.log('🎯 [Voltas-TATKAL] Found target div with id "text"');
    } else {
        // Fallback to original insertion selectors
        const insertionSelectors = [
            '.container-fluid',
            '.container',
            'main',
            '#main',
            '.main-content',
            'body > div:first-child',
            'body',
        ];

        for (const selector of insertionSelectors) {
            const element = document.querySelector(selector);
            if (element && element.offsetParent !== null) {
                insertionTarget = element;
                insertionMethod = selector;
                console.log(
                    '🎯 [Voltas-TATKAL] Found fallback insertion target:',
                    selector
                );
                break;
            }
        }
    }

    if (insertionTarget) {
        insertionTarget.insertBefore(
            congratulationDiv,
            insertionTarget.firstChild
        );
        console.log(
            '🎯 [Voltas-TATKAL] ===== CONGRATULATION MESSAGE DISPLAYED SUCCESSFULLY ====='
        );
        console.log('🎯 [Voltas-TATKAL] Insertion method:', insertionMethod);
    } else {
        document.body.insertBefore(congratulationDiv, document.body.firstChild);
        insertionMethod = 'body-fallback';
        console.log(
            '🎯 [Voltas-TATKAL] Congratulation message inserted into body as fallback'
        );
    }

    contentLogger.info(
        '✅ Voltas congratulation message displayed successfully',
        {
            elementId: 'Voltas-congratulation',
            insertionTarget: insertionTarget?.tagName || 'body-fallback',
            insertionMethod: insertionMethod,
            timestamp: new Date().toISOString(),
        }
    );
}
// Removed automatic congratulation message display
// The showPnrAnimation function is still available for manual triggering if needed
chrome.runtime.onMessage.addListener(
    async (_0xb13df4, _0xea05c1, _0x1204bf) => {
        if ('irctc' !== _0xb13df4.id) {
            return void _0x1204bf('Invalid ID');
        }
        const _0x28dc6a = _0xb13df4.msg.type;
        if ('selectJourney' === _0x28dc6a) {
            console.log('selectJourney action received');
            let _0x1c9dae = document.querySelectorAll('.btn.btn-primary');
            if (_0x1c9dae.length > 0x1 && _0x1c9dae[0x1]) {
                simulateClick(_0x1c9dae[0x1]);
                console.log('Close last trxn popup');
            }
            const _0x4e901f = document.querySelector(
                '#divMain > div > app-train-list'
            );
            if (!_0x4e901f) {
                console.error(
                    'Train list container not found for selectJourney.'
                );
                return;
            }
            const _0x23b5b2 = [
                ..._0x4e901f.querySelectorAll('.tbis-div app-train-avl-enq'),
            ];
            const _0x14a7bd = user_data.journey_details['train-no'];
            if (!_0x14a7bd) {
                console.error(
                    'Train number missing in user_data for selectJourney.'
                );
                return;
            }
            const _0x2790d1 = _0x23b5b2.find(_0xf40b16 => {
                const _0x106825 = _0xf40b16.querySelector('div.train-heading');
                return (
                    _0x106825 &&
                    _0x106825.innerText
                        .trim()
                        .includes(_0x14a7bd.split('-')[0x0])
                );
            });
            if ('M' === user_data.travel_preferences.AvailabilityCheck) {
                return void showCustomAlert(
                    'Please manually select train and click Book'
                );
            }
            if (
                'A' === user_data.travel_preferences.AvailabilityCheck ||
                'I' === user_data.travel_preferences.AvailabilityCheck
            ) {
                if (!_0x2790d1) {
                    return void showCustomAlert(
                        'Precheck - Train (' +
                            _0x14a7bd +
                            ') not found. Proceed manually or correct data.'
                    );
                }
                const _0x4d76c7 = classTranslator(
                    user_data.journey_details['class']
                );
                if (
                    ![
                        ..._0x2790d1.querySelectorAll(
                            'table tr td div.pre-avl'
                        ),
                    ].find(
                        _0x290aae =>
                            _0x290aae.querySelector('div')?.['innerText'] ===
                            _0x4d76c7
                    )
                ) {
                    return void showCustomAlert(
                        'Precheck - Selected Class not available. Proceed manually or correct data.'
                    );
                }
            }
            const _0x5d0e3b = document.querySelector(
                'div.row.col-sm-12.h_head1 > span > strong'
            );
            if ('A' === user_data.travel_preferences.AvailabilityCheck) {
                if (
                    ['TQ', 'PT', 'GN'].includes(user_data.journey_details.quota)
                ) {
                    console.log('Verify tatkal/general time');
                    const _0x23193f = user_data.journey_details['class'];
                    let _0x78c5df = '00:00:00';
                    let _0x50504b = '00:00:00';
                    if (
                        ['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(
                            _0x23193f.toUpperCase()
                        )
                    ) {
                        _0x78c5df = user_data.other_preferences.acbooktime;
                    } else {
                        _0x78c5df = user_data.other_preferences.slbooktime;
                    }
                    if ('GN' === user_data.journey_details.quota) {
                        _0x78c5df = user_data.other_preferences.gnbooktime;
                    }
                    console.log('Required Booking Time:', _0x78c5df);
                    var _0x37c66e = 0x0;
                    let _0x5505bd = new MutationObserver(_0x9140b3 => {
                        _0x50504b = new Date().toString().split(' ')[0x4];
                        console.log('Current Time for booking:', _0x50504b);
                        if (_0x50504b >= _0x78c5df) {
                            _0x5505bd.disconnect();
                            selectJourney();
                        } else {
                            if (_0x37c66e === 0x0) {
                                try {
                                    const _0x532ffd =
                                        document.createElement('div');
                                    _0x532ffd.textContent =
                                        'Please wait... Booking will start at ' +
                                        _0x78c5df;
                                    Object.assign(_0x532ffd.style, {
                                        textAlign: 'center',
                                        color: 'white',
                                        height: 'auto',
                                        fontSize: '20px',
                                    });
                                    document
                                        .querySelector(
                                            '#divMain > div > app-train-list > div > div > div > div.clearfix'
                                        )
                                        ?.[
                                            'insertAdjacentElement'
                                        ]('afterend', _0x532ffd);
                                } catch (_0x126599) {
                                    console.log(
                                        'Wait message display failed',
                                        _0x126599
                                    );
                                }
                            }
                            try {
                                const _0x35defd = document.querySelector(
                                    '#divMain > div > app-train-list > div > div > div > div:nth-child(2)'
                                );
                                if (_0x35defd) {
                                    _0x35defd.style.background =
                                        _0x37c66e % 0x2 === 0x0
                                            ? 'green'
                                            : 'red';
                                }
                            } catch (_0x4d69c2) {
                                console.log(
                                    'Wait indicator style failed',
                                    _0x4d69c2
                                );
                            }
                            _0x37c66e++;
                        }
                    });
                    if (_0x5d0e3b) {
                        _0x5505bd.observe(_0x5d0e3b, {
                            childList: true,
                            subtree: true,
                            characterDataOldValue: true,
                        });
                    } else {
                        console.warn(
                            'Header element for time observer not found.'
                        );
                    }
                } else {
                    selectJourney();
                }
            } else {
                if ('I' === user_data.travel_preferences.AvailabilityCheck) {
                    selectJourney();
                }
            }
        } else {
            if ('fillPassengerDetails' === _0x28dc6a) {
                await fillPassengerDetails();
            } else {
                if ('reviewBooking' === _0x28dc6a) {
                    if (user_data.fare_limit?.['enableFareLimit']) {
                        let _0x3e19b4 = 0x0;
                        const _0x5a1134 = [
                            '#fare-summary .col-xs-12.line-def.top-header span.pull-right strong',
                            '.total-fare',
                            '#totalAmount',
                            '.fare-summary span.amount',
                            'span.fare-value',
                            '.fare-breakup-summary .fare-amount',
                            "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value",
                            'div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold',
                            'div.fare-breakup-summary div.fare-amount',
                            'div.fare-detail-item:nth-child(5) > div:nth-child(2)',
                            'div.col-sm-6.text-right.font-small-bold',
                        ];
                        for (const _0x5320b0 of _0x5a1134) {
                            const _0x4247d3 = document.querySelector(_0x5320b0);
                            if (
                                _0x4247d3?.['innerText']['match'](
                                    /(\d[\d,]*\.?\d*)/
                                )
                            ) {
                                _0x3e19b4 = parseFloat(
                                    _0x4247d3.innerText.replace(/[^0-9.]/g, '')
                                );
                                if (!isNaN(_0x3e19b4)) {
                                    console.log(
                                        'Found total fare ' +
                                            _0x3e19b4 +
                                            ' using "' +
                                            _0x5320b0 +
                                            '"'
                                    );
                                    break;
                                }
                            }
                        }
                        if (!isNaN(_0x3e19b4) && _0x3e19b4 > 0x0) {
                            const _0x584052 = parseFloat(
                                user_data.fare_limit.maxFareAmount
                            );
                            if (!isNaN(_0x584052) && _0x3e19b4 > _0x584052) {
                                return showCustomConfirm(
                                    'Total fare (' +
                                        _0x3e19b4 +
                                        ') exceeds limit (' +
                                        _0x584052 +
                                        '). Proceed?',
                                    () => proceedAfterFareCheck(),
                                    () => {
                                        showCustomAlert(
                                            'Booking cancelled due to high fare.'
                                        );
                                        window.location.href =
                                            'https://www.irctc.co.in/nget/train-search';
                                    }
                                );
                            }
                        } else {
                            console.warn(
                                'Could not determine total fare for limit check.'
                            );
                        }
                    }
                    await proceedAfterFareCheck();
                } else {
                    if ('bkgPaymentOptions' === _0x28dc6a) {
                        addDelay(0xc8);
                        console.log('bkgPaymentOptions');
                        let _0x5042d2 = 'Multiple Payment Service';
                        let _0x4b3116 =
                            'IRCTC iPay (Credit Card/Debit Card/UPI)';
                        let _0x34a8e4 = true;
                        const _0x5e10cb =
                            user_data.other_preferences.paymentmethod;
                        if (_0x5e10cb.includes('IRCUPI')) {
                            _0x34a8e4 = false;
                            _0x5042d2 =
                                'IRCTC iPay (Credit Card/Debit Card/UPI)';
                            _0x4b3116 =
                                'Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)';
                        } else {
                            if (_0x5e10cb.includes('PAYTMUPI')) {
                                _0x5042d2 = 'BHIM/ UPI/ USSD';
                                _0x4b3116 =
                                    'Pay using BHIM (Powered by PAYTM ) also accepts UPI';
                            } else {
                                if (_0x5e10cb.includes('PHONEPEUPI')) {
                                    _0x5042d2 = 'Multiple Payment Service';
                                    _0x4b3116 =
                                        'Credit & Debit cards / Wallet / UPI (Powered by PhonePe)';
                                } else {
                                    if (_0x5e10cb.includes('PAYUUPI')) {
                                        _0x5042d2 = 'Multiple Payment Service';
                                        _0x4b3116 =
                                            'Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)';
                                    } else {
                                        if (_0x5e10cb.includes('AMZPAYWAL')) {
                                            _0x5042d2 = 'Wallets / Cash Card';
                                            _0x4b3116 = 'Amazon Pay Balance';
                                        } else {
                                            if (
                                                _0x5e10cb.includes('irctc_dc')
                                            ) {
                                                _0x34a8e4 = false;
                                                _0x5042d2 =
                                                    'IRCTC iPay (Credit Card/Debit Card/UPI)';
                                                _0x4b3116 =
                                                    'Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)';
                                            } else {
                                                if (
                                                    _0x5e10cb.includes(
                                                        'MOBUPI'
                                                    ) &&
                                                    window.navigator.userAgent.includes(
                                                        'Android'
                                                    )
                                                ) {
                                                    _0x5042d2 =
                                                        'Multiple Payment Service';
                                                    _0x4b3116 =
                                                        'Credit & Debit cards / Wallet / UPI (Powered by PhonePe)';
                                                } else {
                                                    if (
                                                        _0x5e10cb.includes(
                                                            'IRCWA'
                                                        )
                                                    ) {
                                                        _0x5042d2 =
                                                            'IRCTC eWallet';
                                                        _0x4b3116 =
                                                            'IRCTC eWallet';
                                                    } else if (
                                                        _0x5e10cb.includes(
                                                            'HDFCDB'
                                                        )
                                                    ) {
                                                        _0x5042d2 =
                                                            'Payment Gateway / Credit Card / Debit Card';
                                                        _0x4b3116 =
                                                            'Visa/Master Card(Powered By HDFC BANK)';
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        let _0x293601 = _0x4b3116.replace(/&/g, '&amp;');
                        let _0x342845 = false;
                        var _0x171bd5 = setInterval(() => {
                            console.log(
                                '[PaymentInterval] Checking for bank types. Found:',
                                document.getElementsByClassName('bank-type')
                                    .length
                            );
                            if (
                                document.getElementsByClassName('bank-type')
                                    .length > 0x1
                            ) {
                                clearInterval(_0x171bd5);
                                console.log(
                                    '[PaymentInterval] Bank types condition met. Proceeding.'
                                );
                                var _0x66d542 = document
                                    .getElementById('pay-type')
                                    ?.['getElementsByTagName']('div');
                                if (!_0x66d542 || _0x66d542.length === 0x0) {
                                    console.error(
                                        "[PaymentLogic] Payment categories container '#pay-type' not found or is empty."
                                    );
                                    showCustomAlert(
                                        'Payment categories container not found. Please select manually.'
                                    );
                                    return;
                                }
                                console.log(
                                    '[PaymentLogic] Found ' +
                                        _0x66d542.length +
                                        ' potential category elements. Searching for category text: "' +
                                        _0x5042d2 +
                                        '"'
                                );
                                let _0x29a310 = false;
                                for (let _0x42b239 of _0x66d542) {
                                    if (
                                        _0x42b239 &&
                                        _0x42b239.innerText &&
                                        _0x42b239.innerText.includes(_0x5042d2)
                                    ) {
                                        console.log(
                                            '[PaymentLogic] Category "' +
                                                _0x5042d2 +
                                                '" found:',
                                            _0x42b239.innerText
                                        );
                                        _0x29a310 = true;
                                        if (_0x34a8e4) {
                                            console.log(
                                                '[PaymentLogic] Clicking category:',
                                                _0x42b239
                                            );
                                            simulateClick(_0x42b239);
                                        } else {
                                            console.log(
                                                '[PaymentLogic] Category click skipped due to clickCategory=false.'
                                            );
                                        }
                                        setTimeout(() => {
                                            console.log(
                                                '[PaymentLogic-Timeout] Looking for payment option text: "' +
                                                    _0x293601 +
                                                    '"'
                                            );
                                            var _0x5200c2 =
                                                document.getElementsByClassName(
                                                    'border-all no-pad'
                                                );
                                            if (
                                                !_0x5200c2 ||
                                                _0x5200c2.length === 0x0
                                            ) {
                                                console.warn(
                                                    "[PaymentLogic-Timeout] No elements found with class 'border-all no-pad'."
                                                );
                                                showCustomAlert(
                                                    'No payment option elements found. Please select manually.'
                                                );
                                                return;
                                            }
                                            console.log(
                                                '[PaymentLogic-Timeout] Found ' +
                                                    _0x5200c2.length +
                                                    ' potential payment option elements.'
                                            );
                                            let _0x2c19c8 = false;
                                            for (let _0x5473b7 of _0x5200c2) {
                                                const _0x5e8208 =
                                                    _0x5473b7?.[
                                                        'getElementsByTagName'
                                                    ]('span')[0x0];
                                                const _0x44ece3 =
                                                    _0x5473b7 &&
                                                    getComputedStyle(_0x5473b7)
                                                        .display !== 'none' &&
                                                    getComputedStyle(_0x5473b7)
                                                        .visibility !==
                                                        'hidden' &&
                                                    parseFloat(
                                                        getComputedStyle(
                                                            _0x5473b7
                                                        ).opacity
                                                    ) > 0x0 &&
                                                    !_0x5473b7.disabled;
                                                const _0x17371d =
                                                    _0x5e8208?.['innerHTML']?.[
                                                        'toUpperCase'
                                                    ]() || '';
                                                const _0x3b5b64 =
                                                    _0x293601.toUpperCase();
                                                console.log(
                                                    '[PaymentLogic-Timeout] Checking option: Visible&Interactable=' +
                                                        _0x44ece3 +
                                                        ', Text="' +
                                                        _0x17371d +
                                                        '", Target="' +
                                                        _0x3b5b64 +
                                                        '"',
                                                    _0x5473b7
                                                );
                                                if (
                                                    _0x44ece3 &&
                                                    _0x5e8208 &&
                                                    _0x17371d.includes(
                                                        _0x3b5b64
                                                    )
                                                ) {
                                                    console.log(
                                                        '[PaymentLogic-Timeout] Matching payment option found and is suitable:',
                                                        _0x5473b7
                                                    );
                                                    console.log(
                                                        '[PaymentLogic-Timeout] Clicking payment option:',
                                                        _0x5473b7
                                                    );
                                                    simulateClick(_0x5473b7);
                                                    _0x342845 = true;
                                                    _0x2c19c8 = true;
                                                    const _0x2b4895 =
                                                        document.getElementsByClassName(
                                                            'btn-primary'
                                                        )[0x0];
                                                    if (_0x2b4895) {
                                                        _0x2b4895.scrollIntoView(
                                                            {
                                                                behavior:
                                                                    'smooth',
                                                                block: 'center',
                                                                inline: 'nearest',
                                                            }
                                                        );
                                                        console.log(
                                                            "[PaymentLogic-Timeout] Scrolled to 'Pay' button:",
                                                            _0x2b4895
                                                        );
                                                        if (
                                                            user_data
                                                                .other_preferences
                                                                .paymentManual
                                                        ) {
                                                            showCustomAlert(
                                                                'Manually submit the payment page.'
                                                            );
                                                        } else {
                                                            console.log(
                                                                "[PaymentLogic-Timeout] Attempting to click 'Pay' button automatically in 500ms."
                                                            );
                                                            setTimeout(() => {
                                                                console.log(
                                                                    "[PaymentLogic-Timeout-Pay] Clicking 'Pay' button:",
                                                                    _0x2b4895
                                                                );
                                                                simulateClick(
                                                                    _0x2b4895
                                                                );
                                                            }, 0x12c);
                                                        }
                                                    } else {
                                                        console.warn(
                                                            "[PaymentLogic-Timeout] 'Pay' button (btn-primary) not found."
                                                        );
                                                        showCustomAlert(
                                                            "Could not find the 'Pay' button. Please click it manually."
                                                        );
                                                    }
                                                    break;
                                                }
                                            }
                                            if (!_0x2c19c8) {
                                                console.warn(
                                                    '[PaymentLogic-Timeout] Selected payment option text "' +
                                                        _0x293601 +
                                                        '" not found or not suitable among ' +
                                                        _0x5200c2.length +
                                                        ' candidates.'
                                                );
                                                let _0x40bcf6 = Array.from(
                                                    _0x5200c2
                                                ).map(
                                                    (_0x5e38c9, _0x5a4206) => {
                                                        const _0x39f1a8 =
                                                            _0x5e38c9?.[
                                                                'getElementsByTagName'
                                                            ]('span')[0x0]?.[
                                                                'innerHTML'
                                                            ] || 'N/A';
                                                        const _0x560764 =
                                                            _0x5e38c9 &&
                                                            getComputedStyle(
                                                                _0x5e38c9
                                                            ).display !==
                                                                'none' &&
                                                            getComputedStyle(
                                                                _0x5e38c9
                                                            ).visibility !==
                                                                'hidden' &&
                                                            parseFloat(
                                                                getComputedStyle(
                                                                    _0x5e38c9
                                                                ).opacity
                                                            ) > 0x0 &&
                                                            !_0x5e38c9.disabled;
                                                        return (
                                                            'Option ' +
                                                            _0x5a4206 +
                                                            ': Visible&Interactable=' +
                                                            _0x560764 +
                                                            ', Text="' +
                                                            _0x39f1a8 +
                                                            '"'
                                                        );
                                                    }
                                                );
                                                console.log(
                                                    '[PaymentLogic-Timeout] Available options details:',
                                                    _0x40bcf6
                                                );
                                                showCustomAlert(
                                                    'Selected payment option not available. Please select manually.'
                                                );
                                            }
                                        }, 0x12c);
                                        break;
                                    }
                                }
                                if (!_0x29a310 && _0x66d542.length > 0x0) {
                                    console.warn(
                                        '[PaymentLogic] Payment category text "' +
                                            _0x5042d2 +
                                            '" not found after checking all category elements.'
                                    );
                                    let _0x447946 = Array.from(_0x66d542).map(
                                        _0x52833a => _0x52833a.innerText
                                    );
                                    console.log(
                                        '[PaymentLogic] Available category texts:',
                                        _0x447946
                                    );
                                    showCustomAlert(
                                        'Payment category "' +
                                            _0x5042d2 +
                                            '" not found. Please select manually.'
                                    );
                                }
                            }
                        }, 0x1f4);
                    } else {
                        if ('showPnrAnimation' === _0x28dc6a) {
                            showPnrAnimation();
                        } else {
                            _0x1204bf(
                                'Something went wrong: Unknown message type'
                            );
                        }
                    }
                }
            }
        }
    }
);
async function proceedAfterFareCheck() {
    document.querySelector('#captcha')?.['scrollIntoView']({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest',
    });
    if (user_data.other_preferences.autoCaptcha) {
        setTimeout(async () => await getCaptchaTC(), 0x1f4);
    } else {
        const _0x3edcd4 = document.querySelector('#captcha');
        if (_0x3edcd4) {
            await typeTextHumanLike(_0x3edcd4, 'X');
            _0x3edcd4.focus();
        }
    }
}
let captchaRetry = 0x0;
async function getCaptcha() {
    if (captchaRetry >= 0x64) {
        return;
    }
    captchaRetry++;
    const _0x1c5382 = document.querySelector('.captcha-img');
    if (!_0x1c5382 || !_0x1c5382.src || _0x1c5382.src.length < 0x17) {
        setTimeout(getCaptcha, 0x3e8);
        return;
    }

    // Use local OCR instead of Google Vision API
    try {
        console.log(
            '[IRCTC DEBUG] ======= Starting CAPTCHA Processing ======='
        );
        console.log('[IRCTC DEBUG] CAPTCHA image element found:', !!_0x1c5382);
        console.log(
            '[IRCTC DEBUG] CAPTCHA image src length:',
            _0x1c5382.src?.length
        );
        console.log(
            '[IRCTC DEBUG] CAPTCHA image src preview:',
            _0x1c5382.src?.substring(0, 100)
        );
        console.log('[IRCTC DEBUG] OCR functions available:', {
            processCaptchaWithLocalOCRAuto:
                typeof window.processCaptchaWithLocalOCRAuto,
            VoltasOCR: typeof window.VoltasOCR,
        });

        console.log(
            '🔍 [IRCTC DEBUG] Processing CAPTCHA with local OCR (Google Vision API replacement)...'
        );
        const captchaText = await window.processCaptchaWithLocalOCRAuto(
            _0x1c5382.src
        );

        console.log('[IRCTC DEBUG] OCR processing completed. Result:', {
            success: !!captchaText,
            length: captchaText?.length || 0,
            text: captchaText,
        });

        let _0x590592 = '';
        for (const _0x52fb28 of String(captchaText)
            .replace(/\s/g, '')
            .replace(')', 'J')
            .replace(']', 'J')) {
            if (
                'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(
                    _0x52fb28
                )
            ) {
                _0x590592 += _0x52fb28;
            }
        }

        const _0x1f96da = document.querySelector('#captcha');
        if (_0x1f96da) {
            await typeTextHumanLike(_0x1f96da, _0x590592);
        }

        console.log('[IRCTC DEBUG] Final cleaned text:', _0x590592);
        console.log('[IRCTC DEBUG] Filling CAPTCHA input field...');

        if (!captchaText || captchaText.length < 4) {
            console.log(
                '[IRCTC DEBUG] Local OCR could not extract valid CAPTCHA, refreshing...',
                {
                    originalText: captchaText,
                    cleanedText: _0x590592,
                    originalLength: captchaText?.length || 0,
                    cleanedLength: _0x590592?.length || 0,
                }
            );
            simulateClick(
                document.querySelector('.glyphicon.glyphicon-repeat')?.[
                    'parentElement'
                ]
            );
            setTimeout(getCaptcha, 0x1f4);
        } else {
            console.log(
                '[IRCTC DEBUG] CAPTCHA text extracted successfully, proceeding...'
            );
        }

        const _0x23da62 = document.querySelector('app-login');
        const _0x247cd6 = document.querySelector(
            '#divMain > div > app-review-booking > p-toast'
        );
        const _0x5c13dc = (_0x3b916e, _0x178433) => {
            setTimeout(getCaptcha, 0x1f4);
            console.log('disconnect ' + _0x3b916e + 'Captcha');
            _0x178433.disconnect();
        };
        const _0x2789d0 = new MutationObserver((_0x419532, _0x191ce8) => {
            if (
                _0x23da62?.['innerText']
                    ['toLowerCase']()
                    ['includes']('valid captcha')
            ) {
                _0x5c13dc('login', _0x191ce8);
            }
            if (
                _0x247cd6?.['innerText']
                    ['toLowerCase']()
                    ['includes']('valid captcha')
            ) {
                _0x5c13dc('review', _0x191ce8);
            }
        });
        if (_0x23da62) {
            _0x2789d0.observe(_0x23da62, {
                childList: true,
                subtree: true,
            });
        }
        if (_0x247cd6) {
            _0x2789d0.observe(_0x247cd6, {
                childList: true,
                subtree: true,
            });
        }
    } catch (error) {
        console.error('[IRCTC DEBUG] Local OCR processing failed:', {
            error: error,
            message: error?.message,
            stack: error?.stack,
            retryCount: captchaRetry,
        });
        // Fallback: refresh captcha and retry
        simulateClick(
            document.querySelector('.glyphicon.glyphicon-repeat')?.[
                'parentElement'
            ]
        );
        setTimeout(getCaptcha, 0x1f4);
    }
}
async function getCaptchaTC() {
    if (captchaRetry >= 0x64) {
        return;
    }
    captchaRetry++;
    const _0x3a4ea2 = document.querySelector('.captcha-img');
    if (!_0x3a4ea2 || !_0x3a4ea2.src || _0x3a4ea2.src.length < 0x17) {
        setTimeout(getCaptchaTC, 0x3e8);
        return;
    }

    // Use local OCR instead of TrueCaptcha API
    try {
        console.log(
            '🔍 Processing CAPTCHA with local OCR (TrueCaptcha API replacement)...'
        );
        const captchaText = await window.processCaptchaWithLocalOCRAuto(
            _0x3a4ea2.src
        );

        let _0x6eeedf = '';
        for (const _0x247a1c of String(captchaText)
            .replace(/\s/g, '')
            .replace(')', 'J')
            .replace(']', 'J')) {
            if (
                'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(
                    _0x247a1c
                )
            ) {
                _0x6eeedf += _0x247a1c;
            }
        }

        const _0xd216dd = document.querySelector('#captcha');
        if (_0xd216dd) {
            await typeTextHumanLike(_0xd216dd, _0x6eeedf);
        }

        if (!captchaText || captchaText.length < 4) {
            console.log(
                'Local OCR could not extract valid CAPTCHA, refreshing...'
            );
            simulateClick(
                document.querySelector('.glyphicon.glyphicon-repeat')?.[
                    'parentElement'
                ]
            );
            setTimeout(getCaptchaTC, 0x1f4);
        }

        const _0x37b5ab = document.querySelector('app-login');
        const _0x2a7a51 = document.querySelector(
            '#divMain > div > app-review-booking > p-toast'
        );
        const _0x333dc2 = (_0x29e6d1, _0x744350) => {
            setTimeout(getCaptchaTC, 0x1f4);
            console.log('disconnect ' + _0x29e6d1 + 'Captcha');
            _0x744350.disconnect();
        };
        const _0x4a4a01 = new MutationObserver((_0x2f8250, _0x36416e) => {
            if (
                _0x37b5ab?.['innerText']
                    ['toLowerCase']()
                    ['includes']('valid captcha')
            ) {
                _0x333dc2('login', _0x36416e);
            }
            if (
                _0x2a7a51?.['innerText']
                    ['toLowerCase']()
                    ['includes']('valid captcha')
            ) {
                _0x333dc2('review', _0x36416e);
            }
        });
        if (_0x37b5ab) {
            _0x4a4a01.observe(_0x37b5ab, {
                childList: true,
                subtree: true,
            });
        }
        if (_0x2a7a51) {
            _0x4a4a01.observe(_0x2a7a51, {
                childList: true,
                subtree: true,
            });
        }

        if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
            const _0x50c0b3 = document.querySelector('#divMain > app-login');
            if (_0x50c0b3) {
                const _0x2feb7f = _0x50c0b3.querySelector(
                    "input[formcontrolname='userid']"
                );
                const _0x3be7f1 = _0x50c0b3.querySelector(
                    "input[formcontrolname='password']"
                );
                if (_0x2feb7f?.['value'] && _0x3be7f1?.['value']) {
                    setTimeout(() => {
                        simulateClick(
                            _0x50c0b3.querySelector(
                                "button[type='submit'][class='search_btn train_Search']"
                            )
                        );
                        simulateClick(
                            _0x50c0b3.querySelector(
                                "button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"
                            )
                        );
                    }, 0x1f4);
                } else {
                    showCustomAlert(
                        'Username/password not filled for auto-submit.'
                    );
                }
            }
            const _0x3e5dd2 = document.querySelector(
                '#divMain > div > app-review-booking'
            );
            if (_0x3e5dd2 && _0xd216dd?.['value']) {
                const _0x3dc9c0 = _0x3e5dd2.querySelector(
                    '.btnDefault.train_Search'
                );
                if (_0x3dc9c0) {
                    setTimeout(() => {
                        if (user_data.other_preferences.confirmberths) {
                            if (document.querySelector('.AVAILABLE')) {
                                simulateClick(_0x3dc9c0);
                            } else {
                                showCustomConfirm(
                                    'No seats available. Continue booking?',
                                    () => simulateClick(_0x3dc9c0),
                                    () => console.log('Booking stopped.')
                                );
                            }
                        } else {
                            simulateClick(_0x3dc9c0);
                        }
                    }, 0x1f4);
                }
            }
        }
    } catch (error) {
        console.error('Local OCR processing failed:', error);
        // Fallback: refresh captcha and retry
        simulateClick(
            document.querySelector('.glyphicon.glyphicon-repeat')?.[
                'parentElement'
            ]
        );
        setTimeout(getCaptchaTC, 0x1f4);
    }
}
async function loadLoginDetails() {
    const _0x4bf522 = document.querySelector('#divMain > app-login');
    const _0x19d2a4 = _0x4bf522.querySelector(
        "input[type='text'][formcontrolname='userid']"
    );
    const _0x50e942 = _0x4bf522.querySelector(
        "input[type='password'][formcontrolname='password']"
    );
    await typeTextHumanLike(
        _0x19d2a4,
        user_data.irctc_credentials.user_name ?? ''
    );
    await typeTextHumanLike(
        _0x50e942,
        user_data.irctc_credentials.password ?? ''
    );
    document.querySelector('#captcha').scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest',
    });
    if (user_data.other_preferences.autoCaptcha) {
        setTimeout(async () => {
            await getCaptchaTC();
        }, 0x1f4);
    } else {
        console.log('Manual captcha filling');
        const _0x32d972 = document.querySelector('#captcha');
        await typeTextHumanLike(_0x32d972, 'X');
        _0x32d972.focus();
    }
}
function loadJourneyDetails() {
    console.log('filling_journey_details');
    const _0x5e47cb = document.querySelector('app-jp-input form');
    const _0x478c8e = _0x5e47cb.querySelector('#origin > span > input');
    _0x478c8e.value = user_data.journey_details.from;
    _0x478c8e.dispatchEvent(new Event('keydown'));
    _0x478c8e.dispatchEvent(new Event('input'));
    const _0x3e5e94 = _0x5e47cb.querySelector('#destination > span > input');
    _0x3e5e94.value = user_data.journey_details.destination;
    _0x3e5e94.dispatchEvent(new Event('keydown'));
    _0x3e5e94.dispatchEvent(new Event('input'));
    const _0x52ee87 = _0x5e47cb.querySelector('#jDate > span > input');
    _0x52ee87.value = user_data.journey_details.date
        ? '' + user_data.journey_details.date.split('-').reverse().join('/')
        : '';
    _0x52ee87.dispatchEvent(new Event('keydown'));
    _0x52ee87.dispatchEvent(new Event('input'));
    const _0x3a0083 = _0x5e47cb.querySelector('#journeyClass');
    _0x3a0083.querySelector("div > div[role='button']").click();
    addDelay(0x12c);
    [..._0x3a0083.querySelectorAll('ul li')]
        .filter(
            _0x5612bd =>
                _0x5612bd.innerText ===
                classTranslator(user_data.journey_details['class'])
        )[0x0]
        ?.['click']();
    addDelay(0x12c);
    const _0x105012 = _0x5e47cb.querySelector('#journeyQuota');
    _0x105012.querySelector("div > div[role='button']").click();
    [..._0x105012.querySelectorAll('ul li')]
        .filter(
            _0x5887e2 =>
                _0x5887e2.innerText ===
                quotaTranslator(user_data.journey_details.quota)
        )[0x0]
        ?.['click']();
    addDelay(0x12c);
    const _0x5e8c6c = _0x5e47cb.querySelector(
        "button.search_btn.train_Search[type='submit']"
    );
    addDelay(0x12c);
    console.log('filled_journey_details');
    _0x5e8c6c.click();
}
function selectJourneyOld() {
    if (!user_data.journey_details['train-no']) {
        return;
    }
    const _0x246cb0 = [
        ...document
            .querySelector('#divMain > div > app-train-list')
            .querySelectorAll('.tbis-div app-train-avl-enq'),
    ];
    console.log(user_data.journey_details['train-no']);
    const _0x2057c8 = _0x246cb0.filter(_0x1b9a7f =>
        _0x1b9a7f
            .querySelector('div.train-heading')
            .innerText.trim()
            .includes(user_data.journey_details['train-no'])
    )[0x0];
    if (!_0x2057c8) {
        console.log('Train not found.');
        showCustomAlert('Train not found');
        statusUpdate('journey_selection_stopped.no_train');
        return;
    }
    const _0x24400d = classTranslator(user_data.journey_details['class']);
    const _0x6075a0 = new Date(user_data.journey_details.date)
        .toString()
        .split(' ');
    const _0x4bcefc = {
        attributes: false,
        childList: true,
        subtree: true,
    };
    [..._0x2057c8.querySelectorAll('table tr td div.pre-avl')]
        .filter(
            _0x23291a => _0x23291a.querySelector('div').innerText === _0x24400d
        )[0x0]
        ?.['click']();
    const _0x23a263 = document.querySelector(
        '#divMain > div > app-train-list > p-toast'
    );
    new MutationObserver((_0x320979, _0x164e30) => {
        const _0x16a00c = [
            ..._0x2057c8.querySelectorAll(
                "div p-tabmenu ul[role='tablist'] li[role='tab']"
            ),
        ].filter(
            _0xdb4d37 => _0xdb4d37.querySelector('div').innerText === _0x24400d
        )[0x0];
        const _0x4a5586 = [
            ..._0x2057c8.querySelectorAll('div div table td div.pre-avl'),
        ].filter(
            _0x1e9733 =>
                _0x1e9733.querySelector('div').innerText ===
                _0x6075a0[0x0] + ', ' + _0x6075a0[0x2] + ' ' + _0x6075a0[0x1]
        )[0x0];
        const _0x445b40 = _0x2057c8.querySelector(
            'button.btnDefault.train_Search.ng-star-inserted'
        );
        if (_0x16a00c) {
            if (!_0x16a00c.classList.contains('ui-state-active')) {
                _0x16a00c.click();
                return;
            }
        }
        if (_0x4a5586) {
            if (_0x4a5586.classList.contains('selected-class')) {
                _0x445b40.click();
                _0x164e30.disconnect();
            } else {
                _0x4a5586.click();
            }
        }
    }).observe(_0x2057c8, _0x4bcefc);
    const _0x4fdee3 = new MutationObserver((_0x33940b, _0x4a7ce5) => {
        console.log('Popup error observed');
        console.log(
            'Class count:',
            [..._0x2057c8.querySelectorAll('table tr td div.pre-avl')].length
        );
        console.log('Class elements:', [
            ..._0x2057c8.querySelectorAll('table tr td div.pre-avl'),
        ]);
        if (_0x23a263.innerText.includes('Unable to perform')) {
            [..._0x2057c8.querySelectorAll('table tr td div.pre-avl')]
                .filter(
                    _0x4c47db =>
                        _0x4c47db.querySelector('div').innerText === _0x24400d
                )[0x0]
                ?.['click']();
            _0x4a7ce5.disconnect();
        }
    });
    _0x4fdee3.observe(_0x23a263, _0x4bcefc);
}
function retrySelectJourney() {
    console.log('Retrying selectJourney...');
    setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
    const _0x555bed = setInterval(() => {
        const _0x5430e9 = document.querySelector(
            '#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a'
        );
        const _0x2ece6d = document.querySelector(
            'body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a'
        );
        const _0x266316 = _0x5430e9 || _0x2ece6d;
        const _0x119e13 = document.querySelector('#loaderP');
        const _0xc4cef8 = _0x119e13 && _0x119e13.style.display !== 'none';
        if (_0x266316 && !_0xc4cef8) {
            console.log('Toast link found. Clicking it now...');
            _0x266316.click();
            console.log('Toast link clicked');
            retrySelectJourney();
            clearInterval(_0x555bed);
        }
    }, 0x3e8);
    if (!user_data?.['journey_details']?.['train-no']) {
        console.error('Train number is not available in user_data.');
        return;
    }
    const _0x1ea2cd = document.querySelector('#divMain > div > app-train-list');
    if (!_0x1ea2cd) {
        console.error('Train list parent not found.');
        return;
    }
    const _0x3d0c59 = Array.from(
        _0x1ea2cd.querySelectorAll('.tbis-div app-train-avl-enq')
    );
    const _0xeaf214 = user_data.journey_details['train-no'];
    const _0x47ef9d = classTranslator(user_data.journey_details['class']);
    const _0xe47091 = new Date(user_data.journey_details.date);
    const _0x1f50eb =
        _0xe47091.toDateString().split(' ')[0x0] +
        ', ' +
        _0xe47091.toDateString().split(' ')[0x2] +
        ' ' +
        _0xe47091.toDateString().split(' ')[0x1];
    console.log('Train Number:', _0xeaf214);
    console.log('Class:', _0x47ef9d);
    console.log('Date:', _0x1f50eb);
    const _0x4e5878 = _0x3d0c59.find(_0x1b119c =>
        _0x1b119c
            .querySelector('div.train-heading')
            .innerText.trim()
            .includes(_0xeaf214.split('-')[0x0])
    );
    if (!_0x4e5878) {
        console.error('Train not found.');
        statusUpdate('journey_selection_stopped.no_train');
        return;
    }
    const _0x20b6c7 = _0x6ea601 => {
        if (!_0x6ea601) {
            return false;
        }
        const _0x3cafb9 = window.getComputedStyle(_0x6ea601);
        return (
            _0x3cafb9.display !== 'none' &&
            _0x3cafb9.visibility !== 'hidden' &&
            _0x3cafb9.opacity !== '0'
        );
    };
    const _0x3334aa = Array.from(
        _0x4e5878.querySelectorAll('table tr td div.pre-avl')
    );
    const _0x366712 = _0x3334aa.find(
        _0x5f4ec8 =>
            _0x5f4ec8.querySelector('div').innerText.trim() === _0x47ef9d
    );
    const _0x2ece40 = Array.from(_0x4e5878.querySelectorAll('span')).find(
        _0x5a5919 => _0x5a5919.innerText.trim() === _0x47ef9d
    );
    const _0x305357 = _0x366712 || _0x2ece40;
    if (!_0x305357) {
        console.error('Class to click not found.');
        return;
    }
    const _0x49825b = document.querySelector('#loaderP');
    if (_0x20b6c7(_0x49825b)) {
        console.error('Loader is visible. Cannot click the class yet.');
        return;
    }
    _0x305357.click();
    let _0x1912b7;
    new MutationObserver((_0x102432, _0x363b7c) => {
        console.log('Mutation observed at', new Date().toLocaleTimeString());
        clearTimeout(_0x1912b7);
        _0x1912b7 = setTimeout(() => {
            const _0xefd37a = Array.from(
                _0x4e5878.querySelectorAll('div div table td div.pre-avl')
            );
            const _0x45678e = _0xefd37a.find(
                _0x2117ab =>
                    _0x2117ab.querySelector('div').innerText.trim() ===
                    _0x1f50eb
            );
            console.log('FOUND date cell to click:', _0x45678e);
            if (_0x45678e) {
                _0x45678e.click();
                console.log('Clicked on date cell');
                setTimeout(() => {
                    const _0x3efd2a = () => {
                        const _0x4c203f = _0x4e5878.querySelector(
                            'button.btnDefault.train_Search.ng-star-inserted'
                        );
                        if (_0x20b6c7(document.querySelector('#loaderP'))) {
                            console.warn('Loader still visible, retrying...');
                            return setTimeout(_0x3efd2a, 0x64);
                        }
                        if (
                            !_0x4c203f ||
                            _0x4c203f.classList.contains('disable-book') ||
                            _0x4c203f.disabled
                        ) {
                            console.warn(
                                'Book button disabled or not found, retrying...'
                            );
                            retrySelectJourney();
                        } else {
                            setTimeout(() => {
                                _0x4c203f.click();
                                console.log('Clicked on Book button');
                                clearTimeout(_0x1912b7);
                                _0x363b7c.disconnect();
                            }, 0x12c);
                        }
                    };
                    _0x3efd2a();
                }, 0x3e8);
            } else {
                console.warn('Date cell to click not found.');
            }
        }, 0x12c);
    }).observe(_0x4e5878, {
        attributes: false,
        childList: true,
        subtree: true,
    });
}
let keyCounter = 0x0;
async function fillPassengerDetails() {
    console.log('passenger_filling_started');
    keyCounter = Date.now();
    if (user_data.journey_details.boarding?.['length'] > 0x0) {
        const _0x257f66 = Array.from(
            document.getElementsByTagName('strong')
        ).find(_0x254582 =>
            _0x254582.innerText.includes(
                user_data.journey_details.from.split('-')[0x0].trim() + ' | '
            )
        );
        if (_0x257f66) {
            simulateClick(_0x257f66);
            addDelay(0x12c);
        }
        const _0x3f5161 = Array.from(
            document.getElementsByTagName('strong')
        ).find(_0x4b4d12 =>
            _0x4b4d12.innerText.includes(
                user_data.journey_details.boarding.split('-')[0x0].trim()
            )
        );
        if (_0x3f5161) {
            simulateClick(_0x3f5161);
        }
    }
    const _0x932f12 = document.querySelector('app-passenger-input');
    if (!_0x932f12) {
        console.error('Passenger app element not found.');
        return;
    }
    for (
        let _0x4e42c3 = 0x1;
        _0x4e42c3 < user_data.passenger_details.length;
        _0x4e42c3++
    ) {
        addDelay(0xc8);
        simulateClick(document.getElementsByClassName('prenext')[0x0]);
    }
    try {
        for (
            let _0x141995 = 0x0;
            _0x141995 < user_data.infant_details.length;
            _0x141995++
        ) {
            addDelay(0xc8);
            simulateClick(document.getElementsByClassName('prenext')[0x2]);
        }
    } catch (_0x15406f) {
        console.error('Add infant error', _0x15406f);
    }
    const _0x49b559 = [..._0x932f12.querySelectorAll('app-passenger')];
    for (
        let _0x24e4ed = 0x0;
        _0x24e4ed < user_data.passenger_details.length;
        _0x24e4ed++
    ) {
        const _0x16b7c3 = user_data.passenger_details[_0x24e4ed];
        if (!_0x49b559[_0x24e4ed]) {
            continue;
        }
        const _0x264f39 = _0x49b559[_0x24e4ed];
        const _0x62a764 = _0x264f39.querySelector('p-autocomplete input');
        if (_0x62a764) {
            await typeTextHumanLike(_0x62a764, _0x16b7c3.name);
        }
        const _0x414f50 = _0x264f39.querySelector(
            "input[formcontrolname='passengerAge']"
        );
        if (_0x414f50) {
            await typeTextHumanLike(_0x414f50, _0x16b7c3.age);
        }
        const _0x5d3e2a = _0x264f39.querySelector(
            "select[formcontrolname='passengerGender']"
        );
        if (_0x5d3e2a) {
            _0x5d3e2a.value = _0x16b7c3.gender;
            _0x5d3e2a.dispatchEvent(new Event('change'));
        }
        const _0x4dd0d0 = _0x264f39.querySelector(
            "select[formcontrolname='passengerBerthChoice']"
        );
        if (_0x4dd0d0) {
            _0x4dd0d0.value = _0x16b7c3.berth;
            _0x4dd0d0.dispatchEvent(new Event('change'));
        }
        const _0x54b09b = _0x264f39.querySelector(
            "select[formcontrolname='passengerFoodChoice']"
        );
        if (_0x54b09b) {
            _0x54b09b.value = _0x16b7c3.food;
            _0x54b09b.dispatchEvent(new Event('change'));
        }
        try {
            const _0x419e96 = _0x264f39.querySelector(
                "input[formcontrolname='childBerthFlag']"
            );
            if (
                _0x419e96 &&
                _0x16b7c3.passengerchildberth !== _0x419e96.checked
            ) {
                simulateClick(_0x419e96);
                addDelay(0xc8);
                if (_0x16b7c3.passengerchildberth) {
                    const _0xa2084e = _0x264f39.querySelector(
                        'p-dialog app-passenger-confirm-dialog button.btn.btn-primary'
                    );
                    if (_0xa2084e && _0xa2084e.offsetParent !== null) {
                        simulateClick(_0xa2084e);
                        addDelay(0xc8);
                    } else {
                        const _0x1a422f = _0x264f39.querySelector(
                            'p-dialog p-footer button'
                        );
                        if (_0x1a422f && _0x1a422f.offsetParent !== null) {
                            simulateClick(_0x1a422f);
                            addDelay(0xc8);
                        }
                    }
                }
            }
        } catch (_0x20b835) {
            console.error('Child berth error', _0x20b835);
        }
    }
    const _0xe2acbb = [..._0x932f12.querySelectorAll('app-infant')];
    user_data.infant_details.forEach((_0x34f61e, _0x1cc1fd) => {
        if (!_0xe2acbb[_0x1cc1fd]) {
            return;
        }
        const _0x2e9588 = _0xe2acbb[_0x1cc1fd];
        const _0x13341a = _0x2e9588.querySelector('input#infant-name');
        if (_0x13341a) {
            _0x13341a.value = _0x34f61e.name;
            _0x13341a.dispatchEvent(new Event('input'));
        }
        const _0x4c4d45 = _0x2e9588.querySelector(
            "select[formcontrolname='age']"
        );
        if (_0x4c4d45) {
            _0x4c4d45.value = _0x34f61e.age;
            _0x4c4d45.dispatchEvent(new Event('change'));
        }
        const _0x5e23c5 = _0x2e9588.querySelector(
            "select[formcontrolname='gender']"
        );
        if (_0x5e23c5) {
            _0x5e23c5.value = _0x34f61e.gender;
            _0x5e23c5.dispatchEvent(new Event('change'));
        }
    });
    if (user_data.other_preferences.mobileNumber) {
        const _0x1c05d2 = _0x932f12.querySelector('input#mobileNumber');
        if (_0x1c05d2) {
            await typeTextHumanLike(
                _0x1c05d2,
                user_data.other_preferences.mobileNumber
            );
        }
    }
    const _0x4c93a4 = user_data.other_preferences.paymentmethod.includes('UPI')
        ? '2'
        : '1';
    const _0xae1242 = [
        ..._0x932f12.querySelectorAll(
            "p-radiobutton[formcontrolname='paymentType'] input"
        ),
    ].find(_0x275c82 => _0x275c82.value === _0x4c93a4);
    if (_0xae1242) {
        simulateClick(_0xae1242);
    }
    const _0xa0012d = _0x932f12.querySelector('input#autoUpgradation');
    if (
        _0xa0012d &&
        user_data.other_preferences.autoUpgradation !== _0xa0012d.checked
    ) {
        simulateClick(_0xa0012d);
    }
    const _0xc0dd2b = _0x932f12.querySelector('input#confirmberths');
    if (
        _0xc0dd2b &&
        user_data.other_preferences.confirmberths !== _0xc0dd2b.checked
    ) {
        simulateClick(_0xc0dd2b);
    }
    const _0x1e42c3 =
        user_data.travel_preferences.travelInsuranceOpted === 'yes'
            ? 'true'
            : 'false';
    const _0x33b019 = [
        ..._0x932f12.querySelectorAll(
            "p-radiobutton[formcontrolname='travelInsuranceOpted'] input"
        ),
    ].find(_0x19272b => _0x19272b.value === _0x1e42c3);
    if (_0x33b019) {
        simulateClick(_0x33b019);
    }
    try {
        const _0x33936d = _0x932f12.querySelector(
            "input[formcontrolname='coachId']"
        );
        if (_0x33936d && user_data.travel_preferences.prefcoach?.['trim']()) {
            _0x33936d.value = user_data.travel_preferences.prefcoach;
            _0x33936d.dispatchEvent(new Event('input'));
        }
        const _0x2cf53f = _0x932f12.querySelector(
            "p-dropdown[formcontrolname='reservationChoice']"
        );
        if (
            _0x2cf53f &&
            user_data.travel_preferences.reservationchoice &&
            !user_data.travel_preferences.reservationchoice.includes(
                'Reservation Choice'
            )
        ) {
            simulateClick(_0x2cf53f.querySelector("div[role='button']"));
            addDelay(0x12c);
            const _0x2ac98a = [..._0x2cf53f.querySelectorAll('ul li')].find(
                _0x6cf506 =>
                    _0x6cf506.innerText ===
                    user_data.travel_preferences.reservationchoice
            );
            if (_0x2ac98a) {
                simulateClick(_0x2ac98a);
            }
        }
    } catch (_0x5d671d) {
        console.error('Coach/Reservation choice error', _0x5d671d);
    }
    submitPassengerDetailsForm(_0x932f12);
}
function submitPassengerDetailsForm(_0x153cf3) {
    window.scrollBy(0x0, 0x258, 'smooth');
    if (user_data.other_preferences.psgManual) {
        return showCustomAlert('Manually submit passenger page.');
    }
    let _0x12d516;
    const _0x2446ca = () => {
        if (keyCounter > 0x0 && Date.now() - keyCounter > 0x7d0) {
            clearInterval(_0x12d516);
            let _0xf0b4de = null;
            const _0x57776e = [
                "button.train_Search.btnDefault[type='submit']",
                "button[type='submit'].btn-primary.pull-right",
                'button.btn.btn-primary.manual-booking-btn',
                "button.psgn-btn[type='submit']",
                'button#validate',
                "button[type='submit']",
                '.btn-primary',
                '.btn-success',
            ];
            if (_0x153cf3) {
                for (const _0x9f910 of _0x57776e) {
                    const _0x41c80a = _0x153cf3.querySelector(_0x9f910);
                    if (
                        _0x41c80a &&
                        _0x41c80a &&
                        getComputedStyle(_0x41c80a).display !== 'none' &&
                        getComputedStyle(_0x41c80a).visibility !== 'hidden' &&
                        parseFloat(getComputedStyle(_0x41c80a).opacity) > 0x0 &&
                        !_0x41c80a.disabled
                    ) {
                        _0xf0b4de = _0x41c80a;
                        console.log(
                            'Passenger page: Found button with selector (scoped): "' +
                                _0x9f910 +
                                '"',
                            _0x41c80a
                        );
                        break;
                    }
                }
            }
            if (!_0xf0b4de) {
                const _0x707dd5 = [
                    '#psgn-form button.train_Search.btnDefault',
                    'button.btnDefault.train_Search',
                ];
                for (const _0x49247e of _0x707dd5) {
                    const _0x4f90df = document.querySelector(_0x49247e);
                    if (
                        _0x4f90df &&
                        _0x4f90df &&
                        getComputedStyle(_0x4f90df).display !== 'none' &&
                        getComputedStyle(_0x4f90df).visibility !== 'hidden' &&
                        parseFloat(getComputedStyle(_0x4f90df).opacity) > 0x0 &&
                        !_0x4f90df.disabled
                    ) {
                        _0xf0b4de = _0x4f90df;
                        console.log(
                            'Passenger page: Found button with selector (global): "' +
                                _0x49247e +
                                '"',
                            _0x4f90df
                        );
                        break;
                    }
                }
            }
            if (!_0xf0b4de && _0x153cf3) {
                const _0x43dc7e = _0x153cf3.querySelectorAll('button, a.btn');
                for (let _0x5daec5 of _0x43dc7e) {
                    const _0x27c29a =
                        _0x5daec5.innerText?.['trim']()['toLowerCase']();
                    if (
                        _0x27c29a &&
                        (_0x27c29a.includes('continue') ||
                            _0x27c29a.includes('proceed') ||
                            _0x27c29a.includes('submit') ||
                            _0x27c29a.includes('next') ||
                            _0x27c29a.includes('payment'))
                    ) {
                        if (
                            _0x5daec5 &&
                            getComputedStyle(_0x5daec5).display !== 'none' &&
                            getComputedStyle(_0x5daec5).visibility !==
                                'hidden' &&
                            parseFloat(getComputedStyle(_0x5daec5).opacity) >
                                0x0 &&
                            !_0x5daec5.disabled &&
                            !_0x27c29a.includes('cancel') &&
                            !_0x27c29a.includes('back')
                        ) {
                            _0xf0b4de = _0x5daec5;
                            console.log(
                                'Passenger page: Found button by text content:',
                                _0x27c29a,
                                _0x5daec5
                            );
                            break;
                        }
                    }
                }
            }
            if (!_0xf0b4de) {
                const _0x2be796 = document.querySelectorAll(
                    "button[type='submit']"
                );
                for (let _0x59d9cf of _0x2be796) {
                    if (
                        _0x59d9cf &&
                        getComputedStyle(_0x59d9cf).display !== 'none' &&
                        getComputedStyle(_0x59d9cf).visibility !== 'hidden' &&
                        parseFloat(getComputedStyle(_0x59d9cf).opacity) > 0x0 &&
                        !_0x59d9cf.disabled
                    ) {
                        _0xf0b4de = _0x59d9cf;
                        console.log(
                            'Passenger page: Fallback found a visible submit button:',
                            _0x59d9cf
                        );
                        break;
                    }
                }
            }
            if (_0xf0b4de) {
                console.log(
                    'Attempting to click passenger page continue button:',
                    _0xf0b4de
                );
                simulateClick(_0xf0b4de);
            } else {
                console.error(
                    'Passenger page continue/submit button NOT FOUND with any known strategy.'
                );
                showCustomAlert(
                    "Could not find the 'Continue' button on the passenger page. Please click it manually if available."
                );
            }
        }
    };
    _0x12d516 = setInterval(_0x2446ca, 0x1f4);
}
async function continueScript() {
    contentLogger.info('🚀 Starting continueScript execution', {
        url: window.location.href,
        timestamp: new Date().toISOString(),
    });

    const _0xb5a26 = document.querySelector(
        'body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted'
    );

    contentLogger.debug('🔍 Login button element found', {
        found: !!_0xb5a26,
        text: _0xb5a26?.innerText?.trim() || 'N/A',
    });

    if (window.location.href.includes('train-search')) {
        if (_0xb5a26 && _0xb5a26.innerText.trim().toUpperCase() === 'LOGOUT') {
            contentLogger.info(
                '✅ User is logged in, proceeding to load journey details',
                {
                    buttonText: _0xb5a26.innerText.trim(),
                }
            );
            console.log(
                'User is logged in. Proceeding to load journey details.'
            );
            loadJourneyDetails();
        } else {
            if (
                _0xb5a26 &&
                _0xb5a26.innerText.trim().toUpperCase() === 'LOGIN'
            ) {
                contentLogger.info(
                    '🔐 LOGIN button found, starting 15-second countdown',
                    {
                        buttonText: _0xb5a26.innerText.trim(),
                    }
                );
                console.log(
                    'IRCTC page loaded. LOGIN button found. Starting 15-second countdown...'
                );

                // Start the booking timer widget
                if (window.BookingTimer) {
                    window.BookingTimer.startBookingTimer();
                    window.BookingTimer.updateBookingTimerStatus(
                        'Login starting in 15 seconds...'
                    );
                }

                let _0x59afd2 = 0xf;
                const _0x16b697 = setInterval(async () => {
                    _0x59afd2--;

                    // Update our Voltas booking timer status instead of showing "Ocean Login"
                    if (window.BookingTimer) {
                        window.BookingTimer.updateBookingTimerStatus(
                            `Login starting in ${_0x59afd2} seconds...`
                        );
                    }

                    if (_0x59afd2 <= 0x0) {
                        clearInterval(_0x16b697);

                        // Update timer status and proceed
                        if (window.BookingTimer) {
                            window.BookingTimer.updateBookingTimerStatus(
                                'Initiating login...'
                            );
                        }

                        console.log(
                            'Countdown finished. Clicking LOGIN button.'
                        );
                        simulateClick(_0xb5a26);
                        await loadLoginDetails();
                    }
                }, 0x3e8);
            } else {
                console.log(
                    "LOGIN/LOGOUT link not found or text doesn't match. Waiting for page changes or manual interaction."
                );
            }
        }
    } else {
        console.log(
            'Not on train-search page. continueScript takes no action.'
        );
    }
}
async function a() {}
window.onload = function () {
    contentLogger.info('🌐 Window onload triggered', {
        url: window.location.href,
        timestamp: new Date().toISOString(),
        readyState: document.readyState,
    });
    console.log('Content script loaded and window.onload triggered.');
    setInterval(() => statusUpdate('Keep listener alive.'), 0x3a98);
    const _0x53a58d = document.querySelector(
        'body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1'
    );
    if (_0x53a58d) {
        new MutationObserver((_0xee5163, _0x437416) => {
            if (
                _0xee5163.some(
                    _0x1bd2f6 =>
                        _0x1bd2f6.type === 'childList' &&
                        [..._0x1bd2f6.addedNodes].some(
                            _0x69a106 =>
                                _0x69a106?.['innerText']
                                    ?.['trim']()
                                    ['toUpperCase']() === 'LOGOUT'
                        )
                )
            ) {
                console.log('LOGOUT detected in header via MutationObserver.');
                _0x437416.disconnect();
                loadJourneyDetails();
            }
        }).observe(_0x53a58d, {
            childList: true,
            subtree: false,
        });
    } else {
        console.warn(
            'Header div for MutationObserver not found on window.onload.'
        );
    }
    chrome.storage.local.get(null, _0x62fa0e => {
        user_data = _0x62fa0e;
        contentLogger.info('📦 User data loaded from storage', {
            hasIrctcCredentials: !!_0x62fa0e?.irctc_credentials,
            hasJourneyDetails: !!_0x62fa0e?.journey_details,
            hasPassengerDetails: !!_0x62fa0e?.passenger_details,
            passengerCount: _0x62fa0e?.passenger_details?.length || 0,
            trainNumber: _0x62fa0e?.journey_details?.['train-no'] || 'not-set',
            from: _0x62fa0e?.journey_details?.from || 'not-set',
            destination: _0x62fa0e?.journey_details?.destination || 'not-set',
        });
        console.log('User data loaded from storage:', user_data);
        continueScript();
    });
};
