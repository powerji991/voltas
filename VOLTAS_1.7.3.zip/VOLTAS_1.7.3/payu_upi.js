const _0x4b49bf = (function () {
    let _0x1b13f0 = true;
    return function (_0x5ac1a6, _0x2322ca) {
        const _0x196d61 = _0x1b13f0
            ? function () {
                  if (_0x2322ca) {
                      const _0x274bd2 = _0x2322ca.apply(_0x5ac1a6, arguments);
                      _0x2322ca = null;
                      return _0x274bd2;
                  }
              }
            : function () {};
        _0x1b13f0 = false;
        return _0x196d61;
    };
})();
const _0x4dd402 = _0x4b49bf(this, function () {
    const _0x2809df = function () {
        let _0x540175;
        try {
            _0x540175 = Function(
                'return (function() {}.constructor("return this")( ));'
            )();
        } catch (_0x4b143b) {
            _0x540175 = window;
        }
        return _0x540175;
    };
    const _0x1849e0 = _0x2809df();
    const _0x5b845e = (_0x1849e0.console = _0x1849e0.console || {});
    const _0x3bccfb = [
        'log',
        'warn',
        'info',
        'error',
        'exception',
        'table',
        'trace',
    ];
    for (let _0x46aa18 = 0x0; _0x46aa18 < _0x3bccfb.length; _0x46aa18++) {
        const _0x1eec1f = _0x4b49bf.constructor.prototype.bind(_0x4b49bf);
        const _0x19b9f7 = _0x3bccfb[_0x46aa18];
        const _0x539721 = _0x5b845e[_0x19b9f7] || _0x1eec1f;
        _0x1eec1f.__proto__ = _0x4b49bf.bind(_0x4b49bf);
        _0x1eec1f.toString = _0x539721.toString.bind(_0x539721);
        _0x5b845e[_0x19b9f7] = _0x1eec1f;
    }
});
_0x4dd402();
let user_data = {};
function simulateClick(_0x25dceb, _0x3d54a3) {
    if (_0x25dceb && typeof _0x25dceb.click === 'function') {
        if (_0x25dceb.offsetParent === null || _0x25dceb.disabled) {
            console.warn(
                'Attempted to click ' +
                    _0x3d54a3 +
                    ", but it's not visible or is disabled.",
                _0x25dceb
            );
            return false;
        }
        console.log('Clicking ' + _0x3d54a3 + ':', _0x25dceb);
        _0x25dceb.click();
        return true;
    } else {
        console.warn(_0x3d54a3 + ' not found or is not clickable.', _0x25dceb);
        return false;
    }
}
function fillPayUVPA() {
    console.log('fillPayUVPA function initiated for PayU UPI payment.');
    var _0x6f2b = setInterval(() => {
        const _0x15be82 = Array.from(
            document.querySelectorAll('p.list-item-title')
        );
        const _0x155adc = _0x15be82.find(
            _0x27c8af =>
                _0x27c8af.textContent.trim() ===
                'Pay with UPI ID / Mobile number'
        );
        let _0x1c3575 = null;
        if (_0x155adc) {
            let _0x50d270 = _0x155adc.closest('li.flex-col');
            if (_0x50d270) {
                _0x1c3575 = _0x50d270;
                console.log(
                    'UPI card (li.flex-col containing "Pay with UPI ID / Mobile number") found:',
                    _0x1c3575
                );
            } else {
                _0x1c3575 = _0x155adc;
                console.warn(
                    'Parent li.flex-col not found for UPI title, will try to click the title <p> element directly.'
                );
            }
        }
        if (_0x1c3575) {
            clearInterval(_0x6f2b);
            if (!simulateClick(_0x1c3575, 'UPI Option Card/Title')) {
                alert(
                    'Could not click the UPI option. Please select it manually.'
                );
                return;
            }
            setTimeout(() => {
                const _0x287341 = document.querySelector('#upi2Id');
                if (_0x287341) {
                    console.log(
                        'PayU VPA input field (#upi2Id) found:',
                        _0x287341
                    );
                    if (user_data && user_data.vpa && user_data.vpa.vpa) {
                        const _0x1fe423 = user_data.vpa.vpa;
                        console.log(
                            'Populating PayU VPA input field with:',
                            _0x1fe423
                        );
                        _0x287341.focus();
                        _0x287341.value = '';
                        _0x287341.dispatchEvent(
                            new Event('input', {
                                bubbles: true,
                            })
                        );
                        const _0x1ac5fe = Object.getOwnPropertyDescriptor(
                            window.HTMLInputElement.prototype,
                            'value'
                        ).set;
                        if (_0x1ac5fe) {
                            _0x1ac5fe.call(_0x287341, _0x1fe423);
                        } else {
                            _0x287341.value = _0x1fe423;
                        }
                        _0x287341.dispatchEvent(
                            new Event('input', {
                                bubbles: true,
                            })
                        );
                        _0x287341.dispatchEvent(
                            new Event('change', {
                                bubbles: true,
                            })
                        );
                        _0x287341.dispatchEvent(
                            new KeyboardEvent('keyup', {
                                bubbles: true,
                            })
                        );
                        console.log(
                            'UPI ID entered into #upi2Id with all events. Current value:',
                            _0x287341.value
                        );
                        setTimeout(() => {
                            const _0x12c279 = document.querySelector(
                                '#upi-verify-enabled'
                            );
                            if (
                                !simulateClick(
                                    _0x12c279,
                                    'Verify UPI Button (#upi-verify-enabled)'
                                )
                            ) {
                                console.warn(
                                    'Verify button was not clicked or found. Checking for PROCEED button anyway.'
                                );
                            }
                            setTimeout(() => {
                                const _0x38eac8 = Array.from(
                                    document.querySelectorAll('span')
                                );
                                const _0xe7518b = _0x38eac8.find(
                                    _0xf4cf34 =>
                                        _0xf4cf34.textContent
                                            .trim()
                                            .toUpperCase() === 'PROCEED'
                                );
                                if (
                                    !simulateClick(
                                        _0xe7518b,
                                        'PROCEED Button (span)'
                                    )
                                ) {
                                    alert(
                                        'Could not click the PROCEED button. Please click it manually.'
                                    );
                                }
                            }, 0x320);
                        }, 0x1f4);
                    } else {
                        console.warn(
                            'VPA (UPI ID) not found in user_data for PayU flow.'
                        );
                        alert(
                            'Your UPI ID is not saved. Please save it in the extension and try again.'
                        );
                    }
                } else {
                    console.warn(
                        'PayU VPA input field (#upi2Id) NOT found after clicking UPI option.'
                    );
                    alert(
                        'Could not find the UPI ID input field. Please check the PayU page structure.'
                    );
                }
            }, 0x2bc);
        } else {
            console.log('PayU UPI option/card not yet available. Retrying...');
        }
    }, 0x1f4);
}
chrome.storage.local.get(null, _0x3cf167 => {
    user_data = _0x3cf167;
    console.log('User data loaded on PayU page:', user_data);
    if (
        user_data &&
        user_data.other_preferences &&
        user_data.other_preferences.paymentmethod === 'PAYUUPIID'
    ) {
        console.log(
            'PayU UPI ID payment method selected. Initializing PayU VPA fill.'
        );
        if (document.readyState !== 'loading') {
            fillPayUVPA();
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                console.log(
                    'DOMContentLoaded event fired on PayU page. Calling fillPayUVPA.'
                );
                fillPayUVPA();
            });
        }
    } else {
        console.log(
            'Not a PayU UPI ID payment method, or payment method not found. PayU script will not run automation.'
        );
    }
});
