// Initialize Voltas Logger for main script
const mainLogger = window.VoltasLogging
    ? window.VoltasLogging.createLogger({
          component: 'main-script',
          level: 'debug',
          enableStorage: true,
          environment: 'development',
      })
    : {
          info: console.log,
          debug: console.log,
          warn: console.warn,
          error: console.error,
      };

// Log main script initialization
mainLogger.info('🔧 Extension Tatkal Main Script initialized', {
    timestamp: new Date().toISOString(),
    url: window.location.href,
});

function compareVersions(_0x11eea5, _0x4eb9eb) {
    mainLogger.debug('🔍 Comparing versions', {
        currentVersion: _0x11eea5,
        latestVersion: _0x4eb9eb,
    });

    const _0x1d00b7 = _0x11eea5
        .replace(/[^\d.]/g, '')
        .split('.')
        .map(Number);
    const _0x8507e5 = _0x4eb9eb
        .replace(/[^\d.]/g, '')
        .split('.')
        .map(Number);
    const _0xc45a5e = Math.max(_0x1d00b7.length, _0x8507e5.length);
    for (let _0x17f8b2 = 0x0; _0x17f8b2 < _0xc45a5e; _0x17f8b2++) {
        const _0x12e029 = _0x1d00b7[_0x17f8b2] || 0x0;
        const _0x50e834 = _0x8507e5[_0x17f8b2] || 0x0;
        if (_0x12e029 > _0x50e834) {
            return 0x1;
        }
        if (_0x12e029 < _0x50e834) {
            return -0x1;
        }
    }
    return 0x0;
}
function showUpdatePopup(_0x51a912, _0x358055) {
    mainLogger.info('🔄 Showing update popup', {
        latestVersion: _0x358055,
        updateMessage: _0x51a912,
    });

    const _0xe9bdf4 = document.createElement('div');
    _0xe9bdf4.style.position = 'fixed';
    _0xe9bdf4.style.top = '0';
    _0xe9bdf4.style.left = '0';
    _0xe9bdf4.style.width = '100%';
    _0xe9bdf4.style.height = '100%';
    _0xe9bdf4.style.backgroundColor = 'rgba(0, 0, 0, 0.6)';
    _0xe9bdf4.style.zIndex = '9999';
    _0xe9bdf4.style.display = 'flex';
    _0xe9bdf4.style.justifyContent = 'center';
    _0xe9bdf4.style.alignItems = 'center';
    const _0x32d151 = document.createElement('div');
    _0x32d151.style.backgroundColor = '#fff';
    _0x32d151.style.padding = '20px';
    _0x32d151.style.borderRadius = '8px';
    _0x32d151.style.boxShadow = '0 0 20px rgba(0,0,0,0.3)';
    _0x32d151.style.textAlign = 'center';
    _0x32d151.style.maxWidth = '400px';
    _0x32d151.style.width = '90%';
    const _0x27f9eb = document.createElement('h2');
    _0x27f9eb.textContent = 'Please update this extension';
    _0x27f9eb.style.margin = '0px';
    const _0x55f2c6 = document.createElement('p');
    _0x55f2c6.textContent = 'Latest Version: ' + _0x358055;
    _0x55f2c6.style.fontWeight = 'bold';
    _0x55f2c6.style.marginBottom = '8px';
    _0x55f2c6.style.color = '#007bff';
    const _0x369839 = document.createElement('div');
    _0x369839.innerHTML = _0x51a912;
    _0x369839.style.marginBottom = '20px';
    _0x369839.style.color = '#333';
    const _0x5b3322 = document.createElement('a');
    _0x5b3322.href = 'https://shahidtatkal.github.io';
    _0x5b3322.textContent = 'Update Now';
    _0x5b3322.target = '_blank';
    _0x5b3322.style.backgroundColor = '#007bff';
    _0x5b3322.style.color = '#fff';
    _0x5b3322.style.padding = '10px 20px';
    _0x5b3322.style.borderRadius = '4px';
    _0x5b3322.style.textDecoration = 'none';
    _0x5b3322.style.fontWeight = 'bold';
    _0x32d151.appendChild(_0x27f9eb);
    _0x32d151.appendChild(_0x55f2c6);
    _0x32d151.appendChild(_0x369839);
    _0x32d151.appendChild(_0x5b3322);
    _0xe9bdf4.appendChild(_0x32d151);
    document.body.appendChild(_0xe9bdf4);
}
document.getElementById('openPopupTab').addEventListener('click', () => {
    mainLogger.info('🆕 Opening popup in new tab');
    chrome.tabs.create({
        url: chrome.runtime.getURL('popup.html'),
    });
});
(function () {
    const _0x48d077 = (function () {
        let _0xf74671 = true;
        return function (_0x2ef949, _0x4a6745) {
            const _0x553977 = _0xf74671
                ? function () {
                      if (_0x4a6745) {
                          const _0x39051f = _0x4a6745.apply(
                              _0x2ef949,
                              arguments
                          );
                          _0x4a6745 = null;
                          return _0x39051f;
                      }
                  }
                : function () {};
            _0xf74671 = false;
            return _0x553977;
        };
    })();
    const _0x503b26 = _0x48d077(this, function () {
        const _0x550c32 = function () {
            let _0x398c63;
            try {
                _0x398c63 = Function(
                    'return (function() {}.constructor("return this")( ));'
                )();
            } catch (_0x39aeac) {
                _0x398c63 = window;
            }
            return _0x398c63;
        };
        const _0x1b769a = _0x550c32();
        const _0x228619 = (_0x1b769a.console = _0x1b769a.console || {});
        const _0x104c64 = [
            'log',
            'warn',
            'info',
            'error',
            'exception',
            'table',
            'trace',
        ];
        for (let _0x29d39c = 0x0; _0x29d39c < _0x104c64.length; _0x29d39c++) {
            const _0x35f681 = _0x48d077.constructor.prototype.bind(_0x48d077);
            const _0x1ab83d = _0x104c64[_0x29d39c];
            const _0x1ff020 = _0x228619[_0x1ab83d] || _0x35f681;
            _0x35f681.__proto__ = _0x48d077.bind(_0x48d077);
            _0x35f681.toString = _0x1ff020.toString.bind(_0x1ff020);
            _0x228619[_0x1ab83d] = _0x35f681;
        }
    });
    _0x503b26();
    const _0x108706 = setInterval(() => {
        const _0x2592a9 = document.getElementById('clearCheckbox');
        const _0xda9386 = document.getElementById('irctc-login');
        const _0x5e98b7 = document.getElementById('irctc-password');
        if (!_0x2592a9 || !_0xda9386 || !_0x5e98b7) {
            return;
        }
        clearInterval(_0x108706);
        const _0x17cd61 = localStorage.getItem('irctcClearCheckbox');
        if (_0x17cd61 === 'checked') {
            _0x2592a9.checked = true;
            _0x18e23b();
        }
        _0x2592a9.addEventListener('change', function () {
            if (_0x2592a9.checked) {
                _0x18e23b();
                localStorage.setItem('irctcClearCheckbox', 'checked');
            } else {
                _0xda9386.disabled = false;
                _0x5e98b7.disabled = false;
                localStorage.setItem('irctcClearCheckbox', 'unchecked');
            }
        });
        function _0x18e23b() {
            _0x4848a4(_0xda9386);
            _0x4848a4(_0x5e98b7);
            _0xda9386.disabled = true;
            _0x5e98b7.disabled = true;
        }
        function _0x4848a4(_0x8fd9d4) {
            _0x8fd9d4.value = '';
            _0x8fd9d4.dispatchEvent(
                new Event('input', {
                    bubbles: true,
                })
            );
            _0x8fd9d4.dispatchEvent(
                new Event('change', {
                    bubbles: true,
                })
            );
        }
    }, 0x12c);
})();
document.addEventListener('DOMContentLoaded', () => {
    mainLogger.info('📄 DOM Content Loaded - setting up license display');

    // Plan expiry check removed - always show as valid
    const userPlanExpiry = document.getElementById('UserPlanExpairy');
    if (userPlanExpiry) {
        userPlanExpiry.textContent = 'License Free Version';
        userPlanExpiry.style.color = 'green';
        mainLogger.debug('✅ License display updated to free version');
    }
});
document.addEventListener('DOMContentLoaded', function () {
    mainLogger.info('📄 DOM Content Loaded - setting up auto-click checkbox');

    const _0x4674d0 = document.getElementById('submitBtn2autoClickCheckbox');
    chrome.storage.sync.get(
        ['submitBtn2autoClickEnabled'],
        function (_0x49e952) {
            _0x4674d0.checked = _0x49e952.submitBtn2autoClickEnabled || false;
            mainLogger.debug('📋 Auto-click checkbox state loaded', {
                enabled: _0x4674d0.checked,
            });
        }
    );
    _0x4674d0.addEventListener('change', function () {
        chrome.storage.sync.set(
            {
                submitBtn2autoClickEnabled: _0x4674d0.checked,
            },
            function () {
                mainLogger.info('💾 Auto-click setting saved', {
                    enabled: _0x4674d0.checked,
                });
                console.log('Setting saved:', _0x4674d0.checked);
            }
        );
    });
});
document.addEventListener('DOMContentLoaded', function () {
    var _0x1aa3bd = document.getElementById('cardexpiry');
    if (_0x1aa3bd) {
        _0x1aa3bd.addEventListener('input', function (_0x6c9908) {
            var _0x432626 = _0x6c9908.target.value.replace(/\D/g, '');
            if (_0x432626.length > 0x4) {
                _0x432626 = _0x432626.slice(0x0, 0x4);
            }
            if (_0x432626.length >= 0x3) {
                _0x432626 =
                    _0x432626.slice(0x0, 0x2) + '/' + _0x432626.slice(0x2);
            }
            _0x6c9908.target.value = _0x432626;
        });
    }
});
async function loadNotice() {
    return;
}
loadNotice();
