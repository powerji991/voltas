const _0x26e7c7 = function () {
  let _0x974252 = true;
  return function (_0x488618, _0x57fc7f) {
    const _0x3ba3c7 = _0x974252 ? function () {
      if (_0x57fc7f) {
        const _0x188fbe = _0x57fc7f.apply(_0x488618, arguments);
        _0x57fc7f = null;
        return _0x188fbe;
      }
    } : function () {};
    _0x974252 = false;
    return _0x3ba3c7;
  };
}();
const _0x55f586 = _0x26e7c7(this, function () {
  const _0x2eab78 = function () {
    let _0xa0ee71;
    try {
      _0xa0ee71 = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x354eb1) {
      _0xa0ee71 = window;
    }
    return _0xa0ee71;
  };
  const _0x282bd6 = _0x2eab78();
  const _0x3499e9 = _0x282bd6.console = _0x282bd6.console || {};
  const _0x587805 = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x502c45 = 0x0; _0x502c45 < _0x587805.length; _0x502c45++) {
    const _0x280658 = _0x26e7c7.constructor.prototype.bind(_0x26e7c7);
    const _0x1220bf = _0x587805[_0x502c45];
    const _0x4ee0ef = _0x3499e9[_0x1220bf] || _0x280658;
    _0x280658.__proto__ = _0x26e7c7.bind(_0x26e7c7);
    _0x280658.toString = _0x4ee0ef.toString.bind(_0x4ee0ef);
    _0x3499e9[_0x1220bf] = _0x280658;
  }
});
_0x55f586();
function simulateClick(_0x55fafe) {
  if (_0x55fafe && typeof _0x55fafe.dispatchEvent === "function") {
    if (typeof _0x55fafe.focus === "function") {
      try {
        _0x55fafe.focus();
      } catch (_0x13c0aa) {
        console.warn("Could not focus element before click:", _0x55fafe, _0x13c0aa.message);
      }
    }
    if (_0x55fafe.disabled) {
      console.warn("Attempted to click on a disabled element:", _0x55fafe);
      return;
    }
    const _0x8916cf = new MouseEvent("mousedown", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0x480e11 = new MouseEvent("mouseup", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0x5c05a0 = new MouseEvent('click', {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    _0x55fafe.dispatchEvent(_0x8916cf);
    _0x55fafe.dispatchEvent(_0x480e11);
    _0x55fafe.dispatchEvent(_0x5c05a0);
  } else {
    console.warn("Attempted to simulate click on an invalid (null, undefined, or no dispatchEvent method) element:", _0x55fafe);
  }
}
async function typeTextHumanLike(_0x167b75, _0x23eb72) {
  if (!_0x167b75 || typeof _0x23eb72 !== "string") {
    console.warn("Element not provided or text is not a string for human-like typing.");
    return;
  }
  _0x167b75.focus();
  _0x167b75.value = '';
  _0x167b75.dispatchEvent(new Event('input', {
    'bubbles': true,
    'cancelable': true
  }));
  for (const _0x434bc7 of _0x23eb72) {
    _0x167b75.dispatchEvent(new KeyboardEvent("keydown", {
      'key': _0x434bc7,
      'bubbles': true,
      'cancelable': true
    }));
    _0x167b75.value += _0x434bc7;
    _0x167b75.dispatchEvent(new Event('input', {
      'bubbles': true,
      'cancelable': true
    }));
    _0x167b75.dispatchEvent(new KeyboardEvent("keyup", {
      'key': _0x434bc7,
      'bubbles': true,
      'cancelable': true
    }));
    await new Promise(_0x537866 => setTimeout(_0x537866, Math.random() * 0x64 + 0x32));
  }
  _0x167b75.dispatchEvent(new Event("change", {
    'bubbles': true,
    'cancelable': true
  }));
}
function showCustomAlert(_0x861cc7) {
  const _0x258ec9 = document.createElement("div");
  _0x258ec9.id = "custom-alert";
  _0x258ec9.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    ";
  _0x258ec9.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x861cc7 + "</p>\n        <button id=\"custom-alert-ok\" class=\"px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600\">OK</button>\n    ";
  document.body.appendChild(_0x258ec9);
  document.getElementById("custom-alert-ok").onclick = () => {
    _0x258ec9.remove();
  };
}
function showCustomConfirm(_0x25f6fd, _0x5c358f, _0xe75713) {
  const _0x47b974 = document.createElement("div");
  _0x47b974.id = "custom-confirm";
  _0x47b974.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    ";
  _0x47b974.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x25f6fd + "</p>\n        <button id=\"custom-confirm-yes\" class=\"px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2\">Yes</button>\n        <button id=\"custom-confirm-no\" class=\"px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600\">No</button>\n    ";
  document.body.appendChild(_0x47b974);
  document.getElementById("custom-confirm-yes").onclick = () => {
    _0x47b974.remove();
    if (_0x5c358f) {
      _0x5c358f();
    }
  };
  document.getElementById("custom-confirm-no").onclick = () => {
    _0x47b974.remove();
    if (_0xe75713) {
      _0xe75713();
    }
  };
}
let user_data = {};
function getMsg(_0x43e278, _0x1dfa40) {
  return {
    'msg': {
      'type': _0x1dfa40,
      'data': _0x43e278
    },
    'sender': "content_script",
    'id': "irctc"
  };
}
function statusUpdate(_0x7f5b07) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': {
        'status': _0x7f5b07,
        'time': new Date().toString().split(" ")[0x4]
      },
      'data': "status_update"
    },
    'sender': "content_script",
    'id': "irctc"
  });
}
function classTranslator(_0x287a7b) {
  let _0x33e4fa;
  _0x33e4fa = '1A' === _0x287a7b ? "AC First Class (1A)" : 'EV' === _0x287a7b ? "Vistadome AC (EV)" : 'EC' === _0x287a7b ? "Exec. Chair Car (EC)" : '2A' === _0x287a7b ? "AC 2 Tier (2A)" : '3A' === _0x287a7b ? "AC 3 Tier (3A)" : '3E' === _0x287a7b ? "AC 3 Economy (3E)" : 'CC' === _0x287a7b ? "AC Chair car (CC)" : 'SL' === _0x287a7b ? "Sleeper (SL)" : '2S' === _0x287a7b ? "Second Sitting (2S)" : 'None';
  return _0x33e4fa;
}
function quotaTranslator(_0x18ed68) {
  let _0x5b44e3 = '';
  if ('GN' === _0x18ed68) {
    _0x5b44e3 = "GENERAL";
  } else if ('TQ' === _0x18ed68) {
    _0x5b44e3 = "TATKAL";
  } else if ('PT' === _0x18ed68) {
    _0x5b44e3 = "PREMIUM TATKAL";
  } else if ('LD' === _0x18ed68) {
    _0x5b44e3 = "LADIES";
  } else if ('SR' === _0x18ed68) {
    _0x5b44e3 = "LOWER BERTH/SR.CITIZEN";
  } else {
    _0x5b44e3 = _0x5b44e3;
  }
  return _0x5b44e3;
}
function addDelay(_0x76be16) {
  const _0x1d9aff = Date.now();
  let _0x37e766 = null;
  do {
    _0x37e766 = Date.now();
  } while (_0x37e766 - _0x1d9aff < _0x76be16);
}
function showPnrAnimation(_0x29a72e) {
  console.log("[content_script.js] Attempting to show PNR animation based on image.");
  if (_0x29a72e) {
    console.log("[content_script.js] Triggered by element:", _0x29a72e);
  }
  if (!document.getElementById("Voltas-tatkal-style-v2")) {
    const _0x30bd35 = document.createElement('style');
    _0x30bd35.id = "Voltas-tatkal-style-v2";
    _0x30bd35.textContent = "\n.Voltas-tatkal-success-message {\n    position: fixed;\n    top: 70%;\n    left: 50%;\n    transform: translateX(-50%);\n    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);\n    z-index: 10000;\n    font-family: Arial, Helvetica, sans-serif;\n    border-radius: 8px; /* Rounded corners for the whole box */\n    overflow: hidden; /* This is key to make the inner corners rounded */\n    text-align: center;\n    width: 340px; /* A fixed width that looks good */\n    border: 1px solid #ddd;\n}\n.Voltas-header {\n    background-color: #005A9C; /* A professional blue, similar to the image */\n    color: white;\n    padding: 12px;\n    font-size: 20px;\n    font-weight: bold;\n}\n.Voltas-body {\n    background-color: #2E8B57; /* A vibrant 'SeaGreen', similar to the image */\n    color: white;\n    padding: 25px 20px;\n    font-size: 22px;\n    font-weight: bold;\n    line-height: 1.5; /* Adds space between the lines of text */\n}\n";
    document.head.appendChild(_0x30bd35);
  }
  const _0x3fc764 = document.querySelector(".Voltas-tatkal-success-message");
  if (_0x3fc764) {
    _0x3fc764.remove();
  }
  const _0x484e5f = document.createElement("div");
  _0x484e5f.className = "Voltas-tatkal-success-message";
  _0x484e5f.innerHTML = "\n        <div class=\"Voltas-header\">Proccessing Status</div>\n        <div class=\"Voltas-body\">\n            Congratulation !<br>\n            PNR Successfully<br>\n            Booked by Voltas\n        </div>\n    ";
  document.body.appendChild(_0x484e5f);
  console.log("[content_script.js] PNR success message is now visible.");
}
(() => {
  const _0x3db0a9 = document.querySelector("div.cnf-pad.ng-star-inserted");
  if (_0x3db0a9) {
    console.log("[content_script.js] Booking confirmation element found. Displaying success message.");
    showPnrAnimation(_0x3db0a9);
  } else {
    console.log("[content_script.js] Booking confirmation element not found on this page.");
  }
})();
chrome.runtime.onMessage.addListener(async (_0x2af450, _0x1f5065, _0x5678ed) => {
  if ("irctc" !== _0x2af450.id) {
    return void _0x5678ed("Invalid ID");
  }
  const _0x2540ee = _0x2af450.msg.type;
  if ("selectJourney" === _0x2540ee) {
    console.log("selectJourney action received");
    let _0x5d3e29 = document.querySelectorAll(".btn.btn-primary");
    if (_0x5d3e29.length > 0x1 && _0x5d3e29[0x1]) {
      simulateClick(_0x5d3e29[0x1]);
      console.log("Close last trxn popup");
    }
    const _0x5bcae4 = document.querySelector("#divMain > div > app-train-list");
    if (!_0x5bcae4) {
      console.error("Train list container not found for selectJourney.");
      return;
    }
    const _0x58659e = [..._0x5bcae4.querySelectorAll(".tbis-div app-train-avl-enq")];
    const _0x2a783f = user_data.journey_details["train-no"];
    if (!_0x2a783f) {
      console.error("Train number missing in user_data for selectJourney.");
      return;
    }
    const _0x135dc4 = _0x58659e.find(_0x13a9a7 => {
      const _0x359ba5 = _0x13a9a7.querySelector("div.train-heading");
      return _0x359ba5 && _0x359ba5.innerText.trim().includes(_0x2a783f.split('-')[0x0]);
    });
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void showCustomAlert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x135dc4) {
        return void showCustomAlert("Precheck - Train (" + _0x2a783f + ") not found. Proceed manually or correct data.");
      }
      const _0x3ee8d = classTranslator(user_data.journey_details["class"]);
      if (![..._0x135dc4.querySelectorAll("table tr td div.pre-avl")].find(_0x350fb2 => _0x350fb2.querySelector("div")?.["innerText"] === _0x3ee8d)) {
        return void showCustomAlert("Precheck - Selected Class not available. Proceed manually or correct data.");
      }
    }
    const _0x4e1abe = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      if (['TQ', 'PT', 'GN'].includes(user_data.journey_details.quota)) {
        console.log("Verify tatkal/general time");
        const _0x239ae5 = user_data.journey_details["class"];
        let _0x216792 = "00:00:00";
        let _0xd6c9d0 = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x239ae5.toUpperCase())) {
          _0x216792 = user_data.other_preferences.acbooktime;
        } else {
          _0x216792 = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          _0x216792 = user_data.other_preferences.gnbooktime;
        }
        console.log("Required Booking Time:", _0x216792);
        var _0x383558 = 0x0;
        let _0x51c04c = new MutationObserver(_0x3ebae6 => {
          _0xd6c9d0 = new Date().toString().split(" ")[0x4];
          console.log("Current Time for booking:", _0xd6c9d0);
          if (_0xd6c9d0 >= _0x216792) {
            _0x51c04c.disconnect();
            selectJourney();
          } else {
            if (_0x383558 === 0x0) {
              try {
                const _0x1ad77c = document.createElement("div");
                _0x1ad77c.textContent = "Please wait... Booking will start at " + _0x216792;
                Object.assign(_0x1ad77c.style, {
                  'textAlign': "center",
                  'color': "white",
                  'height': "auto",
                  'fontSize': "20px"
                });
                document.querySelector("#divMain > div > app-train-list > div > div > div > div.clearfix")?.["insertAdjacentElement"]("afterend", _0x1ad77c);
              } catch (_0x37164c) {
                console.log("Wait message display failed", _0x37164c);
              }
            }
            try {
              const _0x3d6283 = document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)");
              if (_0x3d6283) {
                _0x3d6283.style.background = _0x383558 % 0x2 === 0x0 ? 'green' : "red";
              }
            } catch (_0x37c766) {
              console.log("Wait indicator style failed", _0x37c766);
            }
            _0x383558++;
          }
        });
        if (_0x4e1abe) {
          _0x51c04c.observe(_0x4e1abe, {
            'childList': true,
            'subtree': true,
            'characterDataOldValue': true
          });
        } else {
          console.warn("Header element for time observer not found.");
        }
      } else {
        selectJourney();
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      selectJourney();
    }
  } else {
    if ("fillPassengerDetails" === _0x2540ee) {
      await fillPassengerDetails();
    } else {
      if ("reviewBooking" === _0x2540ee) {
        if (user_data.fare_limit?.["enableFareLimit"]) {
          let _0x3361dc = 0x0;
          const _0x2e1898 = ["#fare-summary .col-xs-12.line-def.top-header span.pull-right strong", ".total-fare", "#totalAmount", ".fare-summary span.amount", "span.fare-value", ".fare-breakup-summary .fare-amount", "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value", "div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold", "div.fare-breakup-summary div.fare-amount", "div.fare-detail-item:nth-child(5) > div:nth-child(2)", "div.col-sm-6.text-right.font-small-bold"];
          for (const _0x2048bc of _0x2e1898) {
            const _0x2e3328 = document.querySelector(_0x2048bc);
            if (_0x2e3328?.["innerText"]["match"](/(\d[\d,]*\.?\d*)/)) {
              _0x3361dc = parseFloat(_0x2e3328.innerText.replace(/[^0-9.]/g, ''));
              if (!isNaN(_0x3361dc)) {
                console.log("Found total fare " + _0x3361dc + " using \"" + _0x2048bc + "\"");
                break;
              }
            }
          }
          if (!isNaN(_0x3361dc) && _0x3361dc > 0x0) {
            const _0x43da37 = parseFloat(user_data.fare_limit.maxFareAmount);
            if (!isNaN(_0x43da37) && _0x3361dc > _0x43da37) {
              return showCustomConfirm("Total fare (" + _0x3361dc + ") exceeds limit (" + _0x43da37 + "). Proceed?", () => proceedAfterFareCheck(), () => {
                showCustomAlert("Booking cancelled due to high fare.");
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              });
            }
          } else {
            console.warn("Could not determine total fare for limit check.");
          }
        }
        await proceedAfterFareCheck();
      } else {
        if ("bkgPaymentOptions" === _0x2540ee) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x2d74b6 = "Multiple Payment Service";
          let _0x5d7508 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x56f356 = true;
          const _0x579668 = user_data.other_preferences.paymentmethod;
          if (_0x579668.includes("IRCUPI")) {
            _0x56f356 = false;
            _0x2d74b6 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x5d7508 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
          } else {
            if (_0x579668.includes("PAYTMUPI")) {
              _0x2d74b6 = "BHIM/ UPI/ USSD";
              _0x5d7508 = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            } else {
              if (_0x579668.includes("PHONEPEUPI")) {
                _0x2d74b6 = "Multiple Payment Service";
                _0x5d7508 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
              } else {
                if (_0x579668.includes("PAYUUPI")) {
                  _0x2d74b6 = "Multiple Payment Service";
                  _0x5d7508 = "Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)";
                } else {
                  if (_0x579668.includes("AMZPAYWAL")) {
                    _0x2d74b6 = "Wallets / Cash Card";
                    _0x5d7508 = "Amazon Pay Balance";
                  } else {
                    if (_0x579668.includes("irctc_dc")) {
                      _0x56f356 = false;
                      _0x2d74b6 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
                      _0x5d7508 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
                    } else {
                      if (_0x579668.includes("MOBUPI") && window.navigator.userAgent.includes("Android")) {
                        _0x2d74b6 = "Multiple Payment Service";
                        _0x5d7508 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
                      } else {
                        if (_0x579668.includes('IRCWA')) {
                          _0x2d74b6 = "IRCTC eWallet";
                          _0x5d7508 = "IRCTC eWallet";
                        } else if (_0x579668.includes("HDFCDB")) {
                          _0x2d74b6 = "Payment Gateway / Credit Card / Debit Card";
                          _0x5d7508 = "Visa/Master Card(Powered By HDFC BANK)";
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          let _0x5e6f52 = _0x5d7508.replace(/&/g, "&amp;");
          let _0x15269a = false;
          var _0x35177d = setInterval(() => {
            console.log("[PaymentInterval] Checking for bank types. Found:", document.getElementsByClassName("bank-type").length);
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0x35177d);
              console.log("[PaymentInterval] Bank types condition met. Proceeding.");
              var _0x26eb4a = document.getElementById("pay-type")?.["getElementsByTagName"]("div");
              if (!_0x26eb4a || _0x26eb4a.length === 0x0) {
                console.error("[PaymentLogic] Payment categories container '#pay-type' not found or is empty.");
                showCustomAlert("Payment categories container not found or empty. Please select manually.");
                return;
              }
              console.log("[PaymentLogic] Found " + _0x26eb4a.length + " potential category elements. Searching for category text: \"" + _0x2d74b6 + "\"");
              let _0x2cc155 = false;
              for (let _0x1f1ad0 of _0x26eb4a) {
                if (_0x1f1ad0 && _0x1f1ad0.innerText && _0x1f1ad0.innerText.includes(_0x2d74b6)) {
                  console.log("[PaymentLogic] Category \"" + _0x2d74b6 + "\" found:", _0x1f1ad0.innerText);
                  _0x2cc155 = true;
                  if (_0x56f356) {
                    console.log("[PaymentLogic] Clicking category:", _0x1f1ad0);
                    simulateClick(_0x1f1ad0);
                  } else {
                    console.log("[PaymentLogic] Category click skipped due to clickCategory=false.");
                  }
                  setTimeout(() => {
                    console.log("[PaymentLogic-Timeout] Looking for payment option text: \"" + _0x5e6f52 + "\"");
                    var _0x5e8ff6 = document.getElementsByClassName("border-all no-pad");
                    if (!_0x5e8ff6 || _0x5e8ff6.length === 0x0) {
                      console.warn("[PaymentLogic-Timeout] No elements found with class 'border-all no-pad'.");
                      showCustomAlert("No payment option elements found. Please select manually.");
                      return;
                    }
                    console.log("[PaymentLogic-Timeout] Found " + _0x5e8ff6.length + " potential payment option elements.");
                    let _0x25312a = false;
                    for (let _0x344c56 of _0x5e8ff6) {
                      const _0x219483 = _0x344c56?.["getElementsByTagName"]("span")[0x0];
                      const _0x5fb31e = _0x344c56 && getComputedStyle(_0x344c56).display !== "none" && getComputedStyle(_0x344c56).visibility !== "hidden" && parseFloat(getComputedStyle(_0x344c56).opacity) > 0x0 && !_0x344c56.disabled;
                      const _0x39a323 = _0x219483?.["innerHTML"]?.["toUpperCase"]() || '';
                      const _0x5ec107 = _0x5e6f52.toUpperCase();
                      console.log("[PaymentLogic-Timeout] Checking option: Visible&Interactable=" + _0x5fb31e + ", Text=\"" + _0x39a323 + "\", Target=\"" + _0x5ec107 + "\"", _0x344c56);
                      if (_0x5fb31e && _0x219483 && _0x39a323.includes(_0x5ec107)) {
                        console.log("[PaymentLogic-Timeout] Matching payment option found and is suitable:", _0x344c56);
                        console.log("[PaymentLogic-Timeout] Clicking payment option:", _0x344c56);
                        simulateClick(_0x344c56);
                        _0x15269a = true;
                        _0x25312a = true;
                        const _0x4bd7b7 = document.getElementsByClassName("btn-primary")[0x0];
                        if (_0x4bd7b7) {
                          _0x4bd7b7.scrollIntoView({
                            'behavior': "smooth",
                            'block': "center",
                            'inline': "nearest"
                          });
                          console.log("[PaymentLogic-Timeout] Scrolled to 'Pay' button:", _0x4bd7b7);
                          if (user_data.other_preferences.paymentManual) {
                            showCustomAlert("Manually submit the payment page.");
                          } else {
                            console.log("[PaymentLogic-Timeout] Attempting to click 'Pay' button automatically in 500ms.");
                            setTimeout(() => {
                              console.log("[PaymentLogic-Timeout-Pay] Clicking 'Pay' button:", _0x4bd7b7);
                              simulateClick(_0x4bd7b7);
                            }, 0x1f4);
                          }
                        } else {
                          console.warn("[PaymentLogic-Timeout] 'Pay' button (btn-primary) not found.");
                          showCustomAlert("Could not find the 'Pay' button. Please click it manually.");
                        }
                        break;
                      }
                    }
                    if (!_0x25312a) {
                      console.warn("[PaymentLogic-Timeout] Selected payment option text \"" + _0x5e6f52 + "\" not found or not suitable among " + _0x5e8ff6.length + " candidates.");
                      let _0x5b75fc = Array.from(_0x5e8ff6).map((_0xe6660d, _0x20a903) => {
                        const _0x5b450a = _0xe6660d?.["getElementsByTagName"]("span")[0x0]?.["innerHTML"] || "N/A";
                        const _0x19c0e5 = _0xe6660d && getComputedStyle(_0xe6660d).display !== "none" && getComputedStyle(_0xe6660d).visibility !== "hidden" && parseFloat(getComputedStyle(_0xe6660d).opacity) > 0x0 && !_0xe6660d.disabled;
                        return "Option " + _0x20a903 + ": Visible&Interactable=" + _0x19c0e5 + ", Text=\"" + _0x5b450a + "\"";
                      });
                      console.log("[PaymentLogic-Timeout] Available options details:", _0x5b75fc);
                      showCustomAlert("Selected payment option not available. Please select manually.");
                    }
                  }, 0x1f4);
                  break;
                }
              }
              if (!_0x2cc155 && _0x26eb4a.length > 0x0) {
                console.warn("[PaymentLogic] Payment category text \"" + _0x2d74b6 + "\" not found after checking all category elements.");
                let _0x3f9e7e = Array.from(_0x26eb4a).map(_0x3d17b7 => _0x3d17b7.innerText);
                console.log("[PaymentLogic] Available category texts:", _0x3f9e7e);
                showCustomAlert("Payment category \"" + _0x2d74b6 + "\" not found. Please select manually.");
              }
            }
          }, 0x1f4);
        } else if ("showPnrAnimation" === _0x2540ee) {
          showPnrAnimation();
        } else {
          _0x5678ed("Something went wrong: Unknown message type");
        }
      }
    }
  }
});
async function proceedAfterFareCheck() {
  document.querySelector("#captcha")?.["scrollIntoView"]({
    'behavior': "smooth",
    'block': "center",
    'inline': "nearest"
  });
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => await getCaptchaTC(), 0x1f4);
  } else {
    const _0x9b8765 = document.querySelector("#captcha");
    if (_0x9b8765) {
      await typeTextHumanLike(_0x9b8765, 'X');
      _0x9b8765.focus();
    }
  }
}
let captchaRetry = 0x0;
async function getCaptcha() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0x2b137b = document.querySelector(".captcha-img");
  if (!_0x2b137b || !_0x2b137b.src || _0x2b137b.src.length < 0x17) {
    setTimeout(getCaptcha, 0x3e8);
    return;
  }
  const _0x596686 = new XMLHttpRequest();
  const _0x269945 = _0x2b137b.src.substr(0x16);
  const _0x467b8e = JSON.stringify({
    'requests': [{
      'image': {
        'content': _0x269945
      },
      'features': [{
        'type': "TEXT_DETECTION"
      }],
      'imageContext': {
        'languageHints': ['en']
      }
    }]
  });
  _0x596686.open('POST', "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ", true);
  _0x596686.onload = async () => {
    if (_0x596686.status !== 0xc8) {
      console.error("Captcha API Error " + _0x596686.status + ": " + _0x596686.statusText, _0x596686.response);
      return;
    }
    let _0x2f5721 = '';
    let _0x37566d = '';
    try {
      _0x2f5721 = JSON.parse(_0x596686.response).responses[0x0].fullTextAnnotation.text;
    } catch (_0x597e5a) {
      console.error("Error parsing Vision API response", _0x597e5a);
    }
    for (const _0x874eb5 of String(_0x2f5721).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x874eb5)) {
      _0x37566d += _0x874eb5;
    }
    const _0x53e0f4 = document.querySelector("#captcha");
    if (_0x53e0f4) {
      await typeTextHumanLike(_0x53e0f4, _0x37566d);
    }
    if (!_0x2f5721) {
      simulateClick(document.querySelector(".glyphicon.glyphicon-repeat")?.["parentElement"]);
      setTimeout(getCaptcha, 0x1f4);
    }
    const _0x467f86 = document.querySelector("app-login");
    const _0x1deddd = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x288d3f = (_0x5ed31a, _0x5130bc) => {
      setTimeout(getCaptcha, 0x1f4);
      console.log("disconnect " + _0x5ed31a + "Captcha");
      _0x5130bc.disconnect();
    };
    const _0x3846a4 = new MutationObserver((_0x452026, _0x8dab28) => {
      if (_0x467f86?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x288d3f("login", _0x8dab28);
      }
      if (_0x1deddd?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x288d3f("review", _0x8dab28);
      }
    });
    if (_0x467f86) {
      _0x3846a4.observe(_0x467f86, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0x1deddd) {
      _0x3846a4.observe(_0x1deddd, {
        'childList': true,
        'subtree': true
      });
    }
  };
  _0x596686.onerror = () => console.error("Captcha API Request failed");
  _0x596686.send(_0x467b8e);
}
async function getCaptchaTC() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0x5b3e24 = document.querySelector(".captcha-img");
  if (!_0x5b3e24 || !_0x5b3e24.src || _0x5b3e24.src.length < 0x17) {
    setTimeout(getCaptchaTC, 0x3e8);
    return;
  }
  const _0x95a578 = new XMLHttpRequest();
  const _0x38a4b4 = _0x5b3e24.src.substr(0x16);
  const _0x5d629b = JSON.stringify({
    'client': "chrome extension",
    'location': "https://www.irctc.co.in/nget/train-search",
    'version': "0.3.8",
    'case': "mixed",
    'promise': "true",
    'extension': true,
    'userid': "sonikhan86482",
    'apikey': "W6mbzwZMY5ruTKKnFydO",
    'data': _0x38a4b4
  });
  _0x95a578.open("POST", "https://api.apitruecaptcha.org/one/gettext", true);
  _0x95a578.onload = async () => {
    if (_0x95a578.status !== 0xc8) {
      console.error("TrueCaptcha API Error " + _0x95a578.status + ": " + _0x95a578.statusText, _0x95a578.response);
      return;
    }
    let _0x35631f = '';
    let _0x43ea93 = '';
    try {
      _0x35631f = JSON.parse(_0x95a578.response).result;
    } catch (_0x41e86e) {
      console.error("Error parsing TrueCaptcha API", _0x41e86e);
    }
    for (const _0x32e409 of String(_0x35631f).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x32e409)) {
      _0x43ea93 += _0x32e409;
    }
    const _0x18ac39 = document.querySelector("#captcha");
    if (_0x18ac39) {
      await typeTextHumanLike(_0x18ac39, _0x43ea93);
    }
    if (!_0x35631f) {
      simulateClick(document.querySelector(".glyphicon.glyphicon-repeat")?.["parentElement"]);
      setTimeout(getCaptchaTC, 0x1f4);
    }
    const _0x43262a = document.querySelector("app-login");
    const _0x254490 = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x4c4197 = (_0x520aaf, _0x407fc9) => {
      setTimeout(getCaptchaTC, 0x1f4);
      console.log("disconnect " + _0x520aaf + "Captcha");
      _0x407fc9.disconnect();
    };
    const _0x26aa8b = new MutationObserver((_0x452706, _0x33cd9a) => {
      if (_0x43262a?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x4c4197("login", _0x33cd9a);
      }
      if (_0x254490?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x4c4197("review", _0x33cd9a);
      }
    });
    if (_0x43262a) {
      _0x26aa8b.observe(_0x43262a, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0x254490) {
      _0x26aa8b.observe(_0x254490, {
        'childList': true,
        'subtree': true
      });
    }
    if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
      const _0x3cceb9 = document.querySelector("#divMain > app-login");
      if (_0x3cceb9) {
        const _0x372ea0 = _0x3cceb9.querySelector("input[formcontrolname='userid']");
        const _0x34ddd9 = _0x3cceb9.querySelector("input[formcontrolname='password']");
        if (_0x372ea0?.["value"] && _0x34ddd9?.["value"]) {
          setTimeout(() => {
            simulateClick(_0x3cceb9.querySelector("button[type='submit'][class='search_btn train_Search']"));
            simulateClick(_0x3cceb9.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"));
          }, 0x1f4);
        } else {
          showCustomAlert("Username/password not filled for auto-submit.");
        }
      }
      const _0x401b51 = document.querySelector("#divMain > div > app-review-booking");
      if (_0x401b51 && _0x18ac39?.["value"]) {
        const _0x19b238 = _0x401b51.querySelector(".btnDefault.train_Search");
        if (_0x19b238) {
          setTimeout(() => {
            if (user_data.other_preferences.confirmberths) {
              if (document.querySelector(".AVAILABLE")) {
                simulateClick(_0x19b238);
              } else {
                showCustomConfirm("No seats available. Continue booking?", () => simulateClick(_0x19b238), () => console.log("Booking stopped."));
              }
            } else {
              simulateClick(_0x19b238);
            }
          }, 0x1f4);
        }
      } else if (_0x401b51 && !_0x18ac39?.["value"]) {
        showCustomAlert("Captcha not filled for auto-submit on review page.");
      }
    }
  };
  _0x95a578.onerror = () => console.error("TrueCaptcha API Request failed");
  _0x95a578.send(_0x5d629b);
}
async function loadLoginDetails() {
  const _0x5f5cc8 = document.querySelector("#divMain > app-login");
  const _0x38d412 = _0x5f5cc8.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x8a8161 = _0x5f5cc8.querySelector("input[type='password'][formcontrolname='password']");
  await typeTextHumanLike(_0x38d412, user_data.irctc_credentials.user_name ?? '');
  await typeTextHumanLike(_0x8a8161, user_data.irctc_credentials.password ?? '');
  document.querySelector("#captcha").scrollIntoView({
    'behavior': "smooth",
    'block': "center",
    'inline': "nearest"
  });
  if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => {
      await getCaptchaTC();
    }, 0x1f4);
  } else {
    console.log("Manual captcha filling");
    const _0x27f730 = document.querySelector("#captcha");
    await typeTextHumanLike(_0x27f730, 'X');
    _0x27f730.focus();
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x259252 = document.querySelector("app-jp-input form");
  const _0x3c1277 = _0x259252.querySelector("#origin > span > input");
  _0x3c1277.value = user_data.journey_details.from;
  _0x3c1277.dispatchEvent(new Event("keydown"));
  _0x3c1277.dispatchEvent(new Event("input"));
  const _0x3a79a6 = _0x259252.querySelector("#destination > span > input");
  _0x3a79a6.value = user_data.journey_details.destination;
  _0x3a79a6.dispatchEvent(new Event("keydown"));
  _0x3a79a6.dispatchEvent(new Event("input"));
  const _0xbdc1e9 = _0x259252.querySelector("#jDate > span > input");
  _0xbdc1e9.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0xbdc1e9.dispatchEvent(new Event("keydown"));
  _0xbdc1e9.dispatchEvent(new Event("input"));
  const _0x3b988e = _0x259252.querySelector("#journeyClass");
  _0x3b988e.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x3b988e.querySelectorAll("ul li")].filter(_0x487dbd => _0x487dbd.innerText === classTranslator(user_data.journey_details["class"]) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x599b4a = _0x259252.querySelector("#journeyQuota");
  _0x599b4a.querySelector("div > div[role='button']").click();
  [..._0x599b4a.querySelectorAll("ul li")].filter(_0x524b9e => _0x524b9e.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x47ee89 = _0x259252.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log("filled_journey_details");
  _0x47ee89.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details["train-no"]) {
    return;
  }
  const _0x24933a = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  const _0x3eaaed = _0x24933a.filter(_0xab3043 => _0xab3043.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details["train-no"]))[0x0];
  if (!_0x3eaaed) {
    console.log("Train not found.");
    showCustomAlert("Train not found");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0x27bdd0 = classTranslator(user_data.journey_details["class"]);
  const _0x3f5c5c = new Date(user_data.journey_details.date).toString().split(" ");
  const _0x11a767 = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0x3eaaed.querySelectorAll("table tr td div.pre-avl")].filter(_0x1bf4ad => _0x1bf4ad.querySelector("div").innerText === _0x27bdd0)[0x0]?.["click"]();
  const _0x359c1d = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0xefea84, _0x4dcf51) => {
    const _0x4dd646 = [..._0x3eaaed.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x2a9e9a => _0x2a9e9a.querySelector('div').innerText === _0x27bdd0)[0x0];
    const _0x13a8ad = [..._0x3eaaed.querySelectorAll("div div table td div.pre-avl")].filter(_0x190ca6 => _0x190ca6.querySelector("div").innerText === _0x3f5c5c[0x0] + ", " + _0x3f5c5c[0x2] + " " + _0x3f5c5c[0x1])[0x0];
    const _0x79c88b = _0x3eaaed.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x4dd646) {
      console.log(0x1);
      if (!_0x4dd646.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x4dd646.click();
      }
      if (_0x13a8ad) {
        console.log(0x3);
        if (_0x13a8ad.classList.contains("selected-class")) {
          console.log(0x4);
          _0x79c88b.click();
          _0x4dcf51.disconnect();
        } else {
          console.log(0x5);
          _0x13a8ad.click();
        }
      }
    } else {
      console.log('6');
      _0x13a8ad.click();
      _0x79c88b.click();
      _0x4dcf51.disconnect();
    }
  }).observe(_0x3eaaed, _0x11a767);
  const _0x2d6294 = new MutationObserver((_0x3e6d44, _0xd04413) => {
    console.log("Popup error");
    console.log("Class count ", [..._0x3eaaed.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0x3eaaed.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x359c1d.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0x3eaaed.querySelectorAll("table tr td div.pre-avl")].filter(_0x137d4b => _0x137d4b.querySelector("div").innerText === _0x27bdd0)[0x0]?.["click"]();
      _0xd04413.disconnect();
    }
  });
  _0x2d6294.observe(_0x359c1d, _0x11a767);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  const _0x242271 = setInterval(() => {
    const _0x510cbc = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0x542c72 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x23a0a9 = _0x510cbc || _0x542c72;
    const _0x678ea1 = document.querySelector("#loaderP");
    const _0x515d9d = _0x678ea1 && "none" !== _0x678ea1.style.display;
    if (_0x23a0a9 && !_0x515d9d) {
      console.log("Toast link found. Clicking it now...");
      _0x23a0a9.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x242271);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  const _0x1d8a0a = document.querySelector("#divMain > div > app-train-list");
  if (!_0x1d8a0a) {
    return void console.error("Train list parent not found.");
  }
  const _0x51a782 = Array.from(_0x1d8a0a.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x177919 = user_data.journey_details["train-no"];
  const _0x2a2a40 = classTranslator(user_data.journey_details["class"]);
  const _0x20d375 = new Date(user_data.journey_details.date);
  const _0xdb9972 = _0x20d375.toDateString().split(" ")[0x0] + ", " + _0x20d375.toDateString().split(" ")[0x2] + " " + _0x20d375.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x177919);
  console.log("Class:", _0x2a2a40);
  console.log("date", _0xdb9972);
  const _0x3f096d = _0x51a782.find(_0x233ebc => _0x233ebc.querySelector("div.train-heading").innerText.trim().includes(_0x177919.split('-')[0x0]));
  if (!_0x3f096d) {
    console.error("Train not found.");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0x568309 = _0xcc4178 => {
    if (!_0xcc4178) {
      return false;
    }
    const _0x372a29 = window.getComputedStyle(_0xcc4178);
    return "none" !== _0x372a29.display && "hidden" !== _0x372a29.visibility && '0' !== _0x372a29.opacity;
  };
  const _0x1aece6 = Array.from(_0x3f096d.querySelectorAll("table tr td div.pre-avl")).find(_0x1325d8 => _0x1325d8.querySelector('div').innerText.trim() === _0x2a2a40);
  const _0x940cd1 = Array.from(_0x3f096d.querySelectorAll("span")).find(_0x2369ab => _0x2369ab.innerText.trim() === _0x2a2a40);
  const _0x52ae98 = _0x1aece6 || _0x940cd1;
  console.log("FOUND updatedClassToClick:", _0x52ae98);
  if (!_0x52ae98) {
    return void console.error("Class to click not found.");
  }
  const _0x1369f1 = document.querySelector("#loaderP");
  if (_0x568309(_0x1369f1)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0xb09242;
  _0x52ae98.click();
  new MutationObserver((_0x5c720e, _0x233faf) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0xb09242);
    _0xb09242 = setTimeout(() => {
      const _0x4a5ddf = Array.from(_0x3f096d.querySelectorAll("div div table td div.pre-avl")).find(_0x9c04fe => _0x9c04fe.querySelector("div").innerText.trim() === _0xdb9972);
      console.log("FOUND classTabToSelect:", _0x4a5ddf);
      if (_0x4a5ddf) {
        _0x4a5ddf.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          const _0x4f1f6f = () => {
            const _0x3c11e7 = _0x3f096d.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x568309(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0x4f1f6f, 0x64);
            }
            if (!_0x3c11e7 || _0x3c11e7.classList.contains("disable-book") || _0x3c11e7.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              setTimeout(() => {
                _0x3c11e7.click();
                console.log("Clicked on bookBtn");
                clearTimeout(_0xb09242);
                _0x233faf.disconnect();
              }, 0x12c);
            }
          };
          _0x4f1f6f();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x3f096d, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
async function fillPassengerDetails() {
  console.log("passenger_filling_started");
  keyCounter = Date.now();
  if (user_data.journey_details.boarding?.["length"] > 0x0) {
    const _0x2c42d8 = Array.from(document.getElementsByTagName("strong")).find(_0xd2a3a3 => _0xd2a3a3.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x2c42d8) {
      simulateClick(_0x2c42d8);
    }
    addDelay(0x12c);
    const _0x5802d3 = Array.from(document.getElementsByTagName("strong")).find(_0x242863 => _0x242863.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x5802d3) {
      simulateClick(_0x5802d3);
    }
  }
  const _0x217809 = document.querySelector("app-passenger-input");
  if (!_0x217809) {
    return console.error("Passenger app element not found.");
  }
  for (let _0x11880d = 0x1; _0x11880d < user_data.passenger_details.length; _0x11880d++) {
    addDelay(0xc8);
    simulateClick(document.getElementsByClassName("prenext")[0x0]);
  }
  try {
    for (let _0x18611b = 0x0; _0x18611b < user_data.infant_details.length; _0x18611b++) {
      addDelay(0xc8);
      simulateClick(document.getElementsByClassName("prenext")[0x2]);
    }
  } catch (_0xd28921) {
    console.error("Add infant error", _0xd28921);
  }
  const _0x2bd718 = [..._0x217809.querySelectorAll("app-passenger")];
  for (let _0x4b6c4d = 0x0; _0x4b6c4d < user_data.passenger_details.length; _0x4b6c4d++) {
    const _0x368cc1 = user_data.passenger_details[_0x4b6c4d];
    if (!_0x2bd718[_0x4b6c4d]) {
      continue;
    }
    const _0x3cb043 = _0x2bd718[_0x4b6c4d];
    const _0x2cca9c = _0x3cb043.querySelector("p-autocomplete input");
    if (_0x2cca9c) {
      await typeTextHumanLike(_0x2cca9c, _0x368cc1.name);
    }
    const _0x1342b5 = _0x3cb043.querySelector("input[formcontrolname='passengerAge']");
    if (_0x1342b5) {
      await typeTextHumanLike(_0x1342b5, _0x368cc1.age);
    }
    const _0x16dcd = _0x3cb043.querySelector("select[formcontrolname='passengerGender']");
    if (_0x16dcd) {
      _0x16dcd.value = _0x368cc1.gender;
      _0x16dcd.dispatchEvent(new Event("change"));
    }
    const _0x496518 = _0x3cb043.querySelector("select[formcontrolname='passengerBerthChoice']");
    if (_0x496518) {
      _0x496518.value = _0x368cc1.berth;
      _0x496518.dispatchEvent(new Event("change"));
    }
    const _0x458d08 = _0x3cb043.querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x458d08) {
      _0x458d08.value = _0x368cc1.food;
      _0x458d08.dispatchEvent(new Event("change"));
    }
    try {
      const _0x4a0616 = _0x3cb043.querySelector("input[formcontrolname='childBerthFlag']");
      if (_0x4a0616 && _0x368cc1.passengerchildberth !== _0x4a0616.checked) {
        simulateClick(_0x4a0616);
        addDelay(0xc8);
        if (_0x368cc1.passengerchildberth) {
          const _0xe2e27 = _0x3cb043.querySelector("p-dialog app-passenger-confirm-dialog button.btn.btn-primary");
          if (_0xe2e27 && _0xe2e27.offsetParent !== null) {
            simulateClick(_0xe2e27);
            addDelay(0xc8);
          } else {
            const _0x4122fa = _0x3cb043.querySelector("p-dialog p-footer button");
            if (_0x4122fa && _0x4122fa.offsetParent !== null) {
              simulateClick(_0x4122fa);
            }
            addDelay(0xc8);
          }
        }
      }
    } catch (_0x3a2837) {
      console.error("Child berth error", _0x3a2837);
    }
  }
  const _0x3e1b22 = [..._0x217809.querySelectorAll("app-infant")];
  user_data.infant_details.forEach((_0x54f349, _0x3d8e9b) => {
    if (!_0x3e1b22[_0x3d8e9b]) {
      return;
    }
    const _0x438b9e = _0x3e1b22[_0x3d8e9b];
    const _0x4870bb = _0x438b9e.querySelector("input#infant-name");
    if (_0x4870bb) {
      _0x4870bb.value = _0x54f349.name;
      _0x4870bb.dispatchEvent(new Event("input"));
    }
    const _0x576084 = _0x438b9e.querySelector("select[formcontrolname='age']");
    if (_0x576084) {
      _0x576084.value = _0x54f349.age;
      _0x576084.dispatchEvent(new Event("change"));
    }
    const _0xfc05bf = _0x438b9e.querySelector("select[formcontrolname='gender']");
    if (_0xfc05bf) {
      _0xfc05bf.value = _0x54f349.gender;
      _0xfc05bf.dispatchEvent(new Event("change"));
    }
  });
  if (user_data.other_preferences.mobileNumber) {
    const _0x2e3aee = _0x217809.querySelector("input#mobileNumber");
    if (_0x2e3aee) {
      await typeTextHumanLike(_0x2e3aee, user_data.other_preferences.mobileNumber);
    }
  }
  const _0x1bc8d3 = user_data.other_preferences.paymentmethod.includes("UPI") ? '2' : '1';
  const _0x16494e = [..._0x217809.querySelectorAll("p-radiobutton[formcontrolname='paymentType'] input")].find(_0x43b999 => _0x43b999.value === _0x1bc8d3);
  if (_0x16494e) {
    simulateClick(_0x16494e);
  }
  const _0x5d2400 = _0x217809.querySelector("input#autoUpgradation");
  if (_0x5d2400 && user_data.other_preferences.autoUpgradation !== _0x5d2400.checked) {
    simulateClick(_0x5d2400);
  }
  const _0x194246 = _0x217809.querySelector("input#confirmberths");
  if (_0x194246 && user_data.other_preferences.confirmberths !== _0x194246.checked) {
    simulateClick(_0x194246);
  }
  const _0x3d668c = user_data.travel_preferences.travelInsuranceOpted === "yes" ? "true" : 'false';
  const _0x4d187c = [..._0x217809.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input")].find(_0xee51e1 => _0xee51e1.value === _0x3d668c);
  if (_0x4d187c) {
    simulateClick(_0x4d187c);
  }
  try {
    const _0x3ac96e = _0x217809.querySelector("input[formcontrolname='coachId']");
    if (_0x3ac96e && user_data.travel_preferences.prefcoach?.["trim"]()) {
      _0x3ac96e.value = user_data.travel_preferences.prefcoach;
      _0x3ac96e.dispatchEvent(new Event("input"));
    }
    const _0x17f9a9 = _0x217809.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x17f9a9 && user_data.travel_preferences.reservationchoice && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      simulateClick(_0x17f9a9.querySelector("div[role='button']"));
      addDelay(0x12c);
      const _0x3375ce = [..._0x17f9a9.querySelectorAll("ul li")].find(_0x17977d => _0x17977d.innerText === user_data.travel_preferences.reservationchoice);
      if (_0x3375ce) {
        simulateClick(_0x3375ce);
      }
    }
  } catch (_0x46ce93) {
    console.error("Coach/Reservation choice error", _0x46ce93);
  }
  submitPassengerDetailsForm(_0x217809);
}
function submitPassengerDetailsForm(_0x48db16) {
  window.scrollBy(0x0, 0x258, "smooth");
  if (user_data.other_preferences.psgManual) {
    return showCustomAlert("Manually submit passenger page.");
  }
  const _0xd484c7 = () => {
    if (keyCounter > 0x0 && Date.now() - keyCounter > 0x7d0) {
      clearInterval(_0x4caad0);
      let _0x1bb687 = null;
      const _0x2261bb = ["button.train_Search.btnDefault[type='submit']", "button[type='submit'].btn-primary.pull-right", "button.btn.btn-primary.manual-booking-btn", "button.psgn-btn[type='submit']", "button#validate", "button[type='submit']", ".btn-primary", ".btn-success"];
      if (_0x48db16) {
        for (const _0x219f2e of _0x2261bb) {
          const _0x61f9a5 = _0x48db16.querySelector(_0x219f2e);
          if (_0x61f9a5 && _0x61f9a5 && getComputedStyle(_0x61f9a5).display !== "none" && getComputedStyle(_0x61f9a5).visibility !== "hidden" && parseFloat(getComputedStyle(_0x61f9a5).opacity) > 0x0 && !_0x61f9a5.disabled) {
            _0x1bb687 = _0x61f9a5;
            console.log("Passenger page: Found button with selector (scoped): \"" + _0x219f2e + "\"", _0x61f9a5);
            break;
          }
        }
      }
      if (!_0x1bb687) {
        const _0x4d7529 = ["#psgn-form button.train_Search.btnDefault", "button.btnDefault.train_Search"];
        for (const _0x210b0c of _0x4d7529) {
          const _0xc1fcd6 = document.querySelector(_0x210b0c);
          if (_0xc1fcd6 && _0xc1fcd6 && getComputedStyle(_0xc1fcd6).display !== "none" && getComputedStyle(_0xc1fcd6).visibility !== "hidden" && parseFloat(getComputedStyle(_0xc1fcd6).opacity) > 0x0 && !_0xc1fcd6.disabled) {
            _0x1bb687 = _0xc1fcd6;
            console.log("Passenger page: Found button with selector (global): \"" + _0x210b0c + "\"", _0xc1fcd6);
            break;
          }
        }
      }
      if (!_0x1bb687 && _0x48db16) {
        const _0x380183 = _0x48db16.querySelectorAll("button, a.btn");
        for (let _0x28b557 of _0x380183) {
          const _0x39c40c = _0x28b557.innerText?.["trim"]()["toLowerCase"]();
          if (_0x39c40c && (_0x39c40c.includes("continue") || _0x39c40c.includes("proceed") || _0x39c40c.includes("submit") || _0x39c40c.includes("next") || _0x39c40c.includes("payment"))) {
            if (_0x28b557 && getComputedStyle(_0x28b557).display !== "none" && getComputedStyle(_0x28b557).visibility !== "hidden" && parseFloat(getComputedStyle(_0x28b557).opacity) > 0x0 && !_0x28b557.disabled && !_0x39c40c.includes("cancel") && !_0x39c40c.includes('back')) {
              _0x1bb687 = _0x28b557;
              console.log("Passenger page: Found button by text content: ", _0x39c40c, _0x28b557);
              break;
            }
          }
        }
      }
      if (_0x1bb687) {
        console.log("Attempting to click passenger page continue button:", _0x1bb687);
        simulateClick(_0x1bb687);
      } else {
        console.error("Passenger page continue/submit button NOT FOUND with any known strategy.");
        showCustomAlert("Could not find the 'Continue' button on the passenger page. Please click it manually if available.");
      }
    }
  };
  const _0x4caad0 = setInterval(_0xd484c7, 0x1f4);
}
async function continueScript() {
  const _0x4681f0 = document.querySelector("body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if (_0x4681f0 && _0x4681f0.innerText.trim().toUpperCase() === "LOGOUT") {
      console.log("User is logged in. Proceeding to load journey details.");
      loadJourneyDetails();
    } else {
      if (_0x4681f0 && _0x4681f0.innerText.trim().toUpperCase() === "LOGIN") {
        console.log("IRCTC page loaded. LOGIN button found. Starting 15-second countdown...");
        let _0xd72938 = document.getElementById("irctc-login-countdown-element");
        if (!_0xd72938) {
          _0xd72938 = document.createElement("div");
          _0xd72938.id = "irctc-login-countdown-element";
          _0xd72938.style.cssText = "\n                    position: fixed; top: 10px; left: 50%; transform: translateX(-50%);\n                    background-color: rgba(0,0,0,0.7); color: white; padding: 10px 20px;\n                    border-radius: 5px; z-index: 20000; font-size: 16px;\n                ";
          document.body.appendChild(_0xd72938);
        }
        let _0x309f53 = 0xf;
        _0xd72938.textContent = "Voltas Login " + _0x309f53 + " Will Start In Seconds...";
        const _0x214696 = setInterval(async () => {
          _0x309f53--;
          if (_0xd72938) {
            _0xd72938.textContent = "Voltas Login " + _0x309f53 + " Will Start In Seconds...";
          }
          if (_0x309f53 <= 0x0) {
            clearInterval(_0x214696);
            if (_0xd72938 && _0xd72938.parentElement) {
              _0xd72938.remove();
            }
            console.log("Countdown finished. Clicking LOGIN button.");
            simulateClick(_0x4681f0);
            await loadLoginDetails();
          }
        }, 0x3e8);
      } else {
        console.log("LOGIN/LOGOUT link not found or text doesn't match. Waiting for page changes or manual interaction.");
      }
    }
  } else {
    console.log("Not on train-search page. continueScript takes no action.");
  }
}
async function a() {}
window.onload = function () {
  console.log("Content script loaded and window.onload triggered.");
  setInterval(() => statusUpdate("Keep listener alive."), 0x3a98);
  const _0x354ed0 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1");
  if (_0x354ed0) {
    new MutationObserver((_0x1ea41a, _0x1bf86f) => {
      if (_0x1ea41a.some(_0x4e4f9b => _0x4e4f9b.type === "childList" && [..._0x4e4f9b.addedNodes].some(_0x4a039c => _0x4a039c?.["innerText"]?.["trim"]()["toUpperCase"]() === "LOGOUT"))) {
        console.log("LOGOUT detected in header via MutationObserver.");
        _0x1bf86f.disconnect();
        loadJourneyDetails();
      }
    }).observe(_0x354ed0, {
      'childList': true,
      'subtree': false
    });
  } else {
    console.warn("Header div for MutationObserver not found on window.onload.");
  }
  chrome.storage.local.get(null, _0x382b26 => {
    user_data = _0x382b26;
    console.log("User data loaded from storage:", user_data);
    continueScript();
  });
};