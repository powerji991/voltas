/*************************************************************
 * HDFC PAY SCRIPT – NOW UPDATED WITH LOCAL OCR LOGIC
 *************************************************************/

// let user_data = {}; // This line is removed to prevent redeclaration error.
                      // It is assumed user_data is loaded by another script like secure_hdfc.js
GetVpa();

let intervalID = "";
let intervalID1 = "";

// ------------------------------------------------------------------
//  Helper : busy-wait delay (unchanged)
// ------------------------------------------------------------------
function addDelay(milliseconds) {
    const date = Date.now();
    let currentDate = null;
    do {
        currentDate = Date.now();
    } while (currentDate - date < milliseconds);
}

// ------------------------------------------------------------------
//  Main handler for HDFC PG page (unchanged)
// ------------------------------------------------------------------
function hdfcPgHandler() {
    intervalID = setInterval(function () {
        if (!IsInPrograss()) {
            console.log("HDFC bank startt");
            /* document.querySelectorAll(".payment_mode")[0].click();
               addDelay(200);
               document.querySelectorAll("#other_debit")[0].click(); */
        }
    }, 200);

    intervalID1 = setInterval(function () {
        if (!IsInPrograss1()) {
            console.log("Fill data start");

            const cardno = document.getElementById("card_no");
            cardno.value = user_data["other_preferences"]["cardnumber"];
            cardno.dispatchEvent(new Event("input"));
            cardno.dispatchEvent(new Event("change"));

            const name = document.getElementById("name");
            name.value = user_data["other_preferences"]["cardholder"];
            name.dispatchEvent(new Event("input"));
            name.dispatchEvent(new Event("change"));

            const OtherDebitcvvHideShow = document.getElementById("other_debit_cvv_no");
            OtherDebitcvvHideShow.value = user_data["other_preferences"]["cardcvv"];
            OtherDebitcvvHideShow.dispatchEvent(new Event("input"));
            OtherDebitcvvHideShow.dispatchEvent(new Event("change"));

            console.log("exp Month", user_data["other_preferences"]["cardexpiry"].split("/")[0]);
            console.log("exp Year",  user_data["other_preferences"]["cardexpiry"].split("/")[1]);

            const expmonth = document.getElementById("expMonthSelect");
            expmonth.value = Number(user_data["other_preferences"]["cardexpiry"].split("/")[0]);
            expmonth.dispatchEvent(new Event("input"));
            expmonth.dispatchEvent(new Event("change"));

            const expYearSelect = document.getElementById("expYearSelect");
            expYearSelect.value = "20" + user_data["other_preferences"]["cardexpiry"].split("/")[1];
            expYearSelect.dispatchEvent(new Event("input"));
            expYearSelect.dispatchEvent(new Event("change"));

            // --- Kick off captcha solver -------------
            getCaptcha();
            console.log("END");
        }
    }, 200);
}

// ------------------------------------------------------------------
//  Page-readiness helpers (unchanged)
// ------------------------------------------------------------------
function IsInPrograss() {
    // This logic might need adjustment if it relies on other scripts.
    // For now, keeping it as is.
    try {
        console.log("wait for page");
        document.querySelectorAll(".payment_mode")[0].click();
        addDelay(200);
        document.querySelectorAll("#other_debit")[0].click();
        if (document.getElementById("captchaDiv").style.display != "none") {
            console.log("Page loaded.");
            clearInterval(intervalID);
            return false;
        }
    } catch (e) {
        // Suppress errors if elements are not found immediately
    }
    return true;
}
function IsInPrograss1() {
    console.log("wait for captcha page");
    if (document.getElementById("captchaDiv") && document.getElementById("captchaDiv").style.display != "none") {
        console.log("captcha Page loaded.");
        clearInterval(intervalID1);
        return false;
    }
    return true;
}

// ------------------------------------------------------------------
//  Load user data from chrome.storage (unchanged)
// ------------------------------------------------------------------
function GetVpa() {
    console.log("GetVpa");
    // Ensure user_data is only loaded if not already present.
    if (typeof user_data === 'undefined' || Object.keys(user_data).length === 0) {
        chrome.storage.local.get(null, (result) => {
            user_data = result;
            if (document.readyState !== "loading") {
                hdfcPgHandler();
            } else {
                document.addEventListener("DOMContentLoaded", function () {
                    hdfcPgHandler();
                });
            }
        });
    } else {
        if (document.readyState !== "loading") {
            hdfcPgHandler();
        } else {
            document.addEventListener("DOMContentLoaded", function () {
                hdfcPgHandler();
            });
        }
    }
}


// ==================================================================
//  START: NEW LOCAL OCR SOLVER
// ==================================================================
let captchaRetry = 0;

async function getCaptcha() {
    // Manual mode (if explicitly disabled in preferences)
    if (user_data?.other_preferences?.autoCaptcha === false) {
        console.log("[Captcha] मैन्युअल मोड – इनपुट फ़ील्ड पर फ़ोकस।");
        document.getElementById("capacha")?.focus();
        return;
    }
    if (captchaRetry >= 100) {
        return;
    }
    captchaRetry++;
    const captchaImg = document.querySelector('.captcha-img') || document.getElementById('captcha_image');
    if (!captchaImg || !captchaImg.src || captchaImg.src.length < 23) {
        setTimeout(getCaptcha, 1000);
        return;
    }
    const xhr = new XMLHttpRequest();
    // Use the full image src for TrueCaptcha
    const imgData = captchaImg.src;
    const payload = JSON.stringify({
        'client': "chrome extension",
        'location': "https://www.irctc.co.in/nget/train-search",
        'version': "0.3.8",
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': 'AVINASH',
        'apikey': "p8pY7iIitCprCYtem9xP",
        'data': imgData
    });
    xhr.open('POST', 'https://api.apitruecaptcha.org/one/gettext', true);
    xhr.onload = async () => {
        if (xhr.status !== 200) {
            console.error("TrueCaptcha API Error " + xhr.status + ": " + xhr.statusText, xhr.response);
            return;
        }
        try {
            const response = JSON.parse(xhr.responseText);
            let result = response.result || '';
            let filtered = '';
            for (const ch of String(result).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) {
                if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(ch)) {
                    filtered += ch;
                }
            }
            const inField = document.getElementById("capacha");
            if (inField) {
                inField.value = filtered;
                inField.dispatchEvent(new Event("input", { bubbles: true }));
                inField.dispatchEvent(new Event("change", { bubbles: true }));
                inField.focus();
            }
            if (!filtered) {
                console.log("[Captcha] Blank decode, reloading captcha...");
                document.getElementById("reload")?.click();
                return setTimeout(getCaptcha, 500);
            }
            // auto-submit (always, because payment page)
            document.getElementById("submit_btn")?.click();
        } catch (err) {
            console.error("[Captcha] Solver threw error:", err);
            setTimeout(getCaptcha, 1000);
        }
    };
    xhr.onerror = () => {
        console.error("[Captcha] TrueCaptcha API network error");
        setTimeout(getCaptcha, 1000);
    };
    xhr.send(payload);
}

// ==================================================================
//  END: NEW LOCAL OCR SOLVER
// ==================================================================


/* // ==================================================================
//  START: COMMENTED OUT OLD VPS-BASED CAPTCHA CODE
// ==================================================================
let captchaRetry = 0;          // max 100 attempts

async function getCaptchaTC() {
    if (captchaRetry >= 100) return;
    captchaRetry++;

    console.log("[Captcha] Attempt", captchaRetry, "- solving via TrueCaptcha VPS...");

    const captchaImg = document.getElementById("captcha_image");
    if (!captchaImg || !captchaImg.src) {
        console.log("[Captcha] Image not yet ready, retrying...");
        return setTimeout(getCaptchaTC, 1000);
    }

    try {
        // fetch image → blob → base64
        const blob = await fetch(captchaImg.src).then(res => res.blob());
        const base64 = await new Promise(resolve => {
            const fr = new FileReader();
            fr.onloadend = () => resolve(fr.result);
            fr.readAsDataURL(blob);
        });

        const imgContent = base64.replace(/^data:image\/(png|jpg|jpeg|gif);base64,/, "");

        const resp = await fetch("https://aa1b-43-240-4-108.ngrok-free.app/solve-truecaptcha", {
            method : "POST",
            headers: { "Content-Type": "application/json" },
            body   : JSON.stringify({ imageContent: imgContent })
        });

        if (!resp.ok) {
            console.error("[Captcha] VPS error:", await resp.text());
            return setTimeout(getCaptchaTC, 1000);
        }

        const data = await resp.json();
        let captchaText   = data.result || "";
        let filteredText  = "";
        const allowedChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@";

        for (const ch of String(captchaText).replace(/\s/g,"").replace(")", "J").replace("]", "J")) {
            if (allowedChar.includes(ch)) filteredText += ch;
        }

        console.log("[Captcha] Decoded →", filteredText || "(empty)");

        const inField = document.getElementById("capacha");
        if (inField) {
            inField.value = filteredText;
            inField.dispatchEvent(new Event("input"));
            inField.dispatchEvent(new Event("change"));
            inField.focus();
        }

        if (!filteredText) {
            console.log("[Captcha] Blank decode, reloading captcha...");
            document.getElementById("reload")?.click();
            return setTimeout(getCaptchaTC, 500);
        }

        // auto-submit (always, because payment page)
        document.getElementById("submit_btn")?.click();

    } catch (err) {
        console.error("[Captcha] Solver threw error:", err);
        setTimeout(getCaptchaTC, 1000);
    }
}
// ==================================================================
//  END: COMMENTED OUT OLD VPS-BASED CAPTCHA CODE
// ==================================================================
*/