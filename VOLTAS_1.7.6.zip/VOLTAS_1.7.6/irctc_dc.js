// irctc_dc.js

// सहायक फ़ंक्शन: मानव-जैसी टाइपिंग का अनुकरण करने के लिए
// यह फ़ंक्शन content_script.js से लिया गया है ताकि यह सुनिश्चित हो सके कि इनपुट सही ढंग से काम करे
async function typeTextHumanLike(element, text) {
    if (!element || typeof text !== 'string') {
        console.warn("Human-like typing के लिए एलिमेंट या टेक्स्ट नहीं मिला।");
        return;
    }
    element.focus();
    element.value = '';
    element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));

    for (const char of text) {
        element.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true, cancelable: true }));
        element.value += char;
        element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true, cancelable: true }));
        await new Promise(resolve => setTimeout(resolve, Math.random() * 80 + 40)); // थोड़ा विलंब
    }
    element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
}

// यह मुख्य फ़ंक्शन है जो यह जांचता है कि सही भुगतान मोड चुना गया है या नहीं
function automateDebitCardFlow() {
    chrome.storage.local.get('other_preferences', (data) => {
        const paymentMethod = data.other_preferences ? data.other_preferences.paymentmethod : null;

        if (paymentMethod === 'irctc_dc') {
            console.log("IPAY DC (irctc_dc) मोड सक्रिय। विवरण भरा जा रहा है।");
            fillDebitCardDetails(data.other_preferences);
        }
    });
}

// यह फ़ंक्शन अब मानव-जैसी टाइपिंग का उपयोग करके डेबिट कार्ड फॉर्म को भरता है
async function fillDebitCardDetails(prefs) { // इस फ़ंक्शन को 'async' बनाया गया है
    // आपके द्वारा प्रदान किए गए चयनकर्ताओं का उपयोग
    const cardNumber = document.querySelector('#mndtCardNo');
    const mandateDate = document.querySelector('#mandateDate');
    const mandateCvv = document.querySelector('#mandateCvv');
    const mandateName = document.querySelector('#mandateName');
    const payBtn = document.querySelector('#autoDebitBtn');

    // मानव-जैसी टाइपिंग का उपयोग करके फ़ील्ड भरना
    if (cardNumber && prefs.cardnumber) {
        const cleanCardNumber = prefs.cardnumber.replace(/\D/g, '');
        const formattedCardNumber = cleanCardNumber.match(/.{1,4}/g)?.join(' ') || '';
        await typeTextHumanLike(cardNumber, formattedCardNumber); //
    }
    if (mandateDate && prefs.cardexpiry) {
        await typeTextHumanLike(mandateDate, prefs.cardexpiry); //
    }
    if (mandateCvv && prefs.cardcvv) {
        await typeTextHumanLike(mandateCvv, prefs.cardcvv); //
    }
    if (mandateName && prefs.cardholder) {
        await typeTextHumanLike(mandateName, prefs.cardholder); //
    }

    // 'Pay' बटन पर क्लिक करना
    if (payBtn && !prefs.paymentManual) { //
        setTimeout(() => {
            payBtn.click();
            console.log("Pay बटन पर क्लिक किया गया!");
        }, 500); // 1.5 सेकंड का विलंब
    } else if (!payBtn) {
        console.log("Pay बटन नहीं मिला!");
    }
}

// जब पेज लोड हो तो स्वचालन शुरू करें
automateDebitCardFlow();