const _0x393671 = function () {
  let _0x38ecb0 = true;
  return function (_0x2fd8aa, _0x19298b) {
    const _0x4ee7d2 = _0x38ecb0 ? function () {
      if (_0x19298b) {
        const _0x43fce1 = _0x19298b.apply(_0x2fd8aa, arguments);
        _0x19298b = null;
        return _0x43fce1;
      }
    } : function () {};
    _0x38ecb0 = false;
    return _0x4ee7d2;
  };
}();
const _0x552cba = _0x393671(this, function () {
  let _0x52e10e;
  try {
    const _0x36af8f = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x52e10e = _0x36af8f();
  } catch (_0x4f107c) {
    _0x52e10e = window;
  }
  const _0xe607b8 = _0x52e10e.console = _0x52e10e.console || {};
  const _0x33bfc9 = ["log", 'warn', "info", "error", "exception", "table", "trace"];
  for (let _0x3a287d = 0x0; _0x3a287d < _0x33bfc9.length; _0x3a287d++) {
    const _0x2bb136 = _0x393671.constructor.prototype.bind(_0x393671);
    const _0x46ed33 = _0x33bfc9[_0x3a287d];
    const _0x4433e1 = _0xe607b8[_0x46ed33] || _0x2bb136;
    _0x2bb136.__proto__ = _0x393671.bind(_0x393671);
    _0x2bb136.toString = _0x4433e1.toString.bind(_0x4433e1);
    _0xe607b8[_0x46ed33] = _0x2bb136;
  }
});
_0x552cba();
function showCustomAlert(_0xa9bc2c) {
  const _0x43493c = document.createElement("div");
  _0x43493c.id = "custom-alert";
  _0x43493c.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    ";
  _0x43493c.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0xa9bc2c + "</p>\n        <button id=\"custom-alert-ok\" class=\"px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600\">OK</button>\n    ";
  document.body.appendChild(_0x43493c);
  document.getElementById("custom-alert-ok").onclick = () => {
    _0x43493c.remove();
  };
}
function showCustomConfirm(_0x5c176e, _0x115644, _0x3a574b) {
  const _0x1f9af0 = document.createElement("div");
  _0x1f9af0.id = "custom-confirm";
  _0x1f9af0.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    ";
  _0x1f9af0.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x5c176e + "</p>\n        <button id=\"custom-confirm-yes\" class=\"px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2\">Yes</button>\n        <button id=\"custom-confirm-no\" class=\"px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600\">No</button>\n    ";
  document.body.appendChild(_0x1f9af0);
  document.getElementById("custom-confirm-yes").onclick = () => {
    _0x1f9af0.remove();
    if (_0x115644) {
      _0x115644();
    }
  };
  document.getElementById("custom-confirm-no").onclick = () => {
    _0x1f9af0.remove();
    if (_0x3a574b) {
      _0x3a574b();
    }
  };
}
let finalData = {
  'irctc_credentials': {},
  'subs_credentials': {},
  'journey_details': {},
  'passenger_details': [],
  'infant_details': [],
  'travel_preferences': {},
  'other_preferences': {},
  'vpa': {},
  'fare_limit': {
    'enableFareLimit': false,
    'maxFareAmount': '',
    'bookInPopup': false
  },
  'proxy_settings': {
    'activeProxy': "disabled",
    'proxies': Array(0x5).fill(null).map(() => ({
      'ip': '',
      'port': '',
      'user': '',
      'pass': ''
    }))
  }
};
function autocompleteSourcDstTrain(_0x43f036, _0x232f66, _0x445354) {
  var _0x8beb8f;
  function _0x554e84(_0x4bfc71) {
    if (!_0x4bfc71) {
      return false;
    }
    !function (_0x410621) {
      for (var _0x458aca = 0x0; _0x458aca < _0x410621.length; _0x458aca++) {
        _0x410621[_0x458aca].classList.remove("autocomplete-active");
      }
    }(_0x4bfc71);
    if (_0x8beb8f >= _0x4bfc71.length) {
      _0x8beb8f = 0x0;
    }
    if (_0x8beb8f < 0x0) {
      _0x8beb8f = _0x4bfc71.length - 0x1;
    }
    _0x4bfc71[_0x8beb8f].classList.add("autocomplete-active");
  }
  function _0x3dfc9c(_0x5110eb) {
    var _0x3a7d39 = document.getElementsByClassName("autocomplete-items");
    for (var _0x2e3130 = 0x0; _0x2e3130 < _0x3a7d39.length; _0x2e3130++) {
      if (_0x5110eb != _0x3a7d39[_0x2e3130] && _0x5110eb != _0x43f036) {
        _0x3a7d39[_0x2e3130].parentNode.removeChild(_0x3a7d39[_0x2e3130]);
      }
    }
  }
  _0x43f036.addEventListener("input", function (_0x76acdf) {
    var _0x1c7db7;
    var _0x7cf7e;
    var _0x2dec90;
    var _0x309634 = this.value;
    _0x3dfc9c();
    if (!_0x309634) {
      return false;
    }
    _0x8beb8f = -0x1;
    (_0x1c7db7 = document.createElement("DIV")).setAttribute('id', this.id + "autocomplete-list");
    _0x1c7db7.setAttribute('class', "autocomplete-items");
    this.parentNode.appendChild(_0x1c7db7);
    for (_0x2dec90 = 0x0; _0x2dec90 < _0x232f66.length; _0x2dec90++) {
      if (_0x232f66[_0x2dec90].toUpperCase().includes(_0x309634.toUpperCase())) {
        (_0x7cf7e = document.createElement("DIV")).innerHTML = "<strong>" + _0x232f66[_0x2dec90].substr(0x0, _0x309634.length) + "</strong>";
        _0x7cf7e.innerHTML += _0x232f66[_0x2dec90].substr(_0x309634.length);
        _0x7cf7e.innerHTML += "<input type='hidden' value='" + _0x232f66[_0x2dec90] + "'>";
        _0x7cf7e.addEventListener("click", function (_0x5a49c7) {
          _0x43f036.value = this.getElementsByTagName("input")[0x0].value;
          if ("SOURCE" == _0x445354) {
            finalData.journey_details.from = this.getElementsByTagName("input")[0x0].value;
          }
          if ("DEST" == _0x445354) {
            finalData.journey_details.destination = this.getElementsByTagName("input")[0x0].value;
          }
          if ("TRAIN" == _0x445354) {
            const _0x3bf3ca = this.getElementsByTagName("input")[0x0].value;
            finalData.journey_details["train-no"] = _0x3bf3ca.trim();
          }
          if ("BOARDING" == _0x445354) {
            finalData.journey_details.boarding = this.getElementsByTagName("input")[0x0].value;
          }
          _0x3dfc9c();
        });
        _0x1c7db7.appendChild(_0x7cf7e);
      }
    }
  });
  _0x43f036.addEventListener("keydown", function (_0xd244e6) {
    var _0x48f07c = document.getElementById(this.id + "autocomplete-list");
    if (_0x48f07c) {
      _0x48f07c = _0x48f07c.getElementsByTagName("div");
    }
    if (0x28 == _0xd244e6.keyCode) {
      _0x8beb8f++;
      _0x554e84(_0x48f07c);
    } else if (0x26 == _0xd244e6.keyCode) {
      _0x8beb8f--;
      _0x554e84(_0x48f07c);
    } else if (0xd == _0xd244e6.keyCode) {
      _0xd244e6.preventDefault();
      if (_0x8beb8f > -0x1 && _0x48f07c) {
        _0x48f07c[_0x8beb8f].click();
      }
    }
  });
  document.addEventListener("click", function (_0x37de4d) {
    _0x3dfc9c(_0x37de4d.target);
  });
}
const stationData = [];
const stationList = [];
async function fetchStationData() {
  try {
    const _0x20315c = await fetch("https://suryarajputg.github.io/accet/stationlist.json");
    if (!_0x20315c.ok) {
      showCustomAlert("Unable to fetch station data", "HTTP error! status: " + _0x20315c.status);
      throw new Error("Unable to fetch station data", "HTTP error! status: " + _0x20315c.status);
    }
    const _0x2e5302 = await _0x20315c.json();
    stationData.push(..._0x2e5302);
    for (let _0x4195f8 in stationData) stationList.push(stationData[_0x4195f8].name + " - " + stationData[_0x4195f8].code);
    return stationList;
  } catch (_0x4d703d) {
    console.error("Station data fetching error:", _0x4d703d);
    showCustomAlert("Station data fetching error:", _0x4d703d);
    throw _0x4d703d;
  }
}
async function fetchTrainData() {
  try {
    const _0x4a4bee = await fetch("https://suryarajputg.github.io/accet/train_data.js");
    if (!_0x4a4bee.ok) {
      showCustomAlert("Unable to fetch train data", "HTTP error! status: " + _0x4a4bee.status);
      throw new Error("Unable to fetch train data", "HTTP error! status: " + _0x4a4bee.status);
    }
    return (await _0x4a4bee.text()).split(/\r?\n/);
  } catch (_0x3ba558) {
    console.error("Train data fetching error:", _0x3ba558);
    showCustomAlert("Train data fetching error:", _0x3ba558);
    throw _0x3ba558;
  }
}
function setIRCTCUsername(_0xe8a4a9) {
  if (!finalData.irctc_credentials) {
    finalData.irctc_credentials = {};
  }
  finalData.irctc_credentials.user_name = _0xe8a4a9.target.value;
  console.log("data-update", finalData);
}
function setIRCTCPassword(_0x1ff909) {
  finalData.irctc_credentials.password = _0x1ff909.target.value;
  console.log("data-update", finalData);
}
function setSubsUsername(_0x4eb2c7) {
  if (!finalData.subs_credentials) {
    finalData.subs_credentials = {};
  }
  finalData.subs_credentials.user_name = _0x4eb2c7.target.value;
  console.log("data-update", finalData);
}
function setSubsPassword(_0x459597) {
  finalData.subs_credentials.password = _0x459597.target.value;
  console.log("data-update", finalData);
}
function setFromStation(_0x393758) {
  finalData.journey_details.from = _0x393758.target.value.toUpperCase();
  document.querySelector("#from-station-input").value = _0x393758.target.value;
}
function setDestinationStation(_0x10beaa) {
  finalData.journey_details.destination = _0x10beaa.target.value.toUpperCase();
  document.querySelector("#destination-station-input").value = _0x10beaa.target.value;
}
function setBoardingStation(_0x4943d4) {
  finalData.journey_details.boarding = _0x4943d4.target.value.toUpperCase();
  document.querySelector("#boarding-station-input").value = _0x4943d4.target.value;
}
function setJourneyClass(_0x31bed1) {
  finalData.journey_details['class'] = _0x31bed1.target.value;
  document.querySelector("#journey-class-input").value = _0x31bed1.target.value;
}
function setQuota(_0x168d37) {
  finalData.journey_details.quota = _0x168d37.target.value;
  document.querySelector("#quota-input").value = _0x168d37.target.value;
}
function journeyDateChanged(_0x5788d2) {
  finalData.journey_details.date = _0x5788d2.target.value;
}
function setTrainNumber(_0x367cdb) {
  finalData.journey_details["train-no"] = _0x367cdb.target.value;
}
function setPassengerDetails(_0x507cc5, _0x2b1b4a, _0x97059d) {
  if (!finalData.passenger_details[_0x2b1b4a]) {
    finalData.passenger_details[_0x2b1b4a] = {};
  }
  finalData.passenger_details[_0x2b1b4a][_0x507cc5.target.name] = "checkbox" === _0x507cc5.target.type ? _0x507cc5.target.checked : _0x507cc5.target.value;
}
function setInfantDetails(_0x2726e1, _0x3fb150, _0x2747a0) {
  if (!finalData.infant_details[_0x3fb150]) {
    finalData.infant_details[_0x3fb150] = {};
  }
  finalData.infant_details[_0x3fb150][_0x2726e1.target.name] = _0x2726e1.target.value;
}
function setOtherPreferences(_0x5786c4) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x5786c4.target.name] = "checkbox" === _0x5786c4.target.type ? _0x5786c4.target.checked : _0x5786c4.target.value;
}
function setAutoCaptcha(_0xf161b0) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0xf161b0.target.name] = "checkbox" === _0xf161b0.target.type ? _0xf161b0.target.checked : _0xf161b0.target.value;
}
function setOtherPreferencesVpa(_0x152cee) {
  if (!finalData.vpa) {
    finalData.vpa = {};
  }
  finalData.vpa[_0x152cee.target.name] = _0x152cee.target.value;
}
function setpaymentMethod(_0x32884c) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.paymentmethod = _0x32884c.target.value;
}
function setCaptchaSubmitMode(_0x56f906) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.CaptchaSubmitMode = _0x56f906.target.value;
}
function setCardDetails(_0x1df195) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  if ("cardnumber" == _0x1df195.target.name) {
    finalData.other_preferences[_0x1df195.target.name] = _0x1df195.target.value;
  }
  if ("cardexpiry" == _0x1df195.target.name) {
    finalData.other_preferences[_0x1df195.target.name] = _0x1df195.target.value;
  }
  if ("cardcvv" == _0x1df195.target.name) {
    finalData.other_preferences[_0x1df195.target.name] = _0x1df195.target.value;
  }
  if ("cardholder" == _0x1df195.target.name) {
    finalData.other_preferences[_0x1df195.target.name] = _0x1df195.target.value;
  }
  if ("staticpassword" == _0x1df195.target.name) {
    finalData.other_preferences[_0x1df195.target.name] = _0x1df195.target.value;
  }
}
function setOtherPreferencesbooktime(_0x37ea4a) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x37ea4a.target.name] = _0x37ea4a.target.value;
}
function setcardtype(_0xa1e349) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0xa1e349.target.name] = _0xa1e349.target.value;
}
function setMobileNumber(_0x5aeeef) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x5aeeef.target.name] = _0x5aeeef.target.value;
}
function setTravelPreferences(_0x15e7a5) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x15e7a5.target.name] = "checkbox" === _0x15e7a5.target.type ? _0x15e7a5.target.checked : _0x15e7a5.target.value;
}
function setAvailabilyCheck(_0x3046c0) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x3046c0.target.name] = "checkbox" === _0x3046c0.target.type ? _0x3046c0.target.checked : _0x3046c0.target.value;
}
function setIrctcWallet(_0x23c0a5) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x23c0a5.target.name] = "checkbox" === _0x23c0a5.target.type ? _0x23c0a5.target.checked : _0x23c0a5.target.value;
}
function setTokenString(_0x1472f3) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x1472f3.target.name] = _0x1472f3.target.value;
}
function setprojectId(_0x10ee7c) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x10ee7c.target.name] = _0x10ee7c.target.value;
}
function setFareLimitPreferences(_0x3b663d) {
  if (!finalData.fare_limit) {
    finalData.fare_limit = {
      'enableFareLimit': false,
      'maxFareAmount': '',
      'bookInPopup': false
    };
  }
  finalData.fare_limit[_0x3b663d.target.name] = "checkbox" === _0x3b663d.target.type ? _0x3b663d.target.checked : _0x3b663d.target.value;
  console.log("fare_limit-update", finalData);
}
function isValid_UPI_ID(_0x2ce175) {
  let _0x78e26f = new RegExp("^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$");
  return null != _0x2ce175 && 0x1 == _0x78e26f.test(_0x2ce175);
}
function modifyUserData(_0x39d236 = true) {
  console.log("before modifyUserData", finalData);
  finalData.passenger_details = finalData.passenger_details?.["filter"](_0x1ccd8a => _0x1ccd8a.name?.["length"] > 0x0 && _0x1ccd8a.age?.["length"] > 0x0)?.["map"](_0x379c19 => ({
    'name': _0x379c19.name,
    'age': _0x379c19.age,
    'gender': _0x379c19.gender ?? 'M',
    'berth': _0x379c19.berth ?? '',
    'nationality': 'IN',
    'food': _0x379c19.food ?? 'D',
    'passengerchildberth': _0x379c19.passengerchildberth ?? false
  })) ?? [];
  finalData.infant_details = finalData.infant_details?.["filter"](_0x61af14 => _0x61af14.name?.["length"] > 0x0)?.['map'](_0x56ea5d => ({
    'name': _0x56ea5d.name,
    'age': _0x56ea5d.age ?? '0',
    'gender': _0x56ea5d.gender ?? 'M'
  })) ?? [];
  finalData.other_preferences = finalData.other_preferences || {};
  finalData.journey_details = finalData.journey_details || {};
  finalData.travel_preferences = finalData.travel_preferences || {};
  finalData.fare_limit = finalData.fare_limit || {};
  finalData.vpa = finalData.vpa || {};
  if (finalData.other_preferences.slbooktime == null) {
    finalData.other_preferences.slbooktime = document.getElementById("slbooktime").value;
  }
  if (finalData.other_preferences.acbooktime == null) {
    finalData.other_preferences.acbooktime = document.getElementById("acbooktime").value;
  }
  if (finalData.other_preferences.gnbooktime == null) {
    finalData.other_preferences.gnbooktime = document.getElementById("gnbooktime").value;
  }
  if (finalData.journey_details['class'] == null) {
    finalData.journey_details["class"] = document.getElementById("journey-class-input").value;
  }
  if (finalData.journey_details.quota == null) {
    finalData.journey_details.quota = document.getElementById("quota-input").value;
  }
  if (('TQ' === finalData.journey_details.quota || 'PT' === finalData.journey_details.quota) && finalData.passenger_details.length > 0x4) {
    showCustomAlert("Maximum 4 passengers allowed for Tatkal quota.");
    return false;
  }
  if (finalData.journey_details.boarding == null) {
    finalData.journey_details.boarding = '';
  }
  if (document.getElementById("boarding-station-input").value === '') {
    finalData.journey_details.boarding = '';
  }
  if (finalData.other_preferences.tokenString == null) {
    finalData.other_preferences.tokenString = document.getElementById("tokenString") ? document.getElementById("tokenString").value : '';
  }
  if (finalData.other_preferences.projectId == null) {
    finalData.other_preferences.projectId = document.getElementById("projectId") ? document.getElementById("projectId").value : '';
  }
  if (finalData.other_preferences.mobileNumber == null) {
    finalData.other_preferences.mobileNumber = document.getElementById("mobileNumber").value;
  }
  if (finalData.other_preferences.paymentmethod == null) {
    finalData.other_preferences.paymentmethod = document.getElementById("paymentMethod").value;
  }
  const _0x5636de = document.getElementById("paymentMethod");
  const _0x686a86 = document.getElementById('vpa');
  if (_0x5636de && _0x5636de.value.includes("UPIID")) {
    if (!isValid_UPI_ID(_0x686a86 ? _0x686a86.value : '')) {
      showCustomAlert("Valid UPI ID is required for selected payment method.");
      return false;
    }
  }
  if (finalData.other_preferences.CaptchaSubmitMode == null) {
    finalData.other_preferences.CaptchaSubmitMode = document.getElementById("CaptchaSubmitMode").value;
  }
  if (finalData.other_preferences.cardnumber == null) {
    finalData.other_preferences.cardnumber = document.getElementById("cardnumber").value;
  }
  if (finalData.other_preferences.cardexpiry == null) {
    finalData.other_preferences.cardexpiry = document.getElementById("cardexpiry").value;
  }
  if (finalData.other_preferences.cardcvv == null) {
    finalData.other_preferences.cardcvv = document.getElementById("cardcvv").value;
  }
  if (finalData.other_preferences.cardholder == null) {
    finalData.other_preferences.cardholder = document.getElementById("cardholder").value;
  }
  if (finalData.other_preferences.cardtype == null) {
    finalData.other_preferences.cardtype = document.getElementById("cardtype").value;
  }
  if (finalData.other_preferences.staticpassword == null) {
    finalData.other_preferences.staticpassword = document.getElementById("staticpassword").value;
  }
  const _0x2401d2 = document.getElementsByName("AvailabilityCheck");
  let _0x1dc532 = 'A';
  for (const _0x5775e1 of _0x2401d2) {
    if (_0x5775e1.checked) {
      _0x1dc532 = _0x5775e1.value;
      break;
    }
  }
  if (finalData.travel_preferences.AvailabilityCheck == null) {
    finalData.travel_preferences.AvailabilityCheck = _0x1dc532;
  }
  if (finalData.journey_details["train-no"] == null || finalData.journey_details["train-no"].trim() === '') {
    finalData.journey_details["train-no"] = "00000- DEFAULT";
  }
  if (finalData.fare_limit.enableFareLimit == null) {
    finalData.fare_limit.enableFareLimit = document.getElementById("enableFareLimit").checked;
  }
  if (finalData.fare_limit.maxFareAmount == null) {
    finalData.fare_limit.maxFareAmount = document.getElementById("maxFareAmount").value;
  }
  if (finalData.fare_limit.bookInPopup == null) {
    finalData.fare_limit.bookInPopup = document.getElementById("bookInPopup").checked;
  }
  finalData.proxy_settings = {
    'activeProxy': "disabled",
    'proxies': []
  };
  const _0x23573b = document.querySelector("input[name=\"proxySelection\"]:checked");
  if (_0x23573b) {
    finalData.proxy_settings.activeProxy = _0x23573b.value;
  }
  for (let _0x1362ab = 0x0; _0x1362ab < 0x5; _0x1362ab++) {
    const _0x42240e = _0x1362ab + 0x1;
    const _0x20b3f8 = document.getElementById("proxy-ip-" + _0x42240e);
    const _0x55b4bc = document.getElementById("proxy-port-" + _0x42240e);
    const _0x57f736 = document.getElementById("proxy-user-" + _0x42240e);
    const _0x4e75eb = document.getElementById("proxy-pass-" + _0x42240e);
    finalData.proxy_settings.proxies.push({
      'ip': _0x20b3f8 ? _0x20b3f8.value.trim() : '',
      'port': _0x55b4bc ? _0x55b4bc.value.trim() : '',
      'user': _0x57f736 ? _0x57f736.value.trim() : '',
      'pass': _0x4e75eb ? _0x4e75eb.value.trim() : ''
    });
  }
  console.log("after modifyUserData", finalData);
  chrome.storage.local.set(finalData);
  chrome.runtime.sendMessage({
    'action': "updateProxy"
  }, function (_0x49ff68) {
    if (chrome.runtime.lastError) {
      console.warn("Error sending updateProxy message:", chrome.runtime.lastError.message);
    } else {
      console.log("updateProxy message sent, response:", _0x49ff68);
    }
  });
  if (_0x39d236) {
    showCustomAlert("Data saved successfully");
  }
  return true;
}
function loadUserData() {
  chrome.storage.local.get(null, _0x3cd1c2 => {
    if (0x0 !== Object.keys(_0x3cd1c2).length) {
      if (_0x3cd1c2.irctc_credentials != null) {
        document.querySelector("#irctc-login").value = _0x3cd1c2.irctc_credentials.user_name;
        document.querySelector("#irctc-password").value = _0x3cd1c2.irctc_credentials.password;
        document.querySelector("#from-station-input").value = _0x3cd1c2.journey_details.from;
        document.querySelector("#destination-station-input").value = _0x3cd1c2.journey_details.destination;
        document.querySelector("#boarding-station-input").value = _0x3cd1c2.journey_details.boarding;
        document.querySelector("#journey-date").value = _0x3cd1c2.journey_details.date;
        document.querySelector("#journey-class-input").value = _0x3cd1c2.journey_details["class"];
        document.querySelector("#quota-input").value = _0x3cd1c2.journey_details.quota;
        document.querySelector("#train-no").value = '' + _0x3cd1c2.journey_details["train-no"];
        _0x3cd1c2.passenger_details.forEach((_0x3d5549, _0x532c38) => {
          document.querySelector("#passenger-name-" + (_0x532c38 + 0x1)).value = _0x3d5549.name ?? '';
          document.querySelector('#age-' + (_0x532c38 + 0x1)).value = _0x3d5549.age ?? '';
          document.querySelector("#passenger-gender-" + (_0x532c38 + 0x1)).value = _0x3d5549.gender ?? 'M';
          document.querySelector("#passenger-berth-" + (_0x532c38 + 0x1)).value = _0x3d5549.berth ?? '';
          document.querySelector("#passenger-food-" + (_0x532c38 + 0x1)).value = _0x3d5549.food ?? '';
          document.querySelector("#passengerchildberth" + (_0x532c38 + 0x1)).checked = _0x3d5549.passengerchildberth ?? false;
        });
        if (_0x3cd1c2.infant_details) {
          _0x3cd1c2.infant_details.forEach((_0x58a934, _0x263131) => {
            document.querySelector("#Infant-name-" + (_0x263131 + 0x1)).value = _0x58a934.name ?? '';
            document.querySelector("#Infant-age-" + (_0x263131 + 0x1)).value = _0x58a934.age ?? '0';
            document.querySelector("#Infant-gender-" + (_0x263131 + 0x1)).value = _0x58a934.gender ?? 'M';
          });
        }
        if (_0x3cd1c2.travel_preferences?.["travelInsuranceOpted"]) {
          const _0x3c42df = _0x3cd1c2.travel_preferences.travelInsuranceOpted === "yes" ? '1' : '2';
          const _0x353937 = document.querySelector("#travelInsuranceOpted-" + _0x3c42df);
          if (_0x353937) {
            _0x353937.checked = true;
          }
        }
        if (_0x3cd1c2.travel_preferences?.["prefcoach"]) {
          document.querySelector("#prefcoach").value = _0x3cd1c2.travel_preferences.prefcoach ?? '';
        }
        if (_0x3cd1c2.travel_preferences?.["reservationchoice"]) {
          document.querySelector("#reservationchoice").value = _0x3cd1c2.travel_preferences.reservationchoice ?? '';
        }
        try {
          if (_0x3cd1c2.travel_preferences?.["AvailabilityCheck"]) {
            const _0x559f69 = _0x3cd1c2.travel_preferences.AvailabilityCheck;
            let _0x16d784;
            if (_0x559f69 === 'A') {
              _0x16d784 = 0x1;
            } else {
              if (_0x559f69 === 'M') {
                _0x16d784 = 0x2;
              } else {
                if (_0x559f69 === 'I') {
                  _0x16d784 = 0x3;
                } else {
                  _0x16d784 = 0x1;
                }
              }
            }
            const _0x30988c = document.querySelector("#AvailabilityCheck-" + _0x16d784);
            if (_0x30988c) {
              _0x30988c.checked = true;
            }
          } else {
            const _0x335a51 = document.querySelector("#AvailabilityCheck-1");
            if (_0x335a51) {
              _0x335a51.checked = true;
            }
          }
        } catch (_0x26b49e) {
          console.log("Error setting availability check from storage", _0x26b49e);
          const _0x146e9d = document.querySelector("#AvailabilityCheck-1");
          if (_0x146e9d) {
            _0x146e9d.checked = true;
          }
        }
        if (_0x3cd1c2.other_preferences && Object.keys(_0x3cd1c2.other_preferences).length > 0x0) {
          document.querySelector("#autoUpgradation").checked = _0x3cd1c2.other_preferences.autoUpgradation ?? false;
          document.querySelector("#confirmberths").checked = _0x3cd1c2.other_preferences.confirmberths ?? false;
          document.querySelector("#acbooktime").value = _0x3cd1c2.other_preferences.acbooktime;
          document.querySelector("#slbooktime").value = _0x3cd1c2.other_preferences.slbooktime;
          document.querySelector("#gnbooktime").value = _0x3cd1c2.other_preferences.gnbooktime ?? "07:59:59";
          document.querySelector("#mobileNumber").value = _0x3cd1c2.other_preferences.mobileNumber;
          document.querySelector("#paymentMethod").value = _0x3cd1c2.other_preferences.paymentmethod;
          document.querySelector("#CaptchaSubmitMode").value = _0x3cd1c2.other_preferences.CaptchaSubmitMode;
          document.querySelector("#autoCaptcha").checked = _0x3cd1c2.other_preferences.autoCaptcha ?? false;
          document.querySelector("#psgManual").checked = _0x3cd1c2.other_preferences.psgManual ?? false;
          document.querySelector("#paymentManual").checked = _0x3cd1c2.other_preferences.paymentManual ?? false;
          if (document.querySelector("#tokenString")) {
            document.querySelector("#tokenString").value = _0x3cd1c2.other_preferences.tokenString;
          }
          if (document.querySelector("#projectId")) {
            document.querySelector("#projectId").value = _0x3cd1c2.other_preferences.projectId;
          }
          document.querySelector("#cardnumber").value = _0x3cd1c2.other_preferences.cardnumber;
          document.querySelector("#cardexpiry").value = _0x3cd1c2.other_preferences.cardexpiry;
          document.querySelector("#cardcvv").value = _0x3cd1c2.other_preferences.cardcvv;
          document.querySelector("#cardholder").value = _0x3cd1c2.other_preferences.cardholder;
          document.querySelector("#cardtype").value = _0x3cd1c2.other_preferences.cardtype;
          document.querySelector("#staticpassword").value = _0x3cd1c2.other_preferences.staticpassword;
        }
        if (_0x3cd1c2.vpa && Object.keys(_0x3cd1c2.vpa).length > 0x0 && _0x3cd1c2.vpa.vpa !== '') {
          const _0x5cc30c = document.querySelector("#vpa");
          if (_0x5cc30c) {
            _0x5cc30c.value = _0x3cd1c2.vpa.vpa;
          }
        }
        const _0xfc8f00 = _0x3cd1c2.other_preferences?.["paymentmethod"];
        const _0x13358f = document.getElementById("carddetails");
        if (_0x13358f && (_0xfc8f00 === "DBTCRD" || _0xfc8f00 === "DBTCRDI" || _0xfc8f00 === "HDFCDB")) {}
        if (_0x3cd1c2.fare_limit) {
          document.querySelector("#enableFareLimit").checked = _0x3cd1c2.fare_limit.enableFareLimit ?? false;
          document.querySelector("#maxFareAmount").value = _0x3cd1c2.fare_limit.maxFareAmount ?? '';
          document.querySelector("#bookInPopup").checked = _0x3cd1c2.fare_limit.bookInPopup ?? false;
        }
        if (_0x3cd1c2.proxy_settings) {
          const _0x26a9ff = _0x3cd1c2.proxy_settings;
          const _0x5378e1 = document.querySelector("input[name=\"proxySelection\"][value=\"" + (_0x26a9ff.activeProxy || "disabled") + "\"]");
          if (_0x5378e1) {
            _0x5378e1.checked = true;
          }
          if (_0x26a9ff.proxies && Array.isArray(_0x26a9ff.proxies)) {
            _0x26a9ff.proxies.forEach((_0x543f1d, _0x179e14) => {
              const _0x1969fe = _0x179e14 + 0x1;
              const _0x268d85 = document.getElementById("proxy-ip-" + _0x1969fe);
              const _0x53e33e = document.getElementById("proxy-port-" + _0x1969fe);
              const _0x28da86 = document.getElementById("proxy-user-" + _0x1969fe);
              const _0x300843 = document.getElementById("proxy-pass-" + _0x1969fe);
              if (_0x268d85) {
                _0x268d85.value = _0x543f1d.ip || '';
              }
              if (_0x53e33e) {
                _0x53e33e.value = _0x543f1d.port || '';
              }
              if (_0x28da86) {
                _0x28da86.value = _0x543f1d.user || '';
              }
              if (_0x300843) {
                _0x300843.value = _0x543f1d.pass || '';
              }
            });
          }
        } else {
          const _0x52fb26 = document.querySelector("input[name=\"proxySelection\"][value=\"disabled\"]");
          if (_0x52fb26) {
            _0x52fb26.checked = true;
          }
        }
        finalData = _0x3cd1c2;
      }
    }
  });
}
function getMsg(_0x24e6dc, _0x4832ed) {
  return {
    'msg': {
      'type': _0x24e6dc,
      'data': _0x4832ed
    },
    'sender': "popup",
    'id': "irctc"
  };
}
function saveForm() {
  modifyUserData(true);
}
function clearData() {
  showCustomConfirm("Do you want to clear data?", async () => {
    const _0x2c44b2 = await getDeviceId();
    chrome.storage.local.clear(async () => {
      const _0x357a0e = document.querySelector("form");
      if (_0x357a0e) {
        _0x357a0e.reset();
      }
      loadUserData();
      showCustomAlert("Data cleared successfully!");
      await chrome.storage.local.set({
        'deviceId': _0x2c44b2
      });
    });
  }, () => {
    console.log("Data clear cancelled.");
  });
}
function startScript() {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "activate_script",
      'data': finalData
    },
    'sender': "popup",
    'id': "irctc"
  }, _0x46cc52 => {
    console.log(_0x46cc52, "activate_script response");
  });
}
async function processBookingRequest() {
  const _0xe4da72 = document.getElementById("loader");
  const _0x55b34f = document.getElementById("loader-license");
  const _0x5bf376 = document.getElementById("dvMessage");
  if (_0xe4da72) {
    _0xe4da72.classList.add('fa', "fa-spinner", "fa-spin");
  }
  if (_0x55b34f) {
    _0x55b34f.classList.add('fa', "fa-spinner", "fa-spin");
  }
  if (_0x5bf376) {
    _0x5bf376.innerText = '';
  }
  try {
    const _0x4cb4bb = document.getElementById("subscriber-key");
    const _0x2d48be = _0x4cb4bb ? _0x4cb4bb.value : '';
    if (!_0x2d48be) {
      if (_0x5bf376) {
        _0x5bf376.innerText = "Please enter your subscriber key.";
      } else {
        showCustomAlert("Please enter your subscriber key.");
      }
      if (_0xe4da72) {
        _0xe4da72.classList.remove('fa', "fa-spinner", "fa-spin");
      }
      if (_0x55b34f) {
        _0x55b34f.classList.remove('fa', "fa-spinner", "fa-spin");
      }
      return;
    }
    const _0xad72af = await getDeviceId();
    const _0x50d05d = {
      'UserName': _0x2d48be,
      'MacAddress': _0xad72af
    };
    const _0xf0feb3 = await fetch("https://avoltas.shop/api/get", {
      'method': "POST",
      'headers': {
        'Content-Type': "application/json"
      },
      'body': JSON.stringify(_0x50d05d)
    });
    for (const [_0x493848, _0x4f7311] of _0xf0feb3.headers.entries()) {
      if (_0x493848 == "authorization") {
        await chrome.storage.local.set({
          'authorization': _0x4f7311
        });
      }
    }
    let _0x57a8b7 = '';
    if (!_0xf0feb3.ok) {
      try {
        const _0x3e3154 = await _0xf0feb3.json();
        _0x57a8b7 = _0x3e3154.message || "Licensing check failed: HTTP error " + _0xf0feb3.status;
      } catch (_0x2e8942) {
        _0x57a8b7 = "Licensing check failed: HTTP error " + _0xf0feb3.status + ". Invalid response from server.";
      }
      if (_0x5bf376) {
        _0x5bf376.innerText = _0x57a8b7;
      } else {
        showCustomAlert(_0x57a8b7);
      }
      return;
    }
    // FIX: Only parse once!
    const _0x5b3d12 = await _0xf0feb3.json();
    if (_0x5b3d12.success) {
      console.log("API license check successful.");
      const _0x3a73e0 = modifyUserData(false);
      if (_0x3a73e0) {
        startScript();
      } else {
        console.error("Data preparation failed (e.g., validation error). Booking aborted.");
      }
    } else {
      _0x57a8b7 = _0x5b3d12.message || "Subscription key is not valid or an unknown error occurred.";
      if (_0x5bf376) {
        _0x5bf376.innerText = _0x57a8b7;
      } else {
        showCustomAlert(_0x57a8b7);
      }
    }
  } catch (_0x130d25) {
    console.error("Booking request processing failed:", _0x130d25);
    const _0x4de06c = "Error during booking process: " + _0x130d25.message;
    if (_0x5bf376) {
      _0x5bf376.innerText = _0x4de06c;
    } else {
      showCustomAlert(_0x4de06c);
    }
  } finally {
    if (_0xe4da72) {
      _0xe4da72.classList.remove('fa', "fa-spinner", "fa-spin");
    }
    if (_0x55b34f) {
      _0x55b34f.classList.remove('fa', "fa-spinner", "fa-spin");
    }
  }
}
function connectWithBg() {
  processBookingRequest();
}
function buyPlan() {
  const _0x566825 = document.getElementById("custom-popup");
  if (_0x566825) {
    _0x566825.remove();
  }
  const _0x4da33f = document.createElement("div");
  _0x4da33f.style.position = "fixed";
  _0x4da33f.style.top = '0';
  _0x4da33f.style.left = '0';
  _0x4da33f.style.width = '100%';
  _0x4da33f.style.height = '100%';
  _0x4da33f.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x4da33f.style.zIndex = "9999";
  _0x4da33f.style.display = "flex";
  _0x4da33f.style.justifyContent = "center";
  _0x4da33f.style.alignItems = "center";
  const _0x5e32bf = document.createElement("div");
  _0x5e32bf.style.position = "relative";
  _0x5e32bf.style.width = "90%";
  _0x5e32bf.style.maxWidth = '800px';
  _0x5e32bf.style.height = "80%";
  _0x5e32bf.style.backgroundColor = "#fff";
  _0x5e32bf.style.borderRadius = "10px";
  _0x5e32bf.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x5e32bf.style.overflow = "hidden";
  const _0x2d0316 = document.createElement("button");
  _0x2d0316.innerText = 'X';
  _0x2d0316.style.position = "absolute";
  _0x2d0316.style.top = "10px";
  _0x2d0316.style.right = "15px";
  _0x2d0316.style.fontSize = '24px';
  _0x2d0316.style.background = "none";
  _0x2d0316.style.border = "none";
  _0x2d0316.style.cursor = "pointer";
  _0x2d0316.onclick = () => _0x4da33f.remove();
  const _0x24f694 = document.createElement("iframe");
  _0x24f694.src = "https://avoltas.shop/";
  _0x24f694.style.width = '100%';
  _0x24f694.style.height = '100%';
  _0x24f694.style.border = "none";
  _0x5e32bf.appendChild(_0x2d0316);
  _0x5e32bf.appendChild(_0x24f694);
  _0x4da33f.appendChild(_0x5e32bf);
  document.body.appendChild(_0x4da33f);
}
function OpenSite() {
  window.open("https://avoltas.shop");
}
function showsubscriberpswd() {
  var _0x458d67 = document.getElementById("subscriber-password");
  if ("password" === _0x458d67.type) {
    _0x458d67.type = "text";
  } else {
    _0x458d67.type = "password";
  }
}
function showirctcpswd() {
  var _0x42b8cb = document.getElementById("irctc-password");
  if ("password" === _0x42b8cb.type) {
    _0x42b8cb.type = "text";
  } else {
    _0x42b8cb.type = "password";
  }
}
function showhdfcpass() {
  var _0x43b9fb = document.getElementById("staticpassword");
  if ("password" === _0x43b9fb.type) {
    _0x43b9fb.type = 'text';
  } else {
    _0x43b9fb.type = "password";
  }
}
async function getDeviceId() {
  const _0x3be741 = await chrome.storage.local.get("deviceId");
  const _0x161ba7 = _0x3be741.hasOwnProperty("deviceId");
  const _0x27b945 = _0x161ba7 && typeof _0x3be741.deviceId === "string" && _0x3be741.deviceId.trim() !== '';
  if (!_0x27b945) {
    const _0x353922 = crypto.randomUUID();
    await chrome.storage.local.set({
      'deviceId': _0x353922
    });
    return _0x353922;
  }
  return _0x3be741.deviceId;
}
async function login() {
  const _0x4bf321 = await getDeviceId();
  const _0x2bdefb = {
    'UserName': document.getElementById("subscriber-key").value,
    'MacAddress': _0x4bf321
  };
  const _0x25d876 = document.getElementById("dvMessage");
  if (_0x25d876) {
    _0x25d876.innerText = '';
  }
  try {
    const _0xb3c7b1 = await fetch("https://avoltas.shop/api/get", {
      'method': 'POST',
      'headers': {
        'Content-Type': "application/json"
      },
      'body': JSON.stringify(_0x2bdefb)
    });
    for (const [_0x50cfe3, _0x450da3] of _0xb3c7b1.headers.entries()) {
      if (_0x50cfe3 == "authorization") {
        await chrome.storage.local.set({
          'authorization': _0x450da3
        });
      }
    }
    if (!_0xb3c7b1.ok) {
      let _0x570b4a = "HTTP error! Status: " + _0xb3c7b1.status;
      try {
        const _0x4e24e5 = await _0xb3c7b1.json();
        _0x570b4a = _0x4e24e5.message || _0x570b4a;
      } catch (_0x678d22) {}
      if (_0x25d876) {
        _0x25d876.innerText = _0x570b4a;
      } else {
        showCustomAlert(_0x570b4a);
      }
      return;
    }
    // FIX: Only parse once!
    const _0x5b3d12 = await _0xb3c7b1.json();
    if (_0x5b3d12.success) {
      const _0xb73b97 = document.querySelector("#dvMain");
      const _0x2ae4b7 = document.querySelector("#dvRegister");
      const _0xbcce2e = document.querySelector("#UserPlanExpairy");
      if (_0xb73b97) {
        _0xb73b97.style.display = "block";
      }
      if (_0x2ae4b7) {
        _0x2ae4b7.style.display = "none";
      }
      if (_0xbcce2e) {
        _0xbcce2e.innerText = _0x5b3d12.leftDays;
      }
      await chrome.storage.local.set({
        'licencekey': _0x2bdefb.UserName
      });
    } else {
      const _0x3f5c59 = _0x5b3d12.message || "Invalid Key!";
      if (_0x25d876) {
        _0x25d876.innerText = _0x3f5c59;
      } else {
        showCustomAlert(_0x3f5c59);
      }
    }
  } catch (_0x5c5d80) {
    console.error("Login API call failed:", _0x5c5d80);
    if (_0x25d876) {
      _0x25d876.innerText = "Error connecting to server. Please try again.";
    } else {
      showCustomAlert("Error connecting to server. Please try again.");
    }
  }
}
function createProxyUI() {
  const _0xbcfd73 = document.getElementById("proxy-list");
  if (!_0xbcfd73) {
    return;
  }
  _0xbcfd73.innerHTML = '';
  for (let _0x2abd58 = 0x0; _0x2abd58 < 0x5; _0x2abd58++) {
    const _0x5c2fe3 = _0x2abd58 + 0x1;
    const _0x4ca186 = document.createElement("div");
    _0x4ca186.style.marginBottom = "15px";
    _0x4ca186.innerHTML = "\n            <label style=\"margin-right: 5px;\">\n                <input type=\"radio\" name=\"proxySelection\" value=\"" + _0x5c2fe3 + "\">\n                <strong>Proxy " + _0x5c2fe3 + "</strong>\n            </label>\n            <input type=\"text\" id=\"proxy-ip-" + _0x5c2fe3 + "\" placeholder=\"IP Address\" size=\"15\" style=\"margin-right: 5px;\">\n            <input type=\"text\" id=\"proxy-port-" + _0x5c2fe3 + "\" placeholder=\"Port\" size=\"6\" style=\"margin-right: 5px;\">\n            <input type=\"text\" id=\"proxy-user-" + _0x5c2fe3 + "\" placeholder=\"Username\" size=\"12\" style=\"margin-right: 5px;\">\n            <input type=\"password\" id=\"proxy-pass-" + _0x5c2fe3 + "\" placeholder=\"Password\" size=\"12\">\n            <button type=\"button\" id=\"check-proxy-btn-" + _0x5c2fe3 + "\" style=\"background-color: #007bff; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;\">Check Proxy</button>\n            <span id=\"proxy-status-" + _0x5c2fe3 + "\" style=\"margin-left: 10px; font-weight: bold;\"></span>\n        ";
    _0xbcfd73.appendChild(_0x4ca186);
    const _0x19019a = document.getElementById("check-proxy-btn-" + _0x5c2fe3);
    if (_0x19019a) {
      _0x19019a.addEventListener("click", () => checkProxy(_0x5c2fe3));
    }
  }
}
async function checkProxy(_0x5aad3d) {
  const _0x2f34a4 = document.getElementById("proxy-ip-" + _0x5aad3d);
  const _0x4748c6 = document.getElementById("proxy-port-" + _0x5aad3d);
  const _0x23f194 = document.getElementById("proxy-user-" + _0x5aad3d);
  const _0x30fc7b = document.getElementById("proxy-pass-" + _0x5aad3d);
  const _0x2b7950 = document.getElementById("proxy-status-" + _0x5aad3d);
  const _0x113f1a = {
    'ip': _0x2f34a4 ? _0x2f34a4.value.trim() : '',
    'port': _0x4748c6 ? _0x4748c6.value.trim() : '',
    'user': _0x23f194 ? _0x23f194.value.trim() : '',
    'pass': _0x30fc7b ? _0x30fc7b.value.trim() : ''
  };
  if (!_0x113f1a.ip || !_0x113f1a.port) {
    _0x2b7950.style.color = 'red';
    _0x2b7950.textContent = "IP and Port are required.";
    return;
  }
  _0x2b7950.style.color = "gray";
  _0x2b7950.textContent = "Checking...";
  try {
    const _0x3d023d = await chrome.runtime.sendMessage({
      'action': "checkProxyConnectivity",
      'proxy': _0x113f1a
    });
    if (_0x3d023d.success) {
      _0x2b7950.style.color = "green";
      _0x2b7950.textContent = "Working";
    } else {
      _0x2b7950.style.color = 'red';
      _0x2b7950.textContent = _0x3d023d.message || "Failed";
    }
  } catch (_0x5dfb79) {
    console.error("Error checking proxy:", _0x5dfb79);
    _0x2b7950.style.color = 'red';
    _0x2b7950.textContent = "Error: " + (_0x5dfb79.message || "Unknown");
  }
}
function updateTimer() {
  const _0x1d5bff = document.getElementById("timerClock");
  if (_0x1d5bff) {
    const _0x6fea98 = new Date();
    const _0x25401a = String(_0x6fea98.getHours()).padStart(0x2, '0');
    const _0x14ba36 = String(_0x6fea98.getMinutes()).padStart(0x2, '0');
    const _0x326f2d = String(_0x6fea98.getSeconds()).padStart(0x2, '0');
    _0x1d5bff.textContent = _0x25401a + ':' + _0x14ba36 + ':' + _0x326f2d;
  }
}
fetchStationData().then(_0x19144c => {
  autocompleteSourcDstTrain(document.getElementById("from-station-input"), _0x19144c, "SOURCE");
  autocompleteSourcDstTrain(document.getElementById("destination-station-input"), _0x19144c, 'DEST');
  autocompleteSourcDstTrain(document.getElementById("boarding-station-input"), _0x19144c, "BOARDING");
});
fetchTrainData().then(_0x28cdc3 => {
  autocompleteSourcDstTrain(document.getElementById("train-no"), _0x28cdc3, "TRAIN");
});
window.addEventListener('load', () => {
  createProxyUI();
  loadUserData();
  const _0xc0149d = document.querySelector("#irctc-login");
  if (_0xc0149d) {
    _0xc0149d.addEventListener("change", setIRCTCUsername);
  }
  const _0x564886 = document.querySelector("#irctc-password");
  if (_0x564886) {
    _0x564886.addEventListener("change", setIRCTCPassword);
  }
  const _0x59f676 = document.querySelector("#journey-date");
  if (_0x59f676) {
    _0x59f676.addEventListener("change", journeyDateChanged);
  }
  const _0x831956 = document.querySelector("#journey-class-input");
  if (_0x831956) {
    _0x831956.addEventListener("change", setJourneyClass);
  }
  const _0x1b8513 = document.querySelector("#quota-input");
  if (_0x1b8513) {
    _0x1b8513.addEventListener("change", setQuota);
  }
  for (let _0xbb2c1a = 0x0; _0xbb2c1a < 0x6; _0xbb2c1a++) {
    const _0x351b7b = document.querySelector("#passenger-name-" + (_0xbb2c1a + 0x1));
    if (_0x351b7b) {
      _0x351b7b.addEventListener("change", _0x509458 => setPassengerDetails(_0x509458, _0xbb2c1a, "passenger"));
    }
    const _0x2bd8da = document.querySelector("#age-" + (_0xbb2c1a + 0x1));
    if (_0x2bd8da) {
      _0x2bd8da.addEventListener("change", _0x2fe785 => setPassengerDetails(_0x2fe785, _0xbb2c1a, "passenger"));
    }
    const _0x4b95a5 = document.querySelector("#passenger-gender-" + (_0xbb2c1a + 0x1));
    if (_0x4b95a5) {
      _0x4b95a5.addEventListener("change", _0x2f8f95 => setPassengerDetails(_0x2f8f95, _0xbb2c1a, "passenger"));
    }
    const _0x330c17 = document.querySelector("#passenger-berth-" + (_0xbb2c1a + 0x1));
    if (_0x330c17) {
      _0x330c17.addEventListener("change", _0x3afeda => setPassengerDetails(_0x3afeda, _0xbb2c1a, "passenger"));
    }
    const _0x39fb3b = document.querySelector("#passenger-food-" + (_0xbb2c1a + 0x1));
    if (_0x39fb3b) {
      _0x39fb3b.addEventListener("change", _0x47df09 => setPassengerDetails(_0x47df09, _0xbb2c1a, "passenger"));
    }
    const _0x43a40a = document.querySelector("#passengerchildberth" + (_0xbb2c1a + 0x1));
    if (_0x43a40a) {
      _0x43a40a.addEventListener("change", _0x5a987f => setPassengerDetails(_0x5a987f, _0xbb2c1a, "passenger"));
    }
  }
  for (let _0x41c9fd = 0x0; _0x41c9fd < 0x2; _0x41c9fd++) {
    const _0x7798c8 = document.querySelector("#Infant-name-" + (_0x41c9fd + 0x1));
    if (_0x7798c8) {
      _0x7798c8.addEventListener("change", _0x271da0 => setInfantDetails(_0x271da0, _0x41c9fd, "infant"));
    }
    const _0x22223b = document.querySelector("#Infant-age-" + (_0x41c9fd + 0x1));
    if (_0x22223b) {
      _0x22223b.addEventListener("change", _0x1114b8 => setInfantDetails(_0x1114b8, _0x41c9fd, "infant"));
    }
    const _0xb18b03 = document.querySelector("#Infant-gender-" + (_0x41c9fd + 0x1));
    if (_0xb18b03) {
      _0xb18b03.addEventListener("change", _0x2d1632 => setInfantDetails(_0x2d1632, _0x41c9fd, "infant"));
    }
  }
  const _0x52212d = document.querySelector("#autoUpgradation");
  if (_0x52212d) {
    _0x52212d.addEventListener("change", setOtherPreferences);
  }
  const _0x244a5c = document.querySelector("#autoCaptcha");
  if (_0x244a5c) {
    _0x244a5c.addEventListener("change", setAutoCaptcha);
  }
  const _0xf0d370 = document.querySelector("#psgManual");
  if (_0xf0d370) {
    _0xf0d370.addEventListener("change", setAutoCaptcha);
  }
  const _0x398b1a = document.querySelector("#paymentManual");
  if (_0x398b1a) {
    _0x398b1a.addEventListener("change", setAutoCaptcha);
  }
  const _0x39da6a = document.querySelector("#confirmberths");
  if (_0x39da6a) {
    _0x39da6a.addEventListener("change", setOtherPreferences);
  }
  const _0x561c85 = document.querySelector('#vpa');
  if (_0x561c85) {
    _0x561c85.addEventListener("change", setOtherPreferencesVpa);
  }
  const _0x3f1faa = document.querySelector("#cardnumber");
  if (_0x3f1faa) {
    _0x3f1faa.addEventListener('keyup', () => {
      let _0x4b94ef = _0x3f1faa.value;
      _0x4b94ef = _0x4b94ef.replace(/\s/g, '');
      if (Number(_0x4b94ef) || _0x4b94ef === '') {
        _0x4b94ef = _0x4b94ef.match(/.{1,4}/g);
        _0x4b94ef = _0x4b94ef ? _0x4b94ef.join(" ") : '';
        _0x3f1faa.value = _0x4b94ef;
        if (finalData.other_preferences) {
          finalData.other_preferences.cardnumber = _0x3f1faa.value;
        }
      }
    });
  }
  const _0x5a7365 = document.querySelector("#cardexpiry");
  if (_0x5a7365) {
    _0x5a7365.addEventListener("change", setCardDetails);
  }
  const _0xae35de = document.querySelector("#cardcvv");
  if (_0xae35de) {
    _0xae35de.addEventListener("change", setCardDetails);
  }
  const _0x4363ce = document.querySelector("#cardholder");
  if (_0x4363ce) {
    _0x4363ce.addEventListener("change", setCardDetails);
  }
  const _0x4e7bb6 = document.querySelector("#paymentMethod");
  if (_0x4e7bb6) {
    _0x4e7bb6.addEventListener("change", setpaymentMethod);
  }
  const _0x33e7fd = document.querySelector("#CaptchaSubmitMode");
  if (_0x33e7fd) {
    _0x33e7fd.addEventListener("change", setCaptchaSubmitMode);
  }
  const _0x1fb020 = document.querySelector("#cardtype");
  if (_0x1fb020) {
    _0x1fb020.addEventListener("change", setcardtype);
  }
  const _0x44f6f9 = document.querySelector("#slbooktime");
  if (_0x44f6f9) {
    _0x44f6f9.addEventListener("change", setOtherPreferencesbooktime);
  }
  const _0x319325 = document.querySelector("#acbooktime");
  if (_0x319325) {
    _0x319325.addEventListener("change", setOtherPreferencesbooktime);
  }
  const _0x3812c9 = document.querySelector("#gnbooktime");
  if (_0x3812c9) {
    _0x3812c9.addEventListener("change", setOtherPreferencesbooktime);
  }
  const _0xfa2357 = document.querySelector("#mobileNumber");
  if (_0xfa2357) {
    _0xfa2357.addEventListener("change", setMobileNumber);
  }
  const _0x3ed0b2 = document.querySelector("#travelInsuranceOpted-1");
  if (_0x3ed0b2) {
    _0x3ed0b2.addEventListener("change", setTravelPreferences);
  }
  const _0x21d433 = document.querySelector("#travelInsuranceOpted-2");
  if (_0x21d433) {
    _0x21d433.addEventListener("change", setTravelPreferences);
  }
  const _0x785c0d = document.querySelector("#AvailabilityCheck-1");
  if (_0x785c0d) {
    _0x785c0d.addEventListener("change", setAvailabilyCheck);
  }
  const _0x5901bd = document.querySelector("#AvailabilityCheck-2");
  if (_0x5901bd) {
    _0x5901bd.addEventListener("change", setAvailabilyCheck);
  }
  const _0x229b3d = document.querySelector("#AvailabilityCheck-3");
  if (_0x229b3d) {
    _0x229b3d.addEventListener("change", setAvailabilyCheck);
  }
  const _0x1b6501 = document.querySelector("#reservationchoice");
  if (_0x1b6501) {
    _0x1b6501.addEventListener("change", setTravelPreferences);
  }
  const _0x1bff8f = document.querySelector("#prefcoach");
  if (_0x1bff8f) {
    _0x1bff8f.addEventListener("change", setTravelPreferences);
  }
  const _0xc3264c = document.querySelector("#tokenString");
  if (_0xc3264c) {
    _0xc3264c.addEventListener("change", setTokenString);
  }
  const _0x2c64c8 = document.querySelector("#projectId");
  if (_0x2c64c8) {
    _0x2c64c8.addEventListener("change", setprojectId);
  }
  const _0x4bc945 = document.querySelector("#staticpassword");
  if (_0x4bc945) {
    _0x4bc945.addEventListener("change", setCardDetails);
  }
  const _0x10ddb4 = document.querySelector("#submit-btn");
  if (_0x10ddb4) {
    _0x10ddb4.addEventListener("click", saveForm);
  }
  const _0x313aa8 = document.querySelector("#load-btn-1");
  if (_0x313aa8) {
    _0x313aa8.addEventListener("click", () => buyPlan());
  }
  const _0x4ef8e2 = document.querySelector("#OpenSite");
  if (_0x4ef8e2) {
    _0x4ef8e2.addEventListener("click", () => OpenSite());
  }
  const _0x290b8c = document.querySelector("#login-btn");
  if (_0x290b8c) {
    _0x290b8c.addEventListener("click", () => login());
  }
  const _0x5aaa18 = document.querySelector("#clear-btn");
  if (_0x5aaa18) {
    _0x5aaa18.addEventListener("click", () => clearData());
  }
  const _0x4ae922 = document.querySelector("#connect-btn");
  if (_0x4ae922) {
    _0x4ae922.addEventListener("click", connectWithBg);
  }
  const _0x3513d4 = document.querySelector("#connect-btn-license");
  if (_0x3513d4) {
    _0x3513d4.addEventListener("click", connectWithBg);
  }
  const _0x198f71 = document.querySelector("#showirctcpswd");
  if (_0x198f71) {
    _0x198f71.addEventListener("click", showirctcpswd);
  }
  const _0x2247e1 = document.querySelector("#showhdfcpass");
  if (_0x2247e1) {
    _0x2247e1.addEventListener("click", showhdfcpass);
  }
  const _0x16a407 = document.querySelector("#enableFareLimit");
  if (_0x16a407) {
    _0x16a407.addEventListener("change", setFareLimitPreferences);
  }
  const _0x212ab1 = document.querySelector("#maxFareAmount");
  if (_0x212ab1) {
    _0x212ab1.addEventListener("change", setFareLimitPreferences);
  }
  const _0x327728 = document.querySelector("#bookInPopup");
  if (_0x327728) {
    _0x327728.addEventListener("change", setFareLimitPreferences);
  }
  updateTimer();
  setInterval(updateTimer, 0x3e8);
});