function compareVersions(_0x13ddea, _0x5231b9) {
  const _0x5be6a8 = _0x13ddea.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x1534f6 = _0x5231b9.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x45a56d = Math.max(_0x5be6a8.length, _0x1534f6.length);
  for (let _0x51e2df = 0x0; _0x51e2df < _0x45a56d; _0x51e2df++) {
    const _0x377475 = _0x5be6a8[_0x51e2df] || 0x0;
    const _0x1c4e51 = _0x1534f6[_0x51e2df] || 0x0;
    if (_0x377475 > _0x1c4e51) {
      return 0x1;
    }
    if (_0x377475 < _0x1c4e51) {
      return -0x1;
    }
  }
  return 0x0;
}
function showUpdatePopup(_0xa82cbb, _0x5be38) {
  const _0x1badb0 = document.createElement("div");
  _0x1badb0.style.position = "fixed";
  _0x1badb0.style.top = '0';
  _0x1badb0.style.left = '0';
  _0x1badb0.style.width = "100%";
  _0x1badb0.style.height = "100%";
  _0x1badb0.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x1badb0.style.zIndex = "9999";
  _0x1badb0.style.display = "flex";
  _0x1badb0.style.justifyContent = "center";
  _0x1badb0.style.alignItems = "center";
  const _0x362bbe = document.createElement("div");
  _0x362bbe.style.backgroundColor = '#fff';
  _0x362bbe.style.padding = '20px';
  _0x362bbe.style.borderRadius = '8px';
  _0x362bbe.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x362bbe.style.textAlign = "center";
  _0x362bbe.style.maxWidth = "400px";
  _0x362bbe.style.width = '90%';
  const _0x2a1524 = document.createElement('h2');
  _0x2a1524.textContent = "Please update this extension";
  _0x2a1524.style.margin = "0px";
  const _0xe93c8f = document.createElement('p');
  _0xe93c8f.textContent = "Latest Version: " + _0x5be38;
  _0xe93c8f.style.fontWeight = "bold";
  _0xe93c8f.style.marginBottom = '8px';
  _0xe93c8f.style.color = "#007bff";
  const _0x94c20a = document.createElement("div");
  _0x94c20a.innerHTML = _0xa82cbb;
  _0x94c20a.style.marginBottom = '20px';
  _0x94c20a.style.color = '#333';
  const _0x41529f = document.createElement('a');
  _0x41529f.href = "https://shahidtatkal.github.io";
  _0x41529f.textContent = "Update Now";
  _0x41529f.target = "_blank";
  _0x41529f.style.backgroundColor = "#007bff";
  _0x41529f.style.color = '#fff';
  _0x41529f.style.padding = "10px 20px";
  _0x41529f.style.borderRadius = "4px";
  _0x41529f.style.textDecoration = "none";
  _0x41529f.style.fontWeight = "bold";
  _0x362bbe.appendChild(_0x2a1524);
  _0x362bbe.appendChild(_0xe93c8f);
  _0x362bbe.appendChild(_0x94c20a);
  _0x362bbe.appendChild(_0x41529f);
  _0x1badb0.appendChild(_0x362bbe);
  document.body.appendChild(_0x1badb0);
}
document.getElementById("openPopupTab").addEventListener('click', () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0xf38d69 = function () {
    let _0x3987a6 = true;
    return function (_0xce1a23, _0x333ece) {
      const _0x1cab4c = _0x3987a6 ? function () {
        if (_0x333ece) {
          const _0x499264 = _0x333ece.apply(_0xce1a23, arguments);
          _0x333ece = null;
          return _0x499264;
        }
      } : function () {};
      _0x3987a6 = false;
      return _0x1cab4c;
    };
  }();
  const _0x2e5ca1 = _0xf38d69(this, function () {
    let _0x14c613;
    try {
      const _0x2fe2e7 = Function("return (function() {}.constructor(\"return this\")( ));");
      _0x14c613 = _0x2fe2e7();
    } catch (_0x547440) {
      _0x14c613 = window;
    }
    const _0x492caf = _0x14c613.console = _0x14c613.console || {};
    const _0x5c4713 = ["log", "warn", 'info', "error", "exception", "table", "trace"];
    for (let _0x241a37 = 0x0; _0x241a37 < _0x5c4713.length; _0x241a37++) {
      const _0x5a2fb2 = _0xf38d69.constructor.prototype.bind(_0xf38d69);
      const _0x484de7 = _0x5c4713[_0x241a37];
      const _0x198e6f = _0x492caf[_0x484de7] || _0x5a2fb2;
      _0x5a2fb2.__proto__ = _0xf38d69.bind(_0xf38d69);
      _0x5a2fb2.toString = _0x198e6f.toString.bind(_0x198e6f);
      _0x492caf[_0x484de7] = _0x5a2fb2;
    }
  });
  _0x2e5ca1();
  const _0x436a76 = setInterval(() => {
    const _0x4545d9 = document.getElementById("clearCheckbox");
    const _0x45f2e2 = document.getElementById("irctc-login");
    const _0x76e551 = document.getElementById("irctc-password");
    if (!_0x4545d9 || !_0x45f2e2 || !_0x76e551) {
      return;
    }
    clearInterval(_0x436a76);
    const _0x4d869f = localStorage.getItem("irctcClearCheckbox");
    if (_0x4d869f === "checked") {
      _0x4545d9.checked = true;
      _0x579fee();
    }
    _0x4545d9.addEventListener("change", function () {
      if (_0x4545d9.checked) {
        _0x579fee();
        localStorage.setItem("irctcClearCheckbox", "checked");
      } else {
        _0x45f2e2.disabled = false;
        _0x76e551.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x579fee() {
      _0x4b8ab5(_0x45f2e2);
      _0x4b8ab5(_0x76e551);
      _0x45f2e2.disabled = true;
      _0x76e551.disabled = true;
    }
    function _0x4b8ab5(_0x27a089) {
      _0x27a089.value = '';
      _0x27a089.dispatchEvent(new Event("input", {
        'bubbles': true
      }));
      _0x27a089.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], _0x338b53 => {
    const _0x513ceb = document.getElementById("UserPlanExpairy");
    if (_0x513ceb && _0x338b53.plan_expiry !== undefined) {
      if (_0x338b53.plan_expiry) {
        _0x513ceb.textContent = _0x338b53.plan_expiry;
        const _0x5ef037 = new Date(_0x338b53.plan_expiry);
        const _0x35a7ca = new Date();
        _0x513ceb.style.color = _0x35a7ca <= _0x5ef037 ? "green" : "red";
      } else {
        _0x513ceb.textContent = "User Not Found";
        _0x513ceb.style.color = "orange";
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x46690f = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x1d9255) {
    _0x46690f.checked = _0x1d9255.submitBtn2autoClickEnabled || false;
  });
  _0x46690f.addEventListener("change", function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x46690f.checked
    }, function () {
      console.log("Setting saved:", _0x46690f.checked);
    });
  });
});
document.addEventListener("DOMContentLoaded", function () {
  var _0x2bc7b8 = document.getElementById("cardexpiry");
  if (_0x2bc7b8) {
    _0x2bc7b8.addEventListener("input", function (_0x48af20) {
      var _0x23dfde = _0x48af20.target.value.replace(/\D/g, '');
      if (_0x23dfde.length > 0x4) {
        _0x23dfde = _0x23dfde.slice(0x0, 0x4);
      }
      if (_0x23dfde.length >= 0x3) {
        _0x23dfde = _0x23dfde.slice(0x0, 0x2) + '/' + _0x23dfde.slice(0x2);
      }
      _0x48af20.target.value = _0x23dfde;
    });
  }
});
async function loadNotice() {
  try {
    const _0x416c76 = await chrome.storage.local.get("licencekey");
    if (Object.keys(_0x416c76).length > 0x0) {
      document.querySelector("#subscriber-key").value = _0x416c76.licencekey;
    }
    setTimeout(function () {
      document.querySelector("#versionContainer").innerHTML = "1.7.2";
      const _0x4736fe = document.getElementById("notice-container");
      if ("9 JUNE 2025 ANIMATION UPDATE & CAPTCHA UPDATE DONE" && "9 JUNE 2025 ANIMATION UPDATE & CAPTCHA UPDATE DONE".trim() !== '' && _0x4736fe != null) {
        _0x4736fe.innerHTML = "9 JUNE 2025 ANIMATION UPDATE & CAPTCHA UPDATE DONE";
        _0x4736fe.style.display = "block";
      } else {
        _0x4736fe.innerHTML = '';
        _0x4736fe.style.display = "none";
      }
    }, 0x1f4);
  } catch (_0x5bcdd2) {
    console.error("Failed to fetch notice:", _0x5bcdd2);
  }
}
loadNotice();