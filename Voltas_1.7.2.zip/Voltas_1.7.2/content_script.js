let user_data = {};
function getMsg(_0xbcd546, _0x23fd98) {
  return {
    'msg': {
      'type': _0xbcd546,
      'data': _0x23fd98
    },
    'sender': "content_script",
    'id': "irctc"
  };
}
function statusUpdate(_0x9556c3) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "status_update",
      'data': {
        'status': _0x9556c3,
        'time': new Date().toString().split(" ")[0x4]
      }
    },
    'sender': "content_script",
    'id': "irctc"
  });
}
function classTranslator(_0x4c7290) {
  return labletext = '1A' === _0x4c7290 ? "AC First Class (1A)" : 'EV' === _0x4c7290 ? "Vistadome AC (EV)" : 'EC' === _0x4c7290 ? "Exec. Chair Car (EC)" : '2A' === _0x4c7290 ? "AC 2 Tier (2A)" : '3A' === _0x4c7290 ? "AC 3 Tier (3A)" : '3E' === _0x4c7290 ? "AC 3 Economy (3E)" : 'CC' === _0x4c7290 ? "AC Chair car (CC)" : 'SL' === _0x4c7290 ? "Sleeper (SL)" : '2S' === _0x4c7290 ? "Second Sitting (2S)" : "None";
}
function quotaTranslator(_0x56a68f) {
  if ('GN' === _0x56a68f) {
    labletext = 'GENERAL';
  } else if ('TQ' === _0x56a68f) {
    labletext = 'TATKAL';
  } else if ('PT' === _0x56a68f) {
    labletext = "PREMIUM TATKAL";
  } else if ('LD' === _0x56a68f) {
    labletext = 'LADIES';
  } else if ('SR' === _0x56a68f) {
    labletext = "LOWER BERTH/SR.CITIZEN";
  } else {
    labletext;
  }
  return labletext;
}
function addDelay(_0x5b0419) {
  let _0x51d440 = Date.now();
  let _0x11e796 = null;
  do {
    _0x11e796 = Date.now();
  } while (_0x11e796 - _0x51d440 < _0x5b0419);
}
chrome.runtime.onMessage.addListener((_0x15910c, _0x488d80, _0x56ac54) => {
  if ("irctc" !== _0x15910c.id) {
    return void _0x56ac54("Invalid Id");
  }
  let _0x13aefd = _0x15910c.msg.type;
  if ("selectJourney" === _0x13aefd) {
    console.log('selectJourney');
    if ((popupbtn = document.querySelectorAll(".btn.btn-primary")).length > 0x0) {
      popupbtn[0x1].click();
      console.log("Close last trxn popup");
    }
    let _0x4b66ad = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
    console.log(user_data.journey_details["train-no"]);
    let _0x52cbb1 = user_data.journey_details["train-no"];
    let _0x280fe6 = _0x4b66ad.filter(_0x4ce10f => _0x4ce10f.querySelector('div.train-heading').innerText.trim().includes(_0x52cbb1.split('-')[0x0]))[0x0];
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void alert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x280fe6) {
        console.log("Precheck - Train not found for search criteria.");
        return void alert("Precheck - Train(" + _0x52cbb1 + ") not found for search criteria. You can manually proceed or correct data and restart the process.");
      }
      let _0x23ec85 = labletext = '1A' === user_data.journey_details["class"] ? "AC First Class (1A)" : 'EV' === user_data.journey_details["class"] ? "Vistadome AC (EV)" : 'EC' === user_data.journey_details["class"] ? "Exec. Chair Car (EC)" : '2A' === user_data.journey_details["class"] ? "AC 2 Tier (2A)" : '3A' === user_data.journey_details["class"] ? "AC 3 Tier (3A)" : '3E' === user_data.journey_details["class"] ? "AC 3 Economy (3E)" : 'CC' === user_data.journey_details["class"] ? "AC Chair car (CC)" : 'SL' === user_data.journey_details["class"] ? "Sleeper (SL)" : '2S' === user_data.journey_details["class"] ? "Second Sitting (2S)" : "None";
      if (![..._0x280fe6.querySelectorAll("table tr td div.pre-avl")].filter(_0x206cfb => _0x206cfb.querySelector("div").innerText === _0x23ec85)[0x0]) {
        console.log("Precheck - Selected Class not available in the train.");
        return void alert("Precheck - Selected Class not available in the train. You can manually proceed or correct data and restart the process.");
      }
    }
    let _0x4e2344 = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Automatically click");
      if ('TQ' === user_data.journey_details.quota || 'PT' === user_data.journey_details.quota || 'GN' === user_data.journey_details.quota) {
        console.log("Verify tatkal time");
        let _0x23deee = user_data.journey_details["class"];
        requiredTime = "00:00:00";
        current_time = "00:00:00";
        requiredTime = ['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x23deee.toUpperCase()) ? user_data.other_preferences.acbooktime : user_data.other_preferences.slbooktime;
        if ('GN' === user_data.journey_details.quota) {
          requiredTime = user_data.other_preferences.gnbooktime;
        }
        console.log("requiredTime", requiredTime);
        var _0x476709 = 0x0;
        let _0xed971e = new MutationObserver(_0x44b133 => {
          current_time = new Date().toString().split(" ")[0x4];
          console.log('current_time', current_time);
          if (current_time > requiredTime) {
            _0xed971e.disconnect();
            selectJourney();
          } else {
            if (0x0 == _0x476709) {
              console.log("Inside wait counter 0 ");
              try {
                let _0x33ba4a = document.createElement("div");
                _0x33ba4a.textContent = "Please wait..Booking will automatically start at " + requiredTime;
                _0x33ba4a.style.textAlign = "center";
                _0x33ba4a.style.color = "white";
                _0x33ba4a.style.height = "auto";
                _0x33ba4a.style.fontSize = '20px';
                document.querySelector("#divMain > div > app-train-list > div> div > div > div.clearfix").insertAdjacentElement("afterend", _0x33ba4a);
              } catch (_0x33c1b3) {
                console.log("wait time failed", _0x33c1b3.message);
              }
            }
            try {
              if (_0x476709 % 0x2 == 0x0) {
                console.log("counter1", _0x476709 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = 'green';
              } else {
                console.log("counter2", _0x476709 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "red";
              }
            } catch (_0x10b006) {}
            _0x476709 += 0x1;
            console.log("wait time");
          }
        });
        _0xed971e.observe(_0x4e2344, {
          'childList': true,
          'subtree': true,
          'characterDataOldValue': true
        });
      } else {
        console.log("select journey GENERAL quota");
        selectJourney();
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Immediately click");
      selectJourney();
    }
  } else {
    if ("fillPassengerDetails" === _0x13aefd) {
      console.log("fillPassengerDetails");
      fillPassengerDetails();
    } else {
      if ("reviewBooking" === _0x13aefd) {
        console.log("reviewBooking");
        try {
          chrome.storage.local.get(["plan"], _0x59dca0 => {
            console.log("Retrieved plan: ", userPlan);
             if (userPlan === 'A') {
              console.log("User have active plan");
            } else {
              alert("Please buy a suitable plan to use the extension.");
              try {
                document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
              } catch (_0x5d048a) {
                window.location.href = 'https://www.irctc.co.in/nget/train-search';
              }
            }
          });
        } catch (_0x30585f) {
          alert("Failed to validate plan. Please contact our support team");
          try {
            document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
          } catch (_0x27626a) {
            window.location.href = "https://www.irctc.co.in/nget/train-search";
          }
        }
        document.querySelector('#captcha').scrollIntoView({
          'behavior': "smooth",
          'block': "center",
          'inline': "nearest"
        });
        if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
          setTimeout(() => {
            getCaptchaTC();
          }, 0x1f4);
        } else {
          console.log("Manuall captcha filling");
          let _0x5e28d9 = document.querySelector("#captcha");
          _0x5e28d9.value = 'X';
          _0x5e28d9.dispatchEvent(new Event("input"));
          _0x5e28d9.dispatchEvent(new Event("change"));
          _0x5e28d9.focus();
        }
      } else {
        if ("bkgPaymentOptions" === _0x13aefd) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x297eae = "Multiple Payment Service";
          let _0x3f6127 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x4375b0 = true;
          if (user_data.other_preferences.paymentmethod.includes("IRCUPI")) {
            _0x4375b0 = false;
            _0x297eae = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x3f6127 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
            console.log("Payment option-IRCUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes('PAYTMUPI')) {
            _0x297eae = "BHIM/ UPI/ USSD";
            _0x3f6127 = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            console.log("Payment option-PAYTMUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PHONEPEUPI")) {
            _0x297eae = "Multiple Payment Service";
            _0x3f6127 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            console.log("Payment option-PHONEPEUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PAYUUPIID")) {
            _0x297eae = "Multiple Payment Service";
            _0x3f6127 = "Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)";
            console.log("Payment option-PAYUUPIID");
          }
          if (user_data.other_preferences.paymentmethod.includes("AMZPAYWAL")) {
            _0x297eae = "Wallets / Cash Card";
            _0x3f6127 = "Amazon Pay Balance";
            console.log("Payment option-AMZPAYWAL");
          }
          if (user_data.other_preferences.paymentmethod.includes("MOBUPI")) {
            let _0x501569 = window.navigator.userAgent;
            console.log("BrowserUserAgent", _0x501569);
            if (_0x501569.includes("Android")) {
              console.log("Android browser");
              _0x297eae = "Multiple Payment Service";
              _0x3f6127 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            }
          }
          if (user_data.other_preferences.paymentmethod.includes('IRCWA')) {
            _0x297eae = "IRCTC eWallet";
            _0x3f6127 = "IRCTC eWallet";
            console.log("Payment option-IRCWA");
          }
          if (user_data.other_preferences.paymentmethod.includes("HDFCDB")) {
            _0x297eae = "Payment Gateway / Credit Card / Debit Card";
            _0x3f6127 = "Visa/Master Card(Powered By HDFC BANK)";
            console.log("Payment option-HDFCDB");
          }
          let _0x1fbea4 = _0x3f6127.replace('&', '&amp;');
          let _0x45b5ce = false;
          var _0x3ca6f6 = setInterval(() => {
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0x3ca6f6);
              var _0x54ae31 = document.getElementById('pay-type').getElementsByTagName("div");
              for (i = 0x0; i < _0x54ae31.length; i++) {
                if (_0x54ae31[i].innerText.indexOf(_0x297eae) >= 0x0) {
                  if (_0x4375b0) {
                    _0x54ae31[i].click();
                  }
                  setTimeout(() => {
                    var _0xade4e9 = document.getElementsByClassName("border-all no-pad");
                    for (i = 0x0; i < _0xade4e9.length; i++) {
                      if (0x0 != _0xade4e9[i].getBoundingClientRect().top && -0x1 != _0xade4e9[i].getElementsByTagName("span")[0x0].innerHTML.toUpperCase().indexOf(_0x1fbea4.toUpperCase())) {
                        if (_0x4375b0) {
                          _0xade4e9[i].click();
                        }
                        _0x45b5ce = true;
                        document.getElementsByClassName("btn-primary")[0x0].scrollIntoView({
                          'behavior': 'smooth',
                          'block': "center",
                          'inline': "nearest"
                        });
                        if (user_data.other_preferences.hasOwnProperty("paymentManual") && user_data.other_preferences.paymentManual) {
                          alert("Manually submit the payment page.");
                        } else {
                          setTimeout(() => {
                            let _0x26d0f3 = document.querySelector("#fare-summary > div.col-xs-12.line-def.top-header > span.pull-right > strong");
                            if (!_0x26d0f3) {
                              console.log("❌ Fare element not found. Proceeding anyway...");
                              document.getElementsByClassName("btn-primary")[0x0]?.["click"]();
                              return;
                            }
                            let _0x405cb7 = _0x26d0f3.innerText.trim();
                            let _0x6e9685 = parseFloat(_0x405cb7.replace(/[₹, ]+/g, ''));
                            if (isNaN(_0x6e9685)) {
                              console.log("❌ Could not parse actual fare. Proceeding anyway...");
                              document.getElementsByClassName("btn-primary")[0x0]?.["click"]();
                              return;
                            }
                            chrome.storage.local.get(["fare_limit"], _0x252202 => {
                              let _0x1dff2b = _0x252202.fare_limit;
                              let _0x527354 = _0x1dff2b?.['enableFareLimit'];
                              let _0x159475 = _0x1dff2b?.['bookInPopup'];
                              if (!_0x527354) {
                                console.log("✅ Fare limit disabled, proceeding directly...");
                                document.getElementsByClassName("btn-primary")[0x0]?.['click']();
                                return;
                              }
                              let _0x54c162 = parseFloat(_0x1dff2b.maxFareAmount);
                              if (isNaN(_0x54c162)) {
                                console.log("❌ Max fare limit is invalid, proceeding...");
                                document.getElementsByClassName("btn-primary")[0x0]?.["click"]();
                                return;
                              }
                              if (_0x6e9685 <= _0x54c162) {
                                console.log("✅ Fare ₹" + _0x6e9685 + " is within limit ₹" + _0x54c162 + ". Proceeding...");
                                document.getElementsByClassName("btn-primary")[0x0]?.["click"]();
                                return;
                              }
                              if (!_0x159475) {
                                console.log("✅ Book in Popup Window disabled, proceeding without popup...");
                                document.getElementsByClassName("btn-primary")[0x0]?.["click"]();
                                return;
                              }
                              showCustomConfirm("💰 The fare exceeds your set limit. Do you want to continue?", _0x6e9685, _0x54c162).then(_0x3a884e => {
                                if (_0x3a884e) {
                                  console.log("✅ User confirmed to proceed despite high fare.");
                                  let _0x115829 = document.getElementsByClassName('btn-primary')[0x0];
                                  if (_0x115829) {
                                    _0x115829.click();
                                  } else {
                                    console.log("❌ btn-primary button not found");
                                  }
                                } else {
                                  console.log("❌ User cancelled due to fare limit.");
                                  showCustomAlert("❌ Booking cancelled by user.");
                                  window.location.href = "https://www.irctc.co.in/nget/train-search";
                                }
                              });
                            });
                          }, 0x1f4);
                        }
                        break;
                      }
                      if (!(i != _0xade4e9.length - 0x1 || _0x45b5ce)) {
                        showCustomConfirm("Selected payment option not available, please select other option manually.").then(_0x1e52a8 => {
                          if (_0x1e52a8) {
                            alert("Selected payment option not available, please select other option manually.");
                          }
                        });
                      }
                    }
                  }, 0x1f4);
                }
              }
            }
          }, 0x1f4);
        } else {
          console.log("Nothing to do");
        }
      }
    }
  }
  _0x56ac54("Something went wrong");
});
let captchaRetry = 0x0;
function waitForElement(_0x2abbca, _0x5cec95 = 0x2710) {
  return new Promise((_0x1dfd27, _0x1d01cf) => {
    let _0x2bc270 = Date.now();
    !function _0x27ed42() {
      let _0x1a9793 = document.querySelector(_0x2abbca);
      if (_0x1a9793) {
        _0x1dfd27(_0x1a9793);
      } else if (Date.now() - _0x2bc270 > _0x5cec95) {
        _0x1d01cf("Element not found: " + _0x2abbca);
      } else {
        requestAnimationFrame(_0x27ed42);
      }
    }();
  });
}
function showCustomAlert(_0x2c1065) {
  alert(_0x2c1065);
}
function showCustomConfirm(_0x122cd7, _0x554e3e, _0x3fbe16) {
  return new Promise(_0x50a4ac => {
    let _0x5b320e = document.getElementById("custom-confirm-modal");
    if (_0x5b320e) {
      _0x5b320e.remove();
    }
    let _0x184c51 = document.createElement('div');
    _0x184c51.id = "custom-confirm-modal";
    _0x184c51.style = "\n      position: fixed; top: 0; left: 0; right: 0; bottom: 0;\n      background: rgba(0,0,0,0.5); z-index: 9999;\n      display: flex; justify-content: center; align-items: center;\n    ";
    let _0x879f40 = document.createElement("div");
    _0x879f40.style = "\n      background: white; padding: 20px; border-radius: 10px;\n      max-width: 400px; width: 90%; text-align: center;\n      box-shadow: 0 0 10px rgba(0,0,0,0.3);\n    ";
    let _0x318659 = document.createElement('p');
    _0x318659.innerHTML = "\n      " + _0x122cd7 + "<br><br>\n      <strong>Website Fare:</strong> ₹" + _0x554e3e.toFixed(0x2) + "<br>\n      <strong>Your Limit:</strong> ₹" + _0x3fbe16.toFixed(0x2) + "\n    ";
    _0x318659.style = "font-size: 16px; margin-bottom: 20px;";
    let _0x486cfa = document.createElement("button");
    _0x486cfa.textContent = "YES";
    _0x486cfa.style = "margin-right: 10px; padding: 8px 16px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;";
    let _0xe4afc = document.createElement("button");
    _0xe4afc.textContent = 'NO';
    _0xe4afc.style = "padding: 8px 16px; background-color: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer;";
    _0x486cfa.onclick = () => {
      _0x184c51.remove();
      _0x50a4ac(true);
    };
    _0xe4afc.onclick = () => {
      _0x184c51.remove();
      _0x50a4ac(false);
    };
    _0x879f40.appendChild(_0x318659);
    _0x879f40.appendChild(_0x486cfa);
    _0x879f40.appendChild(_0xe4afc);
    _0x184c51.appendChild(_0x879f40);
    document.body.appendChild(_0x184c51);
  });
}
function getCaptcha() {
  if (captchaRetry < 0x64) {
    console.log('getCaptcha');
    captchaRetry += 0x1;
    let _0x305496 = document.querySelector('.captcha-img');
    if (_0x305496) {
      let _0x371d85 = new XMLHttpRequest();
      let _0x3dc917 = _0x305496.src.substr(0x16);
      let _0x113c84 = JSON.stringify({
        'requests': [{
          'image': {
            'content': _0x3dc917
          },
          'features': [{
            'type': "TEXT_DETECTION"
          }],
          'imageContext': {
            'languageHints': ['en']
          }
        }]
      });
      user_data.other_preferences.projectId;
      _0x371d85.open("POST", "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyBiX0N7keMT0oUpTbeO2wRLXiYSG2sR5hg", false);
      _0x371d85.onload = function () {
        if (0xc8 != _0x371d85.status) {
          console.log("Error " + _0x371d85.status + ": " + _0x371d85.statusText);
          console.log(_0x371d85.response);
        } else {
          let _0x4304fa = '';
          let _0x21cb04 = document.querySelector("#captcha");
          _0x4304fa = JSON.parse(_0x371d85.response).responses[0x0].fullTextAnnotation.text;
          console.log("Org text", _0x4304fa);
          let _0x3156c8 = Array.from(_0x4304fa.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x12623d = '';
          for (let _0x22bb05 of _0x3156c8) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x22bb05)) {
            _0x12623d += _0x22bb05;
          }
          _0x21cb04.value = _0x12623d;
          if ('' == _0x4304fa) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptcha();
            }, 0x1f4);
          }
          _0x21cb04.dispatchEvent(new Event('input'));
          _0x21cb04.dispatchEvent(new Event('change'));
          _0x21cb04.focus();
          let _0x2367d8 = document.querySelector('app-login');
          let _0xae4fee = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x39ce3f = new MutationObserver(_0x5c398f => {
            if (_0x2367d8 && _0x2367d8.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x39ce3f.disconnect();
            }
            if (_0xae4fee && _0xae4fee.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x39ce3f.disconnect();
            }
          });
          if (_0x2367d8) {
            console.log("observe loginCaptcha");
            _0x39ce3f.observe(_0x2367d8, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0xae4fee) {
            console.log("observe reviewCaptcha");
            _0x39ce3f.observe(_0xae4fee, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
        }
      };
      _0x371d85.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x371d85.send(_0x113c84);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptcha();
      }, 0x3e8);
    }
  }
}
function getCaptchaTC() {
  if (captchaRetry < 0x64) {
    console.log("getCaptchaTC");
    captchaRetry += 0x1;
    let _0x1a8a52 = document.querySelector(".captcha-img");
    if (_0x1a8a52) {
      let _0x35456d = new XMLHttpRequest();
      let _0x46f835 = _0x1a8a52.src.substr(0x16);
      let _0x1e6c6e = JSON.stringify({
        'client': "chrome extension",
        'location': "https://www.irctc.co.in/nget/train-search",
        'version': "0.3.8",
        'case': "mixed",
        'promise': 'true',
        'extension': true,
        'data': _0x46f835
      });
      _0x35456d.open("POST", 'https://kingextension.com/king1/accest/v1/train-search-list.php', false);
      _0x35456d.onload = function () {
        if (0xc8 != _0x35456d.status) {
          console.log("Error " + _0x35456d.status + ": " + _0x35456d.statusText);
          console.log(_0x35456d.response);
        } else {
          let _0x27a93e = '';
          let _0x2b8e6a = document.querySelector('#captcha');
          _0x27a93e = JSON.parse(_0x35456d.response).result;
          console.log("Org text", _0x27a93e);
          let _0x317541 = Array.from(_0x27a93e.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0xd56198 = '';
          for (let _0x54ef20 of _0x317541) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x54ef20)) {
            _0xd56198 += _0x54ef20;
          }
          _0x2b8e6a.value = _0xd56198;
          if ('' == _0x27a93e) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptchaTC();
            }, 0x1f4);
          }
          _0x2b8e6a.dispatchEvent(new Event('input'));
          _0x2b8e6a.dispatchEvent(new Event('change'));
          _0x2b8e6a.focus();
          let _0x1b6a7e = document.querySelector("app-login");
          let _0x501ae4 = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x35f341 = new MutationObserver(_0x4923c2 => {
            if (_0x1b6a7e && _0x1b6a7e.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x35f341.disconnect();
            }
            if (_0x501ae4 && _0x501ae4.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x35f341.disconnect();
            }
          });
          if (_0x1b6a7e) {
            console.log("observe loginCaptcha");
            _0x35f341.observe(_0x1b6a7e, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0x501ae4) {
            console.log("observe reviewCaptcha");
            _0x35f341.observe(_0x501ae4, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (undefined !== user_data.other_preferences.CaptchaSubmitMode && 'A' == user_data.other_preferences.CaptchaSubmitMode) {
            console.log("Auto submit captcha");
            let _0x2c10d5 = document.querySelector("#divMain > app-login");
            if (_0x2c10d5) {
              let _0x3b4951 = _0x2c10d5.querySelector("button[type='submit'][class='search_btn train_Search']");
              let _0x12cd39 = _0x2c10d5.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']");
              let _0x1ef71c = _0x2c10d5.querySelector("input[type='text'][formcontrolname='userid']");
              let _0x288794 = _0x2c10d5.querySelector("input[type='password'][formcontrolname='password']");
              if ('' != _0x1ef71c.value && '' != _0x288794.value) {
                console.log("Submit login info and captcha");
                setTimeout(() => {
                  try {
                    _0x3b4951.click();
                  } catch (_0x23e5f0) {}
                  try {
                    _0x12cd39.click();
                  } catch (_0x55d126) {}
                }, 0x1f4);
              } else {
                alert("Unable to auto submit loging info, username and password not filled,please submit manually");
              }
            }
            if (reviewPage = document.querySelector("#divMain > div > app-review-booking")) {
              console.log("reviewPage", reviewPage);
              if ('' != document.querySelector("#captcha").value) {
                let _0x5d962f = document.querySelector('.btnDefault.train_Search');
                if (_0x5d962f) {
                  setTimeout(() => {
                    console.log("Confirm berth", user_data.other_preferences.confirmberths);
                    if (user_data.other_preferences.confirmberths) {
                      if (document.querySelector(".AVAILABLE")) {
                        console.log("Seats available");
                        _0x5d962f.click();
                      } else {
                        if (0x1 != confirm("No seats Available, Do you still want to continue booking?")) {
                          return void console.log("No Seats available, STOP");
                        }
                        console.log("No Seats available, still Go ahead");
                        _0x5d962f.click();
                      }
                    } else {
                      _0x5d962f.click();
                    }
                  }, 0x1f4);
                }
              } else {
                alert("Captcha automatically not filled, submit manually");
              }
            }
          } else {
            console.log("Manual captcha submission");
          }
        }
      };
      _0x35456d.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x35456d.send(_0x1e6c6e);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptchaTC();
      }, 0x3e8);
    }
  }
}
async function typeSlow(_0x3536e3, _0x385db9, _0x246be4 = 0x96) {
  if (_0x3536e3) {
    _0x3536e3.focus();
    _0x3536e3.value = '';
    _0x3536e3.dispatchEvent(new Event("input", {
      'bubbles': true
    }));
    for (let _0x3a27d3 of _0x385db9) {
      await new Promise(_0x1cb963 => setTimeout(_0x1cb963, _0x246be4 + 0x32 * Math.random()));
      _0x3536e3.value += _0x3a27d3;
      _0x3536e3.dispatchEvent(new Event("input", {
        'bubbles': true
      }));
    }
    _0x3536e3.dispatchEvent(new Event('change', {
      'bubbles': true
    }));
  }
}
async function loadLoginDetails() {
  let _0x4c694d = document.querySelector("#divMain > app-login");
  let _0x1aa45a = _0x4c694d?.["querySelector"]("input[formcontrolname='userid']");
  let _0x32d35e = _0x4c694d?.["querySelector"]("input[formcontrolname='password']");
  let _0x278222 = document.querySelector("input[formcontrolname='captcha']");
  let _0x570e22 = user_data.irctc_credentials.user_name ?? '';
  let _0x53ee29 = user_data.irctc_credentials.password ?? '';
  _0x278222?.['scrollIntoView']({
    'behavior': "smooth",
    'block': "center"
  });
  await typeSlow(_0x1aa45a, _0x570e22);
  await typeSlow(_0x32d35e, _0x53ee29);
  if (user_data.other_preferences?.['autoCaptcha']) {
    try {
      let _0x47cdfd = await getCaptchaTC();
      if (_0x47cdfd) {
        await typeSlow(_0x278222, _0x47cdfd, 0xfa);
        console.log("✅ Captcha typed:", _0x47cdfd);
      } else {
        console.warn("❌ Captcha not received");
      }
    } catch (_0xa898fe) {
      console.error("❌ Error fetching captcha:", _0xa898fe);
    }
  } else {
    console.log("⚠️ AutoCaptcha OFF");
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  let _0x34b35e = document.querySelector("app-jp-input form");
  let _0x4055a4 = _0x34b35e.querySelector("#origin > span > input");
  _0x4055a4.value = user_data.journey_details.from;
  _0x4055a4.dispatchEvent(new Event("keydown"));
  _0x4055a4.dispatchEvent(new Event("input"));
  let _0x2e97e0 = _0x34b35e.querySelector("#destination > span > input");
  _0x2e97e0.value = user_data.journey_details.destination;
  _0x2e97e0.dispatchEvent(new Event('keydown'));
  _0x2e97e0.dispatchEvent(new Event('input'));
  let _0xfea842 = _0x34b35e.querySelector("#jDate > span > input");
  _0xfea842.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0xfea842.dispatchEvent(new Event("keydown"));
  _0xfea842.dispatchEvent(new Event("input"));
  let _0x2a7b1e = _0x34b35e.querySelector("#journeyClass");
  _0x2a7b1e.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x2a7b1e.querySelectorAll("ul li")].filter(_0xc6612b => _0xc6612b.innerText === (labletext = '1A' === user_data.journey_details['class'] ? "AC First Class (1A)" : 'EV' === user_data.journey_details['class'] ? "Vistadome AC (EV)" : 'EC' === user_data.journey_details['class'] ? "Exec. Chair Car (EC)" : '2A' === user_data.journey_details['class'] ? "AC 2 Tier (2A)" : '3A' === user_data.journey_details['class'] ? "AC 3 Tier (3A)" : '3E' === user_data.journey_details['class'] ? "AC 3 Economy (3E)" : 'CC' === user_data.journey_details['class'] ? "AC Chair car (CC)" : 'SL' === user_data.journey_details['class'] ? "Sleeper (SL)" : '2S' === user_data.journey_details['class'] ? "Second Sitting (2S)" : "None") ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  let _0x3fbe71 = _0x34b35e.querySelector('#journeyQuota');
  _0x3fbe71.querySelector("div > div[role='button']").click();
  [..._0x3fbe71.querySelectorAll("ul li")].filter(_0x3b00cb => _0x3b00cb.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  let _0x34ab9f = _0x34b35e.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log("filled_journey_details");
  _0x34ab9f.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details['train-no']) {
    return;
  }
  let _0x5a552b = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  let _0x4e6be2 = _0x5a552b.filter(_0xb5ec5f => _0xb5ec5f.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details['train-no']))[0x0];
  if (!_0x4e6be2) {
    console.log("Train not found.");
    alert("Train not found");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  let _0x18c750 = labletext = '1A' === user_data.journey_details['class'] ? "AC First Class (1A)" : 'EV' === user_data.journey_details['class'] ? "Vistadome AC (EV)" : 'EC' === user_data.journey_details['class'] ? "Exec. Chair Car (EC)" : '2A' === user_data.journey_details['class'] ? "AC 2 Tier (2A)" : '3A' === user_data.journey_details['class'] ? "AC 3 Tier (3A)" : '3E' === user_data.journey_details['class'] ? "AC 3 Economy (3E)" : 'CC' === user_data.journey_details['class'] ? "AC Chair car (CC)" : 'SL' === user_data.journey_details['class'] ? "Sleeper (SL)" : '2S' === user_data.journey_details['class'] ? "Second Sitting (2S)" : "None";
  let _0x21215d = new Date(user_data.journey_details.date).toString().split(" ");
  let _0x3f122f = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0x4e6be2.querySelectorAll("table tr td div.pre-avl")].filter(_0x54b583 => _0x54b583.querySelector("div").innerText === _0x18c750)[0x0]?.["click"]();
  let _0x353d41 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x57af34, _0x29e4f1) => {
    let _0x2fbcf2 = [..._0x4e6be2.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x23964d => _0x23964d.querySelector('div').innerText === _0x18c750)[0x0];
    let _0x1390fe = [..._0x4e6be2.querySelectorAll("div div table td div.pre-avl")].filter(_0x4f3211 => _0x4f3211.querySelector('div').innerText === _0x21215d[0x0] + ", " + _0x21215d[0x2] + " " + _0x21215d[0x1])[0x0];
    let _0x4c84ca = _0x4e6be2.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x2fbcf2) {
      console.log(0x1);
      if (!_0x2fbcf2.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x2fbcf2.click();
      }
      if (_0x1390fe) {
        console.log(0x3);
        if (_0x1390fe.classList.contains("selected-class")) {
          console.log(0x4);
          _0x4c84ca.click();
          _0x29e4f1.disconnect();
        } else {
          console.log(0x5);
          _0x1390fe.click();
        }
      }
    } else {
      console.log('6');
      _0x1390fe.click();
      _0x4c84ca.click();
      _0x29e4f1.disconnect();
    }
  }).observe(_0x4e6be2, _0x3f122f);
  let _0x4e522a = new MutationObserver((_0x3645a1, _0x1cacf7) => {
    console.log("Popup error");
    console.log("Class count ", [..._0x4e6be2.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0x4e6be2.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x353d41.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0x4e6be2.querySelectorAll("table tr td div.pre-avl")].filter(_0x2d1443 => _0x2d1443.querySelector("div").innerText === _0x18c750)[0x0]?.["click"]();
      _0x1cacf7.disconnect();
    }
  });
  _0x4e522a.observe(_0x353d41, _0x3f122f);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  let _0x2e8268 = setInterval(() => {
    let _0xfef2a3 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    let _0x13ee19 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    let _0x290204 = _0xfef2a3 || _0x13ee19;
    let _0x374743 = document.querySelector("#loaderP");
    let _0x37c413 = _0x374743 && "none" !== _0x374743.style.display;
    if (_0x290204 && !_0x37c413) {
      console.log("Toast link found. Clicking it now...");
      _0x290204.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x2e8268);
    }
  }, 0x3e8);
  if (!user_data?.['journey_details']?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  let _0x2ad11a = document.querySelector("#divMain > div > app-train-list");
  if (!_0x2ad11a) {
    return void console.error("Train list parent not found.");
  }
  let _0x5aa884 = Array.from(_0x2ad11a.querySelectorAll(".tbis-div app-train-avl-enq"));
  let _0x3cb52c = user_data.journey_details["train-no"];
  let _0x1fffac = labletext = '1A' === user_data.journey_details['class'] ? "AC First Class (1A)" : 'EV' === user_data.journey_details['class'] ? "Vistadome AC (EV)" : 'EC' === user_data.journey_details['class'] ? "Exec. Chair Car (EC)" : '2A' === user_data.journey_details['class'] ? "AC 2 Tier (2A)" : '3A' === user_data.journey_details['class'] ? "AC 3 Tier (3A)" : '3E' === user_data.journey_details['class'] ? "AC 3 Economy (3E)" : 'CC' === user_data.journey_details['class'] ? "AC Chair car (CC)" : 'SL' === user_data.journey_details['class'] ? "Sleeper (SL)" : '2S' === user_data.journey_details['class'] ? "Second Sitting (2S)" : "None";
  let _0x57cee2 = new Date(user_data.journey_details.date);
  let _0x504915 = _0x57cee2.toDateString().split(" ")[0x0] + ", " + _0x57cee2.toDateString().split(" ")[0x2] + " " + _0x57cee2.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x3cb52c);
  console.log('Class:', _0x1fffac);
  console.log('date', _0x504915);
  let _0x387dfd = _0x5aa884.find(_0x301d0e => _0x301d0e.querySelector("div.train-heading").innerText.trim().includes(_0x3cb52c.split('-')[0x0]));
  if (!_0x387dfd) {
    console.error("Train not found.");
    return void statusUpdate('journey_selection_stopped.no_train');
  }
  let _0x2809e9 = _0x40d5ff => {
    if (!_0x40d5ff) {
      return false;
    }
    let _0xd02ecf = window.getComputedStyle(_0x40d5ff);
    return "none" !== _0xd02ecf.display && "hidden" !== _0xd02ecf.visibility && '0' !== _0xd02ecf.opacity;
  };
  let _0x358041 = Array.from(_0x387dfd.querySelectorAll("table tr td div.pre-avl")).find(_0x46e439 => _0x46e439.querySelector('div').innerText.trim() === _0x1fffac);
  let _0x155e76 = Array.from(_0x387dfd.querySelectorAll('span')).find(_0x4a98dc => _0x4a98dc.innerText.trim() === _0x1fffac);
  let _0x270fdc = _0x358041 || _0x155e76;
  console.log("FOUND updatedClassToClick:", _0x270fdc);
  if (!_0x270fdc) {
    return void console.error("Class to click not found.");
  }
  let _0x562d91 = document.querySelector('#loaderP');
  if (_0x2809e9(_0x562d91)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0x551a56;
  _0x270fdc.click();
  new MutationObserver((_0x3dc885, _0x4c68e0) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x551a56);
    _0x551a56 = setTimeout(() => {
      let _0x955ea8 = Array.from(_0x387dfd.querySelectorAll("div div table td div.pre-avl")).find(_0x529fb9 => _0x529fb9.querySelector("div").innerText.trim() === _0x504915);
      console.log("FOUND classTabToSelect:", _0x955ea8);
      if (_0x955ea8) {
        _0x955ea8.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          let _0x5a7ded = () => {
            let _0x3941cf = _0x387dfd.querySelector('button.btnDefault.train_Search.ng-star-inserted');
            if (_0x2809e9(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0x5a7ded, 0x64);
            }
            if (!_0x3941cf || _0x3941cf.classList.contains('disable-book') || _0x3941cf.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              setTimeout(() => {
                _0x3941cf.click();
                console.log("Clicked on bookBtn");
                clearTimeout(_0x551a56);
                _0x4c68e0.disconnect();
              }, 0x12c);
            }
          };
          _0x5a7ded();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x387dfd, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
setTimeout(() => {
  chrome.storage.local.get(['fare_limit'], _0x457a52 => {
    let _0x11f489 = _0x457a52.fare_limit;
    let _0x3a364a = _0x11f489?.["enableFareLimit"];
    if (!_0x3a364a) {
      let _0x3dfbe4 = document.querySelector('.btn-primary');
      if (_0x3dfbe4) {
        _0x3dfbe4.click();
      } else {
        console.log("btn-primary button not found");
      }
      return;
    }
    let _0x2a079b = parseFloat(_0x11f489.maxFareAmount);
    if (isNaN(_0x2a079b)) {
      let _0xed1498 = document.querySelector('.btn-primary');
      if (_0xed1498) {
        _0xed1498.click();
      }
      return;
    }
    let _0x3bb746 = document.querySelector("#fare-summary > div.col-xs-12.line-def.top-header > span.pull-right > strong");
    if (!_0x3bb746) {
      let _0x452732 = document.querySelector(".btn-primary");
      if (_0x452732) {
        _0x452732.click();
      }
      return;
    }
    let _0x2d00d3 = _0x3bb746.innerText.trim();
    let _0x1c8984 = parseFloat(_0x2d00d3.replace(/[₹, ]+/g, ''));
    if (isNaN(_0x1c8984)) {
      let _0x19bf66 = document.querySelector(".btn-primary");
      if (_0x19bf66) {
        _0x19bf66.click();
      }
      return;
    }
    if (_0x1c8984 <= _0x2a079b) {
      let _0xe235f = document.querySelector(".btn-primary");
      if (_0xe235f) {
        _0xe235f.click();
      }
      return;
    }
    showCustomConfirm("The total fare shown on the website exceeds your set limit. Do you want to continue?", _0x1c8984, _0x2a079b).then(_0x1d3a95 => {
      if (_0x1d3a95) {
        let _0x4c5c03 = document.querySelector(".btn-primary");
        if (_0x4c5c03) {
          _0x4c5c03.click();
        } else {
          console.log("btn-primary button not found");
        }
      } else {
        showCustomAlert("❌ Booking cancelled by user.");
        window.location.href = "https://www.irctc.co.in/nget/train-search";
      }
    });
  });
}, 0x1f4);
document.querySelectorAll("input[type=\"checkbox\"]").forEach(_0x383fa5 => {
  _0x383fa5.addEventListener('click', _0x517020 => {
    console.log("Checkbox " + _0x517020.target.id + " is now " + (_0x517020.target.checked ? "checked" : "unchecked"));
  });
});
loadLoginDetails();
let keyCounter = 0x0;
function fillPassengerDetails() {
  console.log("passenger_filling_started");
  if (user_data.journey_details.boarding.length > 0x0) {
    console.log("Set boarding station " + user_data.journey_details.boarding);
    let _0xb35448 = document.getElementsByTagName("strong");
    let _0x1033f6 = Array.from(_0xb35448).filter(_0x24ad2c => _0x24ad2c.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x1033f6[0x0]) {
      _0x1033f6[0x0].click();
      addDelay(0x12c);
    }
    let _0x3dabb5 = document.getElementsByTagName("strong");
    let _0x2a3c1e = Array.from(_0x3dabb5).filter(_0x4c03d1 => _0x4c03d1.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x2a3c1e[0x0]) {
      _0x2a3c1e[0x0].click();
    }
  }
  keyCounter = new Date().getTime();
  let _0x3338ca = document.querySelector('app-passenger-input');
  let _0x133958 = 0x1;
  for (; _0x133958 < user_data.passenger_details.length;) {
    addDelay(0xc8);
    document.getElementsByClassName("prenext")[0x0].click();
    _0x133958++;
  }
  try {
    let _0x59cab9 = 0x0;
    for (; _0x59cab9 < user_data.infant_details.length;) {
      addDelay(0xc8);
      document.getElementsByClassName('prenext')[0x2].click();
      _0x59cab9++;
    }
  } catch (_0x266dcd) {
    console.error("add infant error", _0x266dcd);
  }
  let _0x4d0e97 = [..._0x3338ca.querySelectorAll("app-passenger")];
  let _0x4fbd4b = [..._0x3338ca.querySelectorAll('app-infant')];
  user_data.passenger_details.forEach((_0x4bab37, _0x825e5e) => {
    let _0x229093 = _0x4d0e97[_0x825e5e].querySelector("p-autocomplete > span > input");
    _0x229093.value = _0x4bab37.name;
    _0x229093.dispatchEvent(new Event("input"));
    let _0x415ce3 = _0x4d0e97[_0x825e5e].querySelector("input[type='number'][formcontrolname='passengerAge']");
    _0x415ce3.value = _0x4bab37.age;
    _0x415ce3.dispatchEvent(new Event('input'));
    let _0x31db71 = _0x4d0e97[_0x825e5e].querySelector("select[formcontrolname='passengerGender']");
    _0x31db71.value = _0x4bab37.gender;
    _0x31db71.dispatchEvent(new Event("change"));
    let _0xa30aad = _0x4d0e97[_0x825e5e].querySelector("select[formcontrolname='passengerBerthChoice']");
    _0xa30aad.value = _0x4bab37.berth;
    _0xa30aad.dispatchEvent(new Event('change'));
    let _0x246f5b = _0x4d0e97[_0x825e5e].querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x246f5b) {
      _0x246f5b.value = _0x4bab37.food;
      _0x246f5b.dispatchEvent(new Event("change"));
    }
    try {
      let _0x158fd7 = _0x4d0e97[_0x825e5e].querySelector("input[type='checkbox'][formcontrolname='childBerthFlag']");
      console.log('noChildberth', _0x825e5e, _0x4bab37.passengerchildberth);
      if (_0x158fd7 && _0x4bab37.passengerchildberth) {
        console.log("set child half seat");
        _0x158fd7.click();
        addDelay(0xc8);
        if (document.evaluate("//div[contains(text(),'No berth will be allotted for child and')]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
          console.log("clikc OK");
          document.querySelector("app-passenger > p-dialog > div > div > div > p-footer > button").click();
          addDelay(0xc8);
        }
      }
    } catch (_0x5d56a8) {
      console.error("opt Half seat error", _0x5d56a8);
    }
  });
  try {
    user_data.infant_details.forEach((_0x31c488, _0x1dd476) => {
      let _0x557ed1 = _0x4fbd4b[_0x1dd476].querySelector("input#infant-name[name='infant-name']");
      _0x557ed1.value = _0x31c488.name;
      _0x557ed1.dispatchEvent(new Event("input"));
      let _0x118904 = _0x4fbd4b[_0x1dd476].querySelector("select[formcontrolname='age']");
      _0x118904.value = _0x31c488.age;
      _0x118904.dispatchEvent(new Event("change"));
      let _0x1b8e9f = _0x4fbd4b[_0x1dd476].querySelector("select[formcontrolname='gender']");
      _0x1b8e9f.value = _0x31c488.gender;
      _0x1b8e9f.dispatchEvent(new Event('change'));
    });
  } catch (_0x427cbb) {
    console.error("fill infant error", _0x427cbb);
  }
  if ('' !== user_data.other_preferences.mobileNumber) {
    let _0x2d3c32 = _0x3338ca.querySelector("input#mobileNumber[formcontrolname='mobileNumber'][name='mobileNumber']");
    _0x2d3c32.value = user_data.other_preferences.mobileNumber;
    _0x2d3c32.dispatchEvent(new Event("input"));
  }
  let _0x2fca8a = [..._0x3338ca.querySelectorAll("p-radiobutton[formcontrolname='paymentType'][name='paymentType'] input[type='radio']")];
  addDelay(0x64);
  let _0x4f7bcd = '2';
  if (!user_data.other_preferences.paymentmethod.includes('UPI')) {
    _0x4f7bcd = 0x1;
  }
  _0x2fca8a.filter(_0x25cd73 => _0x25cd73.value === _0x4f7bcd)[0x0]?.["click"]();
  let _0x2635b3 = _0x3338ca.querySelector("input#autoUpgradation[type='checkbox'][formcontrolname='autoUpgradationSelected']");
  if (_0x2635b3 && user_data.other_preferences.hasOwnProperty("autoUpgradation") && user_data.other_preferences.autoUpgradation) {
    _0x2635b3.checked = user_data.other_preferences.autoUpgradation ?? false;
  }
  let _0x2fea7d = _0x3338ca.querySelector("input#confirmberths[type='checkbox'][formcontrolname='bookOnlyIfCnf']");
  if (_0x2fea7d && user_data.other_preferences.hasOwnProperty("confirmberths") && user_data.other_preferences.confirmberths) {
    _0x2fea7d.checked = user_data.other_preferences.confirmberths ?? false;
  }
  let _0x404d02 = [..._0x3338ca.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input[type='radio'][name='travelInsuranceOpted-0']")];
  addDelay(0xc8);
  _0x404d02.filter(_0x241e06 => _0x241e06.value === ("yes" === user_data.travel_preferences.travelInsuranceOpted ? 'true' : "false"))[0x0]?.["click"]();
  try {
    let _0x5065e0 = _0x3338ca.querySelector("input[formcontrolname='coachId']");
    if (_0x5065e0 && user_data.travel_preferences.hasOwnProperty("prefcoach") && user_data.travel_preferences.prefcoach.trim().length > 0x0) {
      console.log("set preferred coach Id");
      _0x5065e0.value = user_data.travel_preferences.prefcoach;
    }
    let _0x29a8e1 = _0x3338ca.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x29a8e1 && user_data.travel_preferences.hasOwnProperty("reservationchoice") && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      console.log("set reservationchoice");
      _0x29a8e1.querySelector("div > div[role='button']").click();
      addDelay(0x12c);
      [..._0x29a8e1.querySelectorAll("ul li")].filter(_0x909ee4 => _0x909ee4.innerText === user_data.travel_preferences.reservationchoice ?? '')[0x0]?.["click"]();
    }
  } catch (_0x2d39bb) {
    console.error("pref coach and reservation choice error", _0x2d39bb);
  }
  submitPassengerDetailsForm(_0x3338ca);
}
function submitPassengerDetailsForm(_0x7b0fd8) {
  console.log("passenger_filling_completed");
  window.scrollBy(0x0, 0x258, 'smooth');
  if (user_data.other_preferences.hasOwnProperty("psgManual") && user_data.other_preferences.psgManual) {
    alert("Manually submit the passenger page.");
  } else {
    var _0x99a482 = setInterval(function () {
      var _0x1d64a9 = new Date().getTime();
      if (keyCounter > 0x0 && _0x1d64a9 - keyCounter > 0x7d0) {
        clearInterval(_0x99a482);
        _0x7b0fd8.querySelector("#psgn-form > form div > button.train_Search.btnDefault[type='submit']")?.["click"]();
        window.scrollBy(0x0, 0x258, 'smooth');
      }
    }, 0x1f4);
  }
}
function continueScript() {
  let _0x2bae2a = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if ("LOGOUT" === _0x2bae2a.innerText.trim().toUpperCase()) {
      loadJourneyDetails();
    }
    if ('LOGIN' === _0x2bae2a.innerText.trim().toUpperCase()) {
      _0x2bae2a.click();
      loadLoginDetails();
    }
  } else if (!window.location.href.includes('nget/booking/train-list')) {
    console.log("Nothing to do");
  }
}
function continueScript() {
  let _0x1b5a5d = setInterval(() => {
    let _0x5846c5 = document.querySelector("a.search_btn.loginText.ng-star-inserted");
    if (_0x5846c5) {
      clearInterval(_0x1b5a5d);
      let _0x1e69e7 = _0x5846c5.innerText.trim().toUpperCase();
      if ('LOGIN' === _0x1e69e7) {
        console.log("LOGIN button found. Showing countdown...");
        let _0x1303bc = document.getElementById("custom-login-countdown");
        if (!_0x1303bc) {
          (_0x1303bc = document.createElement('div')).id = "custom-login-countdown";
          _0x1303bc.style.cssText = "\n\t\t\tposition: fixed;\n\t\t\ttop: 20px;\n\t\t\tleft: 50%;\n\t\t\ttransform: translateX(-50%);\n\t\t\tbackground-color: rgba(0, 0, 0, 0.9);\n\t\t\tcolor: #fff;\n\t\t\tpadding: 10px 25px;\n\t\t\tborder-radius: 8px;\n\t\t\tfont-size: 12px;\n\t\t\tz-index: 99999;\n\t\t\tbox-shadow: 0 0 10px rgba(0,0,0,0.5);\n\t\t  ";
          document.body.appendChild(_0x1303bc);
          let _0x3b1398 = ["rgba(18, 18, 18, 0.95)", "rgba(45, 25, 70, 0.95)", "rgba(30, 40, 60, 0.95)", "rgba(60, 20, 40, 0.95)", "rgba(25, 60, 50, 0.95)", "rgba(18, 18, 18, 0.95)"];
          let _0x2f38e1 = 0x0;
          setInterval(() => {
            _0x1303bc.style.backgroundColor = _0x3b1398[_0x2f38e1];
            _0x2f38e1 = (_0x2f38e1 + 0x1) % _0x3b1398.length;
          }, 0x12c);
        }
        let _0x52f427 = 0x7;
        _0x1303bc.innerText = "Voltas 🔐 लॉगिन " + _0x52f427 + " सेकंड में शुरू होगा...";
        let _0x2618b0 = setInterval(() => {
          _0x52f427--;
          _0x1303bc.innerText = "KING 🔐 लॉगिन " + _0x52f427 + " सेकंड में शुरू होगा...";
          if (_0x52f427 <= 0x0) {
            clearInterval(_0x2618b0);
            if (_0x1303bc.parentElement) {
              _0x1303bc.remove();
            }
            console.log("✅ Countdown finished. Clicking login button...");
            _0x5846c5.click();
            loadLoginDetails();
          }
        }, 0x3e8);
      } else {
        console.log("User already logged in or login text not found.");
      }
    } else {
      console.log("⏳ Waiting for login button...");
    }
  }, 0x1f4);
}
async function a() {
  let _0x57c935 = user_data.subs_credentials.user_name ?? '';
  user_data.subs_credentials.password;
  console.log("Simulating plan check for:", _0x57c935);
  console.log("Fake plan check successful. Continuing...");
}
window.onload = function (_0x98e13d) {
  setInterval(function () {
    console.log("Repeater");
    statusUpdate("Keep listener alive.");
  }, 0x3a98);
  let _0x374283 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 ");
  new MutationObserver((_0x1b3960, _0x3ec6c6) => {
    if (_0x1b3960.filter(_0x13d32f => 'childList' === _0x13d32f.type && _0x13d32f.addedNodes.length > 0x0 && [..._0x13d32f.addedNodes].filter(_0x355f22 => 'LOGOUT' === _0x355f22?.["innerText"]?.["trim"]()?.['toUpperCase']()).length > 0x0).length > 0x0) {
      _0x3ec6c6.disconnect();
      loadJourneyDetails();
    } else {
      _0x374283.click();
      loadLoginDetails();
    }
  }).observe(_0x374283, {
    'attributes': false,
    'childList': true,
    'subtree': false
  });
  chrome.storage.local.get(null, _0x17990a => {
    user_data = _0x17990a;
    continueScript();
  });
};