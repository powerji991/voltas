let user_data = {};
function fillVPA() {
  function _0x331492(_0x44e4d0, _0x16e147) {
    _0x44e4d0.dispatchEvent(new Event('keydown', {
      'bubbles': true
    }));
    _0x44e4d0.value = _0x16e147;
    _0x44e4d0.dispatchEvent(new Event("keyup", {
      'bubbles': true
    }));
    _0x44e4d0.dispatchEvent(new Event('input', {
      'bubbles': true
    }));
    _0x44e4d0.dispatchEvent(new Event("change", {
      'bubbles': true
    }));
  }
  console.log("Fill paytm VPA");
  document.getElementById('ptm-upi').getElementsByTagName("div")[0x1].getElementsByTagName('div')[0x0].click();
  console.log("Fill paytm VPA-after click");
  var _0x5b3b82 = setInterval(function () {
    if (document.getElementsByName("upiMode").length > 0x0) {
      clearInterval(_0x5b3b82);
      var _0x19d57d = setInterval(function () {
        var _0x558153 = document.getElementsByName('upiMode')[0x0].parentNode.parentNode.parentNode.getElementsByTagName("input")[0x1];
        if (_0x558153 != null) {
          clearInterval(_0x19d57d);
          _0x331492(_0x558153, user_data.vpa.vpa);
          setTimeout(function () {
            document.getElementsByClassName("btn-primary")[0x1].click();
          }, 0x1f4);
        }
      }, 0x64);
    }
  }, 0x1f4);
}
chrome.storage.local.get(null, _0x106ae9 => {
  user_data = _0x106ae9;
  if (user_data.other_preferences.paymentmethod == "UPIID") {
    if (document.readyState !== "loading") {
      fillVPA();
    } else {
      document.addEventListener("DOMContentLoaded", function () {
        fillVPA();
      });
    }
  }
});