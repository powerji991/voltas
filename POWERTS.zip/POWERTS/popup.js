let finalData = {
  'irctc_credentials': {},
  'journey_details': {},
  'passenger_details': [],
  'travel_preferences': {},
  'other_preferences': {},
  'vpa': {}
};
function autocompleteSourcDstTrain(_0x28432e, _0x461711, _0x1d21a8) {
  var _0x1c39a4;
  function _0x5742aa(_0x54297f) {
    if (!_0x54297f) {
      return false;
    }
    !function (_0x56b619) {
      for (var _0x212551 = 0x0; _0x212551 < _0x56b619.length; _0x212551++) {
        _0x56b619[_0x212551].classList.remove('autocomplete-active');
      }
    }(_0x54297f);
    if (_0x1c39a4 >= _0x54297f.length) {
      _0x1c39a4 = 0x0;
    }
    if (_0x1c39a4 < 0x0) {
      _0x1c39a4 = _0x54297f.length - 0x1;
    }
    _0x54297f[_0x1c39a4].classList.add('autocomplete-active');
  }
  function _0x238734(_0x15f2cc) {
    var _0x2ce6ad = document.getElementsByClassName("autocomplete-items");
    for (var _0xf5caff = 0x0; _0xf5caff < _0x2ce6ad.length; _0xf5caff++) {
      if (_0x15f2cc != _0x2ce6ad[_0xf5caff] && _0x15f2cc != _0x28432e) {
        _0x2ce6ad[_0xf5caff].parentNode.removeChild(_0x2ce6ad[_0xf5caff]);
      }
    }
  }
  _0x28432e.addEventListener("input", function (_0x33b203) {
    var _0x193cfc;
    var _0xdf604d;
    var _0x5d78cc;
    var _0x80ece9 = this.value;
    _0x238734();
    if (!_0x80ece9) {
      return false;
    }
    _0x1c39a4 = -0x1;
    (_0x193cfc = document.createElement("DIV")).setAttribute('id', this.id + 'autocomplete-list');
    _0x193cfc.setAttribute("class", "autocomplete-items");
    this.parentNode.appendChild(_0x193cfc);
    for (_0x5d78cc = 0x0; _0x5d78cc < _0x461711.length; _0x5d78cc++) {
      if (_0x461711[_0x5d78cc].toUpperCase().includes(_0x80ece9.toUpperCase())) {
        (_0xdf604d = document.createElement("DIV")).innerHTML = "<strong>" + _0x461711[_0x5d78cc].substr(0x0, _0x80ece9.length) + "</strong>";
        _0xdf604d.innerHTML += _0x461711[_0x5d78cc].substr(_0x80ece9.length);
        _0xdf604d.innerHTML += "<input type='hidden' value='" + _0x461711[_0x5d78cc] + "'>";
        _0xdf604d.addEventListener("click", function (_0x2a60c7) {
          _0x28432e.value = this.getElementsByTagName("input")[0x0].value;
          if ("SOURCE" == _0x1d21a8) {
            finalData.journey_details.from = this.getElementsByTagName('input')[0x0].value;
          }
          if ("DEST" == _0x1d21a8) {
            finalData.journey_details.destination = this.getElementsByTagName("input")[0x0].value;
          }
          if ("TRAIN" == _0x1d21a8) {
            const _0x518242 = this.getElementsByTagName("input")[0x0].value;
            finalData.journey_details["train-no"] = _0x518242.trim();
          }
          if ("BOARDING" == _0x1d21a8) {
            finalData.journey_details.boarding = this.getElementsByTagName("input")[0x0].value;
          }
          _0x238734();
        });
        _0x193cfc.appendChild(_0xdf604d);
      }
    }
  });
  _0x28432e.addEventListener('keydown', function (_0x6c14bf) {
    var _0x571976 = document.getElementById(this.id + 'autocomplete-list');
    if (_0x571976) {
      _0x571976 = _0x571976.getElementsByTagName('div');
    }
    if (0x28 == _0x6c14bf.keyCode) {
      _0x1c39a4++;
      _0x5742aa(_0x571976);
    } else if (0x26 == _0x6c14bf.keyCode) {
      _0x1c39a4--;
      _0x5742aa(_0x571976);
    } else if (0xd == _0x6c14bf.keyCode) {
      _0x6c14bf.preventDefault();
      if (_0x1c39a4 > -0x1 && _0x571976) {
        _0x571976[_0x1c39a4].click();
      }
    }
  });
  document.addEventListener('click', function (_0x641937) {
    _0x238734(_0x641937.target);
  });
}
const stationData = [];
const stationList = [];
async function fetchStationData() {
  try {
    const _0x565cf1 = await fetch("https://suryarajputg.github.io/accet/stationlist.json");
    if (!_0x565cf1.ok) {
      alert("Unable to fetch station data", "HTTP error! status: " + _0x565cf1.status);
      throw new Error("Unable to fetch station data", "HTTP error! status: " + _0x565cf1.status);
    }
    const _0x2a728b = await _0x565cf1.json();
    stationData.push(..._0x2a728b);
    for (let _0x28c0cd in stationData) stationList.push(stationData[_0x28c0cd].name + " - " + stationData[_0x28c0cd].code);
    return stationList;
  } catch (_0x2cfc2b) {
    console.error("Station date fetching error:", _0x2cfc2b);
    alert("Station data fetching error:", _0x2cfc2b);
    throw _0x2cfc2b;
  }
}
async function fetchTrainData() {
  try {
    const _0x4ff888 = await fetch("https://suryarajputg.github.io/accet/train_data.js");
    if (!_0x4ff888.ok) {
      alert("Unable to fetch train data", "HTTP error! status: " + _0x4ff888.status);
      throw new Error("Unable to fetch train data", "HTTP error! status: " + _0x4ff888.status);
    }
    return (await _0x4ff888.text()).split(/\r?\n/);
  } catch (_0xce984e) {
    console.error("Train data fetching error:", _0xce984e);
    alert("Train data fetching error:", _0xce984e);
    throw _0xce984e;
  }
}
function setIRCTCUsername(_0x28372a) {
  if (!finalData.irctc_credentials) {
    finalData.irctc_credentials = {};
  }
  finalData.irctc_credentials.user_name = _0x28372a.target.value;
  console.log("data-update", finalData);
}
function setIRCTCPassword(_0x2c003a) {
  finalData.irctc_credentials.password = _0x2c003a.target.value;
  console.log("data-update", finalData);
}
function setFromStation(_0xef72f6) {
  finalData.journey_details.from = _0xef72f6.target.value.toUpperCase();
  document.querySelector("#from-station-input").value = _0xef72f6.target.value;
}
function setDestinationStation(_0x12cbc9) {
  finalData.journey_details.destination = _0x12cbc9.target.value.toUpperCase();
  document.querySelector("#destination-station-input").value = _0x12cbc9.target.value;
}
function setBoardingStation(_0x4fb54a) {
  finalData.journey_details.boarding = _0x4fb54a.target.value.toUpperCase();
  document.querySelector("#boarding-station-input").value = _0x4fb54a.target.value;
}
function setJourneyClass(_0x2838d5) {
  finalData.journey_details["class"] = _0x2838d5.target.value;
  document.querySelector("#journey-class-input").value = _0x2838d5.target.value;
}
function setQuota(_0x2689da) {
  finalData.journey_details.quota = _0x2689da.target.value;
  document.querySelector('#quota-input').value = _0x2689da.target.value;
}
function journeyDateChanged(_0x7745db) {
  finalData.journey_details.date = _0x7745db.target.value;
}
function setTrainNumber(_0x25ace0) {
  finalData.journey_details["train-no"] = _0x25ace0.target.value;
}
function setPassengerDetails(_0x24839c, _0x543c28, _0x277bdc) {
  if (!finalData.passenger_details[_0x543c28]) {
    finalData.passenger_details[_0x543c28] = {};
  }
  finalData.passenger_details[_0x543c28][_0x24839c.target.name] = 'checkbox' === _0x24839c.target.type ? _0x24839c.target.checked : _0x24839c.target.value;
}
function setInfantDetails(_0x2bd3f4, _0x3c5e30, _0x3a5c5b) {
  if (!finalData.infant_details[_0x3c5e30]) {
    finalData.infant_details[_0x3c5e30] = {};
  }
  finalData.infant_details[_0x3c5e30][_0x2bd3f4.target.name] = _0x2bd3f4.target.value;
}
function setOtherPreferences(_0x36d102) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x36d102.target.name] = 'checkbox' === _0x36d102.target.type ? _0x36d102.target.checked : _0x36d102.target.value;
}
function setAutoCaptcha(_0x11dc08) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x11dc08.target.name] = 'checkbox' === _0x11dc08.target.type ? _0x11dc08.target.checked : _0x11dc08.target.value;
}
function setOtherPreferencesVpa(_0x4695ac) {
  if (!finalData.vpa) {
    finalData.vpa = {};
  }
  finalData.vpa[_0x4695ac.target.name] = _0x4695ac.target.value;
}
function setpaymentMethod(_0x200153) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.paymentmethod = _0x200153.target.value;
}
function setCaptchaSubmitMode(_0x2cfaee) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences.CaptchaSubmitMode = _0x2cfaee.target.value;
}
function setCardDetails(_0x5ba611) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  if ("cardnumber" == _0x5ba611.target.name) {
    finalData.other_preferences[_0x5ba611.target.name] = _0x5ba611.target.value;
  }
  if ("cardexpiry" == _0x5ba611.target.name) {
    finalData.other_preferences[_0x5ba611.target.name] = _0x5ba611.target.value;
  }
  if ("cardcvv" == _0x5ba611.target.name) {
    finalData.other_preferences[_0x5ba611.target.name] = _0x5ba611.target.value;
  }
  if ('cardholder' == _0x5ba611.target.name) {
    finalData.other_preferences[_0x5ba611.target.name] = _0x5ba611.target.value;
  }
  if ("staticpassword" == _0x5ba611.target.name) {
    finalData.other_preferences[_0x5ba611.target.name] = _0x5ba611.target.value;
  }
}
function setOtherPreferencesbooktime(_0x1e4e0b) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x1e4e0b.target.name] = _0x1e4e0b.target.value;
}
function setcardtype(_0x1191ff) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x1191ff.target.name] = _0x1191ff.target.value;
}
function setMobileNumber(_0x160834) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x160834.target.name] = _0x160834.target.value;
}
function setTravelPreferences(_0x2e5e64) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x2e5e64.target.name] = "checkbox" === _0x2e5e64.target.type ? _0x2e5e64.target.checked : _0x2e5e64.target.value;
}
function setAvailabilyCheck(_0x1c0ea7) {
  if (!finalData.travel_preferences) {
    finalData.travel_preferences = {};
  }
  finalData.travel_preferences[_0x1c0ea7.target.name] = "checkbox" === _0x1c0ea7.target.type ? _0x1c0ea7.target.checked : _0x1c0ea7.target.value;
}
function setIrctcWallet(_0x179f67) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x179f67.target.name] = "checkbox" === _0x179f67.target.type ? _0x179f67.target.checked : _0x179f67.target.value;
}
function setTokenString(_0x133eb7) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x133eb7.target.name] = _0x133eb7.target.value;
}
function setprojectId(_0x5e8375) {
  if (!finalData.other_preferences) {
    finalData.other_preferences = {};
  }
  finalData.other_preferences[_0x5e8375.target.name] = _0x5e8375.target.value;
}
function modifyUserData() {
  console.log("before modifyUserData");
  console.log(finalData);
  finalData.passenger_details = finalData.passenger_details?.["filter"](_0x2e2c5c => _0x2e2c5c.name?.['length'] > 0x0 && _0x2e2c5c.age?.["length"] > 0x0)?.["map"](_0x4b76f8 => ({
    'name': _0x4b76f8.name,
    'age': _0x4b76f8.age,
    'gender': _0x4b76f8.gender ?? 'M',
    'berth': _0x4b76f8.berth ?? '',
    'nationality': 'IN',
    'food': _0x4b76f8.food ?? 'D',
    'passengerchildberth': _0x4b76f8.passengerchildberth ?? false
  })) ?? [];
  finalData.infant_details = finalData.infant_details?.["filter"](_0x70edfc => _0x70edfc.name?.["length"] > 0x0)?.["map"](_0xae56a2 => ({
    'name': _0xae56a2.name,
    'age': _0xae56a2.age ?? '0',
    'gender': _0xae56a2.gender ?? 'M'
  })) ?? [];
  if (null == finalData.other_preferences.slbooktime) {
    finalData.other_preferences.slbooktime = document.getElementById("slbooktime").value;
  }
  if (null == finalData.other_preferences.acbooktime) {
    finalData.other_preferences.acbooktime = document.getElementById("acbooktime").value;
  }
  if (null == finalData.other_preferences.gnbooktime) {
    finalData.other_preferences.gnbooktime = document.getElementById("gnbooktime").value;
  }
  if (null == finalData.journey_details["class"]) {
    finalData.journey_details["class"] = document.getElementById('journey-class-input').value;
  }
  if (null == finalData.journey_details.quota) {
    finalData.journey_details.quota = document.getElementById("quota-input").value;
  }
  if (('TQ' === finalData.journey_details.quota || 'PT' === finalData.journey_details.quota) && finalData.passenger_details.length > 0x4) {
    alert("For tatkal quota Maximum 4 passengers allowed.");
  } else {
    if (null == finalData.journey_details.boarding) {
      finalData.journey_details.boarding = '';
    }
    if ('' == document.getElementById('boarding-station-input').value) {
      finalData.journey_details.boarding = '';
    }
    if (null == finalData.other_preferences.tokenString) {
      finalData.other_preferences.tokenString = '';
    }
    if (null == finalData.other_preferences.projectId) {
      finalData.other_preferences.projectId = '';
    }
    if (null == finalData.other_preferences.mobileNumber) {
      finalData.other_preferences.mobileNumber = '';
    }
    if (null == finalData.other_preferences.paymentmethod) {
      finalData.other_preferences.paymentmethod = document.getElementById("paymentMethod").value;
    }
    if (!document.getElementById("paymentMethod").value.includes("UPIID") || isValid_UPI_ID(document.getElementById("vpa").value)) {
      if (null == finalData.other_preferences.CaptchaSubmitMode) {
        finalData.other_preferences.CaptchaSubmitMode = document.getElementById("CaptchaSubmitMode").value;
      }
      if (null == finalData.other_preferences.cardnumber) {
        finalData.other_preferences.cardnumber = document.getElementById('cardnumber').value;
      }
      if (null == finalData.other_preferences.cardexpiry) {
        finalData.other_preferences.cardexpiry = document.getElementById("cardexpiry").value;
      }
      if (null == finalData.other_preferences.cardcvv) {
        finalData.other_preferences.cardcvv = document.getElementById("cardcvv").value;
      }
      if (null == finalData.other_preferences.cardholder) {
        finalData.other_preferences.cardholder = document.getElementById("cardholder").value;
      }
      if (null == finalData.other_preferences.cardtype) {
        finalData.other_preferences.cardtype = document.getElementById("cardtype").value;
      }
      if (null == finalData.other_preferences.staticpassword) {
        finalData.other_preferences.staticpassword = document.getElementById('staticpassword').value;
      }
      if (null == finalData.travel_preferences.AvailabilityCheck) {
        finalData.travel_preferences.AvailabilityCheck = 'A';
      }
      if (null == finalData.journey_details["train-no"]) {
        console.log("Set default train nr.");
        finalData.journey_details['train-no'] = "00000- DEFAULT";
      }
      console.log("after modifyUserData");
      console.log(finalData);
      chrome.storage.local.set(finalData);
      alert("Data saved successfully");
    } else {
      alert("Valid UPI ID is required for selected payment method.");
    }
  }
}
function isValid_UPI_ID(_0x4c4ec2) {
  let _0xfaa72d = new RegExp("^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$");
  return null != _0x4c4ec2 && 0x1 == _0xfaa72d.test(_0x4c4ec2);
}
function loadUserData() {
  chrome.storage.local.get(null, _0x48fe5f => {
    console.log("loadUserData");
    console.log(_0x48fe5f);
    if (0x0 !== Object.keys(_0x48fe5f).length) {
      document.querySelector("#irctc-login").value = _0x48fe5f.irctc_credentials.user_name;
      document.querySelector("#irctc-password").value = _0x48fe5f.irctc_credentials.password;
      document.querySelector("#from-station-input").value = _0x48fe5f.journey_details.from;
      document.querySelector("#destination-station-input").value = _0x48fe5f.journey_details.destination;
      document.querySelector('#boarding-station-input').value = _0x48fe5f.journey_details.boarding;
      document.querySelector("#journey-date").value = _0x48fe5f.journey_details.date;
      document.querySelector("#journey-class-input").value = _0x48fe5f.journey_details["class"];
      document.querySelector("#quota-input").value = _0x48fe5f.journey_details.quota;
      document.querySelector("#train-no").value = '' + _0x48fe5f.journey_details["train-no"];
      _0x48fe5f.passenger_details.forEach((_0x1c1f1b, _0x354f5e) => {
        document.querySelector('#passenger-name-' + (_0x354f5e + 0x1)).value = _0x1c1f1b.name ?? '';
        document.querySelector('#age-' + (_0x354f5e + 0x1)).value = _0x1c1f1b.age ?? '';
        document.querySelector("#passenger-gender-" + (_0x354f5e + 0x1)).value = _0x1c1f1b.gender ?? 'M';
        document.querySelector("#passenger-berth-" + (_0x354f5e + 0x1)).value = _0x1c1f1b.berth ?? '';
        document.querySelector('#passenger-food-' + (_0x354f5e + 0x1)).value = _0x1c1f1b.food ?? '';
        document.querySelector('#passengerchildberth' + (_0x354f5e + 0x1)).checked = _0x1c1f1b.passengerchildberth ?? false;
      });
      _0x48fe5f.infant_details.forEach((_0x55ac85, _0x42a3fd) => {
        document.querySelector('#Infant-name-' + (_0x42a3fd + 0x1)).value = _0x55ac85.name ?? '';
        document.querySelector("#Infant-age-" + (_0x42a3fd + 0x1)).value = _0x55ac85.age ?? '0';
        document.querySelector("#Infant-gender-" + (_0x42a3fd + 0x1)).value = _0x55ac85.gender ?? 'M';
      });
      if (_0x48fe5f.travel_preferences?.["travelInsuranceOpted"]) {
        document.querySelector('#travelInsuranceOpted-' + ("yes" === _0x48fe5f.travel_preferences?.["travelInsuranceOpted"] ? 0x1 : 0x2)).checked = true;
      }
      if (_0x48fe5f.travel_preferences.prefcoach) {
        document.querySelector("#prefcoach").value = _0x48fe5f.travel_preferences.prefcoach ?? '';
      }
      if (_0x48fe5f.travel_preferences.reservationchoice) {
        document.querySelector("#reservationchoice").value = _0x48fe5f.travel_preferences.reservationchoice ?? '';
      }
      try {
        if (_0x48fe5f.travel_preferences?.["AvailabilityCheck"]) {
          document.querySelector("#AvailabilityCheck-" + ('A' === _0x48fe5f.travel_preferences?.['AvailabilityCheck'] ? 0x1 : 'M' === _0x48fe5f.travel_preferences?.["AvailabilityCheck"] ? 0x2 : 'I' === _0x48fe5f.travel_preferences?.["AvailabilityCheck"] ? 0x3 : 0x1)).checked = true;
        } else {
          console.log("Load user data - set availability A - if not defined");
          chrome.storage.local.set({
            'travel_preferences': {
              'AvailabilityCheck': 'A'
            }
          }, () => {
            console.log("set AvailabilityCheck A");
          });
        }
      } catch {
        console.log("error getting availability check");
      }
      if (Object.keys(_0x48fe5f.other_preferences).length > 0x0) {
        document.querySelector("#autoUpgradation").checked = _0x48fe5f.other_preferences.autoUpgradation ?? false;
        document.querySelector("#confirmberths").checked = _0x48fe5f.other_preferences.confirmberths ?? false;
        document.querySelector("#acbooktime").value = _0x48fe5f.other_preferences.acbooktime;
        document.querySelector("#slbooktime").value = _0x48fe5f.other_preferences.slbooktime;
        if (_0x48fe5f.other_preferences.hasOwnProperty('gnbooktime')) {
          document.querySelector('#gnbooktime').value = _0x48fe5f.other_preferences.gnbooktime;
        } else {
          console.log("Load user data - set GN book time - if not defined");
          chrome.storage.local.set({
            'other_preferences': {
              'gnbooktime': "07:59:59"
            }
          }, () => {
            console.log("set gnbooktime");
          });
          document.querySelector("#gnbooktime").value = "07:59:59";
        }
        document.querySelector("#mobileNumber").value = _0x48fe5f.other_preferences.mobileNumber;
        document.querySelector('#paymentmethod').value = _0x48fe5f.other_preferences.paymentmethod;
        document.querySelector("#CaptchaSubmitMode").value = _0x48fe5f.other_preferences.CaptchaSubmitMode;
        document.querySelector('#autoCaptcha').checked = _0x48fe5f.other_preferences.autoCaptcha ?? false;
        document.querySelector('#psgManual').checked = _0x48fe5f.other_preferences.psgManual ?? false;
        document.querySelector("#paymentManual").checked = _0x48fe5f.other_preferences.paymentManual ?? false;
        document.querySelector("#tokenString").value = _0x48fe5f.other_preferences.tokenString;
        document.querySelector("#projectId").value = _0x48fe5f.other_preferences.projectId;
      }
      if (Object.keys(_0x48fe5f.vpa).length > 0x0 && '' !== _0x48fe5f.vpa.vpa) {
        console.log("load vpa", _0x48fe5f.vpa.vpa);
        document.querySelector("#vpa").hidden = false;
        document.querySelector("#vpa").value = _0x48fe5f.vpa.vpa;
      }
      if (!('DBTCRD' != _0x48fe5f.other_preferences.paymentmethod && "DBTCRDI" != _0x48fe5f.other_preferences.paymentmethod)) {
        document.getElementById("carddetails").hidden = false;
      }
      document.querySelector('#cardnumber').value = _0x48fe5f.other_preferences.cardnumber;
      document.querySelector('#cardexpiry').value = _0x48fe5f.other_preferences.cardexpiry;
      document.querySelector("#cardcvv").value = _0x48fe5f.other_preferences.cardcvv;
      document.querySelector("#cardholder").value = _0x48fe5f.other_preferences.cardholder;
      document.querySelector("#cardtype").value = _0x48fe5f.other_preferences.cardtype;
      document.querySelector("#staticpassword").value = _0x48fe5f.other_preferences.staticpassword;
      finalData = _0x48fe5f;
    }
  });
}
function getMsg(_0x783357, _0xba0f31) {
  return {
    'msg': {
      'type': _0x783357,
      'data': _0xba0f31
    },
    'sender': "popup",
    'id': "irctc"
  };
}
function saveForm() {
  modifyUserData();
}
function clearData() {
  if (0x1 == confirm("Do you want to clear data?")) {
    chrome.storage.local.clear();
  }
}
function connectWithBg() {
  startScript();
}
function startScript() {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "activate_script",
      'data': finalData
    },
    'sender': "popup",
    'id': "irctc"
  }, _0x30a5c7 => {
    console.log(_0x30a5c7, "activate_script response");
  });
}
function OpenSite() {
  window.open("https://powerbhai.site/ext/", "_blank");
}
function showirctcpswd() {
  var _0x2bfce5 = document.getElementById("irctc-password");
  if ("password" === _0x2bfce5.type) {
    _0x2bfce5.type = "text";
  } else {
    _0x2bfce5.type = "password";
  }
}
function showhdfcpass() {
  var _0x244133 = document.getElementById('staticpassword');
  if ("password" === _0x244133.type) {
    _0x244133.type = "text";
  } else {
    _0x244133.type = 'password';
  }
}
fetchStationData().then(_0x523a9a => {
  autocompleteSourcDstTrain(document.getElementById("from-station-input"), _0x523a9a, 'SOURCE');
  autocompleteSourcDstTrain(document.getElementById("destination-station-input"), _0x523a9a, "DEST");
  autocompleteSourcDstTrain(document.getElementById("boarding-station-input"), _0x523a9a, "BOARDING");
});
fetchTrainData().then(_0xd2278a => {
  autocompleteSourcDstTrain(document.getElementById("train-no"), _0xd2278a, "TRAIN");
});
window.addEventListener("load", () => {
  loadUserData();
  document.querySelector("#irctc-login").addEventListener("change", setIRCTCUsername);
  document.querySelector("#irctc-password").addEventListener("change", setIRCTCPassword);
  document.querySelector("#journey-date").addEventListener('change', journeyDateChanged);
  document.querySelector('#journey-class-input').addEventListener("change", setJourneyClass);
  document.querySelector("#quota-input").addEventListener('change', setQuota);
  for (let _0xae37db = 0x0; _0xae37db < 0x6; _0xae37db++) {
    document.querySelector("#passenger-name-" + (_0xae37db + 0x1)).addEventListener('change', _0xf13f23 => setPassengerDetails(_0xf13f23, _0xae37db, "passenger"));
    document.querySelector("#age-" + (_0xae37db + 0x1)).addEventListener('change', _0x1955ff => setPassengerDetails(_0x1955ff, _0xae37db, "passenger"));
    document.querySelector("#passenger-gender-" + (_0xae37db + 0x1)).addEventListener('change', _0xa29bad => setPassengerDetails(_0xa29bad, _0xae37db, "passenger"));
    document.querySelector("#passenger-berth-" + (_0xae37db + 0x1)).addEventListener("change", _0x2cb5cc => setPassengerDetails(_0x2cb5cc, _0xae37db, 'passenger'));
    document.querySelector("#passenger-food-" + (_0xae37db + 0x1)).addEventListener('change', _0x1e9190 => setPassengerDetails(_0x1e9190, _0xae37db, "passenger"));
    document.querySelector("#passengerchildberth" + (_0xae37db + 0x1)).addEventListener("change", _0x9f64d0 => setPassengerDetails(_0x9f64d0, _0xae37db, "passenger"));
  }
  for (let _0x27c230 = 0x0; _0x27c230 < 0x2; _0x27c230++) {
    document.querySelector("#Infant-name-" + (_0x27c230 + 0x1)).addEventListener("change", _0x1ac8ad => setInfantDetails(_0x1ac8ad, _0x27c230, "infant"));
    document.querySelector("#Infant-age-" + (_0x27c230 + 0x1)).addEventListener("change", _0x58f9a9 => setInfantDetails(_0x58f9a9, _0x27c230, "infant"));
    document.querySelector("#Infant-gender-" + (_0x27c230 + 0x1)).addEventListener("change", _0x1e2fe5 => setInfantDetails(_0x1e2fe5, _0x27c230, "infant"));
  }
  document.querySelector("#autoUpgradation").addEventListener("change", setOtherPreferences);
  document.querySelector("#autoCaptcha").addEventListener("change", setAutoCaptcha);
  document.querySelector("#psgManual").addEventListener('change', setAutoCaptcha);
  document.querySelector("#paymentManual").addEventListener("change", setAutoCaptcha);
  document.querySelector("#confirmberths").addEventListener("change", setOtherPreferences);
  document.querySelector('#vpa').addEventListener('change', setOtherPreferencesVpa);
  const _0x207d6e = document.querySelector("#cardnumber");
  _0x207d6e.addEventListener("keyup", () => {
    let _0x50fc22 = _0x207d6e.value;
    _0x50fc22 = _0x50fc22.replace(/\s/g, '');
    if (Number(_0x50fc22)) {
      _0x50fc22 = _0x50fc22.match(/.{1,4}/g);
      _0x50fc22 = _0x50fc22.join(" ");
      _0x207d6e.value = _0x50fc22;
      finalData.other_preferences.cardnumber = _0x207d6e.value;
    }
  });
  document.querySelector("#cardexpiry").addEventListener("change", setCardDetails);
  document.querySelector("#cardcvv").addEventListener("change", setCardDetails);
  document.querySelector('#cardholder').addEventListener('change', setCardDetails);
  document.querySelector("#paymentMethod").addEventListener('change', setpaymentMethod);
  document.querySelector('#CaptchaSubmitMode').addEventListener("change", setCaptchaSubmitMode);
  document.querySelector("#cardtype").addEventListener("change", setcardtype);
  document.querySelector("#slbooktime").addEventListener("change", setOtherPreferencesbooktime);
  document.querySelector("#acbooktime").addEventListener("change", setOtherPreferencesbooktime);
  document.querySelector("#gnbooktime").addEventListener("change", setOtherPreferencesbooktime);
  document.querySelector("#mobileNumber").addEventListener("change", setMobileNumber);
  document.querySelector("#travelInsuranceOpted-1").addEventListener("change", setTravelPreferences);
  document.querySelector("#travelInsuranceOpted-2").addEventListener("change", setTravelPreferences);
  document.querySelector("#AvailabilityCheck-1").addEventListener("change", setAvailabilyCheck);
  document.querySelector('#AvailabilityCheck-2').addEventListener("change", setAvailabilyCheck);
  document.querySelector("#AvailabilityCheck-3").addEventListener("change", setAvailabilyCheck);
  document.querySelector("#tokenString").addEventListener("change", setTokenString);
  document.querySelector('#projectId').addEventListener('change', setprojectId);
  document.querySelector("#staticpassword").addEventListener("change", setprojectId);
  document.querySelector("#submit-btn").addEventListener('click', saveForm);
  document.querySelector("#load-btn-1").addEventListener("click", () => {
  buyPlan();
});
  document.querySelector("#OpenSite").addEventListener("click", () => {
    OpenSite();
  });
  document.querySelector('#clear-btn').addEventListener('click', () => clearData());
  document.querySelector("#connect-btn").addEventListener("click", connectWithBg);
  document.querySelector("#showirctcpswd").addEventListener("click", showirctcpswd);
  document.querySelector("#showhdfcpass").addEventListener('click', showhdfcpass);
  document.querySelector("#reservationchoice").addEventListener('change', setTravelPreferences);
  document.querySelector("#prefcoach").addEventListener("change", setTravelPreferences);
});
function buyPlan() {
    // Remove old modal if exists
    const oldModal = document.getElementById('custom-modal');
    if (oldModal) oldModal.remove();

    // Create modal
    const modal = document.createElement('div');
    modal.id = 'custom-modal';
    modal.style.cssText = `
        display: flex; position: fixed; z-index: 9999; left: 0; top: 0; width: 100vw; height: 100vh;
        background: rgba(30,40,60,0.55); align-items: center; justify-content: center;
        backdrop-filter: blur(2.5px);
    `;

    modal.innerHTML = `
      <div style="
        background: #fff;
        border-radius: 28px;
        box-shadow: 0 8px 40px 0 rgba(31,38,135,0.37), 0 2px 8px 0 rgba(0,0,0,0.18);
        padding: 44px 32px 32px 32px;
        max-width: 410px;
        width: 92vw;
        text-align: center;
        color: #222;
        position: relative;
        border: 3px solid;
        border-image: linear-gradient(120deg, #ff512f 10%, #dd2476 40%, #43cea2 80%, #185a9d 100%) 1;
        backdrop-filter: blur(8px);
        animation: popIn 0.5s cubic-bezier(.68,-0.55,.27,1.55);
        font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
      ">
        <span id="close-modal" style="
          position: absolute; top: 16px; right: 24px; font-size: 30px; cursor: pointer; color: #fff;
          background: linear-gradient(90deg,#ff512f,#dd2476,#43cea2,#185a9d);
          border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;
          box-shadow: 0 2px 8px rgba(67,206,162,0.18);
          transition: background 0.2s;
        " onmouseover="this.style.background='#222'" onmouseout="this.style.background='linear-gradient(90deg,#ff512f,#dd2476,#43cea2,#185a9d)'">&times;</span>
        
        <h1 style="
          margin-bottom: 18px; font-size: 2.1em; font-weight: bold; letter-spacing: 1px;
          background: linear-gradient(90deg,#ff512f,#dd2476,#43cea2,#185a9d);
          -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent;
          text-shadow: 0 2px 8px rgba(67,206,162,0.12);
        ">Important Notice</h1>
        <p style="
          font-size: 1.25em; margin-bottom: 18px; font-weight: 600;
          background: linear-gradient(90deg,#ff512f,#dd2476,#43cea2,#185a9d);
          -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; color: transparent;
          text-shadow: 0 2px 8px rgba(67,206,162,0.12);
        ">
          Kisi se bhi <b style="color:#ff512f;text-shadow:0 1px 8px #fff;">extension buy</b> mat kro,<br>
          <span style="color:#43cea2;font-weight:700;">FREE</span> use kro!
        </p>
        <p style="font-size:1.13em; margin-bottom:0; color:#185a9d; font-weight:600; letter-spacing:0.5px;">
          Username and Password <span style="background:linear-gradient(90deg,#185a9d,#43cea2);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700;">POWERJI</span> dalo
        </p>
        <div style="margin-top:22px; font-size:0.98em; color:#888;">
          <span style="font-size:1.2em;"></span> <span style="font-style:italic;">Design by <b style="color:#dd2476;">POWERJI</b></span>
        </div>
      </div>
      <style>
        @keyframes popIn {
          0% { transform: scale(0.7); opacity: 0; }
          80% { transform: scale(1.05); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      </style>
    `;

    document.body.appendChild(modal);

    // Close modal on click
    document.getElementById('close-modal').onclick = function() {
        modal.remove();
    };
}