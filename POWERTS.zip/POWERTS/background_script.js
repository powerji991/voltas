let tabDetails;
let status_updates = {};
function getMsg(_0x119a1a, _0x274afa) {
  return {
    'msg': {
      'type': _0x119a1a,
      'data': _0x274afa
    },
    'sender': 'popup',
    'id': 'irctc'
  };
}
chrome.runtime.onMessage.addListener((_0x400a3, _0x4744a5, _0x218c31) => {
  if ("irctc" !== _0x400a3.id) {
    _0x218c31("Invalid Id");
    return;
  }
  let _0x2a0f00 = _0x400a3.msg.type;
  let _0x4e2527 = _0x400a3.msg.data;
  if ("activate_script" === _0x2a0f00) {
    chrome.tabs.create({
      'url': "https://www.irctc.co.in/nget/train-search"
    }, _0x47482e => {
      tabDetails = _0x47482e;
      chrome.scripting.executeScript({
        'target': {
          'tabId': _0x47482e.id
        },
        'files': ["./content_script.js"]
      });
    });
    _0x218c31("Script activated");
  } else if ("status_update" === _0x2a0f00) {
    if (!status_updates[_0x4744a5.id]) {
      status_updates[_0x4744a5.id] = [];
    }
    status_updates[_0x4744a5.id].push({
      'sender': _0x4744a5,
      'data': _0x4e2527
    });
  } else {
    _0x218c31("Something went wrong");
  }
});
chrome.tabs.onUpdated.addListener((_0x55ca18, _0xd9ad1, _0x3083a) => {
  if (_0x55ca18 === tabDetails?.['id'] && _0xd9ad1?.['status'] === "complete") {
    if (_0x3083a.url.includes("booking/train-list")) {
      chrome.tabs.sendMessage(tabDetails.id, {
        'msg': {
          'type': "selectJourney",
          'data': undefined
        },
        'sender': 'popup',
        'id': 'irctc'
      });
    }
    if (_0x3083a.url.includes('booking/psgninput')) {
      chrome.tabs.sendMessage(tabDetails.id, {
        'msg': {
          'type': "fillPassengerDetails",
          'data': undefined
        },
        'sender': 'popup',
        'id': 'irctc'
      });
    }
    if (_0x3083a.url.includes('booking/reviewBooking')) {
      chrome.tabs.sendMessage(tabDetails.id, {
        'msg': {
          'type': "reviewBooking",
          'data': undefined
        },
        'sender': 'popup',
        'id': 'irctc'
      });
    }
    if (_0x3083a.url.includes("payment/bkgPaymentOptions")) {
      chrome.tabs.sendMessage(tabDetails.id, {
        'msg': {
          'type': "bkgPaymentOptions",
          'data': undefined
        },
        'sender': 'popup',
        'id': 'irctc'
      });
    }
  }
});
chrome.runtime.onInstalled.addListener(_0x2542a4 => {
  if (_0x2542a4 === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.tabs.create({
      'url': "https://shahidtatkal.github.io/"
    });
  }
});