let user_data = {};
function fillVPA() {
  function _0x56b465(_0x4ab40a, _0x3bd237) {
    _0x4ab40a.dispatchEvent(new Event("keydown", {
      'bubbles': true
    }));
    _0x4ab40a.value = _0x3bd237;
    _0x4ab40a.dispatchEvent(new Event('keyup', {
      'bubbles': true
    }));
    _0x4ab40a.dispatchEvent(new Event("input", {
      'bubbles': true
    }));
    _0x4ab40a.dispatchEvent(new Event("change", {
      'bubbles': true
    }));
  }
  try {
    console.log("Fill paytm VPA new");
    document.getElementById('ptm-upi').getElementsByTagName("div")[0x1].getElementsByTagName("div")[0x0].click();
    console.log("Fill paytm VPA-after click");
    var _0x4b8feb = setInterval(function () {
      if (document.getElementsByName("upiMode").length > 0x0) {
        clearInterval(_0x4b8feb);
        var _0x3c21a5 = setInterval(function () {
          var _0x139aa1 = document.getElementsByName('upiMode')[0x0].parentNode.parentNode.parentNode.getElementsByTagName("input")[0x1];
          if (_0x139aa1 != null) {
            clearInterval(_0x3c21a5);
            _0x56b465(_0x139aa1, user_data.vpa.vpa);
            setTimeout(function () {
              try {
                const _0x42f24b = document.evaluate("//span[text()='Proceed']", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                console.log("click proceedButton");
                _0x42f24b.click();
              } catch (_0x394632) {
                console.error(_0x394632);
                alert("Unable to request UPI payment. Please proceed manually");
              }
            }, 0x1f4);
          }
        }, 0x64);
      }
    }, 0x1f4);
  } catch (_0x15170f) {
    console.error(_0x15170f);
    alert("Unable to request UPI payment. Please proceed manually");
  }
}
chrome.storage.local.get(null, _0x5d5fe5 => {
  user_data = _0x5d5fe5;
  if (user_data.other_preferences.paymentmethod == "PAYTMUPIID") {
    console.log("PAYTMUPIID");
    {
      if (document.readyState !== "loading") {
        fillVPA();
      } else {
        document.addEventListener('DOMContentLoaded', function () {
          fillVPA();
        });
      }
    }
  }
});