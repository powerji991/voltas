let user_data = {};
function getMsg(_0x28a1d3, _0x53cece) {
  return {
    'msg': {
      'type': _0x28a1d3,
      'data': _0x53cece
    },
    'sender': "content_script",
    'id': 'irctc'
  };
}
function statusUpdate(_0x1430f9) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "status_update",
      'data': {
        'status': _0x1430f9,
        'time': new Date().toString().split(" ")[0x4]
      }
    },
    'sender': 'content_script',
    'id': "irctc"
  });
}
function classTranslator(_0x38b32c) {
  labletext = '1A' === _0x38b32c ? "AC First Class (1A)" : 'EV' === _0x38b32c ? "Vistadome AC (EV)" : 'EC' === _0x38b32c ? "Exec. Chair Car (EC)" : '2A' === _0x38b32c ? "AC 2 Tier (2A)" : '3A' === _0x38b32c ? "AC 3 Tier (3A)" : '3E' === _0x38b32c ? "AC 3 Economy (3E)" : 'CC' === _0x38b32c ? "AC Chair car (CC)" : 'SL' === _0x38b32c ? "Sleeper (SL)" : '2S' === _0x38b32c ? "Second Sitting (2S)" : 'None';
  return labletext;
}
function quotaTranslator(_0x297af3) {
  if ('GN' === _0x297af3) {
    labletext = "GENERAL";
  } else {
    if ('TQ' === _0x297af3) {
      labletext = "TATKAL";
    } else {
      if ('PT' === _0x297af3) {
        labletext = "PREMIUM TATKAL";
      } else {
        if ('LD' === _0x297af3) {
          labletext = "LADIES";
        } else if ('SR' === _0x297af3) {
          labletext = "LOWER BERTH/SR.CITIZEN";
        } else {
          labletext;
        }
      }
    }
  }
  return labletext;
}
function addDelay(_0x5bcbbc) {
  const _0x5f0619 = Date.now();
  let _0x2c2188 = null;
  do {
    _0x2c2188 = Date.now();
  } while (_0x2c2188 - _0x5f0619 < _0x5bcbbc);
}
chrome.runtime.onMessage.addListener((_0x5e789f, _0x1c0644, _0x3df39d) => {
  if ("irctc" !== _0x5e789f.id) {
    return void _0x3df39d("Invalid Id");
  }
  const _0x5f5478 = _0x5e789f.msg.type;
  if ("selectJourney" === _0x5f5478) {
    console.log("selectJourney");
    popupbtn = document.querySelectorAll(".btn.btn-primary");
    if (popupbtn.length > 0x0) {
      popupbtn[0x1].click();
      console.log("Close last trxn popup");
    }
    const _0x9036c8 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
    console.log(user_data.journey_details["train-no"]);
    const _0x3f9692 = user_data.journey_details["train-no"];
    const _0x261927 = _0x9036c8.filter(_0x45d6ba => _0x45d6ba.querySelector("div.train-heading").innerText.trim().includes(_0x3f9692.split('-')[0x0]))[0x0];
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void alert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x261927) {
        console.log("Precheck - Train not found for search criteria.");
        return void alert("Precheck - Train(" + _0x3f9692 + ") not found for search criteria. You can manually proceed or correct data and restart the process.");
      }
      const _0x1d833b = classTranslator(user_data.journey_details["class"]);
      if (![..._0x261927.querySelectorAll("table tr td div.pre-avl")].filter(_0x8a4253 => _0x8a4253.querySelector("div").innerText === _0x1d833b)[0x0]) {
        console.log("Precheck - Selected Class not available in the train.");
        return void alert("Precheck - Selected Class not available in the train. You can manually proceed or correct data and restart the process.");
      }
    }
    const _0x355ee5 = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Automatically click");
      if ('TQ' === user_data.journey_details.quota || 'PT' === user_data.journey_details.quota || 'GN' === user_data.journey_details.quota) {
        console.log("Verify tatkal time");
        const _0x505ceb = user_data.journey_details["class"];
        requiredTime = "00:00:00";
        current_time = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x505ceb.toUpperCase())) {
          requiredTime = user_data.other_preferences.acbooktime;
        } else {
          requiredTime = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          requiredTime = user_data.other_preferences.gnbooktime;
        }
        console.log("requiredTime", requiredTime);
        var _0x3c4196 = 0x0;
        let _0x2b0e1a = new MutationObserver(_0x39215c => {
          current_time = new Date().toString().split(" ")[0x4];
          console.log("current_time", current_time);
          if (current_time > requiredTime) {
            _0x2b0e1a.disconnect();
            selectJourney();
          } else {
            if (0x0 == _0x3c4196) {
              console.log("Inside wait counter 0 ");
              try {
                const _0x2e2b8b = document.createElement("div");
                _0x2e2b8b.textContent = "Please wait..Booking will automatically start at " + requiredTime;
                _0x2e2b8b.style.textAlign = "center";
                _0x2e2b8b.style.color = 'white';
                _0x2e2b8b.style.height = "auto";
                _0x2e2b8b.style.fontSize = "20px";
                document.querySelector("#divMain > div > app-train-list > div> div > div > div.clearfix").insertAdjacentElement("afterend", _0x2e2b8b);
              } catch (_0x316ad9) {
                console.log("wait time failed", _0x316ad9.message);
              }
            }
            try {
              if (_0x3c4196 % 0x2 == 0x0) {
                console.log("counter1", _0x3c4196 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "green";
              } else {
                console.log("counter2", _0x3c4196 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "red";
              }
            } catch (_0x39d8ed) {}
            _0x3c4196 += 0x1;
            console.log("wait time");
          }
        });
        _0x2b0e1a.observe(_0x355ee5, {
          'childList': true,
          'subtree': true,
          'characterDataOldValue': true
        });
      } else {
        console.log("select journey GENERAL quota");
        selectJourney();
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Immediately click");
      selectJourney();
    }
  } else {
    if ('fillPassengerDetails' === _0x5f5478) {
      console.log("fillPassengerDetails");
      fillPassengerDetails();
    } else {
      if ('reviewBooking' === _0x5f5478) {
        console.log("reviewBooking");
        try {
          chrome.storage.local.get(['plan'], _0x445252 => {
  	let currentPlan = 'A';
  	if (currentPlan === 'A') {
    	console.log("User have active plan");
  	} else {
              
              try {
                document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
              } catch (_0x1bc299) {
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              }
            }
          });
        } catch (_0x45b639) {
          alert("Failed to validate plan. Please contact our support team");
          try {
            document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
          } catch (_0xa8e1b2) {
            window.location.href = 'https://www.irctc.co.in/nget/train-search';
          }
        }
        document.querySelector("#captcha").scrollIntoView({
          'behavior': 'smooth',
          'block': "center",
          'inline': "nearest"
        });
        if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
          setTimeout(() => {
            getCaptchaTC();
          }, 0x1f4);
        } else {
          console.log("Manuall captcha filling");
          const _0x3077d6 = document.querySelector("#captcha");
          _0x3077d6.value = 'X';
          _0x3077d6.dispatchEvent(new Event("input"));
          _0x3077d6.dispatchEvent(new Event("change"));
          _0x3077d6.focus();
        }
      } else {
        if ("bkgPaymentOptions" === _0x5f5478) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x5c1a64 = "Multiple Payment Service";
          let _0x115941 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x6ef959 = true;
          if (user_data.other_preferences.paymentmethod.includes("IRCUPI")) {
            _0x6ef959 = false;
            _0x5c1a64 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x115941 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
            console.log("Payment option-IRCUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes('PAYTMUPI')) {
            _0x5c1a64 = "BHIM/ UPI/ USSD";
            _0x115941 = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            console.log("Payment option-PAYTMUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PHONEPEUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Net Banking / Wallet / UPI (Powered by Paytm)";
            console.log("Payment option-PHONEPEUPI");
          }
	  if (user_data.other_preferences.paymentmethod.includes("RAZOUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Net Banking / UPI (Powered by Razorpay)";
            console.log("Payment option-RAZOUPI");
          }
	  if (user_data.other_preferences.paymentmethod.includes("ZAMBOUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            console.log("Payment option-ZAMBOUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("MOBUPI")) {
            const _0x53a91b = window.navigator.userAgent;
            console.log("BrowserUserAgent", _0x53a91b);
            if (_0x53a91b.includes("Android")) {
              console.log("Android browser");
              _0x5c1a64 = "Multiple Payment Service";
              _0x115941 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            }
          }
          if (user_data.other_preferences.paymentmethod.includes("IRCWA")) {
            _0x5c1a64 = "IRCTC eWallet";
            _0x115941 = "IRCTC eWallet";
            console.log("Payment option-IRCWA");
          }
          if (user_data.other_preferences.paymentmethod.includes("HDFCDB")) {
            _0x5c1a64 = "Payment Gateway / Credit Card / Debit Card";
            _0x115941 = "Visa/Master Card(Powered By HDFC BANK)";
            console.log("Payment option-HDFCDB");
          }
          let _0x3e8aaa = _0x115941.replace('&', "&amp;");
          let _0x5ca6e7 = false;
          var _0x5a86f5 = setInterval(() => {
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0x5a86f5);
              var _0x2354a9 = document.getElementById("pay-type").getElementsByTagName("div");
              for (i = 0x0; i < _0x2354a9.length; i++) {
                if (_0x2354a9[i].innerText.indexOf(_0x5c1a64) >= 0x0) {
                  if (_0x6ef959) {
                    _0x2354a9[i].click();
                  }
                  setTimeout(() => {
                    var _0x5370f0 = document.getElementsByClassName("border-all no-pad");
                    for (i = 0x0; i < _0x5370f0.length; i++) {
                      if (0x0 != _0x5370f0[i].getBoundingClientRect().top && -0x1 != _0x5370f0[i].getElementsByTagName("span")[0x0].innerHTML.toUpperCase().indexOf(_0x3e8aaa.toUpperCase())) {
                        if (_0x6ef959) {
                          _0x5370f0[i].click();
                        }
                        _0x5ca6e7 = true;
                        document.getElementsByClassName("btn-primary")[0x0].scrollIntoView({
                          'behavior': "smooth",
                          'block': "center",
                          'inline': "nearest"
                        });
                        if (user_data.other_preferences.hasOwnProperty("paymentManual") && user_data.other_preferences.paymentManual) {
                          alert("Manually submit the payment page.");
                        } else {
                          setTimeout(() => {
                            document.getElementsByClassName("btn-primary")[0x0].click();
                          }, 0x1f4);
                        }
                        break;
                      }
                      if (!(i != _0x5370f0.length - 0x1 || _0x5ca6e7)) {
                        alert("Selected payment option not available, please select other option manually.");
                      }
                    }
                  }, 0x1f4);
                }
              }
            }
          }, 0x1f4);
        } else {
          console.log("Nothing to do");
        }
      }
    }
  }
  _0x3df39d("Something went wrong");
});
let captchaRetry = 0x0;
function getCaptcha() {
  if (captchaRetry < 0x64) {
    console.log("getCaptcha");
    captchaRetry += 0x1;
    const _0x28733a = document.querySelector(".captcha-img");
    if (_0x28733a) {
      const _0x4a94fe = new XMLHttpRequest();
      const _0x36f699 = _0x28733a.src.substr(0x16);
      const _0x2f1c46 = JSON.stringify({
        'requests': [{
          'image': {
            'content': _0x36f699
          },
          'features': [{
            'type': 'TEXT_DETECTION'
          }],
          'imageContext': {
            'languageHints': ['en']
          }
        }]
      });
      user_data.other_preferences.projectId;
      _0x4a94fe.open('POST', 'https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ', false);
      _0x4a94fe.onload = function () {
        if (0xc8 != _0x4a94fe.status) {
          console.log("Error " + _0x4a94fe.status + ": " + _0x4a94fe.statusText);
          console.log(_0x4a94fe.response);
        } else {
          let _0x51955e = '';
          const _0x34af16 = document.querySelector('#captcha');
          _0x51955e = JSON.parse(_0x4a94fe.response).responses[0x0].fullTextAnnotation.text;
          console.log("Org text", _0x51955e);
          const _0x1fcfa6 = Array.from(_0x51955e.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x3eb148 = '';
          for (const _0x1a4c3c of _0x1fcfa6) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x1a4c3c)) {
            _0x3eb148 += _0x1a4c3c;
          }
          _0x34af16.value = _0x3eb148;
          if ('' == _0x51955e) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptcha();
            }, 0x1f4);
          }
          _0x34af16.dispatchEvent(new Event('input'));
          _0x34af16.dispatchEvent(new Event("change"));
          _0x34af16.focus();
          const _0x50213f = document.querySelector("app-login");
          const _0x12cd6f = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x2aec93 = new MutationObserver(_0x4b3782 => {
            if (_0x50213f && _0x50213f.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x2aec93.disconnect();
            }
            if (_0x12cd6f && _0x12cd6f.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptcha();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x2aec93.disconnect();
            }
          });
          if (_0x50213f) {
            console.log("observe loginCaptcha");
            _0x2aec93.observe(_0x50213f, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0x12cd6f) {
            console.log("observe reviewCaptcha");
            _0x2aec93.observe(_0x12cd6f, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
        }
      };
      _0x4a94fe.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x4a94fe.send(_0x2f1c46);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptcha();
      }, 0x3e8);
    }
  }
}
function getCaptchaTC() {
  if (captchaRetry < 0x64) {
    console.log("getCaptchaTC");
    captchaRetry += 0x1;
    const _0x3b97f5 = document.querySelector(".captcha-img");
    if (_0x3b97f5) {
      const _0x52004d = new XMLHttpRequest();
      const _0x241f3b = _0x3b97f5.src.substr(0x16);
      const _0x279c07 = JSON.stringify({
        'client': "chrome extension",
        'location': 'https://www.irctc.co.in/nget/train-search',
        'version': "0.3.8",
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': "zerox99107@gmail.com",
        'apikey': "e6jiBcV6mCApIZFAJD9o",
        'data': _0x241f3b
      });
      _0x52004d.open("POST", "https://api.apitruecaptcha.org/one/gettext", false);
      _0x52004d.onload = function () {
        if (0xc8 != _0x52004d.status) {
          console.log("Error " + _0x52004d.status + ": " + _0x52004d.statusText);
          console.log(_0x52004d.response);
        } else {
          let _0x1f4f37 = '';
          const _0x26fe7d = document.querySelector("#captcha");
          _0x1f4f37 = JSON.parse(_0x52004d.response).result;
          console.log("Org text", _0x1f4f37);
          const _0x3ae02c = Array.from(_0x1f4f37.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0xe768b6 = '';
          for (const _0x5cebd0 of _0x3ae02c) if ('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(_0x5cebd0)) {
            _0xe768b6 += _0x5cebd0;
          }
          _0x26fe7d.value = _0xe768b6;
          if ('' == _0x1f4f37) {
            console.log("Null captcha text from api");
            document.getElementsByClassName("glyphicon glyphicon-repeat")[0x0].parentElement.click();
            setTimeout(() => {
              getCaptchaTC();
            }, 0x1f4);
          }
          _0x26fe7d.dispatchEvent(new Event("input"));
          _0x26fe7d.dispatchEvent(new Event("change"));
          _0x26fe7d.focus();
          // Simulate a real user click on the captcha input after filling (INSTANT, no delay)
          _0x26fe7d.click();
          console.log('[VOLTAS Log] Simulated real user click on captcha input instantly.');
          const _0xcf889c = document.querySelector('app-login');
          const _0x1a2cfc = document.querySelector("#divMain > div > app-review-booking > p-toast");
          let _0x20e6a7 = new MutationObserver(_0x11d30a => {
            if (_0xcf889c && _0xcf889c.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect loginCaptcha");
              _0x20e6a7.disconnect();
            }
            if (_0x1a2cfc && _0x1a2cfc.innerText.toLowerCase().includes("valid captcha")) {
              setTimeout(() => {
                getCaptchaTC();
              }, 0x1f4);
              console.log("disconnect reviewCaptcha");
              _0x20e6a7.disconnect();
            }
          });
          if (_0xcf889c) {
            console.log("observe loginCaptcha");
            _0x20e6a7.observe(_0xcf889c, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (_0x1a2cfc) {
            console.log("observe reviewCaptcha");
            _0x20e6a7.observe(_0x1a2cfc, {
              'childList': true,
              'subtree': true,
              'characterDataOldValue': true
            });
          }
          if (undefined !== user_data.other_preferences.CaptchaSubmitMode && 'A' == user_data.other_preferences.CaptchaSubmitMode) {
            console.log("Auto submit captcha");
            const _0x1bdbed = document.querySelector("#divMain > app-login");
            if (_0x1bdbed) {
              const _0x150122 = _0x1bdbed.querySelector("button[type='submit'][class='search_btn train_Search']");
              const _0x5cfb97 = _0x1bdbed.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']");
              const _0x5a26aa = _0x1bdbed.querySelector("input[type='text'][formcontrolname='userid']");
              const _0x37c03e = _0x1bdbed.querySelector("input[type='password'][formcontrolname='password']");
              if ('' != _0x5a26aa.value && '' != _0x37c03e.value) {
                console.log("Submit login info and captcha");
                setTimeout(() => {
                  try {
                    _0x150122.click();
                  } catch (_0x37c70e) {}
                  try {
                    _0x5cfb97.click();
                  } catch (_0xd1b417) {}
                }, 0x1f4);
              } else {
                alert("Unable to auto submit loging info, username and password not filled,please submit manually");
              }
            }
            reviewPage = document.querySelector("#divMain > div > app-review-booking");
            if (reviewPage) {
              console.log('reviewPage', reviewPage);
              if ('' != document.querySelector("#captcha").value) {
                const _0x439ee7 = document.querySelector(".btnDefault.train_Search");
                if (_0x439ee7) {
                  setTimeout(() => {
                    console.log("Confirm berth", user_data.other_preferences.confirmberths);
                    if (user_data.other_preferences.confirmberths) {
                      if (document.querySelector('.AVAILABLE')) {
                        console.log("Seats available");
                        _0x439ee7.click();
                      } else {
                        if (0x1 != confirm("No seats Available, Do you still want to continue booking?")) {
                          return void console.log("No Seats available, STOP");
                        }
                        console.log("No Seats available, still Go ahead");
                        _0x439ee7.click();
                      }
                    } else {
                      _0x439ee7.click();
                    }
                  }, 0x1f4);
                }
              } else {
                alert("Captcha automatically not filled, submit manually");
              }
            }
          } else {
            console.log("Manual captcha submission");
          }
        }
      };
      _0x52004d.onerror = function () {
        console.log("Captcha API Request failed");
      };
      _0x52004d.send(_0x279c07);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptchaTC();
      }, 0x3e8);
    }
  }
}
function loadLoginDetails() {
  const _0x1d2765 = document.querySelector("#divMain > app-login");
  const _0x2d921d = _0x1d2765.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x45228d = _0x1d2765.querySelector("input[type='password'][formcontrolname='password']");
  _0x1d2765.querySelector("button[type='submit']");
  _0x2d921d.value = user_data.irctc_credentials.user_name ?? '';
  _0x2d921d.dispatchEvent(new Event("input"));
  _0x2d921d.dispatchEvent(new Event("change"));
  _0x45228d.value = user_data.irctc_credentials.password ?? '';
  _0x45228d.dispatchEvent(new Event("input"));
  _0x45228d.dispatchEvent(new Event("change"));
  document.querySelector("#captcha").scrollIntoView({
    'behavior': "smooth",
    'block': "center",
    'inline': 'nearest'
  });
  if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
    setTimeout(() => {
      getCaptchaTC();
    }, 0x1f4);
  } else {
    console.log("Manual captcha filling");
    const _0x4f4e85 = document.querySelector('#captcha');
    _0x4f4e85.value = 'X';
    _0x4f4e85.dispatchEvent(new Event("input"));
    _0x4f4e85.dispatchEvent(new Event("change"));
    _0x4f4e85.focus();
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x4425b4 = document.querySelector("app-jp-input form");
  const _0x45021a = _0x4425b4.querySelector("#origin > span > input");
  _0x45021a.value = user_data.journey_details.from;
  _0x45021a.dispatchEvent(new Event("keydown"));
  _0x45021a.dispatchEvent(new Event("input"));
  const _0x183221 = _0x4425b4.querySelector("#destination > span > input");
  _0x183221.value = user_data.journey_details.destination;
  _0x183221.dispatchEvent(new Event("keydown"));
  _0x183221.dispatchEvent(new Event("input"));
  const _0x4ab00d = _0x4425b4.querySelector("#jDate > span > input");
  _0x4ab00d.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0x4ab00d.dispatchEvent(new Event("keydown"));
  _0x4ab00d.dispatchEvent(new Event("input"));
  const _0x59a9b7 = _0x4425b4.querySelector("#journeyClass");
  _0x59a9b7.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x59a9b7.querySelectorAll("ul li")].filter(_0x43b03f => _0x43b03f.innerText === classTranslator(user_data.journey_details['class']) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x2ee36e = _0x4425b4.querySelector("#journeyQuota");
  _0x2ee36e.querySelector("div > div[role='button']").click();
  [..._0x2ee36e.querySelectorAll("ul li")].filter(_0x8265e => _0x8265e.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x12d5b6 = _0x4425b4.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log('filled_journey_details');
  _0x12d5b6.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details["train-no"]) {
    return;
  }
  const _0x32523 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  const _0xfa52c7 = _0x32523.filter(_0x1dace5 => _0x1dace5.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details["train-no"]))[0x0];
  if (!_0xfa52c7) {
    console.log("Train not found.");
    alert("Train not found");
    return void statusUpdate('journey_selection_stopped.no_train');
  }
  const _0x2a1498 = classTranslator(user_data.journey_details["class"]);
  const _0x5ef38f = new Date(user_data.journey_details.date).toString().split(" ");
  const _0x41cf3d = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].filter(_0x34bcf2 => _0x34bcf2.querySelector("div").innerText === _0x2a1498)[0x0]?.["click"]();
  const _0x31e570 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x1a41ca, _0x48be86) => {
    const _0x416796 = [..._0xfa52c7.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x257bfb => _0x257bfb.querySelector("div").innerText === _0x2a1498)[0x0];
    const _0x53af7d = [..._0xfa52c7.querySelectorAll("div div table td div.pre-avl")].filter(_0x3c1985 => _0x3c1985.querySelector("div").innerText === _0x5ef38f[0x0] + ", " + _0x5ef38f[0x2] + " " + _0x5ef38f[0x1])[0x0];
    const _0x59fa0f = _0xfa52c7.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x416796) {
      console.log(0x1);
      if (!_0x416796.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x416796.click();
      }
      if (_0x53af7d) {
        console.log(0x3);
        if (_0x53af7d.classList.contains('selected-class')) {
          console.log(0x4);
          _0x59fa0f.click();
          _0x48be86.disconnect();
        } else {
          console.log(0x5);
          _0x53af7d.click();
        }
      }
    } else {
      console.log('6');
      _0x53af7d.click();
      _0x59fa0f.click();
      _0x48be86.disconnect();
    }
  }).observe(_0xfa52c7, _0x41cf3d);
  const _0x4c13f8 = new MutationObserver((_0x3e32be, _0xbd52c7) => {
    console.log("Popup error");
    console.log("Class count ", [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x31e570.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].filter(_0x4e73f4 => _0x4e73f4.querySelector("div").innerText === _0x2a1498)[0x0]?.["click"]();
      _0xbd52c7.disconnect();
    }
  });
  _0x4c13f8.observe(_0x31e570, _0x41cf3d);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  const _0x450336 = setInterval(() => {
    const _0x4ef9b6 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0x1d0b16 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x12b6ab = _0x4ef9b6 || _0x1d0b16;
    const _0x5e7162 = document.querySelector("#loaderP");
    const _0x4e4c21 = _0x5e7162 && "none" !== _0x5e7162.style.display;
    if (_0x12b6ab && !_0x4e4c21) {
      console.log("Toast link found. Clicking it now...");
      _0x12b6ab.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x450336);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  const _0x55f7c3 = document.querySelector("#divMain > div > app-train-list");
  if (!_0x55f7c3) {
    return void console.error("Train list parent not found.");
  }
  const _0x517199 = Array.from(_0x55f7c3.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x2a5e89 = user_data.journey_details["train-no"];
  const _0x109709 = classTranslator(user_data.journey_details["class"]);
  const _0x15392a = new Date(user_data.journey_details.date);
  const _0x5a2695 = _0x15392a.toDateString().split(" ")[0x0] + ", " + _0x15392a.toDateString().split(" ")[0x2] + " " + _0x15392a.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x2a5e89);
  console.log("Class:", _0x109709);
  console.log("date", _0x5a2695);
  const _0x46c66c = _0x517199.find(_0x6ffbd4 => _0x6ffbd4.querySelector("div.train-heading").innerText.trim().includes(_0x2a5e89.split('-')[0x0]));
  if (!_0x46c66c) {
    console.error("Train not found.");
    return void statusUpdate('journey_selection_stopped.no_train');
  }
  const _0x148902 = _0x37dd8e => {
    if (!_0x37dd8e) {
      return false;
    }
    const _0x5a616b = window.getComputedStyle(_0x37dd8e);
    return 'none' !== _0x5a616b.display && "hidden" !== _0x5a616b.visibility && '0' !== _0x5a616b.opacity;
  };
  const _0x3717f5 = Array.from(_0x46c66c.querySelectorAll("table tr td div.pre-avl")).find(_0x5d0778 => _0x5d0778.querySelector("div").innerText.trim() === _0x109709);
  const _0x26ed04 = Array.from(_0x46c66c.querySelectorAll("span")).find(_0x4b03cf => _0x4b03cf.innerText.trim() === _0x109709);
  const _0x17effb = _0x3717f5 || _0x26ed04;
  console.log("FOUND updatedClassToClick:", _0x17effb);
  if (!_0x17effb) {
    return void console.error("Class to click not found.");
  }
  const _0x334fdb = document.querySelector("#loaderP");
  if (_0x148902(_0x334fdb)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0x29538d;
  _0x17effb.click();
  new MutationObserver((_0x1e31ce, _0x34ea47) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x29538d);
    _0x29538d = setTimeout(() => {
      const _0x157f95 = Array.from(_0x46c66c.querySelectorAll("div div table td div.pre-avl")).find(_0xa11edc => _0xa11edc.querySelector("div").innerText.trim() === _0x5a2695);
      console.log("FOUND classTabToSelect:", _0x157f95);
      if (_0x157f95) {
        _0x157f95.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          const _0xcccea7 = () => {
            const _0x38c633 = _0x46c66c.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x148902(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0xcccea7, 0x64);
            }
            if (!_0x38c633 || _0x38c633.classList.contains("disable-book") || _0x38c633.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              // INSTANT click on bookBtn after seat refresh, no delay
              _0x38c633.click();
              console.log("Clicked on bookBtn instantly");
              clearTimeout(_0x29538d);
              _0x34ea47.disconnect();
            }
          };
          _0xcccea7();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x46c66c, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
function fillPassengerDetails() {
  console.log("passenger_filling_started");
  if (user_data.journey_details.boarding.length > 0x0) {
    console.log("Set boarding station " + user_data.journey_details.boarding);
    const _0x823d6 = document.getElementsByTagName("strong");
    const _0x51808e = Array.from(_0x823d6).filter(_0x1807c7 => _0x1807c7.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x51808e[0x0]) {
      _0x51808e[0x0].click();
      addDelay(0x12c);
    }
    const _0x47e7eb = document.getElementsByTagName("strong");
    const _0x5caba7 = Array.from(_0x47e7eb).filter(_0x496bb2 => _0x496bb2.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x5caba7[0x0]) {
      _0x5caba7[0x0].click();
    }
  }
  keyCounter = new Date().getTime();
  const _0x3eeb46 = document.querySelector("app-passenger-input");
  let _0x3954bd = 0x1;
  for (; _0x3954bd < user_data.passenger_details.length;) {
    addDelay(0xc8);
    document.getElementsByClassName("prenext")[0x0].click();
    _0x3954bd++;
  }
  try {
    let _0x163857 = 0x0;
    for (; _0x163857 < user_data.infant_details.length;) {
      addDelay(0xc8);
      document.getElementsByClassName("prenext")[0x2].click();
      _0x163857++;
    }
  } catch (_0xd261ca) {
    console.error("add infant error", _0xd261ca);
  }
  const _0x2c35b9 = [..._0x3eeb46.querySelectorAll("app-passenger")];
  const _0x211eb5 = [..._0x3eeb46.querySelectorAll("app-infant")];
  user_data.passenger_details.forEach((_0x1069fd, _0x155fef) => {
    let _0x518e55 = _0x2c35b9[_0x155fef].querySelector("p-autocomplete > span > input");
    _0x518e55.value = _0x1069fd.name;
    _0x518e55.dispatchEvent(new Event("input"));
    let _0x58b1ff = _0x2c35b9[_0x155fef].querySelector("input[type='number'][formcontrolname='passengerAge']");
    _0x58b1ff.value = _0x1069fd.age;
    _0x58b1ff.dispatchEvent(new Event('input'));
    let _0x1dd530 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerGender']");
    _0x1dd530.value = _0x1069fd.gender;
    _0x1dd530.dispatchEvent(new Event("change"));
    let _0xf8b0a2 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerBerthChoice']");
    _0xf8b0a2.value = _0x1069fd.berth;
    _0xf8b0a2.dispatchEvent(new Event("change"));
    let _0x4f0813 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x4f0813) {
      _0x4f0813.value = _0x1069fd.food;
      _0x4f0813.dispatchEvent(new Event("change"));
    }
    try {
      let _0x307148 = _0x2c35b9[_0x155fef].querySelector("input[type='checkbox'][formcontrolname='childBerthFlag']");
      console.log("noChildberth", _0x155fef, _0x1069fd.passengerchildberth);
      if (_0x307148 && _0x1069fd.passengerchildberth) {
        console.log("set child half seat");
        _0x307148.click();
        addDelay(0xc8);
        if (document.evaluate("//div[contains(text(),'No berth will be allotted for child and')]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
          console.log("clikc OK");
          document.querySelector("app-passenger > p-dialog > div > div > div > p-footer > button").click();
          addDelay(0xc8);
        }
      }
    } catch (_0x46a3e3) {
      console.error("opt Half seat error", _0x46a3e3);
    }
  });
  try {
    user_data.infant_details.forEach((_0xeca955, _0x32bd02) => {
      let _0x2023cb = _0x211eb5[_0x32bd02].querySelector("input#infant-name[name='infant-name']");
      _0x2023cb.value = _0xeca955.name;
      _0x2023cb.dispatchEvent(new Event("input"));
      let _0x2fdac3 = _0x211eb5[_0x32bd02].querySelector("select[formcontrolname='age']");
      _0x2fdac3.value = _0xeca955.age;
      _0x2fdac3.dispatchEvent(new Event('change'));
      let _0x26bf61 = _0x211eb5[_0x32bd02].querySelector("select[formcontrolname='gender']");
      _0x26bf61.value = _0xeca955.gender;
      _0x26bf61.dispatchEvent(new Event("change"));
    });
  } catch (_0x580b44) {
    console.error("fill infant error", _0x580b44);
  }
  if ('' !== user_data.other_preferences.mobileNumber) {
    let _0x5d5368 = _0x3eeb46.querySelector("input#mobileNumber[formcontrolname='mobileNumber'][name='mobileNumber']");
    _0x5d5368.value = user_data.other_preferences.mobileNumber;
    _0x5d5368.dispatchEvent(new Event("input"));
  }
  let _0x35d6ea = [..._0x3eeb46.querySelectorAll("p-radiobutton[formcontrolname='paymentType'][name='paymentType'] input[type='radio']")];
  addDelay(0x64);
  let _0x36c0ec = '2';
  if (!user_data.other_preferences.paymentmethod.includes("UPI")) {
    _0x36c0ec = 0x1;
  }
  _0x35d6ea.filter(_0x3bf002 => _0x3bf002.value === _0x36c0ec)[0x0]?.["click"]();
  let _0x2d3efb = _0x3eeb46.querySelector("input#autoUpgradation[type='checkbox'][formcontrolname='autoUpgradationSelected']");
  if (_0x2d3efb && user_data.other_preferences.hasOwnProperty("autoUpgradation") && user_data.other_preferences.autoUpgradation) {
    _0x2d3efb.checked = user_data.other_preferences.autoUpgradation ?? false;
  }
  let _0x13931b = _0x3eeb46.querySelector("input#confirmberths[type='checkbox'][formcontrolname='bookOnlyIfCnf']");
  if (_0x13931b && user_data.other_preferences.hasOwnProperty("confirmberths") && user_data.other_preferences.confirmberths) {
    _0x13931b.checked = user_data.other_preferences.confirmberths ?? false;
  }
  let _0x350b21 = [..._0x3eeb46.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input[type='radio'][name='travelInsuranceOpted-0']")];
  addDelay(0xc8);
  _0x350b21.filter(_0x400214 => _0x400214.value === ('yes' === user_data.travel_preferences.travelInsuranceOpted ? "true" : "false"))[0x0]?.['click']();
  try {
    let _0x55bb51 = _0x3eeb46.querySelector("input[formcontrolname='coachId']");
    if (_0x55bb51 && user_data.travel_preferences.hasOwnProperty('prefcoach') && user_data.travel_preferences.prefcoach.trim().length > 0x0) {
      console.log("set preferred coach Id");
      _0x55bb51.value = user_data.travel_preferences.prefcoach;
    }
    const _0x49c9 = _0x3eeb46.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x49c9 && user_data.travel_preferences.hasOwnProperty("reservationchoice") && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      console.log("set reservationchoice");
      _0x49c9.querySelector("div > div[role='button']").click();
      addDelay(0x12c);
      [..._0x49c9.querySelectorAll("ul li")].filter(_0x18bc55 => _0x18bc55.innerText === user_data.travel_preferences.reservationchoice ?? '')[0x0]?.["click"]();
    }
  } catch (_0x188ef6) {
    console.error("pref coach and reservation choice error", _0x188ef6);
  }
  submitPassengerDetailsForm(_0x3eeb46);
}
function submitPassengerDetailsForm(_0x439043) {
  console.log("passenger_filling_completed");
  window.scrollBy(0x0, 0x258, 'smooth');
  if (user_data.other_preferences.hasOwnProperty("psgManual") && user_data.other_preferences.psgManual) {
    alert("Manually submit the passenger page.");
  } else {
    // INSTANT submit after fill, no delay
    _0x439043.querySelector("#psgn-form > form div > button.train_Search.btnDefault[type='submit']")?.click();
    window.scrollBy(0x0, 0x258, "smooth");
  }
}
function continueScript() {
  const _0x1ec64f = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if ('LOGOUT' === _0x1ec64f.innerText.trim().toUpperCase()) {
      loadJourneyDetails();
    }
    if ("LOGIN" === _0x1ec64f.innerText.trim().toUpperCase()) {
      _0x1ec64f.click();
      loadLoginDetails();
    }
  } else if (!window.location.href.includes("nget/booking/train-list")) {
    console.log("Nothing to do");
  }
}
async function a() {
  const _0x5bd35d = user_data.subs_credentials.user_name ?? '';
  console.log("Simulating plan check for:", _0x5bd35d);
  console.log("Fake plan check successful. Continuing...");
}
function closeIrctcAlertPopup() {
    // Try to find the OK button in the popup
    const okBtn = document.querySelector('.btn.btn-primary');
    if (okBtn && okBtn.innerText.trim().toUpperCase() === "OK") {
        okBtn.click();
        console.log("Closed IRCTC alert popup.");
        return true;
    }
    return false;
}

// Try to close the popup immediately, and also keep checking for a few seconds in case it appears late
let popupCloseAttempts = 0;
const popupCloseInterval = setInterval(() => {
    if (closeIrctcAlertPopup() || popupCloseAttempts > 20) {
        clearInterval(popupCloseInterval);
    }
    popupCloseAttempts++;
}, 200);

window.onload = function (_0xf9043b) {
  setInterval(function () {
    console.log('Repeater');
    statusUpdate("Keep listener alive.");
  }, 0x3a98);
  const _0x3f6fb2 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 ");
  new MutationObserver((_0x21e322, _0x557c11) => {
    if (_0x21e322.filter(_0x3a2190 => "childList" === _0x3a2190.type && _0x3a2190.addedNodes.length > 0x0 && [..._0x3a2190.addedNodes].filter(_0x43eac0 => "LOGOUT" === _0x43eac0?.["innerText"]?.["trim"]()?.["toUpperCase"]()).length > 0x0).length > 0x0) {
      _0x557c11.disconnect();
      loadJourneyDetails();
    } else {
      _0x3f6fb2.click();
      loadLoginDetails();
    }
  }).observe(_0x3f6fb2, {
    'attributes': false,
    'childList': true,
    'subtree': false
  });
  chrome.storage.local.get(null, _0x90969d => {
    user_data = _0x90969d;
    continueScript();
  });
};

console.log("[VOLTAS Log] Step 1: content_script.js loaded successfully.");