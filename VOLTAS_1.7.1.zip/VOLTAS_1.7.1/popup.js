// popup.js

// Function to show a custom alert message
function showCustomAlert(message) {
    const alertDiv = document.createElement('div');
    alertDiv.id = 'custom-alert';
    alertDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        padding: 20px;
        z-index: 10000;
        text-align: center;
        font-family: 'Inter', sans-serif;
        max-width: 90%;
        width: 300px;
    `;
    alertDiv.innerHTML = `
        <p class="text-lg font-semibold mb-4">${message}</p>
        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>
    `;
    document.body.appendChild(alertDiv);

    document.getElementById('custom-alert-ok').onclick = () => {
        alertDiv.remove();
    };
}

// Function to show a custom confirmation dialog
function showCustomConfirm(message, onYes, onNo) {
    const confirmDiv = document.createElement('div');
    confirmDiv.id = 'custom-confirm';
    confirmDiv.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        padding: 20px;
        z-index: 10000;
        text-align: center;
        font-family: 'Inter', sans-serif;
        max-width: 90%;
        width: 350px;
    `;
    confirmDiv.innerHTML = `
        <p class="text-lg font-semibold mb-4">${message}</p>
        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>
        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>
    `;
    document.body.appendChild(confirmDiv);

    document.getElementById('custom-confirm-yes').onclick = () => {
        confirmDiv.remove();
        if (onYes) onYes();
    };

    document.getElementById('custom-confirm-no').onclick = () => {
        confirmDiv.remove();
        if (onNo) onNo();
    };
}


let finalData = { 
    irctc_credentials: {}, 
    subs_credentials: {}, 
    journey_details: {}, 
    passenger_details: [], 
    infant_details: [],  
    travel_preferences: {}, 
    other_preferences: {}, 
    vpa: {}, 
    fare_limit: { 
        enableFareLimit: false, 
        maxFareAmount: "", 
        bookInPopup: false  
    },
    proxy_settings: {
        activeProxy: 'disabled',
        proxies: Array(5).fill(null).map(() => ({ ip: '', port: '', user: '', pass: '' })) 
    }
};

function autocompleteSourcDstTrain(e, t, a) { 
    var r;

    function n(e) { 
        if (!e) return !1; 
        !(function(e) { 
            for (var t = 0; t < e.length; t++) e[t].classList.remove("autocomplete-active"); 
        })(e), r >= e.length && (r = 0), r < 0 && (r = e.length - 1), e[r].classList.add("autocomplete-active"); 
    }

    function o(t) { 
        for (var a = document.getElementsByClassName("autocomplete-items"), r = 0; r < a.length; r++) t != a[r] && t != e && a[r].parentNode.removeChild(a[r]); 
    }
    e.addEventListener("input", function(n) { 
        var s, c, l, i = this.value; 
        if ((o(), !i)) return !1; 
        for (r = -1, (s = document.createElement("DIV")).setAttribute("id", this.id + "autocomplete-list"), s.setAttribute("class", "autocomplete-items"), this.parentNode.appendChild(s), l = 0; l < t.length; l++) t[l].toUpperCase().includes(i.toUpperCase()) && (((c = document.createElement("DIV")).innerHTML = "<strong>" + t[l].substr(0, i.length) + "</strong>"), (c.innerHTML += t[l].substr(i.length)), (c.innerHTML += "<input type='hidden' value='" + t[l] + "'>"), c.addEventListener("click", function(t) { 
            if (((e.value = this.getElementsByTagName("input")[0].value), "SOURCE" == a && (finalData.journey_details.from = this.getElementsByTagName("input")[0].value), "DEST" == a && (finalData.journey_details.destination = this.getElementsByTagName("input")[0].value), "TRAIN" == a)) { 
                const e = this.getElementsByTagName("input")[0].value; 
                finalData.journey_details["train-no"] = e.trim(); 
            }
            "BOARDING" == a && (finalData.journey_details.boarding = this.getElementsByTagName("input")[0].value), o(); 
        }), s.appendChild(c)); 
    }), e.addEventListener("keydown", function(e) { 
        var t = document.getElementById(this.id + "autocomplete-list"); 
        t && (t = t.getElementsByTagName("div")), 40 == e.keyCode ? (r++, n(t)) : 38 == e.keyCode ? (r--, n(t)) : 13 == e.keyCode && (e.preventDefault(), r > -1 && t && t[r].click()); 
    }), document.addEventListener("click", function(e) { 
        o(e.target); 
    });
}
const stationData = [], 
    stationList = []; 
async function fetchStationData() { 
    try {
        const e = await fetch("https://suryarajputg.github.io/accet/stationlist.json"); 
        if (!e.ok) throw ((showCustomAlert("Unable to fetch station data", `HTTP error! status: ${e.status}`), new Error("Unable to fetch station data", `HTTP error! status: ${e.status}`))); 
        const t = await e.json(); 
        stationData.push(...t); 
        for (let e in stationData) stationList.push(stationData[e].name + " - " + stationData[e].code); 
        return stationList; 
    } catch (e) {
        throw ((console.error("Station data fetching error:", e), showCustomAlert("Station data fetching error:", e), e)); 
    }
}
async function fetchTrainData() { 
    try {
        const e = await fetch("https://suryarajputg.github.io/accet/train_data.js"); 
        if (!e.ok) throw ((showCustomAlert("Unable to fetch train data", `HTTP error! status: ${e.status}`), new Error("Unable to fetch train data", `HTTP error! status: ${e.status}`))); 
        return (await e.text()).split(/\r?\n/); 
    } catch (e) {
        throw ((console.error("Train data fetching error:", e), showCustomAlert("Train data fetching error:", e), e)); 
    }
}

function setIRCTCUsername(e) { 
    finalData.irctc_credentials || (finalData.irctc_credentials = {}), (finalData.irctc_credentials.user_name = e.target.value), console.log("data-update", finalData); 
}

function setIRCTCPassword(e) { 
    (finalData.irctc_credentials.password = e.target.value), console.log("data-update", finalData); 
}

function setSubsUsername(e) { 
    finalData.subs_credentials || (finalData.subs_credentials = {}), (finalData.subs_credentials.user_name = e.target.value), console.log("data-update", finalData); 
}

function setSubsPassword(e) { 
    (finalData.subs_credentials.password = e.target.value), console.log("data-update", finalData); 
}

function setFromStation(e) { 
    (finalData.journey_details.from = e.target.value.toUpperCase()), (document.querySelector("#from-station-input").value = e.target.value); 
}

function setDestinationStation(e) { 
    (finalData.journey_details.destination = e.target.value.toUpperCase()), (document.querySelector("#destination-station-input").value = e.target.value); 
}

function setBoardingStation(e) { 
    (finalData.journey_details.boarding = e.target.value.toUpperCase()), (document.querySelector("#boarding-station-input").value = e.target.value); 
}

function setJourneyClass(e) { 
    (finalData.journey_details.class = e.target.value), (document.querySelector("#journey-class-input").value = e.target.value); 
}

function setQuota(e) { 
    (finalData.journey_details.quota = e.target.value), (document.querySelector("#quota-input").value = e.target.value); 
}

function journeyDateChanged(e) { 
    finalData.journey_details.date = e.target.value; 
}

function setTrainNumber(e) { 
    finalData.journey_details["train-no"] = e.target.value; 
}

function setPassengerDetails(e, t, a) { 
    finalData.passenger_details[t] || (finalData.passenger_details[t] = {}), (finalData.passenger_details[t][e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setInfantDetails(e, t, a) { 
    finalData.infant_details[t] || (finalData.infant_details[t] = {}), (finalData.infant_details[t][e.target.name] = e.target.value); 
}

function setOtherPreferences(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setAutoCaptcha(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setOtherPreferencesVpa(e) { 
    finalData.vpa || (finalData.vpa = {}), (finalData.vpa[e.target.name] = e.target.value); 
}

function setpaymentMethod(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences.paymentmethod = e.target.value); 
}

function setCaptchaSubmitMode(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences.CaptchaSubmitMode = e.target.value); 
}

function setCardDetails(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), "cardnumber" == e.target.name && (finalData.other_preferences[e.target.name] = e.target.value), "cardexpiry" == e.target.name && (finalData.other_preferences[e.target.name] = e.target.value), "cardcvv" == e.target.name && (finalData.other_preferences[e.target.name] = e.target.value), "cardholder" == e.target.name && (finalData.other_preferences[e.target.name] = e.target.value), "staticpassword" == e.target.name && (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setOtherPreferencesbooktime(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setcardtype(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setMobileNumber(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setTravelPreferences(e) { 
    finalData.travel_preferences || (finalData.travel_preferences = {}), (finalData.travel_preferences[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setAvailabilyCheck(e) { 
    finalData.travel_preferences || (finalData.travel_preferences = {}), (finalData.travel_preferences[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setIrctcWallet(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value); 
}

function setTokenString(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setprojectId(e) { 
    finalData.other_preferences || (finalData.other_preferences = {}), (finalData.other_preferences[e.target.name] = e.target.value); 
}

function setFareLimitPreferences(e) { 
    finalData.fare_limit || (finalData.fare_limit = { enableFareLimit: false, maxFareAmount: "", bookInPopup: false });  
    finalData.fare_limit[e.target.name] = "checkbox" === e.target.type ? e.target.checked : e.target.value; 
    console.log("fare_limit-update", finalData); 
}

function isValid_UPI_ID(e) { 
    let t = new RegExp("^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$"); 
    return null != e && 1 == t.test(e); 
}


// modifyUserData function update ki gayi hai
function modifyUserData(showSuccessAlert = true) { 
    console.log("before modifyUserData", finalData);
    finalData.passenger_details = finalData.passenger_details?.filter((e) => e.name?.length > 0 && e.age?.length > 0)?.map((e) => ({ 
        name: e.name,
        age: e.age,
        gender: e.gender ?? "M",
        berth: e.berth ?? "",
        nationality: "IN",
        food: e.food ?? "D",
        passengerchildberth: e.passengerchildberth ?? !1,
    })) ?? [];
    finalData.infant_details = finalData.infant_details?.filter((e) => e.name?.length > 0)?.map((e) => ({ 
        name: e.name,
        age: e.age ?? "0",
        gender: e.gender ?? "M",
    })) ?? [];

    // Ensure other_preferences and journey_details exist
    finalData.other_preferences = finalData.other_preferences || {};
    finalData.journey_details = finalData.journey_details || {};
    finalData.travel_preferences = finalData.travel_preferences || {};
    finalData.fare_limit = finalData.fare_limit || {};
     finalData.vpa = finalData.vpa || {};


    if (finalData.other_preferences.slbooktime == null) finalData.other_preferences.slbooktime = document.getElementById("slbooktime").value; 
    if (finalData.other_preferences.acbooktime == null) finalData.other_preferences.acbooktime = document.getElementById("acbooktime").value; 
    if (finalData.other_preferences.gnbooktime == null) finalData.other_preferences.gnbooktime = document.getElementById("gnbooktime").value; 
    if (finalData.journey_details.class == null) finalData.journey_details.class = document.getElementById("journey-class-input").value; 
    if (finalData.journey_details.quota == null) finalData.journey_details.quota = document.getElementById("quota-input").value; 

    if (("TQ" === finalData.journey_details.quota || "PT" === finalData.journey_details.quota) && finalData.passenger_details.length > 4) { 
        showCustomAlert("Maximum 4 passengers allowed for Tatkal quota."); // Yeh hamesha dikhega
        return false;
    }
    if (finalData.journey_details.boarding == null) finalData.journey_details.boarding = ""; 
    if (document.getElementById("boarding-station-input").value === "") finalData.journey_details.boarding = ""; 

    if (finalData.other_preferences.tokenString == null) finalData.other_preferences.tokenString = document.getElementById("tokenString") ? document.getElementById("tokenString").value : "";
    if (finalData.other_preferences.projectId == null) finalData.other_preferences.projectId = document.getElementById("projectId") ? document.getElementById("projectId").value : "";
    if (finalData.other_preferences.mobileNumber == null) finalData.other_preferences.mobileNumber = document.getElementById("mobileNumber").value; 
    if (finalData.other_preferences.paymentmethod == null) finalData.other_preferences.paymentmethod = document.getElementById("paymentMethod").value; 

    const paymentMethodElement = document.getElementById("paymentMethod");
    const vpaElement = document.getElementById("vpa");

    if (paymentMethodElement && paymentMethodElement.value.includes("UPIID")) {
        if (!isValid_UPI_ID(vpaElement ? vpaElement.value : "")) { 
             showCustomAlert("Valid UPI ID is required for selected payment method."); // Yeh hamesha dikhega
             return false;
        }
    }

    if (finalData.other_preferences.CaptchaSubmitMode == null) finalData.other_preferences.CaptchaSubmitMode = document.getElementById("CaptchaSubmitMode").value; 
    if (finalData.other_preferences.cardnumber == null) finalData.other_preferences.cardnumber = document.getElementById("cardnumber").value; 
    if (finalData.other_preferences.cardexpiry == null) finalData.other_preferences.cardexpiry = document.getElementById("cardexpiry").value; 
    if (finalData.other_preferences.cardcvv == null) finalData.other_preferences.cardcvv = document.getElementById("cardcvv").value; 
    if (finalData.other_preferences.cardholder == null) finalData.other_preferences.cardholder = document.getElementById("cardholder").value; 
    if (finalData.other_preferences.cardtype == null) finalData.other_preferences.cardtype = document.getElementById("cardtype").value; 
    if (finalData.other_preferences.staticpassword == null) finalData.other_preferences.staticpassword = document.getElementById("staticpassword").value; 

    const availabilityCheckRadios = document.getElementsByName("AvailabilityCheck");
    let availabilityCheckValue = "A"; // Default
    for (const radio of availabilityCheckRadios) {
        if (radio.checked) {
            availabilityCheckValue = radio.value;
            break;
        }
    }
    if (finalData.travel_preferences.AvailabilityCheck == null) finalData.travel_preferences.AvailabilityCheck = availabilityCheckValue;


    if (finalData.journey_details["train-no"] == null || finalData.journey_details["train-no"].trim() === "") finalData.journey_details["train-no"] = "00000- DEFAULT"; 

    if (finalData.fare_limit.enableFareLimit == null) finalData.fare_limit.enableFareLimit = document.getElementById("enableFareLimit").checked; 
    if (finalData.fare_limit.maxFareAmount == null) finalData.fare_limit.maxFareAmount = document.getElementById("maxFareAmount").value; 
    if (finalData.fare_limit.bookInPopup == null) finalData.fare_limit.bookInPopup = document.getElementById("bookInPopup").checked; 

    // --- PROXY SETTINGS SAVING LOGIC ADDED ---
    finalData.proxy_settings = { activeProxy: 'disabled', proxies: [] }; // Default to disabled
    const checkedProxyRadio = document.querySelector('input[name="proxySelection"]:checked');
    if (checkedProxyRadio) {
        finalData.proxy_settings.activeProxy = checkedProxyRadio.value;
    }

    for (let i = 0; i < 5; i++) {
        const proxyIndex = i + 1;
        const ipElem = document.getElementById(`proxy-ip-${proxyIndex}`);
        const portElem = document.getElementById(`proxy-port-${proxyIndex}`);
        const userElem = document.getElementById(`proxy-user-${proxyIndex}`);
        const passElem = document.getElementById(`proxy-pass-${proxyIndex}`);

        finalData.proxy_settings.proxies.push({
            ip: ipElem ? ipElem.value.trim() : '',
            port: portElem ? portElem.value.trim() : '',
            user: userElem ? userElem.value.trim() : '',
            pass: passElem ? passElem.value.trim() : ''
        });
    }
    // --- END OF PROXY SETTINGS SAVING LOGIC ---

    console.log("after modifyUserData", finalData);
    chrome.storage.local.set(finalData); 

    // --- SEND PROXY UPDATE MESSAGE ---
    chrome.runtime.sendMessage({action:"updateProxy"}, function(response) {
        if (chrome.runtime.lastError) {
            console.warn("Error sending updateProxy message:", chrome.runtime.lastError.message);
        } else {
            console.log("updateProxy message sent, response:", response);
        }
    });
    // --- END OF SEND PROXY UPDATE MESSAGE ---

    if (showSuccessAlert) showCustomAlert("Data saved successfully"); 
    return true;
}


function loadUserData() { 
    chrome.storage.local.get(null, (e) => { 
        if (0 !== Object.keys(e).length) { 
          if(e.irctc_credentials!=null){ 
            document.querySelector("#irctc-login").value = e.irctc_credentials.user_name; 
            document.querySelector("#irctc-password").value = e.irctc_credentials.password; 
            document.querySelector("#from-station-input").value = e.journey_details.from; 
            document.querySelector("#destination-station-input").value = e.journey_details.destination; 
            document.querySelector("#boarding-station-input").value = e.journey_details.boarding; 
            document.querySelector("#journey-date").value = e.journey_details.date; 
            document.querySelector("#journey-class-input").value = e.journey_details.class; 
            document.querySelector("#quota-input").value = e.journey_details.quota; 
            document.querySelector("#train-no").value = `${e.journey_details["train-no"]}`; 
            e.passenger_details.forEach((psgn, t) => { 
                document.querySelector(`#passenger-name-${t + 1}`).value = psgn.name ?? ""; 
                document.querySelector(`#age-${t + 1}`).value = psgn.age ?? ""; 
                document.querySelector(`#passenger-gender-${t + 1}`).value = psgn.gender ?? "M"; 
                document.querySelector(`#passenger-berth-${t + 1}`).value = psgn.berth ?? ""; 
                document.querySelector(`#passenger-food-${t + 1}`).value = psgn.food ?? ""; 
                document.querySelector(`#passengerchildberth${t + 1}`).checked = psgn.passengerchildberth ?? !1; 
            });
            e.infant_details && e.infant_details.forEach((infant, t) => {  
                document.querySelector(`#Infant-name-${t + 1}`).value = infant.name ?? ""; 
                document.querySelector(`#Infant-age-${t + 1}`).value = infant.age ?? "0"; 
                document.querySelector(`#Infant-gender-${t + 1}`).value = infant.gender ?? "M"; 
            });
            if (e.travel_preferences?.travelInsuranceOpted) { 
                 const travelInsuranceValue = e.travel_preferences.travelInsuranceOpted === "yes" ? "1" : "2"; 
                 const radioElement = document.querySelector("#travelInsuranceOpted-" + travelInsuranceValue); 
                 if (radioElement) radioElement.checked = true; 
            }
            if (e.travel_preferences?.prefcoach) document.querySelector("#prefcoach").value = e.travel_preferences.prefcoach ?? ""; 
            if (e.travel_preferences?.reservationchoice) document.querySelector("#reservationchoice").value = e.travel_preferences.reservationchoice ?? ""; 

            try {
                if (e.travel_preferences?.AvailabilityCheck) { 
                    const availabilityCheckValue = e.travel_preferences.AvailabilityCheck; 
                    let radioIndex;
                    if (availabilityCheckValue === "A") radioIndex = 1; 
                    else if (availabilityCheckValue === "M") radioIndex = 2; 
                    else if (availabilityCheckValue === "I") radioIndex = 3; 
                    else radioIndex = 1; // Default
                    const radioElement = document.querySelector("#AvailabilityCheck-" + radioIndex);
                    if (radioElement) radioElement.checked = true;
                } else {
                     const defaultRadio = document.querySelector("#AvailabilityCheck-1"); // Default to 'A'
                     if (defaultRadio) defaultRadio.checked = true;
                }
            } catch(err) { 
                console.log("Error setting availability check from storage", err);
                 const defaultRadio = document.querySelector("#AvailabilityCheck-1");
                 if (defaultRadio) defaultRadio.checked = true;
            }

            if (e.other_preferences && Object.keys(e.other_preferences).length > 0) { 
                document.querySelector("#autoUpgradation").checked = e.other_preferences.autoUpgradation ?? !1; 
                document.querySelector("#confirmberths").checked = e.other_preferences.confirmberths ?? !1; 
                document.querySelector("#acbooktime").value = e.other_preferences.acbooktime; 
                document.querySelector("#slbooktime").value = e.other_preferences.slbooktime; 
                document.querySelector("#gnbooktime").value = e.other_preferences.gnbooktime ?? "07:59:59"; 
                document.querySelector("#mobileNumber").value = e.other_preferences.mobileNumber; 
                document.querySelector("#paymentMethod").value = e.other_preferences.paymentmethod; 
                document.querySelector("#CaptchaSubmitMode").value = e.other_preferences.CaptchaSubmitMode; 
                document.querySelector("#autoCaptcha").checked = e.other_preferences.autoCaptcha ?? !1; 
                document.querySelector("#psgManual").checked = e.other_preferences.psgManual ?? !1; 
                document.querySelector("#paymentManual").checked = e.other_preferences.paymentManual ?? !1; 
                if (document.querySelector("#tokenString")) document.querySelector("#tokenString").value = e.other_preferences.tokenString; 
                if (document.querySelector("#projectId")) document.querySelector("#projectId").value = e.other_preferences.projectId; 
                 document.querySelector("#cardnumber").value = e.other_preferences.cardnumber; 
                document.querySelector("#cardexpiry").value = e.other_preferences.cardexpiry; 
                document.querySelector("#cardcvv").value = e.other_preferences.cardcvv; 
                document.querySelector("#cardholder").value = e.other_preferences.cardholder; 
                document.querySelector("#cardtype").value = e.other_preferences.cardtype; 
                document.querySelector("#staticpassword").value = e.other_preferences.staticpassword; 
            }
            if (e.vpa && Object.keys(e.vpa).length > 0 && e.vpa.vpa !== "") { 
                 const vpaElement = document.querySelector("#vpa");
                 if(vpaElement) {
                    vpaElement.value = e.vpa.vpa; 
                 }
            }
             const paymentMethodVal = e.other_preferences?.paymentmethod;
             const cardDetailsDiv = document.getElementById("carddetails");
             if(cardDetailsDiv && (paymentMethodVal === "DBTCRD" || paymentMethodVal === "DBTCRDI" || paymentMethodVal === "HDFCDB")) { 
                // cardDetailsDiv.hidden = false; // This was the original condition.
                // Corrected logic based on HTML: HDFCDB shows card details.
             }


            if (e.fare_limit) { 
                document.querySelector("#enableFareLimit").checked = e.fare_limit.enableFareLimit ?? false; 
                document.querySelector("#maxFareAmount").value = e.fare_limit.maxFareAmount ?? ""; 
                document.querySelector("#bookInPopup").checked = e.fare_limit.bookInPopup ?? false;  
            }

            // --- PROXY SETTINGS LOADING LOGIC ADDED ---
            if (e.proxy_settings) {
                const settings = e.proxy_settings;
                const activeRadio = document.querySelector(`input[name="proxySelection"][value="${settings.activeProxy || 'disabled'}"]`);
                if (activeRadio) {
                    activeRadio.checked = true;
                }
                if (settings.proxies && Array.isArray(settings.proxies)) {
                    settings.proxies.forEach((proxy, i) => {
                        const proxyIndex = i + 1;
                        const ipElem = document.getElementById(`proxy-ip-${proxyIndex}`);
                        const portElem = document.getElementById(`proxy-port-${proxyIndex}`);
                        const userElem = document.getElementById(`proxy-user-${proxyIndex}`);
                        const passElem = document.getElementById(`proxy-pass-${proxyIndex}`);

                        if(ipElem) ipElem.value = proxy.ip || '';
                        if(portElem) portElem.value = proxy.port || '';
                        if(userElem) userElem.value = proxy.user || '';
                        if(passElem) passElem.value = proxy.pass || '';
                    });
                }
            } else { // Default if no proxy_settings in storage
                 const disabledRadio = document.querySelector('input[name="proxySelection"][value="disabled"]');
                 if (disabledRadio) disabledRadio.checked = true;
            }
            // --- END OF PROXY SETTINGS LOADING LOGIC ---

            finalData = e; 
        }
      }
    });
}

function getMsg(e, t) { 
    return { 
        msg: { 
            type: e, 
            data: t 
        },
        sender: "popup", 
        id: "irctc" 
    };
}

function saveForm() { 
     modifyUserData(true);
}

function clearData() {
  showCustomConfirm("Do you want to clear data?",
    async () => {  // Make the callback async so you can use await
      
      const deviceId = await getDeviceId();

      chrome.storage.local.clear(async () => {
        let finalData = {
          irctc_credentials: {},
          subs_credentials: {},
          journey_details: {},
          passenger_details: [],
          infant_details: [],
          travel_preferences: {},
          other_preferences: {},
          vpa: {},
          fare_limit: {
            enableFareLimit: false,
            maxFareAmount: "",
            bookInPopup: false
          },
          // --- ADDED proxy_settings to clearData ---
          proxy_settings: {
            activeProxy: 'disabled',
            proxies: Array(5).fill(null).map(() => ({
              ip: '',
              port: '',
              user: '',
              pass: ''
            }))
          }
        };

        const formElement = document.querySelector("form");
        if (formElement) formElement.reset();

        loadUserData(); // Will also reset proxy UI due to updated loadUserData
        showCustomAlert("Data cleared successfully!");

        // Save the preserved deviceId
        await chrome.storage.local.set({ deviceId });
      });
    },
    () => {
      console.log("Data clear cancelled.");
    }
  );
}


function startScript() { 
    chrome.runtime.sendMessage(getMsg("activate_script", finalData), (e) => { 
        console.log(e, "activate_script response"); 
    });
}

// processBookingRequest function API call ke liye
async function processBookingRequest() {
    const mainLoader = document.getElementById("loader");
    const licenseSectionLoader = document.getElementById("loader-license");
    const messageDiv = document.getElementById("dvMessage");

    if (mainLoader) mainLoader.classList.add("fa", "fa-spinner", "fa-spin");
    if (licenseSectionLoader) licenseSectionLoader.classList.add("fa", "fa-spinner", "fa-spin");
    if (messageDiv) messageDiv.innerText = "";

    try {
        const subscriberKeyElement = document.getElementById("subscriber-key");
        const subscriberKey = subscriberKeyElement ? subscriberKeyElement.value : '';

        if (!subscriberKey) {
            const msg = "Please enter your subscriber key.";
            if (messageDiv) messageDiv.innerText = msg;
            else showCustomAlert(msg);
            // Loaders ko yahan bhi remove karna chahiye agar key nahi hai
            if (mainLoader) mainLoader.classList.remove("fa", "fa-spinner", "fa-spin");
            if (licenseSectionLoader) licenseSectionLoader.classList.remove("fa", "fa-spinner", "fa-spin");
            return;
        }

        const deviceId = await getDeviceId();
        const url = 'https://avoltas.shop/api/get';
        const apiCallData = {
            UserName: subscriberKey,
            MacAddress: deviceId
        };

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(apiCallData)
        });

        let apiMessageToDisplay = "";
        if (!response.ok) {
            try {
                const errorResult = await response.json();
                apiMessageToDisplay = errorResult.message || `Licensing check failed: HTTP error ${response.status}`;
            } catch (e) {
                apiMessageToDisplay = `Licensing check failed: HTTP error ${response.status}. Invalid response from server.`;
            }
            if (messageDiv) messageDiv.innerText = apiMessageToDisplay;
            else showCustomAlert(apiMessageToDisplay);
            return; // API error ke baad return
        }

        const result = await response.json();

        if (result.success) {
            console.log("API license check successful.");
            const dataPreparationSuccess = modifyUserData(false); // success alert suppress hoga

            if (dataPreparationSuccess) {
                // Data prepare ho gaya aur modifyUserData mein save bhi ho gaya. Ab startScript call karo.
                startScript();
            } else {
                // modifyUserData ne false return kiya, critical alert usne dikha diya hoga.
                console.error("Data preparation failed (e.g., validation error). Booking aborted.");
            }
        } else {
            apiMessageToDisplay = result.message || "Subscription key is not valid or an unknown error occurred.";
            if (messageDiv) messageDiv.innerText = apiMessageToDisplay;
            else showCustomAlert(apiMessageToDisplay);
        }
    } catch (error) {
        console.error("Booking request processing failed:", error);
        const errorText = "Error during booking process: " + error.message;
        if (messageDiv) messageDiv.innerText = errorText;
        else showCustomAlert(errorText);
    } finally {
        if (mainLoader) mainLoader.classList.remove("fa", "fa-spinner", "fa-spin");
        if (licenseSectionLoader) licenseSectionLoader.classList.remove("fa", "fa-spinner", "fa-spin");
    }
}

// connectWithBg ab processBookingRequest ko call karega
function connectWithBg() { 
    processBookingRequest();
}


function buyPlan() { 
    const existingPopup = document.getElementById("custom-popup"); 
    if (existingPopup) existingPopup.remove(); 
    const popup = document.createElement("div"); 
    popup.style.position = "fixed"; 
    popup.style.top = "0"; 
    popup.style.left = "0"; 
    popup.style.width = "100%"; 
    popup.style.height = "100%"; 
    popup.style.backgroundColor = "rgba(0, 0, 0, 0.6)"; 
    popup.style.zIndex = "9999"; 
    popup.style.display = "flex"; 
    popup.style.justifyContent = "center"; 
    popup.style.alignItems = "center"; 
    const popupContent = document.createElement("div"); 
    popupContent.style.position = "relative"; 
    popupContent.style.width = "90%"; 
    popupContent.style.maxWidth = "800px"; 
    popupContent.style.height = "80%"; 
    popupContent.style.backgroundColor = "#fff"; 
    popupContent.style.borderRadius = "10px"; 
    popupContent.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)"; 
    popupContent.style.overflow = "hidden"; 
    const closeButton = document.createElement("button"); 
    closeButton.innerText = "X"; 
    closeButton.style.position = "absolute"; 
    closeButton.style.top = "10px"; 
    closeButton.style.right = "15px"; 
    closeButton.style.fontSize = "24px"; 
    closeButton.style.background = "none"; 
    closeButton.style.border = "none"; 
    closeButton.style.cursor = "pointer"; 
    closeButton.onclick = () => popup.remove(); 
    const iframe = document.createElement("iframe"); 
    iframe.src = "https://avoltas.shop/"; 
    iframe.style.width = "100%"; 
    iframe.style.height = "100%"; 
    iframe.style.border = "none"; 
    popupContent.appendChild(closeButton); 
    popupContent.appendChild(iframe); 
    popup.appendChild(popupContent); 
    document.body.appendChild(popup); 
}

function OpenSite() { 
    window.open("https://avoltas.shop/"); 
}

function showsubscriberpswd() { 
    var e = document.getElementById("subscriber-password"); 
    "password" === e.type ? (e.type = "text") : (e.type = "password"); 
}

function showirctcpswd() { 
    var e = document.getElementById("irctc-password"); 
    "password" === e.type ? (e.type = "text") : (e.type = "password"); 
}

function showhdfcpass() { 
    var e = document.getElementById("staticpassword"); 
    "password" === e.type ? (e.type = "text") : (e.type = "password"); 
}

async function getDeviceId() {
  const result = await chrome.storage.local.get('deviceId');

  const hasDeviceId = result.hasOwnProperty('deviceId');
  const validDeviceId = hasDeviceId && typeof result.deviceId === 'string' && result.deviceId.trim() !== '';

  if (!validDeviceId) {
    const newId = crypto.randomUUID();
    await chrome.storage.local.set({ deviceId: newId });
    return newId;
  }

  return result.deviceId;
}


async function login(){ 
  const deviceId = await getDeviceId(); 
  const url = 'https://avoltas.shop/api/get';  
    const data = { 
        UserName: document.getElementById("subscriber-key").value, 
        MacAddress: deviceId 
    };

    const messageDiv = document.getElementById("dvMessage");
    if (messageDiv) messageDiv.innerText = ""; // Clear previous messages

    try {
        const response = await fetch(url, { 
        method: 'POST', 
        headers: { 
            'Content-Type': 'application/json'  
        },
        body: JSON.stringify(data) 
        });

        if (!response.ok) { 
            let errorMsg = `HTTP error! Status: ${response.status}`;
            try {
                const errorResult = await response.json();
                errorMsg = errorResult.message || errorMsg;
            } catch (e) { /* ignore parsing error */ }
            if (messageDiv) messageDiv.innerText = errorMsg;
            else showCustomAlert(errorMsg);
            return; 
        }

        const result = await response.json(); 
        if(result.success){ 
            const dvMain = document.querySelector("#dvMain");
            const dvRegister = document.querySelector("#dvRegister");
            const userPlanExpiry = document.querySelector("#UserPlanExpairy");

            if (dvMain) dvMain.style.display = "block"; 
            if (dvRegister) dvRegister.style.display = "none"; 
            if (userPlanExpiry) userPlanExpiry.innerText = result.leftDays; 

            await chrome.storage.local.set({ licencekey: data.UserName }); 
        }
        else{ 
            const apiMessage = result.message || "Invalid Key!"; 
            if (messageDiv) messageDiv.innerText = apiMessage; 
            else showCustomAlert(apiMessage); 
        }
    } catch(error) { 
        console.error("Login API call failed:", error); 
        const errorText = "Error connecting to server. Please try again."; 
        if (messageDiv) messageDiv.innerText = errorText; 
        else showCustomAlert(errorText); 
    }
}

// --- PROXY UI CREATION FUNCTION ADDED ---
function createProxyUI() {
    const proxyListDiv = document.getElementById('proxy-list');
    if (!proxyListDiv) return;
    proxyListDiv.innerHTML = ''; // Clear existing
    for (let i = 0; i < 5; i++) {
        const proxyIndex = i + 1;
        const proxySlot = document.createElement('div');
        proxySlot.style.marginBottom = '15px'; // Basic styling
        proxySlot.innerHTML = `
            <label style="margin-right: 5px;">
                <input type="radio" name="proxySelection" value="${proxyIndex}">
                <strong>Proxy ${proxyIndex}</strong>
            </label>
            <input type="text" id="proxy-ip-${proxyIndex}" placeholder="IP Address" size="15" style="margin-right: 5px;">
            <input type="text" id="proxy-port-${proxyIndex}" placeholder="Port" size="6" style="margin-right: 5px;">
            <input type="text" id="proxy-user-${proxyIndex}" placeholder="Username" size="12" style="margin-right: 5px;">
            <input type="password" id="proxy-pass-${proxyIndex}" placeholder="Password" size="12">
            <button type="button" id="check-proxy-btn-${proxyIndex}" style="background-color: #007bff; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;">Check Proxy</button>
            <span id="proxy-status-${proxyIndex}" style="margin-left: 10px; font-weight: bold;"></span>
        `;
        proxyListDiv.appendChild(proxySlot);

        // Add event listener for the new "Check Proxy" button
        const checkButton = document.getElementById(`check-proxy-btn-${proxyIndex}`);
        if (checkButton) {
            checkButton.addEventListener('click', () => checkProxy(proxyIndex));
        }
    }
}
// --- END OF PROXY UI CREATION FUNCTION ---

// Function to send proxy details to background script for checking
async function checkProxy(index) {
    const ipElem = document.getElementById(`proxy-ip-${index}`);
    const portElem = document.getElementById(`proxy-port-${index}`);
    const userElem = document.getElementById(`proxy-user-${index}`);
    const passElem = document.getElementById(`proxy-pass-${index}`);
    const statusSpan = document.getElementById(`proxy-status-${index}`);

    const proxyDetails = {
        ip: ipElem ? ipElem.value.trim() : '',
        port: portElem ? portElem.value.trim() : '',
        user: userElem ? userElem.value.trim() : '',
        pass: passElem ? passElem.value.trim() : ''
    };

    if (!proxyDetails.ip || !proxyDetails.port) {
        statusSpan.style.color = 'red';
        statusSpan.textContent = 'IP and Port are required.';
        return;
    }

    statusSpan.style.color = 'gray';
    statusSpan.textContent = 'Checking...';

    try {
        const response = await chrome.runtime.sendMessage({
            action: "checkProxyConnectivity",
            proxy: proxyDetails
        });

        if (response.success) {
            statusSpan.style.color = 'green';
            statusSpan.textContent = 'Working';
        } else {
            statusSpan.style.color = 'red';
            statusSpan.textContent = response.message || 'Failed';
        }
    } catch (error) {
        console.error("Error checking proxy:", error);
        statusSpan.style.color = 'red';
        statusSpan.textContent = 'Error: ' + (error.message || 'Unknown');
    }
}

// --- Timer Clock Logic Start ---
function updateTimer() {
    const clockElement = document.getElementById('timerClock');
    if (clockElement) {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        clockElement.textContent = `${hours}:${minutes}:${seconds}`;
    }
}
// --- Timer Clock Logic End ---


fetchStationData().then((e) => { 
    autocompleteSourcDstTrain(document.getElementById("from-station-input"), e, "SOURCE"), autocompleteSourcDstTrain(document.getElementById("destination-station-input"), e, "DEST"), autocompleteSourcDstTrain(document.getElementById("boarding-station-input"), e, "BOARDING"); 
}), fetchTrainData().then((e) => { 
    autocompleteSourcDstTrain(document.getElementById("train-no"), e, "TRAIN"); 
}), window.addEventListener("load", () => { 
    // --- CALL createProxyUI() ADDED ---
    createProxyUI();
    // --- END ---
    loadUserData(); 
    // IRCTC Credentials
    const irctcLogin = document.querySelector("#irctc-login");
    if (irctcLogin) irctcLogin.addEventListener("change", setIRCTCUsername); 
    const irctcPassword = document.querySelector("#irctc-password");
    if (irctcPassword) irctcPassword.addEventListener("change", setIRCTCPassword); 

    // Journey Details
    const journeyDate = document.querySelector("#journey-date");
    if (journeyDate) journeyDate.addEventListener("change", journeyDateChanged); 
    const journeyClassInput = document.querySelector("#journey-class-input");
    if (journeyClassInput) journeyClassInput.addEventListener("change", setJourneyClass); 
    const quotaInput = document.querySelector("#quota-input");
    if (quotaInput) quotaInput.addEventListener("change", setQuota); 

    // Passenger Details
    for (let e = 0; e < 6; e++) { 
        const passengerName = document.querySelector(`#passenger-name-${e + 1}`);
        if (passengerName) passengerName.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
        const age = document.querySelector(`#age-${e + 1}`);
        if (age) age.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
        const passengerGender = document.querySelector(`#passenger-gender-${e + 1}`);
        if (passengerGender) passengerGender.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
        const passengerBerth = document.querySelector(`#passenger-berth-${e + 1}`);
        if (passengerBerth) passengerBerth.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
        const passengerFood = document.querySelector(`#passenger-food-${e + 1}`);
        if (passengerFood) passengerFood.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
        const passengerChildBerth = document.querySelector(`#passengerchildberth${e + 1}`);
        if (passengerChildBerth) passengerChildBerth.addEventListener("change", (t) => setPassengerDetails(t, e, "passenger")); 
    }
    // Infant Details
    for (let e = 0; e < 2; e++) { 
        const infantName = document.querySelector(`#Infant-name-${e + 1}`);
        if (infantName) infantName.addEventListener("change", (t) => setInfantDetails(t, e, "infant")); 
        const infantAge = document.querySelector(`#Infant-age-${e + 1}`);
        if (infantAge) infantAge.addEventListener("change", (t) => setInfantDetails(t, e, "infant")); 
        const infantGender = document.querySelector(`#Infant-gender-${e + 1}`);
        if (infantGender) infantGender.addEventListener("change", (t) => setInfantDetails(t, e, "infant")); 
    }

    // Other Preferences
    const autoUpgradation = document.querySelector("#autoUpgradation");
    if (autoUpgradation) autoUpgradation.addEventListener("change", setOtherPreferences); 
    const autoCaptcha = document.querySelector("#autoCaptcha");
    if (autoCaptcha) autoCaptcha.addEventListener("change", setAutoCaptcha); 
    const psgManual = document.querySelector("#psgManual");
    if (psgManual) psgManual.addEventListener("change", setAutoCaptcha); // Note: Uses setAutoCaptcha, consider if this is correct or needs setOtherPreferences 
    const paymentManual = document.querySelector("#paymentManual");
    if (paymentManual) paymentManual.addEventListener("change", setAutoCaptcha); // Note: Uses setAutoCaptcha 
    const confirmBerths = document.querySelector("#confirmberths");
    if (confirmBerths) confirmBerths.addEventListener("change", setOtherPreferences); 
    const vpa = document.querySelector("#vpa");
    if (vpa) vpa.addEventListener("change", setOtherPreferencesVpa); 

    const cardnumber = document.querySelector("#cardnumber"); 
    if (cardnumber) cardnumber.addEventListener("keyup", () => { 
        let t = cardnumber.value; 
        t = t.replace(/\s/g, ""); 
        if (Number(t) || t === "") { // Allow clearing the field
            t = t.match(/.{1,4}/g); 
            t = t ? t.join(" ") : ""; // Handle null case if field is empty
            cardnumber.value = t; 
            if (finalData.other_preferences) finalData.other_preferences.cardnumber = cardnumber.value; 
        }
    });
    const cardexpiry = document.querySelector("#cardexpiry");
    if (cardexpiry) cardexpiry.addEventListener("change", setCardDetails); 
    const cardcvv = document.querySelector("#cardcvv");
    if (cardcvv) cardcvv.addEventListener("change", setCardDetails); 
    const cardholder = document.querySelector("#cardholder");
    if (cardholder) cardholder.addEventListener("change", setCardDetails); 
    const paymentMethod = document.querySelector("#paymentMethod");
    if (paymentMethod) paymentMethod.addEventListener("change", setpaymentMethod); 
    const captchaSubmitMode = document.querySelector("#CaptchaSubmitMode");
    if (captchaSubmitMode) captchaSubmitMode.addEventListener("change", setCaptchaSubmitMode); 
    const cardtype = document.querySelector("#cardtype");
    if (cardtype) cardtype.addEventListener("change", setcardtype); 
    const slbooktime = document.querySelector("#slbooktime");
    if (slbooktime) slbooktime.addEventListener("change", setOtherPreferencesbooktime); 
    const acbooktime = document.querySelector("#acbooktime");
    if (acbooktime) acbooktime.addEventListener("change", setOtherPreferencesbooktime); 
    const gnbooktime = document.querySelector("#gnbooktime");
    if (gnbooktime) gnbooktime.addEventListener("change", setOtherPreferencesbooktime); 
    const mobileNumber = document.querySelector("#mobileNumber");
    if (mobileNumber) mobileNumber.addEventListener("change", setMobileNumber); 

    // Travel Preferences
    const travelInsuranceOpted1 = document.querySelector("#travelInsuranceOpted-1");
    if (travelInsuranceOpted1) travelInsuranceOpted1.addEventListener("change", setTravelPreferences); 
    const travelInsuranceOpted2 = document.querySelector("#travelInsuranceOpted-2");
    if (travelInsuranceOpted2) travelInsuranceOpted2.addEventListener("change", setTravelPreferences); 
    const availabilityCheck1 = document.querySelector("#AvailabilityCheck-1");
    if (availabilityCheck1) availabilityCheck1.addEventListener("change", setAvailabilyCheck); 
    const availabilityCheck2 = document.querySelector("#AvailabilityCheck-2");
    if (availabilityCheck2) availabilityCheck2.addEventListener("change", setAvailabilyCheck); 
    const availabilityCheck3 = document.querySelector("#AvailabilityCheck-3");
    if (availabilityCheck3) availabilityCheck3.addEventListener("change", setAvailabilyCheck); 
    const reservationchoice = document.querySelector("#reservationchoice");
    if (reservationchoice) reservationchoice.addEventListener("change", setTravelPreferences); 
    const prefcoach = document.querySelector("#prefcoach");
    if (prefcoach) prefcoach.addEventListener("change", setTravelPreferences); 

    // Token/Project ID
    const tokenString = document.querySelector("#tokenString");
    if (tokenString) tokenString.addEventListener("change", setTokenString); 
    const projectId = document.querySelector("#projectId");
    if (projectId) projectId.addEventListener("change", setprojectId); 
    const staticpassword = document.querySelector("#staticpassword");
    if (staticpassword) staticpassword.addEventListener("change", setCardDetails); // Changed from setprojectId to setCardDetails


    // Buttons
    const submitBtn = document.querySelector("#submit-btn");
    if (submitBtn) submitBtn.addEventListener("click", saveForm); 
    const loadBtn1 = document.querySelector("#load-btn-1");
    if (loadBtn1) loadBtn1.addEventListener("click", () => buyPlan()); 
    const openSiteBtn = document.querySelector("#OpenSite");
    if (openSiteBtn) openSiteBtn.addEventListener("click", () => OpenSite()); 
    const loginBtn = document.querySelector("#login-btn");
    if (loginBtn) loginBtn.addEventListener("click", () => login()); 
    const clearBtn = document.querySelector("#clear-btn");
    if (clearBtn) clearBtn.addEventListener("click", () => clearData()); 

    const connectBtn = document.querySelector("#connect-btn");
    if (connectBtn) connectBtn.addEventListener("click", connectWithBg); 
    const connectBtnLicense = document.querySelector("#connect-btn-license");
    if (connectBtnLicense) connectBtnLicense.addEventListener("click", connectWithBg); 

    const showIrctcPswd = document.querySelector("#showirctcpswd");
    if (showIrctcPswd) showIrctcPswd.addEventListener("click", showirctcpswd); 
    const showHdfcPswd = document.querySelector("#showhdfcpass");
    if (showHdfcPswd) showHdfcPswd.addEventListener("click", showhdfcpass); 

    // Fare Limit Preferences
    const enableFareLimit = document.querySelector("#enableFareLimit");
    if (enableFareLimit) enableFareLimit.addEventListener("change", setFareLimitPreferences); 
    const maxFareAmount = document.querySelector("#maxFareAmount");
    if (maxFareAmount) maxFareAmount.addEventListener("change", setFareLimitPreferences); 
    const bookInPopup = document.querySelector("#bookInPopup");
    if (bookInPopup) bookInPopup.addEventListener("change", setFareLimitPreferences); 

    // Initialize and start the timer clock
    updateTimer(); // Initial call to display time immediately
    setInterval(updateTimer, 1000); // Update time every second
});

// Purana a() function ab connectWithBg se call nahi hoga.
// login() function "#login-btn" ke liye waisa hi rahega.
