const _0x101f7b = function () {
  let _0xffe421 = true;
  return function (_0x15037c, _0x568bc2) {
    const _0x58bab7 = _0xffe421 ? function () {
      if (_0x568bc2) {
        const _0x1ed48a = _0x568bc2.apply(_0x15037c, arguments);
        _0x568bc2 = null;
        return _0x1ed48a;
      }
    } : function () {};
    _0xffe421 = false;
    return _0x58bab7;
  };
}();
const _0xd18249 = _0x101f7b(this, function () {
  const _0x4a62a0 = function () {
    let _0x40edfe;
    try {
      _0x40edfe = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x115510) {
      _0x40edfe = window;
    }
    return _0x40edfe;
  };
  const _0x47f8b0 = _0x4a62a0();
  const _0x48add3 = _0x47f8b0.console = _0x47f8b0.console || {};
  const _0x137b2c = ["log", "warn", 'info', 'error', "exception", 'table', "trace"];
  for (let _0x55d4f2 = 0x0; _0x55d4f2 < _0x137b2c.length; _0x55d4f2++) {
    const _0x5f2bcd = _0x101f7b.constructor.prototype.bind(_0x101f7b);
    const _0x158da1 = _0x137b2c[_0x55d4f2];
    const _0x4df6f8 = _0x48add3[_0x158da1] || _0x5f2bcd;
    _0x5f2bcd.__proto__ = _0x101f7b.bind(_0x101f7b);
    _0x5f2bcd.toString = _0x4df6f8.toString.bind(_0x4df6f8);
    _0x48add3[_0x158da1] = _0x5f2bcd;
  }
});
_0xd18249();
function simulateClick(_0x4006a4) {
  if (_0x4006a4 && typeof _0x4006a4.dispatchEvent === "function") {
    if (typeof _0x4006a4.focus === "function") {
      try {
        _0x4006a4.focus();
      } catch (_0x574e54) {
        console.warn("Could not focus element before click:", _0x4006a4, _0x574e54.message);
      }
    }
    if (_0x4006a4.disabled) {
      console.warn("Attempted to click on a disabled element:", _0x4006a4);
      return;
    }
    const _0x2c034a = new MouseEvent("mousedown", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0x2da2f8 = new MouseEvent("mouseup", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0x5e4dd2 = new MouseEvent("click", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    _0x4006a4.dispatchEvent(_0x2c034a);
    _0x4006a4.dispatchEvent(_0x2da2f8);
    _0x4006a4.dispatchEvent(_0x5e4dd2);
  } else {
    console.warn("Attempted to simulate click on an invalid (null, undefined, or no dispatchEvent method) element:", _0x4006a4);
  }
}
async function typeTextHumanLike(_0x21174b, _0x2a9762) {
  if (!_0x21174b || typeof _0x2a9762 !== "string") {
    console.warn("Element not provided or text is not a string for human-like typing.");
    return;
  }
  _0x21174b.focus();
  _0x21174b.value = '';
  _0x21174b.dispatchEvent(new Event("input", {
    'bubbles': true,
    'cancelable': true
  }));
  for (const _0x35a445 of _0x2a9762) {
    _0x21174b.dispatchEvent(new KeyboardEvent("keydown", {
      'key': _0x35a445,
      'bubbles': true,
      'cancelable': true
    }));
    _0x21174b.value += _0x35a445;
    _0x21174b.dispatchEvent(new Event("input", {
      'bubbles': true,
      'cancelable': true
    }));
    _0x21174b.dispatchEvent(new KeyboardEvent("keyup", {
      'key': _0x35a445,
      'bubbles': true,
      'cancelable': true
    }));
    await new Promise(_0x43389a => setTimeout(_0x43389a, Math.random() * 0x64 + 0x32));
  }
  _0x21174b.dispatchEvent(new Event("change", {
    'bubbles': true,
    'cancelable': true
  }));
}
function showCustomAlert(_0x24e7f1) {
  const _0x415650 = document.createElement("div");
  _0x415650.id = "custom-alert";
  _0x415650.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    ";
  _0x415650.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x24e7f1 + "</p>\n        <button id=\"custom-alert-ok\" class=\"px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600\">OK</button>\n    ";
  document.body.appendChild(_0x415650);
  document.getElementById("custom-alert-ok").onclick = () => {
    _0x415650.remove();
  };
}
function showCustomConfirm(_0x18e447, _0x46d346, _0x25ba3c) {
  const _0x2e3b89 = document.createElement("div");
  _0x2e3b89.id = "custom-confirm";
  _0x2e3b89.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    ";
  _0x2e3b89.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x18e447 + "</p>\n        <button id=\"custom-confirm-yes\" class=\"px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2\">Yes</button>\n        <button id=\"custom-confirm-no\" class=\"px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600\">No</button>\n    ";
  document.body.appendChild(_0x2e3b89);
  document.getElementById("custom-confirm-yes").onclick = () => {
    _0x2e3b89.remove();
    if (_0x46d346) {
      _0x46d346();
    }
  };
  document.getElementById("custom-confirm-no").onclick = () => {
    _0x2e3b89.remove();
    if (_0x25ba3c) {
      _0x25ba3c();
    }
  };
}
let user_data = {};
function getMsg(_0x1ea0f2, _0xa5ae46) {
  return {
    'msg': {
      'type': _0xa5ae46,
      'data': _0x1ea0f2
    },
    'sender': "content_script",
    'id': "irctc"
  };
}
function statusUpdate(_0x1d4e11) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': {
        'status': _0x1d4e11,
        'time': new Date().toString().split(" ")[0x4]
      },
      'data': "status_update"
    },
    'sender': "content_script",
    'id': "irctc"
  });
}
function classTranslator(_0x38d623) {
  let _0x23e709;
  _0x23e709 = '1A' === _0x38d623 ? "AC First Class (1A)" : 'EV' === _0x38d623 ? "Vistadome AC (EV)" : 'EC' === _0x38d623 ? "Exec. Chair Car (EC)" : '2A' === _0x38d623 ? "AC 2 Tier (2A)" : '3A' === _0x38d623 ? "AC 3 Tier (3A)" : '3E' === _0x38d623 ? "AC 3 Economy (3E)" : 'CC' === _0x38d623 ? "AC Chair car (CC)" : 'SL' === _0x38d623 ? "Sleeper (SL)" : '2S' === _0x38d623 ? "Second Sitting (2S)" : "None";
  return _0x23e709;
}
function quotaTranslator(_0x383ca7) {
  let _0x486dcd = '';
  if ('GN' === _0x383ca7) {
    _0x486dcd = "GENERAL";
  } else if ('TQ' === _0x383ca7) {
    _0x486dcd = "TATKAL";
  } else if ('PT' === _0x383ca7) {
    _0x486dcd = "PREMIUM TATKAL";
  } else if ('LD' === _0x383ca7) {
    _0x486dcd = "LADIES";
  } else if ('SR' === _0x383ca7) {
    _0x486dcd = "LOWER BERTH/SR.CITIZEN";
  } else {
    _0x486dcd = _0x486dcd;
  }
  return _0x486dcd;
}
function addDelay(_0x3d3c6b) {
  const _0x4923b3 = Date.now();
  let _0x41414d = null;
  do {
    _0x41414d = Date.now();
  } while (_0x41414d - _0x4923b3 < _0x3d3c6b);
}
function showPnrAnimation(_0x1772a1) {
  console.log("[content_script.js] Attempting to show PNR animation based on image.");
  if (_0x1772a1) {
    console.log("[content_script.js] Triggered by element:", _0x1772a1);
  }
  if (!document.getElementById("Voltas-tatkal-style-v2")) {
    const _0xa6d28c = document.createElement("style");
    _0xa6d28c.id = "Voltas-tatkal-style-v2";
    _0xa6d28c.textContent = "\n.Voltas-tatkal-success-message {\n    position: fixed;\n    top: 70%;\n    left: 50%;\n    transform: translateX(-50%);\n    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);\n    z-index: 10000;\n    font-family: Arial, Helvetica, sans-serif;\n    border-radius: 8px; /* Rounded corners for the whole box */\n    overflow: hidden; /* This is key to make the inner corners rounded */\n    text-align: center;\n    width: 340px; /* A fixed width that looks good */\n    border: 1px solid #ddd;\n}\n.Voltas-header {\n    background-color: #005A9C; /* A professional blue, similar to the image */\n    color: white;\n    padding: 12px;\n    font-size: 20px;\n    font-weight: bold;\n}\n.Voltas-body {\n    background-color: #2E8B57; /* A vibrant 'SeaGreen', similar to the image */\n    color: white;\n    padding: 25px 20px;\n    font-size: 22px;\n    font-weight: bold;\n    line-height: 1.5; /* Adds space between the lines of text */\n}\n";
    document.head.appendChild(_0xa6d28c);
  }
  const _0x373430 = document.querySelector(".Voltas-tatkal-success-message");
  if (_0x373430) {
    _0x373430.remove();
  }
  const _0x5a98c6 = document.createElement('div');
  _0x5a98c6.className = "Voltas-tatkal-success-message";
  _0x5a98c6.innerHTML = "\n        <div class=\"Voltas-header\">Proccessing Status</div>\n        <div class=\"Voltas-body\">\n            Congratulation !<br>\n            PNR Successfully<br>\n            Booked by Voltas\n        </div>\n    ";
  document.body.appendChild(_0x5a98c6);
  console.log("[content_script.js] PNR success message is now visible.");
}
(() => {
  const _0xc6d1a9 = document.querySelector("div.cnf-pad.ng-star-inserted");
  if (_0xc6d1a9) {
    console.log("[content_script.js] Booking confirmation element found. Displaying success message.");
    showPnrAnimation(_0xc6d1a9);
  } else {
    console.log("[content_script.js] Booking confirmation element not found on this page.");
  }
})();
chrome.runtime.onMessage.addListener(async (_0x4668b9, _0x844a69, _0x3d204a) => {
  if ("irctc" !== _0x4668b9.id) {
    return void _0x3d204a("Invalid ID");
  }
  const _0x584259 = _0x4668b9.msg.type;
  if ("selectJourney" === _0x584259) {
    console.log("selectJourney action received");
    let _0x4a9245 = document.querySelectorAll(".btn.btn-primary");
    if (_0x4a9245.length > 0x1 && _0x4a9245[0x1]) {
      simulateClick(_0x4a9245[0x1]);
      console.log("Close last trxn popup");
    }
    const _0xa5e934 = document.querySelector("#divMain > div > app-train-list");
    if (!_0xa5e934) {
      console.error("Train list container not found for selectJourney.");
      return;
    }
    const _0x4e22ba = [..._0xa5e934.querySelectorAll(".tbis-div app-train-avl-enq")];
    const _0x4225db = user_data.journey_details["train-no"];
    if (!_0x4225db) {
      console.error("Train number missing in user_data for selectJourney.");
      return;
    }
    const _0x350377 = _0x4e22ba.find(_0x3df417 => {
      const _0x4bbc97 = _0x3df417.querySelector("div.train-heading");
      return _0x4bbc97 && _0x4bbc97.innerText.trim().includes(_0x4225db.split('-')[0x0]);
    });
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void showCustomAlert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x350377) {
        return void showCustomAlert("Precheck - Train (" + _0x4225db + ") not found. Proceed manually or correct data.");
      }
      const _0x37783f = classTranslator(user_data.journey_details["class"]);
      if (![..._0x350377.querySelectorAll("table tr td div.pre-avl")].find(_0x30fee8 => _0x30fee8.querySelector("div")?.["innerText"] === _0x37783f)) {
        return void showCustomAlert("Precheck - Selected Class not available. Proceed manually or correct data.");
      }
    }
    const _0x3f898c = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      if (['TQ', 'PT', 'GN'].includes(user_data.journey_details.quota)) {
        console.log("Verify tatkal/general time");
        const _0x5eb301 = user_data.journey_details['class'];
        let _0x2567b9 = "00:00:00";
        let _0x84556b = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x5eb301.toUpperCase())) {
          _0x2567b9 = user_data.other_preferences.acbooktime;
        } else {
          _0x2567b9 = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          _0x2567b9 = user_data.other_preferences.gnbooktime;
        }
        console.log("Required Booking Time:", _0x2567b9);
        var _0x3af4e1 = 0x0;
        let _0x279ea8 = new MutationObserver(_0x26a95b => {
          _0x84556b = new Date().toString().split(" ")[0x4];
          console.log("Current Time for booking:", _0x84556b);
          if (_0x84556b >= _0x2567b9) {
            _0x279ea8.disconnect();
            selectJourney();
          } else {
            if (_0x3af4e1 === 0x0) {
              try {
                const _0x39b537 = document.createElement("div");
                _0x39b537.textContent = "Please wait... Booking will start at " + _0x2567b9;
                Object.assign(_0x39b537.style, {
                  'textAlign': "center",
                  'color': 'white',
                  'height': "auto",
                  'fontSize': "20px"
                });
                document.querySelector("#divMain > div > app-train-list > div > div > div > div.clearfix")?.["insertAdjacentElement"]("afterend", _0x39b537);
              } catch (_0x37829d) {
                console.log("Wait message display failed", _0x37829d);
              }
            }
            try {
              const _0x5362e0 = document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)");
              if (_0x5362e0) {
                _0x5362e0.style.background = _0x3af4e1 % 0x2 === 0x0 ? "green" : 'red';
              }
            } catch (_0x4fa778) {
              console.log("Wait indicator style failed", _0x4fa778);
            }
            _0x3af4e1++;
          }
        });
        if (_0x3f898c) {
          _0x279ea8.observe(_0x3f898c, {
            'childList': true,
            'subtree': true,
            'characterDataOldValue': true
          });
        } else {
          console.warn("Header element for time observer not found.");
        }
      } else {
        selectJourney();
      }
    } else {
      if ('I' === user_data.travel_preferences.AvailabilityCheck) {
        selectJourney();
      }
    }
  } else {
    if ("fillPassengerDetails" === _0x584259) {
      await fillPassengerDetails();
    } else {
      if ("reviewBooking" === _0x584259) {
        if (user_data.fare_limit?.["enableFareLimit"]) {
          let _0x39f1e3 = 0x0;
          const _0x4a09f3 = ["#fare-summary .col-xs-12.line-def.top-header span.pull-right strong", ".total-fare", "#totalAmount", ".fare-summary span.amount", "span.fare-value", ".fare-breakup-summary .fare-amount", "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value", "div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold", "div.fare-breakup-summary div.fare-amount", "div.fare-detail-item:nth-child(5) > div:nth-child(2)", "div.col-sm-6.text-right.font-small-bold"];
          for (const _0x1fc119 of _0x4a09f3) {
            const _0xa9aff3 = document.querySelector(_0x1fc119);
            if (_0xa9aff3?.["innerText"]["match"](/(\d[\d,]*\.?\d*)/)) {
              _0x39f1e3 = parseFloat(_0xa9aff3.innerText.replace(/[^0-9.]/g, ''));
              if (!isNaN(_0x39f1e3)) {
                console.log("Found total fare " + _0x39f1e3 + " using \"" + _0x1fc119 + "\"");
                break;
              }
            }
          }
          if (!isNaN(_0x39f1e3) && _0x39f1e3 > 0x0) {
            const _0x4efe3d = parseFloat(user_data.fare_limit.maxFareAmount);
            if (!isNaN(_0x4efe3d) && _0x39f1e3 > _0x4efe3d) {
              return showCustomConfirm("Total fare (" + _0x39f1e3 + ") exceeds limit (" + _0x4efe3d + "). Proceed?", () => proceedAfterFareCheck(), () => {
                showCustomAlert("Booking cancelled due to high fare.");
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              });
            }
          } else {
            console.warn("Could not determine total fare for limit check.");
          }
        }
        await proceedAfterFareCheck();
      } else {
        if ("bkgPaymentOptions" === _0x584259) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x11194e = "Multiple Payment Service";
          let _0x29de4e = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x1c850f = true;
          const _0x1fa378 = user_data.other_preferences.paymentmethod;
          if (_0x1fa378.includes("IRCUPI")) {
            _0x1c850f = false;
            _0x11194e = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x29de4e = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
          } else {
            if (_0x1fa378.includes("PAYTMUPI")) {
              _0x11194e = "BHIM/ UPI/ USSD";
              _0x29de4e = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            } else {
              if (_0x1fa378.includes("PHONEPEUPI")) {
                _0x11194e = "Multiple Payment Service";
                _0x29de4e = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
              } else {
                if (_0x1fa378.includes("PAYUUPI")) {
                  _0x11194e = "Multiple Payment Service";
                  _0x29de4e = "Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)";
                } else {
                  if (_0x1fa378.includes("AMZPAYWAL")) {
                    _0x11194e = "Wallets / Cash Card";
                    _0x29de4e = "Amazon Pay Balance";
                  } else {
                    if (_0x1fa378.includes("irctc_dc")) {
                      _0x1c850f = false;
                      _0x11194e = "IRCTC iPay (Credit Card/Debit Card/UPI)";
                      _0x29de4e = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
                    } else {
                      if (_0x1fa378.includes("MOBUPI") && window.navigator.userAgent.includes("Android")) {
                        _0x11194e = "Multiple Payment Service";
                        _0x29de4e = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
                      } else {
                        if (_0x1fa378.includes('IRCWA')) {
                          _0x11194e = "IRCTC eWallet";
                          _0x29de4e = "IRCTC eWallet";
                        } else if (_0x1fa378.includes("HDFCDB")) {
                          _0x11194e = "Payment Gateway / Credit Card / Debit Card";
                          _0x29de4e = "Visa/Master Card(Powered By HDFC BANK)";
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          let _0x4b9ce5 = _0x29de4e.replace(/&/g, '&amp;');
          let _0x4d2b31 = false;
          var _0xd50b0c = setInterval(() => {
            console.log("[PaymentInterval] Checking for bank types. Found:", document.getElementsByClassName("bank-type").length);
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0xd50b0c);
              console.log("[PaymentInterval] Bank types condition met. Proceeding.");
              var _0x35f7cc = document.getElementById("pay-type")?.["getElementsByTagName"]("div");
              if (!_0x35f7cc || _0x35f7cc.length === 0x0) {
                console.error("[PaymentLogic] Payment categories container '#pay-type' not found or is empty.");
                showCustomAlert("Payment categories container not found. Please select manually.");
                return;
              }
              console.log("[PaymentLogic] Found " + _0x35f7cc.length + " potential category elements. Searching for category text: \"" + _0x11194e + "\"");
              let _0x32f9cf = false;
              for (let _0x152dbd of _0x35f7cc) {
                if (_0x152dbd && _0x152dbd.innerText && _0x152dbd.innerText.includes(_0x11194e)) {
                  console.log("[PaymentLogic] Category \"" + _0x11194e + "\" found:", _0x152dbd.innerText);
                  _0x32f9cf = true;
                  if (_0x1c850f) {
                    console.log("[PaymentLogic] Clicking category:", _0x152dbd);
                    simulateClick(_0x152dbd);
                  } else {
                    console.log("[PaymentLogic] Category click skipped due to clickCategory=false.");
                  }
                  setTimeout(() => {
                    console.log("[PaymentLogic-Timeout] Looking for payment option text: \"" + _0x4b9ce5 + "\"");
                    var _0x218a60 = document.getElementsByClassName("border-all no-pad");
                    if (!_0x218a60 || _0x218a60.length === 0x0) {
                      console.warn("[PaymentLogic-Timeout] No elements found with class 'border-all no-pad'.");
                      showCustomAlert("No payment option elements found. Please select manually.");
                      return;
                    }
                    console.log("[PaymentLogic-Timeout] Found " + _0x218a60.length + " potential payment option elements.");
                    let _0xaa49b5 = false;
                    for (let _0x2955bd of _0x218a60) {
                      const _0x5ebcd1 = _0x2955bd?.["getElementsByTagName"]("span")[0x0];
                      const _0x245b7c = _0x2955bd && getComputedStyle(_0x2955bd).display !== "none" && getComputedStyle(_0x2955bd).visibility !== "hidden" && parseFloat(getComputedStyle(_0x2955bd).opacity) > 0x0 && !_0x2955bd.disabled;
                      const _0x302cea = _0x5ebcd1?.["innerHTML"]?.["toUpperCase"]() || '';
                      const _0x39b0c2 = _0x4b9ce5.toUpperCase();
                      console.log("[PaymentLogic-Timeout] Checking option: Visible&Interactable=" + _0x245b7c + ", Text=\"" + _0x302cea + "\", Target=\"" + _0x39b0c2 + "\"", _0x2955bd);
                      if (_0x245b7c && _0x5ebcd1 && _0x302cea.includes(_0x39b0c2)) {
                        console.log("[PaymentLogic-Timeout] Matching payment option found and is suitable:", _0x2955bd);
                        console.log("[PaymentLogic-Timeout] Clicking payment option:", _0x2955bd);
                        simulateClick(_0x2955bd);
                        _0x4d2b31 = true;
                        _0xaa49b5 = true;
                        const _0x534ad5 = document.getElementsByClassName("btn-primary")[0x0];
                        if (_0x534ad5) {
                          _0x534ad5.scrollIntoView({
                            'behavior': "smooth",
                            'block': "center",
                            'inline': "nearest"
                          });
                          console.log("[PaymentLogic-Timeout] Scrolled to 'Pay' button:", _0x534ad5);
                          if (user_data.other_preferences.paymentManual) {
                            showCustomAlert("Manually submit the payment page.");
                          } else {
                            console.log("[PaymentLogic-Timeout] Attempting to click 'Pay' button automatically in 500ms.");
                            setTimeout(() => {
                              console.log("[PaymentLogic-Timeout-Pay] Clicking 'Pay' button:", _0x534ad5);
                              simulateClick(_0x534ad5);
                            }, 0x12c);
                          }
                        } else {
                          console.warn("[PaymentLogic-Timeout] 'Pay' button (btn-primary) not found.");
                          showCustomAlert("Could not find the 'Pay' button. Please click it manually.");
                        }
                        break;
                      }
                    }
                    if (!_0xaa49b5) {
                      console.warn("[PaymentLogic-Timeout] Selected payment option text \"" + _0x4b9ce5 + "\" not found or not suitable among " + _0x218a60.length + " candidates.");
                      let _0x2a94cb = Array.from(_0x218a60).map((_0x111df1, _0x30119b) => {
                        const _0x1a90a0 = _0x111df1?.["getElementsByTagName"]("span")[0x0]?.["innerHTML"] || "N/A";
                        const _0x327c0a = _0x111df1 && getComputedStyle(_0x111df1).display !== "none" && getComputedStyle(_0x111df1).visibility !== "hidden" && parseFloat(getComputedStyle(_0x111df1).opacity) > 0x0 && !_0x111df1.disabled;
                        return "Option " + _0x30119b + ": Visible&Interactable=" + _0x327c0a + ", Text=\"" + _0x1a90a0 + "\"";
                      });
                      console.log("[PaymentLogic-Timeout] Available options details:", _0x2a94cb);
                      showCustomAlert("Selected payment option not available. Please select manually.");
                    }
                  }, 0x12c);
                  break;
                }
              }
              if (!_0x32f9cf && _0x35f7cc.length > 0x0) {
                console.warn("[PaymentLogic] Payment category text \"" + _0x11194e + "\" not found after checking all category elements.");
                let _0x2a5d5e = Array.from(_0x35f7cc).map(_0x242d1c => _0x242d1c.innerText);
                console.log("[PaymentLogic] Available category texts:", _0x2a5d5e);
                showCustomAlert("Payment category \"" + _0x11194e + "\" not found. Please select manually.");
              }
            }
          }, 0x1f4);
        } else {
          if ("showPnrAnimation" === _0x584259) {
            showPnrAnimation();
          } else {
            _0x3d204a("Something went wrong: Unknown message type");
          }
        }
      }
    }
  }
});
async function proceedAfterFareCheck() {
  document.querySelector("#captcha")?.["scrollIntoView"]({
    'behavior': "smooth",
    'block': "center",
    'inline': "nearest"
  });
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => await getCaptchaTC(), 0x1f4);
  } else {
    const _0x554226 = document.querySelector("#captcha");
    if (_0x554226) {
      await typeTextHumanLike(_0x554226, 'X');
      _0x554226.focus();
    }
  }
}
let captchaRetry = 0x0;
async function getCaptcha() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0x4337c2 = document.querySelector(".captcha-img");
  if (!_0x4337c2 || !_0x4337c2.src || _0x4337c2.src.length < 0x17) {
    setTimeout(getCaptcha, 0x3e8);
    return;
  }
  const _0x56cd0a = new XMLHttpRequest();
  const _0x103d8c = _0x4337c2.src.substr(0x16);
  const _0x4164b9 = JSON.stringify({
    'requests': [{
      'image': {
        'content': _0x103d8c
      },
      'features': [{
        'type': "TEXT_DETECTION"
      }],
      'imageContext': {
        'languageHints': ['en']
      }
    }]
  });
  _0x56cd0a.open("POST", "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ", true);
  _0x56cd0a.onload = async () => {
    if (_0x56cd0a.status !== 0xc8) {
      console.error("Captcha API Error " + _0x56cd0a.status + ": " + _0x56cd0a.statusText, _0x56cd0a.response);
      return;
    }
    let _0x5e830a = '';
    let _0x254826 = '';
    try {
      _0x5e830a = JSON.parse(_0x56cd0a.response).responses[0x0].fullTextAnnotation.text;
    } catch (_0x1fa58f) {
      console.error("Error parsing Vision API response", _0x1fa58f);
    }
    for (const _0x5752c9 of String(_0x5e830a).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) {
      if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x5752c9)) {
        _0x254826 += _0x5752c9;
      }
    }
    const _0x10eeee = document.querySelector("#captcha");
    if (_0x10eeee) {
      await typeTextHumanLike(_0x10eeee, _0x254826);
    }
    if (!_0x5e830a) {
      simulateClick(document.querySelector(".glyphicon.glyphicon-repeat")?.["parentElement"]);
      setTimeout(getCaptcha, 0x1f4);
    }
    const _0x2a4424 = document.querySelector("app-login");
    const _0x33e5bb = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x563e04 = (_0x21a258, _0x1e6724) => {
      setTimeout(getCaptcha, 0x1f4);
      console.log("disconnect " + _0x21a258 + "Captcha");
      _0x1e6724.disconnect();
    };
    const _0x14af76 = new MutationObserver((_0x4ca951, _0x4a13bf) => {
      if (_0x2a4424?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x563e04("login", _0x4a13bf);
      }
      if (_0x33e5bb?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x563e04("review", _0x4a13bf);
      }
    });
    if (_0x2a4424) {
      _0x14af76.observe(_0x2a4424, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0x33e5bb) {
      _0x14af76.observe(_0x33e5bb, {
        'childList': true,
        'subtree': true
      });
    }
  };
  _0x56cd0a.onerror = () => console.error("Captcha API Request failed");
  _0x56cd0a.send(_0x4164b9);
}
async function getCaptchaTC() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0x41030b = document.querySelector(".captcha-img");
  if (!_0x41030b || !_0x41030b.src || _0x41030b.src.length < 0x17) {
    setTimeout(getCaptchaTC, 0x3e8);
    return;
  }
  const _0x2519d3 = new XMLHttpRequest();
  const _0x2a3aa0 = _0x41030b.src.substr(0x16);
  const _0x3d7a8e = JSON.stringify({
    'client': "chrome extension",
    'location': "https://www.irctc.co.in/nget/train-search",
    'version': "0.3.8",
    'case': "mixed",
    'promise': "true",
    'extension': true,
    'userid': "sonikhan86482",
    'apikey': "ORnT8sjiFvvPBLivb164",
    'data': _0x2a3aa0
  });
  _0x2519d3.open("POST", "https://api.apitruecaptcha.org/one/gettext", true);
  _0x2519d3.onload = async () => {
    if (_0x2519d3.status !== 0xc8) {
      console.error("TrueCaptcha API Error " + _0x2519d3.status + ": " + _0x2519d3.statusText, _0x2519d3.response);
      return;
    }
    let _0xf4ab99 = '';
    let _0x4fa26f = '';
    try {
      _0xf4ab99 = JSON.parse(_0x2519d3.response).result;
    } catch (_0x201007) {
      console.error("Error parsing TrueCaptcha API", _0x201007);
    }
    for (const _0x5668d7 of String(_0xf4ab99).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) {
      if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x5668d7)) {
        _0x4fa26f += _0x5668d7;
      }
    }
    const _0x5d1dc2 = document.querySelector("#captcha");
    if (_0x5d1dc2) {
      await typeTextHumanLike(_0x5d1dc2, _0x4fa26f);
    }
    if (!_0xf4ab99) {
      simulateClick(document.querySelector(".glyphicon.glyphicon-repeat")?.["parentElement"]);
      setTimeout(getCaptchaTC, 0x1f4);
    }
    const _0x2d0f08 = document.querySelector("app-login");
    const _0xc1e7b2 = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x41963a = (_0x56112b, _0x547737) => {
      setTimeout(getCaptchaTC, 0x1f4);
      console.log("disconnect " + _0x56112b + "Captcha");
      _0x547737.disconnect();
    };
    const _0x545c43 = new MutationObserver((_0x64f08, _0x1e56b4) => {
      if (_0x2d0f08?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x41963a("login", _0x1e56b4);
      }
      if (_0xc1e7b2?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x41963a("review", _0x1e56b4);
      }
    });
    if (_0x2d0f08) {
      _0x545c43.observe(_0x2d0f08, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0xc1e7b2) {
      _0x545c43.observe(_0xc1e7b2, {
        'childList': true,
        'subtree': true
      });
    }
    if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
      const _0x213d79 = document.querySelector("#divMain > app-login");
      if (_0x213d79) {
        const _0x77bd53 = _0x213d79.querySelector("input[formcontrolname='userid']");
        const _0x4b4f26 = _0x213d79.querySelector("input[formcontrolname='password']");
        if (_0x77bd53?.["value"] && _0x4b4f26?.["value"]) {
          setTimeout(() => {
            simulateClick(_0x213d79.querySelector("button[type='submit'][class='search_btn train_Search']"));
            simulateClick(_0x213d79.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"));
          }, 0x1f4);
        } else {
          showCustomAlert("Username/password not filled for auto-submit.");
        }
      }
      const _0x90d512 = document.querySelector("#divMain > div > app-review-booking");
      if (_0x90d512 && _0x5d1dc2?.["value"]) {
        const _0x35a75c = _0x90d512.querySelector(".btnDefault.train_Search");
        if (_0x35a75c) {
          setTimeout(() => {
            if (user_data.other_preferences.confirmberths) {
              if (document.querySelector(".AVAILABLE")) {
                simulateClick(_0x35a75c);
              } else {
                showCustomConfirm("No seats available. Continue booking?", () => simulateClick(_0x35a75c), () => console.log("Booking stopped."));
              }
            } else {
              simulateClick(_0x35a75c);
            }
          }, 0x1f4);
        }
      } else if (_0x90d512 && !_0x5d1dc2?.["value"]) {
        showCustomAlert("Captcha not filled for auto-submit on review page.");
      }
    }
  };
  _0x2519d3.onerror = () => console.error("TrueCaptcha API Request failed");
  _0x2519d3.send(_0x3d7a8e);
}
async function loadLoginDetails() {
  const _0x19f608 = document.querySelector("#divMain > app-login");
  const _0x4757c2 = _0x19f608.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x4a67c7 = _0x19f608.querySelector("input[type='password'][formcontrolname='password']");
  await typeTextHumanLike(_0x4757c2, user_data.irctc_credentials.user_name ?? '');
  await typeTextHumanLike(_0x4a67c7, user_data.irctc_credentials.password ?? '');
  document.querySelector("#captcha").scrollIntoView({
    'behavior': "smooth",
    'block': "center",
    'inline': "nearest"
  });
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => {
      await getCaptchaTC();
    }, 0x1f4);
  } else {
    console.log("Manual captcha filling");
    const _0x21dc20 = document.querySelector("#captcha");
    await typeTextHumanLike(_0x21dc20, 'X');
    _0x21dc20.focus();
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x561781 = document.querySelector("app-jp-input form");
  const _0x2b9caa = _0x561781.querySelector("#origin > span > input");
  _0x2b9caa.value = user_data.journey_details.from;
  _0x2b9caa.dispatchEvent(new Event("keydown"));
  _0x2b9caa.dispatchEvent(new Event("input"));
  const _0x3453e1 = _0x561781.querySelector("#destination > span > input");
  _0x3453e1.value = user_data.journey_details.destination;
  _0x3453e1.dispatchEvent(new Event("keydown"));
  _0x3453e1.dispatchEvent(new Event("input"));
  const _0x120bcb = _0x561781.querySelector("#jDate > span > input");
  _0x120bcb.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0x120bcb.dispatchEvent(new Event("keydown"));
  _0x120bcb.dispatchEvent(new Event("input"));
  const _0x15c8b6 = _0x561781.querySelector("#journeyClass");
  _0x15c8b6.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x15c8b6.querySelectorAll("ul li")].filter(_0x53ee01 => _0x53ee01.innerText === classTranslator(user_data.journey_details["class"]))[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x53196b = _0x561781.querySelector("#journeyQuota");
  _0x53196b.querySelector("div > div[role='button']").click();
  [..._0x53196b.querySelectorAll("ul li")].filter(_0x3623aa => _0x3623aa.innerText === quotaTranslator(user_data.journey_details.quota))[0x0]?.['click']();
  addDelay(0x12c);
  const _0x253ebe = _0x561781.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log("filled_journey_details");
  _0x253ebe.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details["train-no"]) {
    return;
  }
  const _0x322520 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  const _0xc96bf7 = _0x322520.filter(_0x834ff5 => _0x834ff5.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details["train-no"]))[0x0];
  if (!_0xc96bf7) {
    console.log("Train not found.");
    showCustomAlert("Train not found");
    statusUpdate("journey_selection_stopped.no_train");
    return;
  }
  const _0x2d0c9c = classTranslator(user_data.journey_details["class"]);
  const _0x42f28e = new Date(user_data.journey_details.date).toString().split(" ");
  const _0x44f9f9 = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0xc96bf7.querySelectorAll("table tr td div.pre-avl")].filter(_0x2f2d82 => _0x2f2d82.querySelector("div").innerText === _0x2d0c9c)[0x0]?.["click"]();
  const _0x1ef025 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x2129f8, _0x40d49b) => {
    const _0x4aa827 = [..._0xc96bf7.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x349182 => _0x349182.querySelector("div").innerText === _0x2d0c9c)[0x0];
    const _0x40092b = [..._0xc96bf7.querySelectorAll("div div table td div.pre-avl")].filter(_0x33322e => _0x33322e.querySelector("div").innerText === _0x42f28e[0x0] + ", " + _0x42f28e[0x2] + " " + _0x42f28e[0x1])[0x0];
    const _0x20c340 = _0xc96bf7.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x4aa827) {
      if (!_0x4aa827.classList.contains("ui-state-active")) {
        _0x4aa827.click();
        return;
      }
    }
    if (_0x40092b) {
      if (_0x40092b.classList.contains("selected-class")) {
        _0x20c340.click();
        _0x40d49b.disconnect();
      } else {
        _0x40092b.click();
      }
    }
  }).observe(_0xc96bf7, _0x44f9f9);
  const _0x1bf8e9 = new MutationObserver((_0x31c060, _0xca83d) => {
    console.log("Popup error observed");
    console.log("Class count:", [..._0xc96bf7.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class elements:", [..._0xc96bf7.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x1ef025.innerText.includes("Unable to perform")) {
      [..._0xc96bf7.querySelectorAll("table tr td div.pre-avl")].filter(_0x2ac533 => _0x2ac533.querySelector("div").innerText === _0x2d0c9c)[0x0]?.["click"]();
      _0xca83d.disconnect();
    }
  });
  _0x1bf8e9.observe(_0x1ef025, _0x44f9f9);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  const _0x4719a2 = setInterval(() => {
    const _0x527a62 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0xadcb4f = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x145b7f = _0x527a62 || _0xadcb4f;
    const _0x11379d = document.querySelector("#loaderP");
    const _0x410e52 = _0x11379d && _0x11379d.style.display !== "none";
    if (_0x145b7f && !_0x410e52) {
      console.log("Toast link found. Clicking it now...");
      _0x145b7f.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      clearInterval(_0x4719a2);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    console.error("Train number is not available in user_data.");
    return;
  }
  const _0x1c99f3 = document.querySelector("#divMain > div > app-train-list");
  if (!_0x1c99f3) {
    console.error("Train list parent not found.");
    return;
  }
  const _0x49336a = Array.from(_0x1c99f3.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x569e6f = user_data.journey_details["train-no"];
  const _0x4120c6 = classTranslator(user_data.journey_details["class"]);
  const _0x283763 = new Date(user_data.journey_details.date);
  const _0x5b3ea0 = _0x283763.toDateString().split(" ")[0x0] + ", " + _0x283763.toDateString().split(" ")[0x2] + " " + _0x283763.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x569e6f);
  console.log("Class:", _0x4120c6);
  console.log("Date:", _0x5b3ea0);
  const _0x4d9d19 = _0x49336a.find(_0x4de6fb => _0x4de6fb.querySelector("div.train-heading").innerText.trim().includes(_0x569e6f.split('-')[0x0]));
  if (!_0x4d9d19) {
    console.error("Train not found.");
    statusUpdate("journey_selection_stopped.no_train");
    return;
  }
  const _0x153216 = _0x416bee => {
    if (!_0x416bee) {
      return false;
    }
    const _0x44a42b = window.getComputedStyle(_0x416bee);
    return _0x44a42b.display !== "none" && _0x44a42b.visibility !== "hidden" && _0x44a42b.opacity !== '0';
  };
  const _0x4affba = Array.from(_0x4d9d19.querySelectorAll("table tr td div.pre-avl"));
  const _0x4fc9ac = _0x4affba.find(_0x1b0d9c => _0x1b0d9c.querySelector("div").innerText.trim() === _0x4120c6);
  const _0x49fb05 = Array.from(_0x4d9d19.querySelectorAll("span")).find(_0x448512 => _0x448512.innerText.trim() === _0x4120c6);
  const _0x4ad0c6 = _0x4fc9ac || _0x49fb05;
  if (!_0x4ad0c6) {
    console.error("Class to click not found.");
    return;
  }
  const _0x32a355 = document.querySelector("#loaderP");
  if (_0x153216(_0x32a355)) {
    console.error("Loader is visible. Cannot click the class yet.");
    return;
  }
  _0x4ad0c6.click();
  let _0x414f17;
  new MutationObserver((_0x2cd142, _0x32a0d9) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x414f17);
    _0x414f17 = setTimeout(() => {
      const _0x4c31d9 = Array.from(_0x4d9d19.querySelectorAll("div div table td div.pre-avl"));
      const _0x30d40e = _0x4c31d9.find(_0x4b6278 => _0x4b6278.querySelector("div").innerText.trim() === _0x5b3ea0);
      console.log("FOUND date cell to click:", _0x30d40e);
      if (_0x30d40e) {
        _0x30d40e.click();
        console.log("Clicked on date cell");
        setTimeout(() => {
          const _0x518ffa = () => {
            const _0x8feac = _0x4d9d19.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x153216(document.querySelector("#loaderP"))) {
              console.warn("Loader still visible, retrying...");
              return setTimeout(_0x518ffa, 0x64);
            }
            if (!_0x8feac || _0x8feac.classList.contains("disable-book") || _0x8feac.disabled) {
              console.warn("Book button disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              setTimeout(() => {
                _0x8feac.click();
                console.log("Clicked on Book button");
                clearTimeout(_0x414f17);
                _0x32a0d9.disconnect();
              }, 0x12c);
            }
          };
          _0x518ffa();
        }, 0x3e8);
      } else {
        console.warn("Date cell to click not found.");
      }
    }, 0x12c);
  }).observe(_0x4d9d19, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
async function fillPassengerDetails() {
  console.log("passenger_filling_started");
  keyCounter = Date.now();
  if (user_data.journey_details.boarding?.["length"] > 0x0) {
    const _0x1abfd8 = Array.from(document.getElementsByTagName("strong")).find(_0x42299f => _0x42299f.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x1abfd8) {
      simulateClick(_0x1abfd8);
      addDelay(0x12c);
    }
    const _0x4973a6 = Array.from(document.getElementsByTagName("strong")).find(_0x279cb3 => _0x279cb3.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x4973a6) {
      simulateClick(_0x4973a6);
    }
  }
  const _0x170c04 = document.querySelector("app-passenger-input");
  if (!_0x170c04) {
    console.error("Passenger app element not found.");
    return;
  }
  for (let _0x4492a9 = 0x1; _0x4492a9 < user_data.passenger_details.length; _0x4492a9++) {
    addDelay(0xc8);
    simulateClick(document.getElementsByClassName("prenext")[0x0]);
  }
  try {
    for (let _0x19704e = 0x0; _0x19704e < user_data.infant_details.length; _0x19704e++) {
      addDelay(0xc8);
      simulateClick(document.getElementsByClassName("prenext")[0x2]);
    }
  } catch (_0x101988) {
    console.error("Add infant error", _0x101988);
  }
  const _0x359539 = [..._0x170c04.querySelectorAll("app-passenger")];
  for (let _0x25095d = 0x0; _0x25095d < user_data.passenger_details.length; _0x25095d++) {
    const _0x4e7f77 = user_data.passenger_details[_0x25095d];
    if (!_0x359539[_0x25095d]) {
      continue;
    }
    const _0x58ec6e = _0x359539[_0x25095d];
    const _0x301f06 = _0x58ec6e.querySelector("p-autocomplete input");
    if (_0x301f06) {
      await typeTextHumanLike(_0x301f06, _0x4e7f77.name);
    }
    const _0x419554 = _0x58ec6e.querySelector("input[formcontrolname='passengerAge']");
    if (_0x419554) {
      await typeTextHumanLike(_0x419554, _0x4e7f77.age);
    }
    const _0x55e4b6 = _0x58ec6e.querySelector("select[formcontrolname='passengerGender']");
    if (_0x55e4b6) {
      _0x55e4b6.value = _0x4e7f77.gender;
      _0x55e4b6.dispatchEvent(new Event("change"));
    }
    const _0x1c2404 = _0x58ec6e.querySelector("select[formcontrolname='passengerBerthChoice']");
    if (_0x1c2404) {
      _0x1c2404.value = _0x4e7f77.berth;
      _0x1c2404.dispatchEvent(new Event("change"));
    }
    const _0x48de46 = _0x58ec6e.querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x48de46) {
      _0x48de46.value = _0x4e7f77.food;
      _0x48de46.dispatchEvent(new Event("change"));
    }
    try {
      const _0x38cff0 = _0x58ec6e.querySelector("input[formcontrolname='childBerthFlag']");
      if (_0x38cff0 && _0x4e7f77.passengerchildberth !== _0x38cff0.checked) {
        simulateClick(_0x38cff0);
        addDelay(0xc8);
        if (_0x4e7f77.passengerchildberth) {
          const _0x1a1cd8 = _0x58ec6e.querySelector("p-dialog app-passenger-confirm-dialog button.btn.btn-primary");
          if (_0x1a1cd8 && _0x1a1cd8.offsetParent !== null) {
            simulateClick(_0x1a1cd8);
            addDelay(0xc8);
          } else {
            const _0x3efc4f = _0x58ec6e.querySelector("p-dialog p-footer button");
            if (_0x3efc4f && _0x3efc4f.offsetParent !== null) {
              simulateClick(_0x3efc4f);
              addDelay(0xc8);
            }
          }
        }
      }
    } catch (_0x19a02a) {
      console.error("Child berth error", _0x19a02a);
    }
  }
  const _0x554dd6 = [..._0x170c04.querySelectorAll("app-infant")];
  user_data.infant_details.forEach((_0x3cf3eb, _0x39831f) => {
    if (!_0x554dd6[_0x39831f]) {
      return;
    }
    const _0x109717 = _0x554dd6[_0x39831f];
    const _0x48a6fe = _0x109717.querySelector("input#infant-name");
    if (_0x48a6fe) {
      _0x48a6fe.value = _0x3cf3eb.name;
      _0x48a6fe.dispatchEvent(new Event("input"));
    }
    const _0x5c59ff = _0x109717.querySelector("select[formcontrolname='age']");
    if (_0x5c59ff) {
      _0x5c59ff.value = _0x3cf3eb.age;
      _0x5c59ff.dispatchEvent(new Event("change"));
    }
    const _0x1ab1e6 = _0x109717.querySelector("select[formcontrolname='gender']");
    if (_0x1ab1e6) {
      _0x1ab1e6.value = _0x3cf3eb.gender;
      _0x1ab1e6.dispatchEvent(new Event("change"));
    }
  });
  if (user_data.other_preferences.mobileNumber) {
    const _0x21a825 = _0x170c04.querySelector("input#mobileNumber");
    if (_0x21a825) {
      await typeTextHumanLike(_0x21a825, user_data.other_preferences.mobileNumber);
    }
  }
  const _0x4f4d77 = user_data.other_preferences.paymentmethod.includes("UPI") ? '2' : '1';
  const _0x2d4b14 = [..._0x170c04.querySelectorAll("p-radiobutton[formcontrolname='paymentType'] input")].find(_0xc94f8d => _0xc94f8d.value === _0x4f4d77);
  if (_0x2d4b14) {
    simulateClick(_0x2d4b14);
  }
  const _0x42d4fe = _0x170c04.querySelector("input#autoUpgradation");
  if (_0x42d4fe && user_data.other_preferences.autoUpgradation !== _0x42d4fe.checked) {
    simulateClick(_0x42d4fe);
  }
  const _0x415841 = _0x170c04.querySelector("input#confirmberths");
  if (_0x415841 && user_data.other_preferences.confirmberths !== _0x415841.checked) {
    simulateClick(_0x415841);
  }
  const _0x16f2d8 = user_data.travel_preferences.travelInsuranceOpted === "yes" ? 'true' : "false";
  const _0x46c34f = [..._0x170c04.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input")].find(_0x4a7137 => _0x4a7137.value === _0x16f2d8);
  if (_0x46c34f) {
    simulateClick(_0x46c34f);
  }
  try {
    const _0x6b2f8b = _0x170c04.querySelector("input[formcontrolname='coachId']");
    if (_0x6b2f8b && user_data.travel_preferences.prefcoach?.['trim']()) {
      _0x6b2f8b.value = user_data.travel_preferences.prefcoach;
      _0x6b2f8b.dispatchEvent(new Event("input"));
    }
    const _0x25960d = _0x170c04.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x25960d && user_data.travel_preferences.reservationchoice && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      simulateClick(_0x25960d.querySelector("div[role='button']"));
      addDelay(0x12c);
      const _0x402975 = [..._0x25960d.querySelectorAll("ul li")].find(_0xd90c8c => _0xd90c8c.innerText === user_data.travel_preferences.reservationchoice);
      if (_0x402975) {
        simulateClick(_0x402975);
      }
    }
  } catch (_0x52e600) {
    console.error("Coach/Reservation choice error", _0x52e600);
  }
  submitPassengerDetailsForm(_0x170c04);
}
function submitPassengerDetailsForm(_0x2bc577) {
  window.scrollBy(0x0, 0x258, "smooth");
  if (user_data.other_preferences.psgManual) {
    return showCustomAlert("Manually submit passenger page.");
  }
  let _0x4a0eba;
  const _0x5d9d84 = () => {
    if (keyCounter > 0x0 && Date.now() - keyCounter > 0x7d0) {
      clearInterval(_0x4a0eba);
      let _0x2b1bff = null;
      const _0x451932 = ["button.train_Search.btnDefault[type='submit']", "button[type='submit'].btn-primary.pull-right", "button.btn.btn-primary.manual-booking-btn", "button.psgn-btn[type='submit']", "button#validate", "button[type='submit']", ".btn-primary", ".btn-success"];
      if (_0x2bc577) {
        for (const _0x16477d of _0x451932) {
          const _0x730687 = _0x2bc577.querySelector(_0x16477d);
          if (_0x730687 && _0x730687 && getComputedStyle(_0x730687).display !== "none" && getComputedStyle(_0x730687).visibility !== "hidden" && parseFloat(getComputedStyle(_0x730687).opacity) > 0x0 && !_0x730687.disabled) {
            _0x2b1bff = _0x730687;
            console.log("Passenger page: Found button with selector (scoped): \"" + _0x16477d + "\"", _0x730687);
            break;
          }
        }
      }
      if (!_0x2b1bff) {
        const _0x28f338 = ["#psgn-form button.train_Search.btnDefault", "button.btnDefault.train_Search"];
        for (const _0x3d3e4c of _0x28f338) {
          const _0x3372dc = document.querySelector(_0x3d3e4c);
          if (_0x3372dc && _0x3372dc && getComputedStyle(_0x3372dc).display !== "none" && getComputedStyle(_0x3372dc).visibility !== "hidden" && parseFloat(getComputedStyle(_0x3372dc).opacity) > 0x0 && !_0x3372dc.disabled) {
            _0x2b1bff = _0x3372dc;
            console.log("Passenger page: Found button with selector (global): \"" + _0x3d3e4c + "\"", _0x3372dc);
            break;
          }
        }
      }
      if (!_0x2b1bff && _0x2bc577) {
        const _0x2bccd3 = _0x2bc577.querySelectorAll("button, a.btn");
        for (let _0x3c579f of _0x2bccd3) {
          const _0x2e9631 = _0x3c579f.innerText?.["trim"]()["toLowerCase"]();
          if (_0x2e9631 && (_0x2e9631.includes("continue") || _0x2e9631.includes("proceed") || _0x2e9631.includes("submit") || _0x2e9631.includes("next") || _0x2e9631.includes("payment"))) {
            if (_0x3c579f && getComputedStyle(_0x3c579f).display !== "none" && getComputedStyle(_0x3c579f).visibility !== "hidden" && parseFloat(getComputedStyle(_0x3c579f).opacity) > 0x0 && !_0x3c579f.disabled && !_0x2e9631.includes("cancel") && !_0x2e9631.includes('back')) {
              _0x2b1bff = _0x3c579f;
              console.log("Passenger page: Found button by text content:", _0x2e9631, _0x3c579f);
              break;
            }
          }
        }
      }
      if (!_0x2b1bff) {
        const _0x536d41 = document.querySelectorAll("button[type='submit']");
        for (let _0x3c36f0 of _0x536d41) {
          if (_0x3c36f0 && getComputedStyle(_0x3c36f0).display !== "none" && getComputedStyle(_0x3c36f0).visibility !== "hidden" && parseFloat(getComputedStyle(_0x3c36f0).opacity) > 0x0 && !_0x3c36f0.disabled) {
            _0x2b1bff = _0x3c36f0;
            console.log("Passenger page: Fallback found a visible submit button:", _0x3c36f0);
            break;
          }
        }
      }
      if (_0x2b1bff) {
        console.log("Attempting to click passenger page continue button:", _0x2b1bff);
        simulateClick(_0x2b1bff);
      } else {
        console.error("Passenger page continue/submit button NOT FOUND with any known strategy.");
        showCustomAlert("Could not find the 'Continue' button on the passenger page. Please click it manually if available.");
      }
    }
  };
  _0x4a0eba = setInterval(_0x5d9d84, 0x1f4);
}
async function continueScript() {
  const _0x24d03e = document.querySelector("body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if (_0x24d03e && _0x24d03e.innerText.trim().toUpperCase() === "LOGOUT") {
      console.log("User is logged in. Proceeding to load journey details.");
      loadJourneyDetails();
    } else {
      if (_0x24d03e && _0x24d03e.innerText.trim().toUpperCase() === "LOGIN") {
        console.log("IRCTC page loaded. LOGIN button found. Starting 15-second countdown...");
        let _0x4ec479 = document.getElementById("irctc-login-countdown-element");
        if (!_0x4ec479) {
          _0x4ec479 = document.createElement("div");
          _0x4ec479.id = "irctc-login-countdown-element";
          _0x4ec479.style.cssText = "\n                    position: fixed; top: 10px; left: 50%; transform: translateX(-50%);\n                    background-color: rgba(0,0,0,0.7); color: white; padding: 10px 20px;\n                    border-radius: 5px; z-index: 20000; font-size: 16px;\n                ";
          document.body.appendChild(_0x4ec479);
        }
        let _0x5e8739 = 0xf;
        _0x4ec479.textContent = "Voltas Login " + _0x5e8739 + " Will Start In Seconds...";
        const _0x3e453b = setInterval(async () => {
          _0x5e8739--;
          if (_0x4ec479) {
            _0x4ec479.textContent = "Voltas Login " + _0x5e8739 + " Will Start In Seconds...";
          }
          if (_0x5e8739 <= 0x0) {
            clearInterval(_0x3e453b);
            if (_0x4ec479 && _0x4ec479.parentElement) {
              _0x4ec479.remove();
            }
            console.log("Countdown finished. Clicking LOGIN button.");
            simulateClick(_0x24d03e);
            await loadLoginDetails();
          }
        }, 0x3e8);
      } else {
        console.log("LOGIN/LOGOUT link not found or text doesn't match. Waiting for page changes or manual interaction.");
      }
    }
  } else {
    console.log("Not on train-search page. continueScript takes no action.");
  }
}
async function a() {}
window.onload = function () {
  console.log("Content script loaded and window.onload triggered.");
  setInterval(() => statusUpdate("Keep listener alive."), 0x3a98);
  const _0x1433aa = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1");
  if (_0x1433aa) {
    new MutationObserver((_0x4624b2, _0x2782a2) => {
      if (_0x4624b2.some(_0x231095 => _0x231095.type === "childList" && [..._0x231095.addedNodes].some(_0x21ae38 => _0x21ae38?.["innerText"]?.["trim"]()["toUpperCase"]() === "LOGOUT"))) {
        console.log("LOGOUT detected in header via MutationObserver.");
        _0x2782a2.disconnect();
        loadJourneyDetails();
      }
    }).observe(_0x1433aa, {
      'childList': true,
      'subtree': false
    });
  } else {
    console.warn("Header div for MutationObserver not found on window.onload.");
  }
  chrome.storage.local.get(null, _0x58b3cf => {
    user_data = _0x58b3cf;
    console.log("User data loaded from storage:", user_data);
    continueScript();
  });
};