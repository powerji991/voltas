function simulateClick(_0x37a552) {
  if (_0x37a552 && typeof _0x37a552.dispatchEvent === "function") {
    if (typeof _0x37a552.focus === "function") {
      try {
        _0x37a552.focus();
      } catch (_0x74c892) {
        console.warn("Could not focus element before click:", _0x37a552, _0x74c892.message);
      }
    }
    if (_0x37a552.disabled) {
      console.warn("Attempted to click on a disabled element:", _0x37a552);
      return;
    }
    const _0x259502 = new MouseEvent("mousedown", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0xbd0a9c = new MouseEvent("mouseup", {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    const _0x49cca5 = new MouseEvent('click', {
      'bubbles': true,
      'cancelable': true,
      'view': window,
      'button': 0x0
    });
    _0x37a552.dispatchEvent(_0x259502);
    _0x37a552.dispatchEvent(_0xbd0a9c);
    _0x37a552.dispatchEvent(_0x49cca5);
  } else {
    console.warn("Attempted to simulate click on an invalid (null, undefined, or no dispatchEvent method) element:", _0x37a552);
  }
}
async function typeTextHumanLike(_0x1e46a0, _0x59e797) {
  if (!_0x1e46a0 || typeof _0x59e797 !== "string") {
    console.warn("Element not provided or text is not a string for human-like typing.");
    return;
  }
  _0x1e46a0.focus();
  _0x1e46a0.value = '';
  _0x1e46a0.dispatchEvent(new Event("input", {
    'bubbles': true,
    'cancelable': true
  }));
  for (const _0x2366c7 of _0x59e797) {
    _0x1e46a0.dispatchEvent(new KeyboardEvent("keydown", {
      'key': _0x2366c7,
      'bubbles': true,
      'cancelable': true
    }));
    _0x1e46a0.value += _0x2366c7;
    _0x1e46a0.dispatchEvent(new Event("input", {
      'bubbles': true,
      'cancelable': true
    }));
    _0x1e46a0.dispatchEvent(new KeyboardEvent("keyup", {
      'key': _0x2366c7,
      'bubbles': true,
      'cancelable': true
    }));
    await new Promise(_0x3e3518 => setTimeout(_0x3e3518, Math.random() * 0x64 + 0x32));
  }
  _0x1e46a0.dispatchEvent(new Event('change', {
    'bubbles': true,
    'cancelable': true
  }));
}
function showCustomAlert(_0x279048) {
  const _0x2b7437 = document.createElement('div');
  _0x2b7437.id = 'custom-alert';
  _0x2b7437.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    ";
  _0x2b7437.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x279048 + "</p>\n        <button id=\"custom-alert-ok\" class=\"px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600\">OK</button>\n    ";
  document.body.appendChild(_0x2b7437);
  document.getElementById("custom-alert-ok").onclick = () => {
    _0x2b7437.remove();
  };
}
function showCustomConfirm(_0x57c940, _0x555097, _0x1a0249) {
  const _0x34eb96 = document.createElement('div');
  _0x34eb96.id = "custom-confirm";
  _0x34eb96.style.cssText = "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    ";
  _0x34eb96.innerHTML = "\n        <p class=\"text-lg font-semibold mb-4\">" + _0x57c940 + "</p>\n        <button id=\"custom-confirm-yes\" class=\"px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2\">Yes</button>\n        <button id=\"custom-confirm-no\" class=\"px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600\">No</button>\n    ";
  document.body.appendChild(_0x34eb96);
  document.getElementById('custom-confirm-yes').onclick = () => {
    _0x34eb96.remove();
    if (_0x555097) {
      _0x555097();
    }
  };
  document.getElementById("custom-confirm-no").onclick = () => {
    _0x34eb96.remove();
    if (_0x1a0249) {
      _0x1a0249();
    }
  };
}
let user_data = {};
function getMsg(_0x13429b, _0x135d7b) {
  return {
    'msg': {
      'type': _0x135d7b,
      'data': _0x13429b
    },
    'sender': "content_script",
    'id': "irctc"
  };
}
function statusUpdate(_0x2e467a) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': {
        'status': _0x2e467a,
        'time': new Date().toString().split(" ")[0x4]
      },
      'data': "status_update"
    },
    'sender': "content_script",
    'id': "irctc"
  });
}
function classTranslator(_0x4303d3) {
  let _0x37e9cc;
  _0x37e9cc = '1A' === _0x4303d3 ? "AC First Class (1A)" : 'EV' === _0x4303d3 ? "Vistadome AC (EV)" : 'EC' === _0x4303d3 ? "Exec. Chair Car (EC)" : '2A' === _0x4303d3 ? "AC 2 Tier (2A)" : '3A' === _0x4303d3 ? "AC 3 Tier (3A)" : '3E' === _0x4303d3 ? "AC 3 Economy (3E)" : 'CC' === _0x4303d3 ? "AC Chair car (CC)" : 'SL' === _0x4303d3 ? "Sleeper (SL)" : '2S' === _0x4303d3 ? "Second Sitting (2S)" : "None";
  return _0x37e9cc;
}
function quotaTranslator(_0x4d2259) {
  let _0x155411 = '';
  if ('GN' === _0x4d2259) {
    _0x155411 = 'GENERAL';
  } else if ('TQ' === _0x4d2259) {
    _0x155411 = 'TATKAL';
  } else if ('PT' === _0x4d2259) {
    _0x155411 = "PREMIUM TATKAL";
  } else if ('LD' === _0x4d2259) {
    _0x155411 = 'LADIES';
  } else if ('SR' === _0x4d2259) {
    _0x155411 = "LOWER BERTH/SR.CITIZEN";
  } else {
    _0x155411 = _0x155411;
  }
  return _0x155411;
}
function addDelay(_0x892d25) {
  const _0x47ec28 = Date.now();
  let _0xcac097 = null;
  do {
    _0xcac097 = Date.now();
  } while (_0xcac097 - _0x47ec28 < _0x892d25);
}
function showPnrAnimation(_0xd87ca8) {
  console.log("[content_script.js] Attempting to show PNR animation based on image.");
  if (_0xd87ca8) {
    console.log("[content_script.js] Triggered by element:", _0xd87ca8);
  }
  if (!document.getElementById("Voltas-tatkal-style-v2")) {
    const _0x28558e = document.createElement("style");
    _0x28558e.id = "Voltas-tatkal-style-v2";
    _0x28558e.textContent = "\n.Voltas-tatkal-success-message {\n    position: fixed;\n    top: 70%;\n    left: 50%;\n    transform: translateX(-50%);\n    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);\n    z-index: 10000;\n    font-family: Arial, Helvetica, sans-serif;\n    border-radius: 8px; /* Rounded corners for the whole box */\n    overflow: hidden; /* This is key to make the inner corners rounded */\n    text-align: center;\n    width: 340px; /* A fixed width that looks good */\n    border: 1px solid #ddd;\n}\n.Voltas-header {\n    background-color: #005A9C; /* A professional blue, similar to the image */\n    color: white;\n    padding: 12px;\n    font-size: 20px;\n    font-weight: bold;\n}\n.Voltas-body {\n    background-color: #2E8B57; /* A vibrant 'SeaGreen', similar to the image */\n    color: white;\n    padding: 25px 20px;\n    font-size: 22px;\n    font-weight: bold;\n    line-height: 1.5; /* Adds space between the lines of text */\n}\n";
    document.head.appendChild(_0x28558e);
  }
  const _0xd88801 = document.querySelector('.Voltas-tatkal-success-message');
  if (_0xd88801) {
    _0xd88801.remove();
  }
  const _0x1052f4 = document.createElement("div");
  _0x1052f4.className = "Voltas-tatkal-success-message";
  _0x1052f4.innerHTML = "\n        <div class=\"Voltas-header\">Proccessing Status</div>\n        <div class=\"Voltas-body\">\n            Congratulation !<br>\n            PNR Successfully<br>\n            Booked by Voltas\n        </div>\n    ";
  document.body.appendChild(_0x1052f4);
  console.log("[content_script.js] PNR success message is now visible.");
}
(() => {
  const _0x280a15 = document.querySelector("div.cnf-pad.ng-star-inserted");
  if (_0x280a15) {
    console.log("[content_script.js] Booking confirmation element found. Displaying success message.");
    showPnrAnimation(_0x280a15);
  } else {
    console.log("[content_script.js] Booking confirmation element not found on this page.");
  }
})();
chrome.runtime.onMessage.addListener(async (_0x27d78f, _0x2aa6fb, _0x4c6c05) => {
  if ("irctc" !== _0x27d78f.id) {
    return void _0x4c6c05("Invalid ID");
  }
  const _0x997ee5 = _0x27d78f.msg.type;
  if ('selectJourney' === _0x997ee5) {
    console.log("selectJourney action received");
    let _0x1cf9ff = document.querySelectorAll(".btn.btn-primary");
    if (_0x1cf9ff.length > 0x1 && _0x1cf9ff[0x1]) {
      simulateClick(_0x1cf9ff[0x1]);
      console.log("Close last trxn popup");
    }
    const _0x33fa02 = document.querySelector("#divMain > div > app-train-list");
    if (!_0x33fa02) {
      console.error("Train list container not found for selectJourney.");
      return;
    }
    const _0x2ab7f7 = [..._0x33fa02.querySelectorAll(".tbis-div app-train-avl-enq")];
    const _0x4afd4f = user_data.journey_details["train-no"];
    if (!_0x4afd4f) {
      console.error("Train number missing in user_data for selectJourney.");
      return;
    }
    const _0x5585e8 = _0x2ab7f7.find(_0xf1cdf5 => {
      const _0x2fb015 = _0xf1cdf5.querySelector("div.train-heading");
      return _0x2fb015 && _0x2fb015.innerText.trim().includes(_0x4afd4f.split('-')[0x0]);
    });
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void showCustomAlert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x5585e8) {
        return void showCustomAlert("Precheck - Train (" + _0x4afd4f + ") not found. Proceed manually or correct data.");
      }
      const _0x336ecd = classTranslator(user_data.journey_details["class"]);
      if (![..._0x5585e8.querySelectorAll("table tr td div.pre-avl")].find(_0x22b37f => _0x22b37f.querySelector("div")?.["innerText"] === _0x336ecd)) {
        return void showCustomAlert("Precheck - Selected Class not available. Proceed manually or correct data.");
      }
    }
    const _0x41c258 = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      if (['TQ', 'PT', 'GN'].includes(user_data.journey_details.quota)) {
        console.log("Verify tatkal/general time");
        const _0x26f4d5 = user_data.journey_details["class"];
        let _0x199239 = "00:00:00";
        let _0x58322b = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x26f4d5.toUpperCase())) {
          _0x199239 = user_data.other_preferences.acbooktime;
        } else {
          _0x199239 = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          _0x199239 = user_data.other_preferences.gnbooktime;
        }
        console.log("Required Booking Time:", _0x199239);
        var _0x20c03d = 0x0;
        let _0x1c67da = new MutationObserver(_0x4534df => {
          _0x58322b = new Date().toString().split(" ")[0x4];
          console.log("Current Time for booking:", _0x58322b);
          if (_0x58322b >= _0x199239) {
            _0x1c67da.disconnect();
            selectJourney();
          } else {
            if (_0x20c03d === 0x0) {
              try {
                const _0x34ead7 = document.createElement("div");
                _0x34ead7.textContent = "Please wait... Booking will start at " + _0x199239;
                Object.assign(_0x34ead7.style, {
                  'textAlign': "center",
                  'color': "white",
                  'height': "auto",
                  'fontSize': "20px"
                });
                document.querySelector("#divMain > div > app-train-list > div > div > div > div.clearfix")?.["insertAdjacentElement"]("afterend", _0x34ead7);
              } catch (_0x495850) {
                console.log("Wait message display failed", _0x495850);
              }
            }
            try {
              const _0x10a14f = document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)");
              if (_0x10a14f) {
                _0x10a14f.style.background = _0x20c03d % 0x2 === 0x0 ? "green" : "red";
              }
            } catch (_0x370422) {
              console.log("Wait indicator style failed", _0x370422);
            }
            _0x20c03d++;
          }
        });
        if (_0x41c258) {
          _0x1c67da.observe(_0x41c258, {
            'childList': true,
            'subtree': true,
            'characterDataOldValue': true
          });
        } else {
          console.warn("Header element for time observer not found.");
        }
      } else {
        selectJourney();
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      selectJourney();
    }
  } else {
    if ("fillPassengerDetails" === _0x997ee5) {
      await fillPassengerDetails();
    } else {
      if ('reviewBooking' === _0x997ee5) {
        if (user_data.fare_limit?.["enableFareLimit"]) {
          let _0x9cc4b9 = 0x0;
          const _0x1841c7 = ["#fare-summary .col-xs-12.line-def.top-header span.pull-right strong", ".total-fare", "#totalAmount", ".fare-summary span.amount", 'span.fare-value', ".fare-breakup-summary .fare-amount", "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value", "div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold", "div.fare-breakup-summary div.fare-amount", "div.fare-detail-item:nth-child(5) > div:nth-child(2)", "div.col-sm-6.text-right.font-small-bold"];
          for (const _0x25fbdb of _0x1841c7) {
            const _0x28423b = document.querySelector(_0x25fbdb);
            if (_0x28423b?.["innerText"]["match"](/(\d[\d,]*\.?\d*)/)) {
              _0x9cc4b9 = parseFloat(_0x28423b.innerText.replace(/[^0-9.]/g, ''));
              if (!isNaN(_0x9cc4b9)) {
                console.log("Found total fare " + _0x9cc4b9 + " using \"" + _0x25fbdb + "\"");
                break;
              }
            }
          }
          if (!isNaN(_0x9cc4b9) && _0x9cc4b9 > 0x0) {
            const _0xdf3de1 = parseFloat(user_data.fare_limit.maxFareAmount);
            if (!isNaN(_0xdf3de1) && _0x9cc4b9 > _0xdf3de1) {
              return showCustomConfirm("Total fare (" + _0x9cc4b9 + ") exceeds limit (" + _0xdf3de1 + "). Proceed?", () => proceedAfterFareCheck(), () => {
                showCustomAlert("Booking cancelled due to high fare.");
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              });
            }
          } else {
            console.warn("Could not determine total fare for limit check.");
          }
        }
        await proceedAfterFareCheck();
      } else {
        if ("bkgPaymentOptions" === _0x997ee5) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x34e92e = "Multiple Payment Service";
          let _0x794d7a = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x467eb9 = true;
          const _0x44b211 = user_data.other_preferences.paymentmethod;
          if (_0x44b211.includes("IRCUPI")) {
            _0x467eb9 = false;
            _0x34e92e = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x794d7a = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
          } else {
            if (_0x44b211.includes("PAYTMUPI")) {
              _0x34e92e = "BHIM/ UPI/ USSD";
              _0x794d7a = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            } else {
              if (_0x44b211.includes("PHONEPEUPI")) {
                _0x34e92e = "Multiple Payment Service";
                _0x794d7a = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
              } else {
                if (_0x44b211.includes('PAYUUPI')) {
                  _0x34e92e = "Multiple Payment Service";
                  _0x794d7a = "Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)";
                } else {
                  if (_0x44b211.includes('MOBUPI') && window.navigator.userAgent.includes('Android')) {
                    _0x34e92e = "Multiple Payment Service";
                    _0x794d7a = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
                  } else {
                    if (_0x44b211.includes('IRCWA')) {
                      _0x34e92e = "IRCTC eWallet";
                      _0x794d7a = "IRCTC eWallet";
                    } else if (_0x44b211.includes('HDFCDB')) {
                      _0x34e92e = "Payment Gateway / Credit Card / Debit Card";
                      _0x794d7a = "Visa/Master Card(Powered By HDFC BANK)";
                    }
                  }
                }
              }
            }
          }
          let _0x33f465 = _0x794d7a.replace(/&/g, "&amp;");
          let _0x1f51be = false;
          var _0x2d7c49 = setInterval(() => {
            console.log("[PaymentInterval] Checking for bank types. Found:", document.getElementsByClassName("bank-type").length);
            if (document.getElementsByClassName('bank-type').length > 0x1) {
              clearInterval(_0x2d7c49);
              console.log("[PaymentInterval] Bank types condition met. Proceeding.");
              var _0x449d5f = document.getElementById("pay-type")?.['getElementsByTagName']("div");
              if (!_0x449d5f || _0x449d5f.length === 0x0) {
                console.error("[PaymentLogic] Payment categories container '#pay-type' not found or is empty.");
                showCustomAlert("Payment categories container not found or empty. Please select manually.");
                return;
              }
              console.log("[PaymentLogic] Found " + _0x449d5f.length + " potential category elements. Searching for category text: \"" + _0x34e92e + "\"");
              let _0x18eb40 = false;
              for (let _0x1e15f5 of _0x449d5f) {
                if (_0x1e15f5 && _0x1e15f5.innerText && _0x1e15f5.innerText.includes(_0x34e92e)) {
                  console.log("[PaymentLogic] Category \"" + _0x34e92e + "\" found:", _0x1e15f5.innerText);
                  _0x18eb40 = true;
                  if (_0x467eb9) {
                    console.log("[PaymentLogic] Clicking category:", _0x1e15f5);
                    simulateClick(_0x1e15f5);
                  } else {
                    console.log("[PaymentLogic] Category click skipped due to clickCategory=false.");
                  }
                  setTimeout(() => {
                    console.log("[PaymentLogic-Timeout] Looking for payment option text: \"" + _0x33f465 + "\"");
                    var _0x106962 = document.getElementsByClassName("border-all no-pad");
                    if (!_0x106962 || _0x106962.length === 0x0) {
                      console.warn("[PaymentLogic-Timeout] No elements found with class 'border-all no-pad'.");
                      showCustomAlert("No payment option elements found. Please select manually.");
                      return;
                    }
                    console.log("[PaymentLogic-Timeout] Found " + _0x106962.length + " potential payment option elements.");
                    let _0x57c1ec = false;
                    for (let _0x278d4c of _0x106962) {
                      const _0x20142b = _0x278d4c?.["getElementsByTagName"]("span")[0x0];
                      const _0x5af826 = _0x278d4c && getComputedStyle(_0x278d4c).display !== 'none' && getComputedStyle(_0x278d4c).visibility !== "hidden" && parseFloat(getComputedStyle(_0x278d4c).opacity) > 0x0 && !_0x278d4c.disabled;
                      const _0x201b70 = _0x20142b?.["innerHTML"]?.["toUpperCase"]() || '';
                      const _0x1ffa0c = _0x33f465.toUpperCase();
                      console.log("[PaymentLogic-Timeout] Checking option: Visible&Interactable=" + _0x5af826 + ", Text=\"" + _0x201b70 + "\", Target=\"" + _0x1ffa0c + "\"", _0x278d4c);
                      if (_0x5af826 && _0x20142b && _0x201b70.includes(_0x1ffa0c)) {
                        console.log("[PaymentLogic-Timeout] Matching payment option found and is suitable:", _0x278d4c);
                        console.log("[PaymentLogic-Timeout] Clicking payment option:", _0x278d4c);
                        simulateClick(_0x278d4c);
                        _0x1f51be = true;
                        _0x57c1ec = true;
                        const _0x56f8f0 = document.getElementsByClassName("btn-primary")[0x0];
                        if (_0x56f8f0) {
                          _0x56f8f0.scrollIntoView({
                            'behavior': "smooth",
                            'block': 'center',
                            'inline': "nearest"
                          });
                          console.log("[PaymentLogic-Timeout] Scrolled to 'Pay' button:", _0x56f8f0);
                          if (user_data.other_preferences.paymentManual) {
                            showCustomAlert("Manually submit the payment page.");
                          } else {
                            console.log("[PaymentLogic-Timeout] Attempting to click 'Pay' button automatically in 500ms.");
                            setTimeout(() => {
                              console.log("[PaymentLogic-Timeout-Pay] Clicking 'Pay' button:", _0x56f8f0);
                              simulateClick(_0x56f8f0);
                            }, 0x1f4);
                          }
                        } else {
                          console.warn("[PaymentLogic-Timeout] 'Pay' button (btn-primary) not found.");
                          showCustomAlert("Could not find the 'Pay' button. Please click it manually.");
                        }
                        break;
                      }
                    }
                    if (!_0x57c1ec) {
                      console.warn("[PaymentLogic-Timeout] Selected payment option text \"" + _0x33f465 + "\" not found or not suitable among " + _0x106962.length + " candidates.");
                      let _0xac38eb = Array.from(_0x106962).map((_0x59c538, _0xe910b4) => {
                        const _0x11e636 = _0x59c538?.["getElementsByTagName"]("span")[0x0]?.["innerHTML"] || 'N/A';
                        const _0x6b44ee = _0x59c538 && getComputedStyle(_0x59c538).display !== 'none' && getComputedStyle(_0x59c538).visibility !== "hidden" && parseFloat(getComputedStyle(_0x59c538).opacity) > 0x0 && !_0x59c538.disabled;
                        return "Option " + _0xe910b4 + ": Visible&Interactable=" + _0x6b44ee + ", Text=\"" + _0x11e636 + "\"";
                      });
                      console.log("[PaymentLogic-Timeout] Available options details:", _0xac38eb);
                      showCustomAlert("Selected payment option not available. Please select manually.");
                    }
                  }, 0x1f4);
                  break;
                }
              }
              if (!_0x18eb40 && _0x449d5f.length > 0x0) {
                console.warn("[PaymentLogic] Payment category text \"" + _0x34e92e + "\" not found after checking all category elements.");
                let _0x14bf61 = Array.from(_0x449d5f).map(_0x4da3a1 => _0x4da3a1.innerText);
                console.log("[PaymentLogic] Available category texts:", _0x14bf61);
                showCustomAlert("Payment category \"" + _0x34e92e + "\" not found. Please select manually.");
              }
            }
          }, 0x1f4);
        } else if ("showPnrAnimation" === _0x997ee5) {
          showPnrAnimation();
        } else {
          _0x4c6c05("Something went wrong: Unknown message type");
        }
      }
    }
  }
});
async function proceedAfterFareCheck() {
  document.querySelector('#captcha')?.["scrollIntoView"]({
    'behavior': "smooth",
    'block': "center",
    'inline': 'nearest'
  });
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => await getCaptchaTC(), 0x1f4);
  } else {
    const _0x5f10f2 = document.querySelector("#captcha");
    if (_0x5f10f2) {
      await typeTextHumanLike(_0x5f10f2, 'X');
      _0x5f10f2.focus();
    }
  }
}
let captchaRetry = 0x0;
async function getCaptcha() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0xf4e190 = document.querySelector(".captcha-img");
  if (!_0xf4e190 || !_0xf4e190.src || _0xf4e190.src.length < 0x17) {
    setTimeout(getCaptcha, 0x3e8);
    return;
  }
  const _0x353cbf = new XMLHttpRequest();
  const _0x5eb6f1 = _0xf4e190.src.substr(0x16);
  const _0x5b0d34 = JSON.stringify({
    'requests': [{
      'image': {
        'content': _0x5eb6f1
      },
      'features': [{
        'type': 'TEXT_DETECTION'
      }],
      'imageContext': {
        'languageHints': ['en']
      }
    }]
  });
  _0x353cbf.open('POST', "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ", true);
  _0x353cbf.onload = async () => {
    if (_0x353cbf.status !== 0xc8) {
      console.error("Captcha API Error " + _0x353cbf.status + ": " + _0x353cbf.statusText, _0x353cbf.response);
      return;
    }
    let _0x4110ea = '';
    let _0x5ec15f = '';
    try {
      _0x4110ea = JSON.parse(_0x353cbf.response).responses[0x0].fullTextAnnotation.text;
    } catch (_0x540b3f) {
      console.error("Error parsing Vision API response", _0x540b3f);
    }
    for (const _0x478e49 of String(_0x4110ea).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) if ('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(_0x478e49)) {
      _0x5ec15f += _0x478e49;
    }
    const _0xbba2ae = document.querySelector("#captcha");
    if (_0xbba2ae) {
      await typeTextHumanLike(_0xbba2ae, _0x5ec15f);
    }
    if (!_0x4110ea) {
      simulateClick(document.querySelector('.glyphicon.glyphicon-repeat')?.["parentElement"]);
      setTimeout(getCaptcha, 0x1f4);
    }
    const _0x47425a = document.querySelector("app-login");
    const _0x1e1402 = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x27c736 = (_0x24b505, _0x1ec6ce) => {
      setTimeout(getCaptcha, 0x1f4);
      console.log("disconnect " + _0x24b505 + 'Captcha');
      _0x1ec6ce.disconnect();
    };
    const _0x283423 = new MutationObserver((_0x171b7b, _0x489a33) => {
      if (_0x47425a?.['innerText']["toLowerCase"]()['includes']("valid captcha")) {
        _0x27c736("login", _0x489a33);
      }
      if (_0x1e1402?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x27c736("review", _0x489a33);
      }
    });
    if (_0x47425a) {
      _0x283423.observe(_0x47425a, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0x1e1402) {
      _0x283423.observe(_0x1e1402, {
        'childList': true,
        'subtree': true
      });
    }
  };
  _0x353cbf.onerror = () => console.error("Captcha API Request failed");
  _0x353cbf.send(_0x5b0d34);
}
async function getCaptchaTC() {
  if (captchaRetry >= 0x64) {
    return;
  }
  captchaRetry++;
  const _0x227ffa = document.querySelector(".captcha-img");
  if (!_0x227ffa || !_0x227ffa.src || _0x227ffa.src.length < 0x17) {
    setTimeout(getCaptchaTC, 0x3e8);
    return;
  }
  const _0x4441d0 = new XMLHttpRequest();
  const _0x41a720 = _0x227ffa.src.substr(0x16);
  const _0x3c1594 = JSON.stringify({
    'client': "chrome extension",
    'location': "https://www.irctc.co.in/nget/train-search",
    'version': '0.3.8',
    'case': 'mixed',
    'promise': "true",
    'extension': true,
    'userid': "shahidtatkal",
    'apikey': 'gQBxwmskFdnjXUDKPhT8',
    'data': _0x41a720
  });
  _0x4441d0.open("POST", 'https://api.apitruecaptcha.org/one/gettext', true);
  _0x4441d0.onload = async () => {
    if (_0x4441d0.status !== 0xc8) {
      console.error("TrueCaptcha API Error " + _0x4441d0.status + ": " + _0x4441d0.statusText, _0x4441d0.response);
      return;
    }
    let _0x2bb1cf = '';
    let _0x214bb4 = '';
    try {
      _0x2bb1cf = JSON.parse(_0x4441d0.response).result;
    } catch (_0x401213) {
      console.error("Error parsing TrueCaptcha API", _0x401213);
    }
    for (const _0x10cfa1 of String(_0x2bb1cf).replace(/\s/g, '').replace(')', 'J').replace(']', 'J')) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x10cfa1)) {
      _0x214bb4 += _0x10cfa1;
    }
    const _0x4545e6 = document.querySelector('#captcha');
    if (_0x4545e6) {
      await typeTextHumanLike(_0x4545e6, _0x214bb4);
    }
    if (!_0x2bb1cf) {
      simulateClick(document.querySelector(".glyphicon.glyphicon-repeat")?.["parentElement"]);
      setTimeout(getCaptchaTC, 0x1f4);
    }
    const _0x50d712 = document.querySelector('app-login');
    const _0x5cfbd1 = document.querySelector("#divMain > div > app-review-booking > p-toast");
    const _0x3bf9c5 = (_0x42f810, _0x2c7ffd) => {
      setTimeout(getCaptchaTC, 0x1f4);
      console.log("disconnect " + _0x42f810 + 'Captcha');
      _0x2c7ffd.disconnect();
    };
    const _0x52f91f = new MutationObserver((_0x42ef90, _0x44c7d2) => {
      if (_0x50d712?.["innerText"]['toLowerCase']()["includes"]("valid captcha")) {
        _0x3bf9c5('login', _0x44c7d2);
      }
      if (_0x5cfbd1?.["innerText"]["toLowerCase"]()["includes"]("valid captcha")) {
        _0x3bf9c5("review", _0x44c7d2);
      }
    });
    if (_0x50d712) {
      _0x52f91f.observe(_0x50d712, {
        'childList': true,
        'subtree': true
      });
    }
    if (_0x5cfbd1) {
      _0x52f91f.observe(_0x5cfbd1, {
        'childList': true,
        'subtree': true
      });
    }
    if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
      const _0x3744c9 = document.querySelector("#divMain > app-login");
      if (_0x3744c9) {
        const _0x3cd0aa = _0x3744c9.querySelector("input[formcontrolname='userid']");
        const _0xdf2371 = _0x3744c9.querySelector("input[formcontrolname='password']");
        if (_0x3cd0aa?.["value"] && _0xdf2371?.["value"]) {
          setTimeout(() => {
            simulateClick(_0x3744c9.querySelector("button[type='submit'][class='search_btn train_Search']"));
            simulateClick(_0x3744c9.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"));
          }, 0x1f4);
        } else {
          showCustomAlert("Username/password not filled for auto-submit.");
        }
      }
      const _0x3926a0 = document.querySelector("#divMain > div > app-review-booking");
      if (_0x3926a0 && _0x4545e6?.["value"]) {
        const _0x47b3c3 = _0x3926a0.querySelector(".btnDefault.train_Search");
        if (_0x47b3c3) {
          setTimeout(() => {
            if (user_data.other_preferences.confirmberths) {
              if (document.querySelector(".AVAILABLE")) {
                simulateClick(_0x47b3c3);
              } else {
                showCustomConfirm("No seats available. Continue booking?", () => simulateClick(_0x47b3c3), () => console.log("Booking stopped."));
              }
            } else {
              simulateClick(_0x47b3c3);
            }
          }, 0x1f4);
        }
      } else if (_0x3926a0 && !_0x4545e6?.["value"]) {
        showCustomAlert("Captcha not filled for auto-submit on review page.");
      }
    }
  };
  _0x4441d0.onerror = () => console.error("TrueCaptcha API Request failed");
  _0x4441d0.send(_0x3c1594);
}
async function loadLoginDetails() {
  const _0x5c76d6 = document.querySelector("#divMain > app-login");
  const _0x391719 = _0x5c76d6.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x387cd0 = _0x5c76d6.querySelector("input[type='password'][formcontrolname='password']");
  await typeTextHumanLike(_0x391719, user_data.irctc_credentials.user_name ?? '');
  await typeTextHumanLike(_0x387cd0, user_data.irctc_credentials.password ?? '');
  document.querySelector("#captcha").scrollIntoView({
    'behavior': 'smooth',
    'block': "center",
    'inline': 'nearest'
  });
  if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
    setTimeout(async () => {
      await getCaptchaTC();
    }, 0x1f4);
  } else {
    console.log("Manual captcha filling");
    const _0x18f5bd = document.querySelector("#captcha");
    await typeTextHumanLike(_0x18f5bd, 'X');
    _0x18f5bd.focus();
  }
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x1e51d2 = document.querySelector("app-jp-input form");
  const _0x3a91f8 = _0x1e51d2.querySelector("#origin > span > input");
  _0x3a91f8.value = user_data.journey_details.from;
  _0x3a91f8.dispatchEvent(new Event("keydown"));
  _0x3a91f8.dispatchEvent(new Event("input"));
  const _0x116883 = _0x1e51d2.querySelector("#destination > span > input");
  _0x116883.value = user_data.journey_details.destination;
  _0x116883.dispatchEvent(new Event("keydown"));
  _0x116883.dispatchEvent(new Event("input"));
  const _0x330bc8 = _0x1e51d2.querySelector("#jDate > span > input");
  _0x330bc8.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0x330bc8.dispatchEvent(new Event("keydown"));
  _0x330bc8.dispatchEvent(new Event("input"));
  const _0x4a9be9 = _0x1e51d2.querySelector("#journeyClass");
  _0x4a9be9.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x4a9be9.querySelectorAll("ul li")].filter(_0xb4ef8c => _0xb4ef8c.innerText === classTranslator(user_data.journey_details['class']) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x548447 = _0x1e51d2.querySelector("#journeyQuota");
  _0x548447.querySelector("div > div[role='button']").click();
  [..._0x548447.querySelectorAll("ul li")].filter(_0x37a75c => _0x37a75c.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.['click']();
  addDelay(0x12c);
  const _0x428f67 = _0x1e51d2.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log("filled_journey_details");
  _0x428f67.click();
}
function selectJourneyOld() {
  if (!user_data.journey_details['train-no']) {
    return;
  }
  const _0x406c20 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details['train-no']);
  const _0x14d14d = _0x406c20.filter(_0x4348d4 => _0x4348d4.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details['train-no']))[0x0];
  if (!_0x14d14d) {
    console.log("Train not found.");
    showCustomAlert("Train not found");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0x55bf9d = classTranslator(user_data.journey_details["class"]);
  const _0x3eb2a4 = new Date(user_data.journey_details.date).toString().split(" ");
  const _0xbc20dc = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0x14d14d.querySelectorAll("table tr td div.pre-avl")].filter(_0x1bd5b6 => _0x1bd5b6.querySelector('div').innerText === _0x55bf9d)[0x0]?.["click"]();
  const _0x4999c9 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x26f1ab, _0x55d78e) => {
    const _0x4f6554 = [..._0x14d14d.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x370fea => _0x370fea.querySelector("div").innerText === _0x55bf9d)[0x0];
    const _0x1403b8 = [..._0x14d14d.querySelectorAll("div div table td div.pre-avl")].filter(_0x32cae9 => _0x32cae9.querySelector("div").innerText === _0x3eb2a4[0x0] + ", " + _0x3eb2a4[0x2] + " " + _0x3eb2a4[0x1])[0x0];
    const _0x1b974a = _0x14d14d.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x4f6554) {
      console.log(0x1);
      if (!_0x4f6554.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x4f6554.click();
      }
      if (_0x1403b8) {
        console.log(0x3);
        if (_0x1403b8.classList.contains('selected-class')) {
          console.log(0x4);
          _0x1b974a.click();
          _0x55d78e.disconnect();
        } else {
          console.log(0x5);
          _0x1403b8.click();
        }
      }
    } else {
      console.log('6');
      _0x1403b8.click();
      _0x1b974a.click();
      _0x55d78e.disconnect();
    }
  }).observe(_0x14d14d, _0xbc20dc);
  const _0x1d7e63 = new MutationObserver((_0x296b49, _0x55ae0e) => {
    console.log("Popup error");
    console.log("Class count ", [..._0x14d14d.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0x14d14d.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x4999c9.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0x14d14d.querySelectorAll("table tr td div.pre-avl")].filter(_0x5cbdb2 => _0x5cbdb2.querySelector('div').innerText === _0x55bf9d)[0x0]?.['click']();
      _0x55ae0e.disconnect();
    }
  });
  _0x1d7e63.observe(_0x4999c9, _0xbc20dc);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourney, 0x3e8);
}
function selectJourney() {
  const _0x47350b = setInterval(() => {
    const _0x304708 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0x4bb7c7 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x186701 = _0x304708 || _0x4bb7c7;
    const _0x5f13ea = document.querySelector("#loaderP");
    const _0x52aa70 = _0x5f13ea && "none" !== _0x5f13ea.style.display;
    if (_0x186701 && !_0x52aa70) {
      console.log("Toast link found. Clicking it now...");
      _0x186701.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x47350b);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  const _0x2ff159 = document.querySelector("#divMain > div > app-train-list");
  if (!_0x2ff159) {
    return void console.error("Train list parent not found.");
  }
  const _0x829de3 = Array.from(_0x2ff159.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x66f70d = user_data.journey_details["train-no"];
  const _0x173c2f = classTranslator(user_data.journey_details['class']);
  const _0x4f297e = new Date(user_data.journey_details.date);
  const _0x1e7732 = _0x4f297e.toDateString().split(" ")[0x0] + ", " + _0x4f297e.toDateString().split(" ")[0x2] + " " + _0x4f297e.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x66f70d);
  console.log('Class:', _0x173c2f);
  console.log("date", _0x1e7732);
  const _0x2a785d = _0x829de3.find(_0x146b43 => _0x146b43.querySelector("div.train-heading").innerText.trim().includes(_0x66f70d.split('-')[0x0]));
  if (!_0x2a785d) {
    console.error("Train not found.");
    return void statusUpdate("journey_selection_stopped.no_train");
  }
  const _0x45996c = _0x25a6ff => {
    if (!_0x25a6ff) {
      return false;
    }
    const _0x1c6d58 = window.getComputedStyle(_0x25a6ff);
    return "none" !== _0x1c6d58.display && "hidden" !== _0x1c6d58.visibility && '0' !== _0x1c6d58.opacity;
  };
  const _0x1b1520 = Array.from(_0x2a785d.querySelectorAll("table tr td div.pre-avl")).find(_0x14c4c8 => _0x14c4c8.querySelector("div").innerText.trim() === _0x173c2f);
  const _0x560618 = Array.from(_0x2a785d.querySelectorAll("span")).find(_0x1f5dfa => _0x1f5dfa.innerText.trim() === _0x173c2f);
  const _0x16ffe8 = _0x1b1520 || _0x560618;
  console.log("FOUND updatedClassToClick:", _0x16ffe8);
  if (!_0x16ffe8) {
    return void console.error("Class to click not found.");
  }
  const _0x67b4df = document.querySelector("#loaderP");
  if (_0x45996c(_0x67b4df)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0x451609;
  _0x16ffe8.click();
  new MutationObserver((_0x5bebdb, _0x32beef) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x451609);
    _0x451609 = setTimeout(() => {
      const _0x3abde6 = Array.from(_0x2a785d.querySelectorAll("div div table td div.pre-avl")).find(_0x234a1d => _0x234a1d.querySelector('div').innerText.trim() === _0x1e7732);
      console.log("FOUND classTabToSelect:", _0x3abde6);
      if (_0x3abde6) {
        _0x3abde6.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          const _0x17e0c0 = () => {
            const _0x24b058 = _0x2a785d.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x45996c(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0x17e0c0, 0x64);
            }
            if (!_0x24b058 || _0x24b058.classList.contains("disable-book") || _0x24b058.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              setTimeout(() => {
                _0x24b058.click();
                console.log("Clicked on bookBtn");
                clearTimeout(_0x451609);
                _0x32beef.disconnect();
              }, 0x12c);
            }
          };
          _0x17e0c0();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x2a785d, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
async function fillPassengerDetails() {
  console.log("passenger_filling_started");
  keyCounter = Date.now();
  if (user_data.journey_details.boarding?.["length"] > 0x0) {
    const _0x116e58 = Array.from(document.getElementsByTagName("strong")).find(_0x355a62 => _0x355a62.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x116e58) {
      simulateClick(_0x116e58);
    }
    addDelay(0x12c);
    const _0x428340 = Array.from(document.getElementsByTagName('strong')).find(_0x5ea02a => _0x5ea02a.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x428340) {
      simulateClick(_0x428340);
    }
  }
  const _0x2a9f98 = document.querySelector("app-passenger-input");
  if (!_0x2a9f98) {
    return console.error("Passenger app element not found.");
  }
  for (let _0x5cf5c8 = 0x1; _0x5cf5c8 < user_data.passenger_details.length; _0x5cf5c8++) {
    addDelay(0xc8);
    simulateClick(document.getElementsByClassName('prenext')[0x0]);
  }
  try {
    for (let _0x3f6b65 = 0x0; _0x3f6b65 < user_data.infant_details.length; _0x3f6b65++) {
      addDelay(0xc8);
      simulateClick(document.getElementsByClassName('prenext')[0x2]);
    }
  } catch (_0x4c15c1) {
    console.error("Add infant error", _0x4c15c1);
  }
  const _0x1e02f2 = [..._0x2a9f98.querySelectorAll('app-passenger')];
  for (let _0x423573 = 0x0; _0x423573 < user_data.passenger_details.length; _0x423573++) {
    const _0x5d5f38 = user_data.passenger_details[_0x423573];
    if (!_0x1e02f2[_0x423573]) {
      continue;
    }
    const _0x33de3d = _0x1e02f2[_0x423573];
    const _0x16d18e = _0x33de3d.querySelector("p-autocomplete input");
    if (_0x16d18e) {
      await typeTextHumanLike(_0x16d18e, _0x5d5f38.name);
    }
    const _0x56d25a = _0x33de3d.querySelector("input[formcontrolname='passengerAge']");
    if (_0x56d25a) {
      await typeTextHumanLike(_0x56d25a, _0x5d5f38.age);
    }
    const _0x513ccb = _0x33de3d.querySelector("select[formcontrolname='passengerGender']");
    if (_0x513ccb) {
      _0x513ccb.value = _0x5d5f38.gender;
      _0x513ccb.dispatchEvent(new Event("change"));
    }
    const _0x1498dc = _0x33de3d.querySelector("select[formcontrolname='passengerBerthChoice']");
    if (_0x1498dc) {
      _0x1498dc.value = _0x5d5f38.berth;
      _0x1498dc.dispatchEvent(new Event("change"));
    }
    const _0x19d653 = _0x33de3d.querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x19d653) {
      _0x19d653.value = _0x5d5f38.food;
      _0x19d653.dispatchEvent(new Event("change"));
    }
    try {
      const _0x4611b0 = _0x33de3d.querySelector("input[formcontrolname='childBerthFlag']");
      if (_0x4611b0 && _0x5d5f38.passengerchildberth !== _0x4611b0.checked) {
        simulateClick(_0x4611b0);
        addDelay(0xc8);
        if (_0x5d5f38.passengerchildberth) {
          const _0x5f4bda = _0x33de3d.querySelector("p-dialog app-passenger-confirm-dialog button.btn.btn-primary");
          if (_0x5f4bda && _0x5f4bda.offsetParent !== null) {
            simulateClick(_0x5f4bda);
            addDelay(0xc8);
          } else {
            const _0x4492da = _0x33de3d.querySelector("p-dialog p-footer button");
            if (_0x4492da && _0x4492da.offsetParent !== null) {
              simulateClick(_0x4492da);
            }
            addDelay(0xc8);
          }
        }
      }
    } catch (_0x5bc0bc) {
      console.error("Child berth error", _0x5bc0bc);
    }
  }
  const _0x1482cb = [..._0x2a9f98.querySelectorAll("app-infant")];
  user_data.infant_details.forEach((_0xe83f6, _0x4f0f0c) => {
    if (!_0x1482cb[_0x4f0f0c]) {
      return;
    }
    const _0x17cafe = _0x1482cb[_0x4f0f0c];
    const _0x42388d = _0x17cafe.querySelector('input#infant-name');
    if (_0x42388d) {
      _0x42388d.value = _0xe83f6.name;
      _0x42388d.dispatchEvent(new Event("input"));
    }
    const _0xfc1afe = _0x17cafe.querySelector("select[formcontrolname='age']");
    if (_0xfc1afe) {
      _0xfc1afe.value = _0xe83f6.age;
      _0xfc1afe.dispatchEvent(new Event("change"));
    }
    const _0x1b123c = _0x17cafe.querySelector("select[formcontrolname='gender']");
    if (_0x1b123c) {
      _0x1b123c.value = _0xe83f6.gender;
      _0x1b123c.dispatchEvent(new Event("change"));
    }
  });
  if (user_data.other_preferences.mobileNumber) {
    const _0x3a0fcd = _0x2a9f98.querySelector("input#mobileNumber");
    if (_0x3a0fcd) {
      await typeTextHumanLike(_0x3a0fcd, user_data.other_preferences.mobileNumber);
    }
  }
  const _0x525774 = user_data.other_preferences.paymentmethod.includes("UPI") ? '2' : '1';
  const _0x530eab = [..._0x2a9f98.querySelectorAll("p-radiobutton[formcontrolname='paymentType'] input")].find(_0x1e2edc => _0x1e2edc.value === _0x525774);
  if (_0x530eab) {
    simulateClick(_0x530eab);
  }
  const _0x4c32ea = _0x2a9f98.querySelector("input#autoUpgradation");
  if (_0x4c32ea && user_data.other_preferences.autoUpgradation !== _0x4c32ea.checked) {
    simulateClick(_0x4c32ea);
  }
  const _0x13f7e2 = _0x2a9f98.querySelector("input#confirmberths");
  if (_0x13f7e2 && user_data.other_preferences.confirmberths !== _0x13f7e2.checked) {
    simulateClick(_0x13f7e2);
  }
  const _0x406e2f = user_data.travel_preferences.travelInsuranceOpted === "yes" ? "true" : "false";
  const _0x6bfe31 = [..._0x2a9f98.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input")].find(_0x4397e3 => _0x4397e3.value === _0x406e2f);
  if (_0x6bfe31) {
    simulateClick(_0x6bfe31);
  }
  try {
    const _0x12b0f9 = _0x2a9f98.querySelector("input[formcontrolname='coachId']");
    if (_0x12b0f9 && user_data.travel_preferences.prefcoach?.['trim']()) {
      _0x12b0f9.value = user_data.travel_preferences.prefcoach;
      _0x12b0f9.dispatchEvent(new Event('input'));
    }
    const _0x49eb9b = _0x2a9f98.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x49eb9b && user_data.travel_preferences.reservationchoice && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      simulateClick(_0x49eb9b.querySelector("div[role='button']"));
      addDelay(0x12c);
      const _0x271204 = [..._0x49eb9b.querySelectorAll("ul li")].find(_0x2efdd4 => _0x2efdd4.innerText === user_data.travel_preferences.reservationchoice);
      if (_0x271204) {
        simulateClick(_0x271204);
      }
    }
  } catch (_0xc91f43) {
    console.error("Coach/Reservation choice error", _0xc91f43);
  }
  submitPassengerDetailsForm(_0x2a9f98);
}
function submitPassengerDetailsForm(_0x11a4e0) {
  window.scrollBy(0x0, 0x258, "smooth");
  if (user_data.other_preferences.psgManual) {
    return showCustomAlert("Manually submit passenger page.");
  }
  const _0x4005f8 = () => {
    if (keyCounter > 0x0 && Date.now() - keyCounter > 0x7d0) {
      clearInterval(_0x2d9862);
      let _0x435683 = null;
      const _0x3fd827 = ["button.train_Search.btnDefault[type='submit']", "button[type='submit'].btn-primary.pull-right", "button.btn.btn-primary.manual-booking-btn", "button.psgn-btn[type='submit']", "button#validate", "button[type='submit']", ".btn-primary", ".btn-success"];
      if (_0x11a4e0) {
        for (const _0x55620f of _0x3fd827) {
          const _0x5b0952 = _0x11a4e0.querySelector(_0x55620f);
          if (_0x5b0952 && _0x5b0952 && getComputedStyle(_0x5b0952).display !== 'none' && getComputedStyle(_0x5b0952).visibility !== "hidden" && parseFloat(getComputedStyle(_0x5b0952).opacity) > 0x0 && !_0x5b0952.disabled) {
            _0x435683 = _0x5b0952;
            console.log("Passenger page: Found button with selector (scoped): \"" + _0x55620f + "\"", _0x5b0952);
            break;
          }
        }
      }
      if (!_0x435683) {
        const _0x5031de = ["#psgn-form button.train_Search.btnDefault", "button.btnDefault.train_Search"];
        for (const _0x2168e3 of _0x5031de) {
          const _0xa2e156 = document.querySelector(_0x2168e3);
          if (_0xa2e156 && _0xa2e156 && getComputedStyle(_0xa2e156).display !== 'none' && getComputedStyle(_0xa2e156).visibility !== "hidden" && parseFloat(getComputedStyle(_0xa2e156).opacity) > 0x0 && !_0xa2e156.disabled) {
            _0x435683 = _0xa2e156;
            console.log("Passenger page: Found button with selector (global): \"" + _0x2168e3 + "\"", _0xa2e156);
            break;
          }
        }
      }
      if (!_0x435683 && _0x11a4e0) {
        const _0x51f613 = _0x11a4e0.querySelectorAll("button, a.btn");
        for (let _0x4239cb of _0x51f613) {
          const _0xb7e2fe = _0x4239cb.innerText?.["trim"]()["toLowerCase"]();
          if (_0xb7e2fe && (_0xb7e2fe.includes('continue') || _0xb7e2fe.includes("proceed") || _0xb7e2fe.includes("submit") || _0xb7e2fe.includes("next") || _0xb7e2fe.includes("payment"))) {
            if (_0x4239cb && getComputedStyle(_0x4239cb).display !== 'none' && getComputedStyle(_0x4239cb).visibility !== "hidden" && parseFloat(getComputedStyle(_0x4239cb).opacity) > 0x0 && !_0x4239cb.disabled && !_0xb7e2fe.includes("cancel") && !_0xb7e2fe.includes("back")) {
              _0x435683 = _0x4239cb;
              console.log("Passenger page: Found button by text content: ", _0xb7e2fe, _0x4239cb);
              break;
            }
          }
        }
      }
      if (_0x435683) {
        console.log("Attempting to click passenger page continue button:", _0x435683);
        simulateClick(_0x435683);
      } else {
        console.error("Passenger page continue/submit button NOT FOUND with any known strategy.");
        showCustomAlert("Could not find the 'Continue' button on the passenger page. Please click it manually if available.");
      }
    }
  };
  const _0x2d9862 = setInterval(_0x4005f8, 0x1f4);
}
async function continueScript() {
  const _0x59d994 = document.querySelector("body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if (_0x59d994 && _0x59d994.innerText.trim().toUpperCase() === "LOGOUT") {
      console.log("User is logged in. Proceeding to load journey details.");
      loadJourneyDetails();
    } else {
      if (_0x59d994 && _0x59d994.innerText.trim().toUpperCase() === "LOGIN") {
        console.log("IRCTC page loaded. LOGIN button found. Starting 15-second countdown...");
        let _0x58894b = document.getElementById('irctc-login-countdown-element');
        if (!_0x58894b) {
          _0x58894b = document.createElement("div");
          _0x58894b.id = "irctc-login-countdown-element";
          _0x58894b.style.cssText = "\n                    position: fixed; top: 10px; left: 50%; transform: translateX(-50%);\n                    background-color: rgba(0,0,0,0.7); color: white; padding: 10px 20px;\n                    border-radius: 5px; z-index: 20000; font-size: 16px;\n                ";
          document.body.appendChild(_0x58894b);
        }
        let _0x3b6801 = 0xf;
        _0x58894b.textContent = "Voltas Login " + _0x3b6801 + " Will Start In Seconds...";
        const _0x2f0bd5 = setInterval(async () => {
          _0x3b6801--;
          if (_0x58894b) {
            _0x58894b.textContent = "Voltas Login " + _0x3b6801 + " Will Start In Seconds...";
          }
          if (_0x3b6801 <= 0x0) {
            clearInterval(_0x2f0bd5);
            if (_0x58894b && _0x58894b.parentElement) {
              _0x58894b.remove();
            }
            console.log("Countdown finished. Clicking LOGIN button.");
            simulateClick(_0x59d994);
            await loadLoginDetails();
          }
        }, 0x3e8);
      } else {
        console.log("LOGIN/LOGOUT link not found or text doesn't match. Waiting for page changes or manual interaction.");
      }
    }
  } else {
    console.log("Not on train-search page. continueScript takes no action.");
  }
}
async function a() {}
window.onload = function () {
  console.log("Content script loaded and window.onload triggered.");
  setInterval(() => statusUpdate("Keep listener alive."), 0x3a98);
  const _0x2bec98 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1");
  if (_0x2bec98) {
    new MutationObserver((_0x54f6d1, _0x431e43) => {
      if (_0x54f6d1.some(_0x357405 => _0x357405.type === "childList" && [..._0x357405.addedNodes].some(_0x2f911 => _0x2f911?.['innerText']?.["trim"]()["toUpperCase"]() === 'LOGOUT'))) {
        console.log("LOGOUT detected in header via MutationObserver.");
        _0x431e43.disconnect();
        loadJourneyDetails();
      }
    }).observe(_0x2bec98, {
      'childList': true,
      'subtree': false
    });
  } else {
    console.warn("Header div for MutationObserver not found on window.onload.");
  }
  chrome.storage.local.get(null, _0x3f102a => {
    user_data = _0x3f102a;
    console.log("User data loaded from storage:", user_data);
    continueScript();
  });
};