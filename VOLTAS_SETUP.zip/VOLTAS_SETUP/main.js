function compareVersions(_0x47d8c7, _0x5cf130) {
  const _0x1463c6 = _0x47d8c7.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x1619b6 = _0x5cf130.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x1481fd = Math.max(_0x1463c6.length, _0x1619b6.length);
  for (let _0x27137e = 0x0; _0x27137e < _0x1481fd; _0x27137e++) {
    const _0x5606f2 = _0x1463c6[_0x27137e] || 0x0;
    const _0x1a9cd2 = _0x1619b6[_0x27137e] || 0x0;
    if (_0x5606f2 > _0x1a9cd2) {
      return 0x1;
    }
    if (_0x5606f2 < _0x1a9cd2) {
      return -0x1;
    }
  }
  return 0x0;
}
function showUpdatePopup(_0x26a498, _0x9003ba) {
  const _0x2fe554 = document.createElement("div");
  _0x2fe554.style.position = "fixed";
  _0x2fe554.style.top = '0';
  _0x2fe554.style.left = '0';
  _0x2fe554.style.width = '100%';
  _0x2fe554.style.height = "100%";
  _0x2fe554.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x2fe554.style.zIndex = "9999";
  _0x2fe554.style.display = "flex";
  _0x2fe554.style.justifyContent = "center";
  _0x2fe554.style.alignItems = "center";
  const _0x178269 = document.createElement("div");
  _0x178269.style.backgroundColor = "#fff";
  _0x178269.style.padding = "20px";
  _0x178269.style.borderRadius = "8px";
  _0x178269.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x178269.style.textAlign = 'center';
  _0x178269.style.maxWidth = "400px";
  _0x178269.style.width = '90%';
  const _0x432ff0 = document.createElement('h2');
  _0x432ff0.textContent = "Please update this extension";
  _0x432ff0.style.margin = "0px";
  const _0x992819 = document.createElement('p');
  _0x992819.textContent = "Latest Version: " + _0x9003ba;
  _0x992819.style.fontWeight = "bold";
  _0x992819.style.marginBottom = "8px";
  _0x992819.style.color = "#007bff";
  const _0x16db56 = document.createElement('div');
  _0x16db56.innerHTML = _0x26a498;
  _0x16db56.style.marginBottom = "20px";
  _0x16db56.style.color = '#333';
  const _0xf87e7b = document.createElement('a');
  _0xf87e7b.href = "https://shahidtatkal.github.io";
  _0xf87e7b.textContent = "Update Now";
  _0xf87e7b.target = "_blank";
  _0xf87e7b.style.backgroundColor = "#007bff";
  _0xf87e7b.style.color = "#fff";
  _0xf87e7b.style.padding = "10px 20px";
  _0xf87e7b.style.borderRadius = "4px";
  _0xf87e7b.style.textDecoration = "none";
  _0xf87e7b.style.fontWeight = 'bold';
  _0x178269.appendChild(_0x432ff0);
  _0x178269.appendChild(_0x992819);
  _0x178269.appendChild(_0x16db56);
  _0x178269.appendChild(_0xf87e7b);
  _0x2fe554.appendChild(_0x178269);
  document.body.appendChild(_0x2fe554);
}
document.getElementById("openPopupTab").addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL('popup.html')
  });
});
(function () {
  const _0x4c3ae8 = setInterval(() => {
    const _0x164c0a = document.getElementById("clearCheckbox");
    const _0x15ee1b = document.getElementById("irctc-login");
    const _0x19a262 = document.getElementById("irctc-password");
    if (!_0x164c0a || !_0x15ee1b || !_0x19a262) {
      return;
    }
    clearInterval(_0x4c3ae8);
    const _0x5a087f = localStorage.getItem("irctcClearCheckbox");
    if (_0x5a087f === "checked") {
      _0x164c0a.checked = true;
      _0x446d1d();
    }
    _0x164c0a.addEventListener("change", function () {
      if (_0x164c0a.checked) {
        _0x446d1d();
        localStorage.setItem('irctcClearCheckbox', "checked");
      } else {
        _0x15ee1b.disabled = false;
        _0x19a262.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x446d1d() {
      _0x218af7(_0x15ee1b);
      _0x218af7(_0x19a262);
      _0x15ee1b.disabled = true;
      _0x19a262.disabled = true;
    }
    function _0x218af7(_0x18b612) {
      _0x18b612.value = '';
      _0x18b612.dispatchEvent(new Event('input', {
        'bubbles': true
      }));
      _0x18b612.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(['plan_expiry'], _0x56968b => {
    const _0x25d423 = document.getElementById("UserPlanExpairy");
    if (_0x25d423 && _0x56968b.plan_expiry !== undefined) {
      if (_0x56968b.plan_expiry) {
        _0x25d423.textContent = _0x56968b.plan_expiry;
        const _0x26069d = new Date(_0x56968b.plan_expiry);
        const _0x379e86 = new Date();
        _0x25d423.style.color = _0x379e86 <= _0x26069d ? "green" : 'red';
      } else {
        _0x25d423.textContent = "User Not Found";
        _0x25d423.style.color = "orange";
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x4e158b = document.getElementById('submitBtn2autoClickCheckbox');
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x2cb2b4) {
    _0x4e158b.checked = _0x2cb2b4.submitBtn2autoClickEnabled || false;
  });
  _0x4e158b.addEventListener("change", function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x4e158b.checked
    }, function () {
      console.log("Setting saved:", _0x4e158b.checked);
    });
  });
});
document.addEventListener("DOMContentLoaded", function () {
  var _0x10ad90 = document.getElementById("cardexpiry");
  if (_0x10ad90) {
    _0x10ad90.addEventListener("input", function (_0x5d5578) {
      var _0x42fb0d = _0x5d5578.target.value.replace(/\D/g, '');
      if (_0x42fb0d.length > 0x4) {
        _0x42fb0d = _0x42fb0d.slice(0x0, 0x4);
      }
      if (_0x42fb0d.length >= 0x3) {
        _0x42fb0d = _0x42fb0d.slice(0x0, 0x2) + '/' + _0x42fb0d.slice(0x2);
      }
      _0x5d5578.target.value = _0x42fb0d;
    });
  }
});
async function loadNotice() {
  try {
    const _0x3808e9 = await chrome.storage.local.get("licencekey");
    if (Object.keys(_0x3808e9).length > 0x0) {
      document.querySelector("#subscriber-key").value = _0x3808e9.licencekey;
    }
    setTimeout(function () {
      document.querySelector("#versionContainer").innerHTML = "1.6.6";
      const _0x40213c = document.getElementById("notice-container");
      if ("03 JUNE 2025  09:10 PM  -  PAYU UPI GATEWAY ADDED" && "03 JUNE 2025  09:10 PM  -  PAYU UPI GATEWAY ADDED".trim() !== '' && _0x40213c != null) {
        _0x40213c.innerHTML = "03 JUNE 2025  09:10 PM  -  PAYU UPI GATEWAY ADDED";
        _0x40213c.style.display = "block";
      } else {
        _0x40213c.innerHTML = '';
        _0x40213c.style.display = "none";
      }
    }, 0x1f4);
  } catch (_0x24820f) {
    console.error("Failed to fetch notice:", _0x24820f);
  }
}
loadNotice();