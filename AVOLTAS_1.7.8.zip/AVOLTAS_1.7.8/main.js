const currentVersion = 'Version 1.7.8',
  updateLink =
    'https://bmw-help.blogspot.com/2025/05/ocean-tatkal-autofill-news.html'
function compareVersions(_0x419fd2, _0x137207) {
  const _0x354925 = _0x419fd2
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x3f3859 = _0x137207
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x3be003 = Math.max(_0x354925.length, _0x3f3859.length)
  for (let _0x25b84a = 0; _0x25b84a < _0x3be003; _0x25b84a++) {
    const _0x4dde3a = _0x354925[_0x25b84a] || 0,
      _0x274c7b = _0x3f3859[_0x25b84a] || 0
    if (_0x4dde3a > _0x274c7b) {
      return 1
    }
    if (_0x4dde3a < _0x274c7b) {
      return -1
    }
  }
  return 0
}
function showUpdatePopup(_0x593321, _0x59f35d) {
  const _0xe93f39 = document.createElement('div')
  _0xe93f39.style.position = 'fixed'
  _0xe93f39.style.top = '0'
  _0xe93f39.style.left = '0'
  _0xe93f39.style.width = '100%'
  _0xe93f39.style.height = '100%'
  _0xe93f39.style.backgroundColor = 'rgba(0, 0, 0, 0.6)'
  _0xe93f39.style.zIndex = '9999'
  _0xe93f39.style.display = 'flex'
  _0xe93f39.style.justifyContent = 'center'
  _0xe93f39.style.alignItems = 'center'
  const _0x49eb77 = document.createElement('div')
  _0x49eb77.style.backgroundColor = '#fff'
  _0x49eb77.style.padding = '25px'
  _0x49eb77.style.borderRadius = '10px'
  _0x49eb77.style.boxShadow = '0 5px 25px rgba(0,0,0,0.2)'
  _0x49eb77.style.textAlign = 'center'
  _0x49eb77.style.maxWidth = '400px'
  _0x49eb77.style.width = '90%'
  const _0x2892ac = document.createElement('h2')
  _0x2892ac.textContent = 'Update Available'
  _0x2892ac.style.margin = '0 0 10px 0'
  const _0x4b8c89 = document.createElement('p')
  _0x4b8c89.textContent = 'A new version (' + _0x59f35d + ') is available.'
  _0x4b8c89.style.fontWeight = 'normal'
  _0x4b8c89.style.margin = '0 0 8px 0'
  _0x4b8c89.style.color = '#555'
  const _0x2ccbeb = document.createElement('div')
  _0x2ccbeb.innerHTML = _0x593321
  _0x2ccbeb.style.marginBottom = '25px'
  _0x2ccbeb.style.color = '#333'
  const _0x2f183a = document.createElement('div')
  _0x2f183a.style.display = 'flex'
  _0x2f183a.style.justifyContent = 'center'
  _0x2f183a.style.gap = '15px'
  const _0x468171 = document.createElement('a')
  _0x468171.href = updateLink
  _0x468171.textContent = 'Update Now'
  _0x468171.target = '_blank'
  _0x468171.style.backgroundColor = '#007bff'
  _0x468171.style.color = '#fff'
  _0x468171.style.padding = '10px 25px'
  _0x468171.style.borderRadius = '5px'
  _0x468171.style.textDecoration = 'none'
  _0x468171.style.fontWeight = 'bold'
  const _0x172e1f = document.createElement('button')
  _0x172e1f.textContent = 'Later'
  _0x172e1f.style.backgroundColor = '#6c757d'
  _0x172e1f.style.color = '#fff'
  _0x172e1f.style.padding = '10px 25px'
  _0x172e1f.style.borderRadius = '5px'
  _0x172e1f.style.border = 'none'
  _0x172e1f.style.fontWeight = 'bold'
  _0x172e1f.style.cursor = 'pointer'
  _0x172e1f.addEventListener('click', () => {
    _0xe93f39.remove()
  })
  _0x2f183a.appendChild(_0x172e1f)
  _0x2f183a.appendChild(_0x468171)
  _0x49eb77.appendChild(_0x2892ac)
  _0x49eb77.appendChild(_0x4b8c89)
  _0x49eb77.appendChild(_0x2ccbeb)
  _0x49eb77.appendChild(_0x2f183a)
  _0xe93f39.appendChild(_0x49eb77)
  document.body.appendChild(_0xe93f39)
}
async function checkRemoteConfig() {
  try {
    const _0x412cac = 'https://subtle-kelpie-7b056b.netlify.app/config.json',
      _0x3ad9e9 = await fetch(_0x412cac, { cache: 'no-store' })
    if (!_0x3ad9e9.ok) {
      throw new Error('HTTP error! status: ' + _0x3ad9e9.status)
    }
    const _0x10c686 = await _0x3ad9e9.json()
    compareVersions(currentVersion, _0x10c686.latestVersion) === -1 &&
      showUpdatePopup(_0x10c686.updateMessage, _0x10c686.latestVersion)
    const _0x1c9d4b = document.getElementById('notice-container')
    _0x10c686.notice &&
      _0x1c9d4b &&
      ((_0x1c9d4b.innerHTML = _0x10c686.notice),
      (_0x1c9d4b.style.display = 'block'))
    const _0x350044 = document.getElementById('versionContainer')
    if (_0x350044) {
      _0x350044.innerHTML = currentVersion
    }
  } catch (_0x172409) {
    console.error('Failed to fetch remote config:', _0x172409)
  }
}
document.getElementById('openPopupTab').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') })
})
;(function () {
  const _0x293cef = setInterval(() => {
    const _0x231aa4 = document.getElementById('clearCheckbox'),
      _0x1606d7 = document.getElementById('irctc-login'),
      _0x4ab547 = document.getElementById('irctc-password')
    if (!_0x231aa4 || !_0x1606d7 || !_0x4ab547) {
      return
    }
    clearInterval(_0x293cef)
    const _0x124423 = localStorage.getItem('irctcClearCheckbox')
    _0x124423 === 'checked' && ((_0x231aa4.checked = true), _0x235ec4())
    _0x231aa4.addEventListener('change', function () {
      _0x231aa4.checked
        ? (_0x235ec4(), localStorage.setItem('irctcClearCheckbox', 'checked'))
        : ((_0x1606d7.disabled = false),
          (_0x4ab547.disabled = false),
          localStorage.setItem('irctcClearCheckbox', 'unchecked'))
    })
    function _0x235ec4() {
      _0xeb9a08(_0x1606d7)
      _0xeb9a08(_0x4ab547)
      _0x1606d7.disabled = true
      _0x4ab547.disabled = true
    }
    function _0xeb9a08(_0x468ff0) {
      _0x468ff0.value = ''
      _0x468ff0.dispatchEvent(new Event('input', { bubbles: true }))
      _0x468ff0.dispatchEvent(new Event('change', { bubbles: true }))
    }
  }, 300)
})()
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const _0x463d70 = await chrome.storage.local.get('licencekey')
    if (_0x463d70 && _0x463d70.licencekey) {
      const _0x28dc57 = document.querySelector('#subscriber-key')
      if (_0x28dc57) {
        _0x28dc57.value = _0x463d70.licencekey
      }
    }
  } catch (_0x4d6ace) {
    console.error('Could not load license key', _0x4d6ace)
  }
  chrome.storage.local.get(['plan_expiry'], (_0x396c08) => {
    const _0x5b78bb = document.getElementById('UserPlanExpairy')
    if (_0x5b78bb && _0x396c08.plan_expiry !== undefined) {
      if (_0x396c08.plan_expiry) {
        _0x5b78bb.textContent = _0x396c08.plan_expiry
        const _0x2bf28e = new Date(_0x396c08.plan_expiry),
          _0x13d000 = new Date()
        _0x5b78bb.style.color = _0x13d000 <= _0x2bf28e ? 'green' : 'red'
      } else {
        _0x5b78bb.textContent = 'User Not Found'
        _0x5b78bb.style.color = 'orange'
      }
    }
  })
  const _0x49697e = document.getElementById('submitBtn2autoClickCheckbox')
  _0x49697e &&
    (chrome.storage.sync.get(
      ['submitBtn2autoClickEnabled'],
      function (_0x53b813) {
        _0x49697e.checked = _0x53b813.submitBtn2autoClickEnabled || false
      }
    ),
    _0x49697e.addEventListener('change', function () {
      chrome.storage.sync.set({ submitBtn2autoClickEnabled: _0x49697e.checked })
    }))
  const _0x31bab7 = document.getElementById('cardexpiry')
  _0x31bab7 &&
    _0x31bab7.addEventListener('input', function (_0x274219) {
      let _0x537d45 = _0x274219.target.value.replace(/\D/g, '')
      if (_0x537d45.length > 4) {
        _0x537d45 = _0x537d45.slice(0, 4)
      }
      if (_0x537d45.length >= 3) {
        _0x537d45 = _0x537d45.slice(0, 2) + '/' + _0x537d45.slice(2)
      }
      _0x274219.target.value = _0x537d45
    })
})
