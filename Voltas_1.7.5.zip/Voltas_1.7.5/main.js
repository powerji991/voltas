function compareVersions(_0x2f2430, _0x5576d5) {
  const _0x5eda55 = _0x2f2430.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x6ec0b7 = _0x5576d5.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x5c8ad4 = Math.max(_0x5eda55.length, _0x6ec0b7.length);
  for (let _0x3300fc = 0x0; _0x3300fc < _0x5c8ad4; _0x3300fc++) {
    const _0x50675a = _0x5eda55[_0x3300fc] || 0x0;
    const _0x25646c = _0x6ec0b7[_0x3300fc] || 0x0;
    if (_0x50675a > _0x25646c) {
      return 0x1;
    }
    if (_0x50675a < _0x25646c) {
      return -0x1;
    }
  }
  return 0x0;
}
function showUpdatePopup(_0x48f987, _0xad3e35) {
  const _0x4d4f10 = document.createElement("div");
  _0x4d4f10.style.position = "fixed";
  _0x4d4f10.style.top = '0';
  _0x4d4f10.style.left = '0';
  _0x4d4f10.style.width = '100%';
  _0x4d4f10.style.height = "100%";
  _0x4d4f10.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x4d4f10.style.zIndex = "9999";
  _0x4d4f10.style.display = "flex";
  _0x4d4f10.style.justifyContent = "center";
  _0x4d4f10.style.alignItems = "center";
  const _0x50fd10 = document.createElement("div");
  _0x50fd10.style.backgroundColor = '#fff';
  _0x50fd10.style.padding = "20px";
  _0x50fd10.style.borderRadius = "8px";
  _0x50fd10.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x50fd10.style.textAlign = "center";
  _0x50fd10.style.maxWidth = "400px";
  _0x50fd10.style.width = "90%";
  const _0x23a3fd = document.createElement('h2');
  _0x23a3fd.textContent = "Please update this extension";
  _0x23a3fd.style.margin = "0px";
  const _0x28ed21 = document.createElement('p');
  _0x28ed21.textContent = "Latest Version: " + _0xad3e35;
  _0x28ed21.style.fontWeight = "bold";
  _0x28ed21.style.marginBottom = "8px";
  _0x28ed21.style.color = "#007bff";
  const _0xfdbbcf = document.createElement("div");
  _0xfdbbcf.innerHTML = _0x48f987;
  _0xfdbbcf.style.marginBottom = "20px";
  _0xfdbbcf.style.color = "#333";
  const _0x257360 = document.createElement('a');
  _0x257360.href = "https://shahidtatkal.github.io";
  _0x257360.textContent = "Update Now";
  _0x257360.target = "_blank";
  _0x257360.style.backgroundColor = '#007bff';
  _0x257360.style.color = '#fff';
  _0x257360.style.padding = "10px 20px";
  _0x257360.style.borderRadius = "4px";
  _0x257360.style.textDecoration = "none";
  _0x257360.style.fontWeight = "bold";
  _0x50fd10.appendChild(_0x23a3fd);
  _0x50fd10.appendChild(_0x28ed21);
  _0x50fd10.appendChild(_0xfdbbcf);
  _0x50fd10.appendChild(_0x257360);
  _0x4d4f10.appendChild(_0x50fd10);
  document.body.appendChild(_0x4d4f10);
}
document.getElementById("openPopupTab").addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0x28fa57 = setInterval(() => {
    const _0x1f470f = document.getElementById("clearCheckbox");
    const _0x553ec0 = document.getElementById("irctc-login");
    const _0x3c531c = document.getElementById('irctc-password');
    if (!_0x1f470f || !_0x553ec0 || !_0x3c531c) {
      return;
    }
    clearInterval(_0x28fa57);
    const _0x25138f = localStorage.getItem("irctcClearCheckbox");
    if (_0x25138f === "checked") {
      _0x1f470f.checked = true;
      _0x47f10d();
    }
    _0x1f470f.addEventListener('change', function () {
      if (_0x1f470f.checked) {
        _0x47f10d();
        localStorage.setItem("irctcClearCheckbox", 'checked');
      } else {
        _0x553ec0.disabled = false;
        _0x3c531c.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x47f10d() {
      _0x4d4677(_0x553ec0);
      _0x4d4677(_0x3c531c);
      _0x553ec0.disabled = true;
      _0x3c531c.disabled = true;
    }
    function _0x4d4677(_0x6eab31) {
      _0x6eab31.value = '';
      _0x6eab31.dispatchEvent(new Event("input", {
        'bubbles': true
      }));
      _0x6eab31.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(["plan_expiry"], _0x367761 => {
    const _0x8f8096 = document.getElementById("UserPlanExpairy");
    if (_0x8f8096 && _0x367761.plan_expiry !== undefined) {
      if (_0x367761.plan_expiry) {
        _0x8f8096.textContent = _0x367761.plan_expiry;
        const _0x3ebf30 = new Date(_0x367761.plan_expiry);
        const _0x48b68c = new Date();
        _0x8f8096.style.color = _0x48b68c <= _0x3ebf30 ? "green" : "red";
      } else {
        _0x8f8096.textContent = "User Not Found";
        _0x8f8096.style.color = "orange";
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x141d64 = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x62c69) {
    _0x141d64.checked = _0x62c69.submitBtn2autoClickEnabled || false;
  });
  _0x141d64.addEventListener('change', function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x141d64.checked
    }, function () {
      console.log("Setting saved:", _0x141d64.checked);
    });
  });
});
document.addEventListener("DOMContentLoaded", function () {
  var _0x1d2328 = document.getElementById("cardexpiry");
  if (_0x1d2328) {
    _0x1d2328.addEventListener('input', function (_0x5d28f4) {
      var _0x411d26 = _0x5d28f4.target.value.replace(/\D/g, '');
      if (_0x411d26.length > 0x4) {
        _0x411d26 = _0x411d26.slice(0x0, 0x4);
      }
      if (_0x411d26.length >= 0x3) {
        _0x411d26 = _0x411d26.slice(0x0, 0x2) + '/' + _0x411d26.slice(0x2);
      }
      _0x5d28f4.target.value = _0x411d26;
    });
  }
});
async function loadNotice() {
  try {
    const _0x4e4ac4 = await chrome.storage.local.get('licencekey');
    if (Object.keys(_0x4e4ac4).length > 0x0) {
      document.querySelector("#subscriber-key").value = _0x4e4ac4.licencekey;
    }
    setTimeout(function () {
      document.querySelector("#versionContainer").innerHTML = "1.7.5";
      const _0x4e8531 = document.getElementById('notice-container');
      if ("11 JUNE 2025  ALL  FIXED DONE - WORKING BANK = HDFC CARD (Bypassed),IPAY DC,Irctc QR,Irctc UPI ID,Paytm QR,Paytm UPI ID,PayU UPI ID,Amazon Pay Wallet" && "10 JUNE 2025  ALL  FIXED DONE - WORKING BANK = HDFC CARD (Bypassed),IPAY DC,Irctc QR,Irctc UPI ID,Paytm QR,Paytm UPI ID,PayU UPI ID,Amazon Pay Wallet".trim() !== '' && _0x4e8531 != null) {
        _0x4e8531.innerHTML = "11 JUNE 2025  ALL  FIXED DONE - WORKING BANK = HDFC CARD (Bypassed),IPAY DC,Irctc QR,Irctc UPI ID,Paytm QR,Paytm UPI ID,PayU UPI ID,Amazon Pay Wallet";
        _0x4e8531.style.display = "block";
      } else {
        _0x4e8531.innerHTML = '';
        _0x4e8531.style.display = "none";
      }
    }, 0x1f4);
  } catch (_0x4b3408) {
    console.error("Failed to fetch notice:", _0x4b3408);
  }
}
loadNotice();