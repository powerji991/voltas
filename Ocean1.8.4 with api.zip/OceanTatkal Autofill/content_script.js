const _0x420204 = (function () {
  let _0x5925d6 = true
  return function (_0x1f3347, _0x563e82) {
    const _0x218e75 = _0x5925d6
      ? function () {
          if (_0x563e82) {
            const _0x316bf2 = _0x563e82.apply(_0x1f3347, arguments)
            return (_0x563e82 = null), _0x316bf2
          }
        }
      : function () {}
    return (_0x5925d6 = false), _0x218e75
  }
})()
;(function () {
  _0x420204(this, function () {
    const _0x388311 = new RegExp('function *\\( *\\)'),
      _0xe8229b = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
      _0x5e7ec1 = _0x1e30e8('init')
    if (
      !_0x388311.test(_0x5e7ec1 + 'chain') ||
      !_0xe8229b.test(_0x5e7ec1 + 'input')
    ) {
      _0x5e7ec1('0')
    } else {
      _0x1e30e8()
    }
  })()
})()
let _0x577b97 = null
function _0x33e28e() {
  if (_0x577b97) {
    console.log('Keep-Alive पिंग पहले से ही एक्टिव है\u0964')
    return
  }
  console.log(
    'Keep-Alive पिंग शुरू\u0964 हर 30 सेकंड में सेशन को ताज़ा किया जाएगा\u0964'
  )
  _0x577b97 = setInterval(() => {
    fetch('https://www.irctc.co.in/nget/api/login/getUserDetails')
      .then((_0x2f1235) => {
        if (_0x2f1235.ok) {
          console.log(
            'Keep-alive पिंग सफल रहा at',
            new Date().toLocaleTimeString()
          )
        } else {
          console.warn(
            'Keep-alive पिंग का रिस्पांस ठीक नहीं था, शायद लॉगआउट हो गया है\u0964 पिंग रोका जा रहा है\u0964'
          )
          clearInterval(_0x577b97)
        }
      })
      .catch((_0x331bfa) => {
        console.error('Keep-alive पिंग फेल हो गया:', _0x331bfa)
        clearInterval(_0x577b97)
      })
  }, 30000)
}
const _0x1f206b = setInterval(() => {
  const _0x38b9f7 = document.querySelector(
    'button.btn.btn-primary[aria-label*="Press OK to confirm"]'
  )
  _0x38b9f7 &&
    (console.log('OCEAN: Initial confirmation pop-up found. Clicking OK.'),
    _0x38b9f7.click(),
    clearInterval(_0x1f206b))
}, 500)
;(function () {
  let _0x5c83a9
  try {
    const _0xbf6bf2 = Function(
      'return (function() {}.constructor("return this")( ));'
    )
    _0x5c83a9 = _0xbf6bf2()
  } catch (_0x393f5f) {
    _0x5c83a9 = window
  }
  _0x5c83a9.setInterval(_0x1e30e8, 4000)
})()
function _0x5c4a77() {
  setInterval(() => {
    const _0xf062c2 = new Date(),
      _0x101193 = String(_0xf062c2.getHours()).padStart(2, '0'),
      _0x378155 = String(_0xf062c2.getMinutes()).padStart(2, '0'),
      _0x4e0805 = String(_0xf062c2.getSeconds()).padStart(2, '0'),
      _0x355a63 = String(_0xf062c2.getMilliseconds()).padStart(3, '0'),
      _0x5223ae =
        _0x101193 + ':' + _0x378155 + ':' + _0x4e0805 + ':' + _0x355a63
    document.dispatchEvent(
      new CustomEvent('ocean-time-update', {
        detail: { timeString: _0x5223ae },
      })
    )
  }, 100)
  console.log(
    'OCEAN: सिस्टम समय प्रोवाइडर (मिलीसेकंड के साथ) शुरू हो गया है\u0964'
  )
}
function _0x5d6a8e(_0x2f2ea8, _0x11b11e = 4000) {
  const _0x438362 = document.getElementById('ocean-fallback-notification')
  if (_0x438362) {
    _0x438362.remove()
  }
  const _0x5ba180 = document.createElement('div')
  _0x5ba180.id = 'ocean-fallback-notification'
  _0x5ba180.textContent = '[OCEAN]: ' + _0x2f2ea8
  Object.assign(_0x5ba180.style, {
    position: 'fixed',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: 'rgba(217, 30, 24, 0.9)',
    color: 'white',
    padding: '12px 25px',
    borderRadius: '8px',
    zIndex: '99999',
    fontSize: '16px',
    fontWeight: 'bold',
    boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
  })
  document.body.appendChild(_0x5ba180)
  setTimeout(() => {
    const _0xd60e23 = document.getElementById('ocean-fallback-notification')
    _0xd60e23 && _0xd60e23.remove()
  }, _0x11b11e)
}
function _0x1ac297() {
  if (document.getElementById('ocean-animation-script')) {
    console.log('OCEAN: Animation assets already present.')
    return
  }
  console.log('OCEAN: Injecting animation assets...')
  const _0x3543b1 = document.createElement('link')
  _0x3543b1.id = 'ocean-animation-style'
  _0x3543b1.rel = 'stylesheet'
  _0x3543b1.type = 'text/css'
  _0x3543b1.href = chrome.runtime.getURL('animation.css')
  document.head.appendChild(_0x3543b1)
  const _0x3d38b2 = document.createElement('script')
  _0x3d38b2.id = 'ocean-animation-script'
  _0x3d38b2.src = chrome.runtime.getURL('animation.js')
  ;(document.head || document.documentElement).appendChild(_0x3d38b2)
  _0x3d38b2.onload = () => {
    console.log('OCEAN: animation.js loaded successfully.')
    _0x3d38b2.remove()
  }
  _0x3d38b2.onerror = () => {
    console.error('OCEAN: Failed to load animation.js.')
  }
}
function _0x502936(_0x1876ae) {
  const _0x33bced = window.location.href
  let _0x2733d6 = 'loadLoginDetails'
  if (_0x33bced.includes('booking/psgninput')) {
    _0x2733d6 = 'fillPassengerDetails'
  } else {
    if (_0x33bced.includes('booking/reviewBooking')) {
      _0x2733d6 = 'reviewBooking'
    } else {
      if (_0x33bced.includes('payment/bkgPaymentOptions')) {
        _0x2733d6 = 'bkgPaymentOptions'
      } else {
        if (_0x33bced.includes('booking/train-list')) {
          _0x2733d6 = 'selectJourney'
        } else {
          if (_0x33bced.includes('nget/train-search')) {
            const _0x2b90c9 = document.querySelector(
              'a.loginText.ng-star-inserted'
            )
            if (
              _0x2b90c9 &&
              _0x2b90c9.innerText.trim().toUpperCase() === 'LOGOUT'
            ) {
              _0x2733d6 = 'loadJourneyDetails'
            }
          }
        }
      }
    }
  }
  const _0x1745ef = _0x1876ae.journey_details || {}
  _0x1876ae.irctc_credentials &&
    _0x1876ae.irctc_credentials.user_name &&
    (_0x1745ef.username = _0x1876ae.irctc_credentials.user_name)
  const _0x4d141d = {
    journeyDetails: _0x1745ef,
    initialStatus: _0x2733d6,
  }
  console.log("OCEAN: Dispatching 'ocean-init-data' with payload:", _0x4d141d)
  setTimeout(() => {
    document.dispatchEvent(
      new CustomEvent('ocean-init-data', { detail: _0x4d141d })
    )
  }, 500)
}
function _0x31f2b4(_0x36a7ec) {
  const _0x5d8e64 = {
    status: _0x36a7ec,
    time: new Date().toString().split(' ')[4],
  }
  chrome.runtime.sendMessage(_0x315f90(_0x5d8e64, 'status_update'))
  console.log(
    "OCEAN: Dispatching 'ocean-status-update' for [" + _0x36a7ec + ']'
  )
  const _0x363aec = _0x539928.journey_details || {}
  if (_0x539928.irctc_credentials && _0x539928.irctc_credentials.user_name) {
    _0x363aec.username = _0x539928.irctc_credentials.user_name
  }
  const _0x4604d9 = {
    statusKey: _0x36a7ec,
    journeyDetails: _0x363aec,
  }
  document.dispatchEvent(
    new CustomEvent('ocean-status-update', { detail: _0x4604d9 })
  )
}
function _0x2bde74(_0x3e5372, _0x160029) {
  if (!_0x3e5372 || typeof _0x160029 !== 'string') {
    console.warn('Element not provided or text is not a string for fastFill.')
    return
  }
  _0x3e5372.focus()
  _0x3e5372.value = _0x160029
  _0x3e5372.dispatchEvent(
    new Event('input', {
      bubbles: true,
      cancelable: true,
    })
  )
  _0x3e5372.dispatchEvent(
    new Event('change', {
      bubbles: true,
      cancelable: true,
    })
  )
  _0x3e5372.blur()
}
function _0x28ed05(_0xd2e499) {
  if (_0xd2e499 && typeof _0xd2e499.click === 'function') {
    if (_0xd2e499.disabled) {
      console.warn('Attempted to click on a disabled element:', _0xd2e499)
      return
    }
    _0xd2e499.click()
  } else {
    console.warn('Attempted to click on an invalid element:', _0xd2e499)
  }
}
function _0x5590db(_0x42e1a7) {
  const _0x59df50 = Date.now()
  let _0x1efd66 = null
  do {
    _0x1efd66 = Date.now()
  } while (_0x1efd66 - _0x59df50 < _0x42e1a7)
}
function _0x2c145b(_0x55b68b) {
  const _0x1dd488 = document.createElement('div')
  _0x1dd488.id = 'custom-alert'
  _0x1dd488.style.cssText =
    "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 300px;\n    "
  _0x1dd488.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x55b68b +
    '</p>\n        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>\n    '
  document.body.appendChild(_0x1dd488)
  document.getElementById('custom-alert-ok').onclick = () => _0x1dd488.remove()
}
function _0x3e9a77(_0x1aabb9, _0x4c2e83, _0x3ee3a0) {
  const _0x7b3816 = document.createElement('div')
  _0x7b3816.id = 'custom-confirm'
  _0x7b3816.style.cssText =
    "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 350px;\n    "
  _0x7b3816.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x1aabb9 +
    '</p>\n        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>\n        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>\n    '
  document.body.appendChild(_0x7b3816)
  document.getElementById('custom-confirm-yes').onclick = () => {
    _0x7b3816.remove()
    if (_0x4c2e83) {
      _0x4c2e83()
    }
  }
  document.getElementById('custom-confirm-no').onclick = () => {
    _0x7b3816.remove()
    if (_0x3ee3a0) {
      _0x3ee3a0()
    }
  }
}
const _0xb50941 = (_0x607207) => {
  return (
    _0x607207 &&
    getComputedStyle(_0x607207).display !== 'none' &&
    getComputedStyle(_0x607207).visibility !== 'hidden' &&
    parseFloat(getComputedStyle(_0x607207).opacity) > 0 &&
    !_0x607207.disabled
  )
}
let _0x539928 = {}
function _0x315f90(_0x32a1ab, _0x2c213b) {
  return {
    msg: {
      type: _0x2c213b,
      data: _0x32a1ab,
    },
    sender: 'content_script',
    id: 'irctc',
  }
}
function _0x59a50e(_0xa0c690) {
  return '1A' === _0xa0c690
    ? 'AC First Class (1A)'
    : 'EV' === _0xa0c690
    ? 'Vistadome AC (EV)'
    : 'EC' === _0xa0c690
    ? 'Exec. Chair Car (EC)'
    : '2A' === _0xa0c690
    ? 'AC 2 Tier (2A)'
    : '3A' === _0xa0c690
    ? 'AC 3 Tier (3A)'
    : '3E' === _0xa0c690
    ? 'AC 3 Economy (3E)'
    : 'CC' === _0xa0c690
    ? 'AC Chair car (CC)'
    : 'SL' === _0xa0c690
    ? 'Sleeper (SL)'
    : '2S' === _0xa0c690
    ? 'Second Sitting (2S)'
    : 'None'
}
function _0x335d32(_0x3c9556) {
  return 'GN' === _0x3c9556
    ? 'GENERAL'
    : 'TQ' === _0x3c9556
    ? 'TATKAL'
    : 'PT' === _0x3c9556
    ? 'PREMIUM TATKAL'
    : 'LD' === _0x3c9556
    ? 'LADIES'
    : 'SR' === _0x3c9556
    ? 'LOWER BERTH/SR.CITIZEN'
    : ''
}
console.log('[Ocean Log] Step 1: content_script.js loaded successfully.')
let _0x2582c4 = false
function _0x43034d() {
  if (_0x2582c4) {
    console.log('[Ocean Log] Step 4a: Animation has already run. Skipping.')
    return
  }
  console.log(
    "[Ocean Log] Step 4: Starting to check for BOTH 'PNR' and 'CNF' text on the page..."
  )
  const _0x449d63 = setInterval(() => {
    if (_0x2582c4) {
      clearInterval(_0x449d63)
      return
    }
    let _0x37e5ea = false,
      _0x5a20b4 = false
    const _0x35d0ba = document.querySelectorAll('span, strong, div, p, a')
    for (const _0x58adfa of _0x35d0ba) {
      if (_0x58adfa.classList.contains('ocean-ignore')) {
        continue
      }
      if (_0x58adfa.offsetParent !== null && _0x58adfa.textContent) {
        const _0x5bed4a = _0x58adfa.textContent.toUpperCase()
        if (_0x5bed4a.includes('PNR')) {
          _0x37e5ea = true
        }
        if (_0x5bed4a.includes('CNF')) {
          _0x5a20b4 = true
        }
      }
    }
    _0x37e5ea &&
      _0x5a20b4 &&
      (console.log(
        '[Ocean Log] Step 5: Success condition met! BOTH elements found.'
      ),
      clearInterval(_0x449d63),
      (_0x2582c4 = true),
      _0x5a438a())
  }, 700)
}
async function _0x5a438a() {
  console.log('[Ocean Log] Step 6: showPnrAnimation() function called.')
  try {
    console.log(
      '[Ocean Log] Step 6.1: Attempting to get data from chrome.storage.'
    )
    const _0x4dc056 = await chrome.storage.local.get([
        'journey_details',
        'other_preferences',
      ]),
      _0x430a14 = _0x4dc056.journey_details || {},
      _0x204774 = _0x4dc056.other_preferences || {}
    console.log(
      '[Ocean Log] Step 6.2: Journey details from storage:',
      _0x430a14
    )
    console.log(
      '[Ocean Log] Step 6.2a: Other preferences from storage:',
      _0x204774
    )
    const _0x366c3f = new Date()
    _0x366c3f.setSeconds(_0x366c3f.getSeconds() - 15)
    const _0x1931e8 = _0x366c3f.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }),
      _0x42b98e = _0x430a14.from ? _0x430a14.from.split('-') : [],
      _0xcad3f = _0x430a14.destination ? _0x430a14.destination.split('-') : [],
      _0x26a717 = _0x430a14.date ? _0x430a14.date.split('-') : [],
      _0x2b71e1 =
        _0x42b98e.length > 1 ? _0x42b98e[1].trim() : _0x430a14.from || '',
      _0x2fdc6d =
        _0xcad3f.length > 1 ? _0xcad3f[1].trim() : _0x430a14.destination || '',
      _0x507242 =
        _0x26a717.length === 3
          ? _0x26a717[2] + '-' + _0x26a717[1] + '-' + _0x26a717[0]
          : '',
      _0x2bf0ed = _0x430a14.class || '',
      _0x572a9d = _0x430a14.quota || '',
      _0x5a61c2 = _0x430a14['train-no'] || 'Train N/A',
      _0x1b3b61 = (
        _0x2b71e1 +
        '-' +
        _0x2fdc6d +
        ' ' +
        _0x507242 +
        ' ' +
        _0x2bf0ed +
        ' ' +
        _0x572a9d
      ).trim()
    let _0x4cf0b5 = 'N/A'
    const _0x21bc64 = _0x204774.paymentmethod || ''
    switch (_0x21bc64) {
      case 'PAYTMUPI':
      case 'PAYTMUPIID':
        _0x4cf0b5 = 'Paytm UPI'
        break
      case 'PHONEPEUPIQR':
        _0x4cf0b5 = 'PhonePe QR'
        break
      case 'RAZORPAYUPI':
        _0x4cf0b5 = 'Razorpay UPI'
        break
      case 'PAYUUPI':
        _0x4cf0b5 = 'PayU UPI'
        break
      case 'AMZPAYWAL':
        _0x4cf0b5 = 'Amazon Pay'
        break
      case 'HDFCDB':
        _0x4cf0b5 = 'HDFC DC'
        break
      case 'kotak_dc':
        _0x4cf0b5 = 'KOTAK DC'
        break
      case 'icici_dc':
        _0x4cf0b5 = 'ICICI DC'
        break
      case 'MOBIKWIKWAL':
        _0x4cf0b5 = 'MOBIKWIK'
        break
      case 'SBINETBANKING':
        _0x4cf0b5 = 'SBI_NB'
        break
      case 'HDFCNETBANKING':
        _0x4cf0b5 = 'HDFC_NB'
        break
      case 'IRCWA':
        _0x4cf0b5 = 'IRCTC eWallet'
        break
      case 'irctc_dc':
      case 'IRCUPIID':
      case 'IRCUPIQR':
        _0x4cf0b5 = 'IRCTC iPay'
        break
      default:
        _0x4cf0b5 = _0x21bc64
    }
    console.log('[Ocean Log] Payment method determined as: ' + _0x4cf0b5)
    let _0x5a6749 = 'N/A'
    const _0x542d06 = [
      '.line-def .orange-text strong',
      'span.pull-right.orange-text strong',
      'span.font-bold.pull-right',
      '.fare-summary .amount',
    ]
    for (const _0x4cb8de of _0x542d06) {
      const _0x1c1247 = document.querySelector(_0x4cb8de)
      if (_0x1c1247) {
        const _0x5e4443 = _0x1c1247.innerText.replace(/[^0-9.]/g, '')
        if (_0x5e4443) {
          _0x5a6749 = _0x5e4443
          console.log(
            "[Ocean Log] Fare found with selector '" +
              _0x4cb8de +
              "': " +
              _0x5a6749
          )
          break
        }
      }
    }
    const _0x24a8ed = 'FARE,' + _0x5a6749
    console.log(
      '[Ocean Log] Step 6.3: All data processed. Creating CSS and pop-ups now.'
    )
    const _0x533e86 =
        "\n            .ocean-tatkal-success-message {\n                position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);\n                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); z-index: 99999;\n                border-radius: 12px; overflow: hidden; text-align: center;\n                width: 90%; max-width: 380px; border: 1px solid #ddd;\n                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n                animation: slideUp 0.5s ease-out forwards;\n            }\n            @keyframes slideUp { from { bottom: -100px; opacity: 0; } to { bottom: 20px; opacity: 1; } }\n            .ocean-header { background-color: #005A9C; color: #fff; padding: 12px 15px; font-size: 18px; font-weight: bold; }\n            .ocean-body {\n                background-color: #2E8B57; color: #fff; padding: 20px;\n                font-size: 16px; line-height: 1.8; font-weight: bold;\n            }\n            #ocean-welcome-message {\n                position: fixed; top: 50%; left: 50%;\n                transform: translate(-50%, -50%) scale(0);\n                z-index: 9999999;\n                background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);\n                color: white; padding: 25px 50px; border-radius: 15px;\n                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4); border: 2px solid #5f9ea0;\n                font-family: 'Segoe UI', Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;\n                font-size: 32px; font-weight: bold; text-align: center; white-space: nowrap;\n                animation: finalRollAndStay 8s ease-in-out forwards;\n            }\n            @media (max-width: 600px) {\n                #ocean-welcome-message {\n                    font-size: 22px; padding: 20px 25px; white-space: normal;\n                }\n            }\n            @keyframes finalRollAndStay {\n                0% { opacity: 0; transform: translate(-50%, -50%) scale(2.5); }\n                15% { opacity: 1; transform: translate(-50%, -50%) scale(1); }\n                40% { transform: translate(-50%, -50%) scale(1) rotate(0deg); }\n                50% { transform: translate(-50%, -50%) scale(1.1) rotate(360deg); }\n                65% { transform: translate(-50%, -50%) scale(1.1) rotate(720deg); }\n                75%, 100% {\n                    opacity: 1;\n                    transform: translate(-50%, -50%) scale(1) rotate(1080deg);\n                }\n            }\n        ",
      _0x33b63f = document.createElement('style')
    _0x33b63f.id = 'ocean-tatkal-style-v2'
    _0x33b63f.textContent = _0x533e86
    document.head.appendChild(_0x33b63f)
    const _0x3ac3fa = document.querySelector('.ocean-tatkal-success-message')
    if (_0x3ac3fa) {
      _0x3ac3fa.remove()
    }
    const _0x556cda = document.createElement('div')
    _0x556cda.className = 'ocean-tatkal-success-message ocean-ignore'
    _0x556cda.innerHTML =
      '\n            <div class="ocean-header">\uD83C\uDF0A Success By Ocean \uD83C\uDF0A</div>\n            <div class="ocean-body">\n                <span>' +
      _0x24a8ed +
      '</span><br>\n                <span>PNRTIME: ' +
      _0x1931e8 +
      '</span><br>\n                <span>PAYMENT: ' +
      _0x4cf0b5 +
      '</span><br>\n                <span>' +
      _0x1b3b61 +
      '</span><br>\n                <span>TRAIN: ' +
      _0x5a61c2 +
      '</span>\n            </div>\n        '
    document.body.appendChild(_0x556cda)
    console.log('[Ocean Log] Step 7: Original success message displayed.')
    setTimeout(() => {
      const _0x43fcd8 = document.querySelector('#ocean-welcome-message')
      if (_0x43fcd8) {
        _0x43fcd8.remove()
      }
      const _0x2bab4d = document.createElement('div')
      _0x2bab4d.id = 'ocean-welcome-message'
      _0x2bab4d.className = 'ocean-ignore'
      _0x2bab4d.textContent = 'Thank you for using Ocean Tatkal'
      document.body.appendChild(_0x2bab4d)
      console.log(
        '[Ocean Log] Step 8: Welcome animation started after 1-second delay.'
      )
    }, 1000)
  } catch (_0x3803f1) {
    console.error('[Ocean Log] Critical Error in showPnrAnimation:', _0x3803f1)
  }
}
console.log('[Ocean Log] Step 2: Setting up message listener.')
chrome.runtime.onMessage.addListener((_0x27638b, _0x6656d3, _0x53176d) => {
  const _0x2f0db2 =
    (_0x27638b && _0x27638b.type) ||
    (_0x27638b && _0x27638b.msg && _0x27638b.msg.type)
  if (_0x2f0db2 === 'showPnrAnimation') {
    console.log(
      "[Ocean Log] Step 3: Message 'showPnrAnimation' received. Triggering animation check."
    )
    _0x43034d()
    _0x53176d({ status: 'PNR check initiated.' })
  }
})
chrome.runtime.onMessage.addListener(
  async (_0x5cd8bb, _0x3154a5, _0x2367f7) => {
    if ('irctc' !== _0x5cd8bb.id) {
      return void _0x2367f7('Invalid ID')
    }
    const _0x11ce64 = _0x5cd8bb.msg.type
    if ('selectJourney' === _0x11ce64) {
      console.log('selectJourney action received')
      _0x31f2b4('selectJourney')
      let _0x49531d = document.querySelectorAll('.btn.btn-primary')
      _0x49531d.length > 1 &&
        _0x49531d[1] &&
        (_0x28ed05(_0x49531d[1]), console.log('Close last trxn popup'))
      const _0xb765c = document.querySelector('#divMain > div > app-train-list')
      if (!_0xb765c) {
        console.error('Train list container not found for selectJourney.')
        return
      }
      const _0x168701 = [
          ..._0xb765c.querySelectorAll('.tbis-div app-train-avl-enq'),
        ],
        _0x3933bf = _0x539928.journey_details['train-no']
      if (!_0x3933bf) {
        console.error('Train number missing in user_data for selectJourney.')
        return
      }
      const _0x502fba = _0x168701.find((_0x217c07) =>
        _0x217c07
          .querySelector('div.train-heading')
          ?.innerText.trim()
          .includes(_0x3933bf.split('-')[0])
      )
      if ('M' === _0x539928.travel_preferences.AvailabilityCheck) {
        return void _0x2c145b('Please manually select train and click Book')
      }
      if (
        'A' === _0x539928.travel_preferences.AvailabilityCheck ||
        'I' === _0x539928.travel_preferences.AvailabilityCheck
      ) {
        if (!_0x502fba) {
          return void _0x2c145b(
            'Precheck - Train (' +
              _0x3933bf +
              ') not found. Proceed manually or correct data.'
          )
        }
        const _0x581bbd = _0x59a50e(_0x539928.journey_details.class)
        if (
          ![..._0x502fba.querySelectorAll('table tr td div.pre-avl')].find(
            (_0x1e4212) =>
              _0x1e4212.querySelector('div')?.innerText === _0x581bbd
          )
        ) {
          return void _0x2c145b(
            'Precheck - Selected Class not available. Proceed manually or correct data.'
          )
        }
      }
      const _0x1770c5 = document.querySelector(
        'div.row.col-sm-12.h_head1 > span > strong'
      )
      if ('A' === _0x539928.travel_preferences.AvailabilityCheck) {
        if (['TQ', 'PT', 'GN'].includes(_0x539928.journey_details.quota)) {
          console.log('Verify tatkal/general time')
          const _0x1053d8 = _0x539928.journey_details.class
          let _0x18b807 = '00:00:00'
          if (
            ['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(
              _0x1053d8.toUpperCase()
            )
          ) {
            _0x18b807 = _0x539928.other_preferences.acbooktime
          } else {
            _0x18b807 = _0x539928.other_preferences.slbooktime
          }
          if ('GN' === _0x539928.journey_details.quota) {
            _0x18b807 = _0x539928.other_preferences.gnbooktime
          }
          console.log('Required Booking Time:', _0x18b807)
          var _0x4ee68f = 0
          let _0x4ddd9d = new MutationObserver(() => {
            let _0x2c5dbc = new Date().toString().split(' ')[4]
            console.log('Current Time for booking:', _0x2c5dbc)
            if (_0x2c5dbc >= _0x18b807) {
              _0x4ddd9d.disconnect(), _0x55d2f2()
            } else {
              if (_0x4ee68f === 0) {
                try {
                  const _0x3bc9e8 = document.createElement('div')
                  _0x3bc9e8.textContent =
                    'Please wait... Booking will start at ' + _0x18b807
                  Object.assign(_0x3bc9e8.style, {
                    textAlign: 'center',
                    color: 'white',
                    height: 'auto',
                    fontSize: '20px',
                  })
                  document
                    .querySelector(
                      '#divMain > div > app-train-list > div > div > div > div.clearfix'
                    )
                    ?.insertAdjacentElement('afterend', _0x3bc9e8)
                } catch (_0x2a53b5) {
                  console.log('Wait message display failed', _0x2a53b5)
                }
              }
              try {
                const _0x5ed9ba = document.querySelector(
                  '#divMain > div > app-train-list > div > div > div > div:nth-child(2)'
                )
                if (_0x5ed9ba) {
                  _0x5ed9ba.style.background =
                    _0x4ee68f % 2 === 0 ? 'green' : 'red'
                }
              } catch (_0x3040be) {
                console.log('Wait indicator style failed', _0x3040be)
              }
              _0x4ee68f++
            }
          })
          if (_0x1770c5) {
            _0x4ddd9d.observe(_0x1770c5, {
              childList: true,
              subtree: true,
              characterDataOldValue: true,
            })
          } else {
            console.warn('Header element for time observer not found.')
          }
        } else {
          _0x55d2f2()
        }
      } else {
        'I' === _0x539928.travel_preferences.AvailabilityCheck && _0x55d2f2()
      }
    } else {
      if ('fillPassengerDetails' === _0x11ce64) {
        _0x31f2b4('fillPassengerDetails')
        await _0xa1e3a3()
      } else {
        if ('reviewBooking' === _0x11ce64) {
          _0x31f2b4('reviewBooking')
          if (_0x539928.fare_limit?.enableFareLimit) {
            let _0x48b242 = 0
            const _0x1b9b32 = [
              '#fare-summary .col-xs-12.line-def.top-header span.pull-right strong',
              '.total-fare',
              '#totalAmount',
              '.fare-summary span.amount',
              'span.fare-value',
              '.fare-breakup-summary .fare-amount',
              "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value",
              'div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold',
              'div.fare-breakup-summary div.fare-amount',
              'div.fare-detail-item:nth-child(5) > div:nth-child(2)',
              'div.col-sm-6.text-right.font-small-bold',
            ]
            for (const _0x11eb86 of _0x1b9b32) {
              const _0xc201 = document.querySelector(_0x11eb86)
              if (_0xc201?.innerText.match(/(\d[\d,]*\.?\d*)/)) {
                _0x48b242 = parseFloat(
                  _0xc201.innerText.replace(/[^0-9.]/g, '')
                )
                if (!isNaN(_0x48b242)) {
                  console.log(
                    'Found total fare ' +
                      _0x48b242 +
                      ' using "' +
                      _0x11eb86 +
                      '"'
                  )
                  break
                }
              }
            }
            if (!isNaN(_0x48b242) && _0x48b242 > 0) {
              const _0x3706d2 = parseFloat(_0x539928.fare_limit.maxFareAmount)
              if (!isNaN(_0x3706d2) && _0x48b242 > _0x3706d2) {
                return _0x3e9a77(
                  'Total fare (' +
                    _0x48b242 +
                    ') exceeds limit (' +
                    _0x3706d2 +
                    '). Proceed?',
                  () => _0x83c5e0(),
                  () => {
                    _0x2c145b('Booking cancelled due to high fare.'),
                      (window.location.href =
                        'https://www.irctc.co.in/nget/train-search')
                  }
                )
              }
            } else {
              console.warn('Could not determine total fare for limit check.')
            }
          }
          await _0x83c5e0()
        } else {
          if ('bkgPaymentOptions' === _0x11ce64) {
            const _0x2ebf85 = (_0x13fe5b) => {
                if (!_0x13fe5b) {
                  return false
                }
                const _0x17e90b = window.getComputedStyle(_0x13fe5b)
                return (
                  _0x17e90b.display !== 'none' &&
                  _0x17e90b.visibility !== 'hidden' &&
                  _0x17e90b.opacity !== '0' &&
                  !_0x13fe5b.disabled
                )
              },
              _0x1a306d = (_0xa20c2a) => {
                return new Promise((_0x53ee95) => {
                  const _0x168927 = document.querySelector(_0xa20c2a)
                  if (_0x168927 && _0x2ebf85(_0x168927)) {
                    return (
                      console.log(
                        'तत्व तुरंत मिला और दृश्यमान है: ' + _0xa20c2a
                      ),
                      _0x53ee95(_0x168927)
                    )
                  }
                  let _0x1794ed
                  const _0x4aa5f3 = setTimeout(() => {
                    console.log(
                      '2 सेकंड का टाइमआउट समाप्त\u0964 ' +
                        _0xa20c2a +
                        ' की दृश्यता की परवाह किए बिना क्लिक करने का प्रयास किया जा रहा है\u0964'
                    )
                    _0x1794ed && _0x1794ed.disconnect()
                    const _0x56e6ea = document.querySelector(_0xa20c2a)
                    _0x53ee95(_0x56e6ea)
                  }, 200)
                  _0x1794ed = new MutationObserver(() => {
                    const _0x2df217 = document.querySelector(_0xa20c2a)
                    _0x2df217 &&
                      _0x2ebf85(_0x2df217) &&
                      (console.log(
                        'तत्व DOM में बदलाव के माध्यम से मिला: ' + _0xa20c2a
                      ),
                      clearTimeout(_0x4aa5f3),
                      _0x1794ed.disconnect(),
                      _0x53ee95(_0x2df217))
                  })
                  _0x1794ed.observe(document.body, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                  })
                })
              },
              _0xf4fd84 = (_0x361e41) => {
                _0x361e41 && _0x361e41.click()
              },
              _0x18e574 = async (_0x513d00, _0x1bac1e) => {
                console.log(
                  'जासूस तैनात: ' +
                    _0x513d00 +
                    ' पर क्लिक करने और प्रोसेसिंग का इंतज़ार करने के लिए\u0964'
                )
                const _0x5603a8 = await _0x1a306d(_0x513d00)
                if (!_0x5603a8) {
                  console.error(
                    'त्रुटि: 2 सेकंड के बाद भी तत्व नहीं मिला: ' + _0x513d00
                  )
                  return
                }
                return (
                  _0xf4fd84(_0x5603a8),
                  console.log(
                    'क्लिक किया: ' +
                      _0x513d00 +
                      '\u0964 अब सर्वर प्रोसेसिंग का इंतज़ार...'
                  ),
                  new Promise((_0x46b262) => {
                    let _0x42b918 = false
                    const _0x2fe0f0 = new MutationObserver(() => {
                      const _0x7af17a = document.querySelector(_0x1bac1e),
                        _0x5e51e5 = (_0x39d092) =>
                          _0x39d092 &&
                          window.getComputedStyle(_0x39d092).display !== 'none'
                      if (!_0x42b918 && _0x5e51e5(_0x7af17a)) {
                        console.log('प्रोसेसिंग शुरू! लोडर दिखा\u0964')
                        _0x42b918 = true
                      }
                      _0x42b918 &&
                        !_0x5e51e5(_0x7af17a) &&
                        (console.log('सिग्नल मिला! प्रोसेसिंग पूरी\u0964'),
                        _0x2fe0f0.disconnect(),
                        _0x46b262())
                    })
                    _0x2fe0f0.observe(document.body, {
                      childList: true,
                      subtree: true,
                    })
                  })
                )
              }
            _0x31f2b4('bkgPaymentOptions')
            console.log('OCEAN: bkgPaymentOptions एक्शन मिला\u0964')
            await _0x1a306d('.bank-type')
            const _0x4c12c3 = _0x539928.other_preferences.paymentmethod,
              _0xcd75f = _0x539928.other_preferences.backup_payment_method,
              _0x502682 = async (_0x240997) => {
                if (!_0x240997) {
                  return { success: false }
                }
                let _0x2f00ef, _0x5848c0
                console.log('OCEAN: पेमेंट का प्रयास: ' + _0x240997)
                if (_0x240997.includes('PAYTMUPI')) {
                  _0x2f00ef = 'BHIM/ UPI/ USSD'
                  _0x5848c0 = 'Pay using BHIM (Powered by PAYTM )'
                } else {
                  if (_0x240997.includes('PHONEPEUPIQR')) {
                    _0x2f00ef = 'Multiple Payment Service'
                    _0x5848c0 = 'Powered by PhonePe'
                  } else {
                    if (_0x240997.includes('RAZORPAYUPI')) {
                      ;(_0x2f00ef = 'Multiple Payment Service'),
                        (_0x5848c0 =
                          'Credit & Debit cards / Net Banking / UPI (Powered by Razorpay)')
                    } else {
                      if (_0x240997.includes('PAYUUPI')) {
                        ;(_0x2f00ef = 'Multiple Payment Service'),
                          (_0x5848c0 =
                            'Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)')
                      } else {
                        if (_0x240997.includes('AMZPAYWAL')) {
                          ;(_0x2f00ef = 'Wallets / Cash Card'),
                            (_0x5848c0 = 'Amazon Pay')
                        } else {
                          if (_0x240997.includes('MOBIKWIKWAL')) {
                            _0x2f00ef = 'Wallets / Cash Card'
                            _0x5848c0 = 'Mobikwik Wallet'
                          } else {
                            if (_0x240997.includes('HDFCDB')) {
                              ;(_0x2f00ef =
                                'Payment Gateway / Credit Card / Debit Card'),
                                (_0x5848c0 = 'Powered By HDFC BANK')
                            } else {
                              if (_0x240997.includes('kotak_dc')) {
                                _0x2f00ef =
                                  'Payment Gateway / Credit Card / Debit Card'
                                _0x5848c0 = 'Powered by KOTAK BANK'
                              } else {
                                if (_0x240997.includes('icici_dc')) {
                                  ;(_0x2f00ef =
                                    'Payment Gateway / Credit Card / Debit Card'),
                                    (_0x5848c0 = 'Powered by ICICI BANK')
                                } else {
                                  if (_0x240997.includes('SBINETBANKING')) {
                                    _0x2f00ef = 'Netbanking'
                                    _0x5848c0 = 'State Bank of India'
                                  } else {
                                    if (_0x240997.includes('HDFCNETBANKING')) {
                                      _0x2f00ef = 'Netbanking'
                                      _0x5848c0 = 'ICICI Bank'
                                    } else {
                                      if (_0x240997.includes('IRCWA')) {
                                        _0x2f00ef = 'IRCTC eWallet'
                                        _0x5848c0 = 'IRCTC eWallet'
                                      } else {
                                        _0x2f00ef =
                                          'IRCTC iPay (Credit Card/Debit Card/UPI)'
                                        _0x5848c0 =
                                          'Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)'
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                let _0x241ed7 = Array.from(
                  document.querySelectorAll(
                    '#pay-type span.bank-type-heading, #pay-type div.bank-type'
                  )
                ).find(
                  (_0x559f00) =>
                    _0x559f00 &&
                    _0x559f00.innerText
                      ?.toUpperCase()
                      .includes(_0x2f00ef.toUpperCase())
                )
                if (!_0x241ed7) {
                  return (
                    console.error(
                      "OCEAN: कैटेगरी '" + _0x2f00ef + "' नहीं मिली\u0964"
                    ),
                    { success: false }
                  )
                }
                _0xf4fd84(_0x241ed7)
                console.log(
                  "OCEAN: कैटेगरी पर क्लिक किया: '" +
                    _0x2f00ef +
                    "'. अब ऑप्शन का इंतज़ार है..."
                )
                if (window.innerWidth <= 512) {
                  const _0x319e45 = document.querySelectorAll(
                    'button.mob-bot-btn.search_btn[type="button"]'
                  )
                  let _0x158533 = false
                  for (const _0x4aa938 of _0x319e45) {
                    if (
                      _0x4aa938.innerText.trim().toUpperCase() === 'CONTINUE'
                    ) {
                      _0x4aa938.click()
                      _0x158533 = true
                      break
                    }
                  }
                  _0x158533
                    ? (console.log('\u2705 Mobile CONTINUE button clicked!'),
                      await new Promise((_0x2e31be) =>
                        setTimeout(_0x2e31be, 700)
                      ))
                    : console.warn(
                        '\u274C CONTINUE button not found in mobile view!'
                      )
                }
                await _0x1a306d('.border-all.no-pad span')
                let _0x51fdc5 = Array.from(
                  document.getElementsByClassName('border-all no-pad')
                ).find((_0x5870a9) => {
                  const _0x4f22af = _0x5870a9?.getElementsByTagName('span')[0]
                  return (
                    _0x2ebf85(_0x5870a9) &&
                    _0x4f22af?.innerText
                      .toUpperCase()
                      .includes(_0x5848c0.toUpperCase())
                  )
                })
                if (_0x51fdc5) {
                  return (
                    console.log(
                      "OCEAN: ऑप्शन '" +
                        _0x5848c0 +
                        "' मिला\u0964 क्लिक कर रहे हैं\u0964"
                    ),
                    _0xf4fd84(_0x51fdc5),
                    { success: true }
                  )
                } else {
                  return (
                    console.warn(
                      "OCEAN: ऑप्शन '" + _0x5848c0 + "' नहीं मिला\u0964"
                    ),
                    { success: false }
                  )
                }
              },
              _0x5a29f1 = await _0x502682(_0x4c12c3)
            if (_0x5a29f1.success) {
              if (!_0x539928.other_preferences.paymentManual) {
                _0x31f2b4('redirectToBank')
                const _0x131855 = parseInt(
                  _0x539928.other_preferences.secSelectionDelay || '0',
                  10
                )
                if (_0x131855 > 0) {
                  const _0x509484 = _0x131855 * 1000
                  console.log(
                    'OCEAN: उपयोगकर्ता द्वारा चुनी गई ' +
                      _0x131855 +
                      ' सेकंड की देरी शुरू\u0964'
                  )
                  _0x5d6a8e(
                    'Waiting for ' +
                      _0x131855 +
                      ' sec before clicking Pay & Book...',
                    _0x509484
                  )
                  await new Promise((_0x44fe95) =>
                    setTimeout(_0x44fe95, _0x509484)
                  )
                  console.log(
                    'OCEAN: ' +
                      _0x131855 +
                      ' सेकंड की देरी समाप्त\u0964 अब Pay & Book पर क्लिक किया जा रहा है\u0964'
                  )
                }
                await _0x18e574('button.btn-primary', '#loaderP')
                if (_0x4c12c3 === 'IRCWA') {
                  console.log(
                    'OCEAN: eWallet कन्फर्मेशन पॉप-अप बटन खोजा जा रहा है\u0964'
                  )
                  const _0x2e09b6 = await _0x1a306d(
                    'button.mob-bot-btn.search_btn'
                  )
                  _0x2e09b6 &&
                    _0x2e09b6.innerText.trim().toUpperCase() === 'CONFIRM' &&
                    (console.log(
                      'OCEAN: eWallet कन्फर्म बटन मिला और क्लिक किया\u0964'
                    ),
                    _0xf4fd84(_0x2e09b6))
                }
              }
            } else {
              console.warn(
                'OCEAN: प्राइमरी मेथड फेल\u0964 बैकअप का प्रयास कर रहे हैं\u0964'
              )
              if (_0xcd75f && _0xcd75f !== '') {
                _0x5d6a8e(
                  'प्राइमरी मेथड फेल\u0964 बैकअप पर स्विच कर रहे हैं: ' +
                    _0xcd75f,
                  5000
                )
                const _0x15017d = await _0x502682(_0xcd75f)
                _0x15017d.success
                  ? ((_0x539928.other_preferences.paymentmethod = _0xcd75f),
                    chrome.storage.local.set({
                      other_preferences: _0x539928.other_preferences,
                    }),
                    !_0x539928.other_preferences.paymentManual &&
                      (_0x31f2b4('redirectToBank'),
                      await _0x18e574('button.btn-primary', '#loaderP')))
                  : _0x5d6a8e(
                      'प्राइमरी और बैकअप दोनों ऑप्शन फेल हो गए\u0964',
                      6000
                    )
              } else {
                _0x5d6a8e(
                  'प्राइमरी मेथड फेल और कोई बैकअप सेट नहीं है\u0964',
                  6000
                )
              }
            }
          } else {
            if ('showPnrAnimation' === _0x11ce64) {
              const _0x1611d9 = document.querySelector(
                'div.cnf-pad.ng-star-inserted'
              )
              if (_0x1611d9) {
                _0x5a438a(_0x1611d9)
              }
            } else {
              _0x2367f7('Something went wrong: Unknown message type')
            }
          }
        }
      }
    }
  }
)
async function _0x83c5e0() { 
  document.querySelector('#captcha')?.scrollIntoView({ 
    behavior: 'smooth', 
    block: 'center', 
  }) 
  if (_0x539928.other_preferences.autoCaptcha) { 
    setTimeout(_0x514fdd, 200) 
  } else { 
    const _0xdaa516 = document.querySelector('#captcha') 
    if (_0xdaa516) {
      _0x2bde74(_0xdaa516, 'X')
      _0xdaa516.focus()
    } 
  } 
} 
let _0x3e472b = 0 
async function _0x514fdd() { 
  if (_0x3e472b >= 100) { 
    return 
  } 
  _0x3e472b++ 
  const _0x3c2a45 = document.querySelector('.captcha-img') 
  if (!_0x3c2a45 || !_0x3c2a45.src || _0x3c2a45.src.length < 23) { 
    setTimeout(_0x514fdd, 1000) 
    return 
  } 
  // Use TrueCaptcha API as provided by user 
  try { 
    const _0x336e9b = _0x3c2a45.src.substr(22) 
    const _0x52004d = new XMLHttpRequest(); 
    const _0x279c07 = JSON.stringify({ 
      'client': "chrome extension", 
      'location': ' `https://www.irctc.co.in/nget/train-search` ', 
      'version': "0.3.8", 
      'case': "mixed", 
      'promise': "true", 
      'extension': true, 
      'userid': "zerox99107@gmail.com", 
      'apikey': "qZuhbPTMovXCDGJwbdfR", 
      'data': _0x336e9b 
    }); 
    _0x52004d.open("POST", "https://api.apitruecaptcha.org/one/gettext", true); 
    _0x52004d.setRequestHeader("Content-Type", "application/json");
    _0x52004d.onreadystatechange = function() {
      if (_0x52004d.readyState === 4) {
        if (_0x52004d.status === 200) {
          let _0x1f4f37 = ''; 
          const _0x24ea8e = document.querySelector("#captcha"); 
          _0x1f4f37 = JSON.parse(_0x52004d.response).result; 
          console.log("Org text", _0x1f4f37); 
          const _0x3ae02c = Array.from(_0x1f4f37.split(" ").join('').replace(')', 'J').replace(']', 'J')); 
          let _0x4b6bbf = ''; 
          for (const _0x5cebd0 of _0x3ae02c) if ('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(_0x5cebd0)) { 
            _0x4b6bbf += _0x5cebd0; 
          } 
          if (_0x24ea8e) {
            _0x2bde74(_0x24ea8e, _0x4b6bbf)
          }
          
          // Process observers and auto-submit after successful captcha solving
          const _0x126334 = document.querySelector('app-login'),
            _0x54d1fc = document.querySelector(
              '#divMain > div > app-review-booking > p-toast'
            ),
            _0x5f26bf = (_0x17e661, _0x28f987) => {
              setTimeout(_0x514fdd, 500), _0x28f987.disconnect()
            },
            _0x3747bc = new MutationObserver((_0xbda2e5, _0x81d1f3) => {
              if (_0x126334?.innerText.toLowerCase().includes('valid captcha')) {
                _0x5f26bf('login', _0x81d1f3)
              }
              if (_0x54d1fc?.innerText.toLowerCase().includes('valid captcha')) {
                _0x5f26bf('review', _0x81d1f3)
              }
            })
          if (_0x126334) {
            _0x3747bc.observe(_0x126334, {
              childList: true,
              subtree: true,
            })
          }
          if (_0x54d1fc) {
            _0x3747bc.observe(_0x54d1fc, {
              childList: true,
              subtree: true,
            })
          }
          if (_0x539928.other_preferences.CaptchaSubmitMode === 'A') {
            const _0x2fb537 = document.querySelector('#divMain > app-login')
            if (_0x2fb537) {
              const _0x25341c = _0x2fb537.querySelector(
                  "input[formcontrolname='userid']"
                ),
                _0x38b5a6 = _0x2fb537.querySelector(
                  "input[formcontrolname='password']"
                )
              _0x25341c?.value && _0x38b5a6?.value
                ? setTimeout(() => {
                    _0x28ed05(
                      _0x2fb537.querySelector(
                        "button[type='submit'][class='search_btn train_Search']"
                      )
                    )
                    _0x28ed05(
                      _0x2fb537.querySelector(
                        "button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"
                      )
                    )
                  }, 100)
                : _0x2c145b('Username/password not filled for auto-submit.')
            }
            const _0x18892d = document.querySelector(
              '#divMain > div > app-review-booking'
            )
            if (_0x18892d && _0x24ea8e?.value) {
              const _0x1249b6 = _0x18892d.querySelector('.btnDefault.train_Search')
              if (_0x1249b6) {
                setTimeout(() => {
                  if (_0x539928.other_preferences.confirmberths) {
                    if (document.querySelector('.AVAILABLE')) {
                      _0x28ed05(_0x1249b6)
                    } else {
                      _0x3e9a77(
                        'No seats available. Continue booking?',
                        () => _0x28ed05(_0x1249b6),
                        () => console.log('Booking stopped.')
                      )
                    }
                  } else {
                    _0x28ed05(_0x1249b6)
                  }
                }, 100)
              }
            } else {
              _0x18892d &&
                !_0x24ea8e?.value &&
                _0x2c145b('Captcha not filled for auto-submit on review page.')
            }
          }
        } else {
          console.log("Error " + _0x52004d.status + ": " + _0x52004d.statusText);
          console.log(_0x52004d.response);
          setTimeout(_0x514fdd, 1000);
        }
      }
    };
    _0x52004d.send(_0x279c07);
  } catch (_0x287707) {
    console.error('Failed to connect to captcha server:', _0x287707)
    _0x2c145b(
      'Could not connect to the captcha server. Please check your network or server status.'
    )
  }
}
async function _0x148245() {
  _0x31f2b4('loadLoginDetails')
  const _0x27665e = document.querySelector('#divMain > app-login'),
    _0x2b19c4 = _0x27665e.querySelector(
      "input[type='text'][formcontrolname='userid']"
    ),
    _0x47de56 = _0x27665e.querySelector(
      "input[type='password'][formcontrolname='password']"
    )
  _0x2bde74(_0x2b19c4, _0x539928.irctc_credentials.user_name ?? '')
  _0x2bde74(_0x47de56, _0x539928.irctc_credentials.password ?? '')
  document.querySelector('#captcha').scrollIntoView({
    behavior: 'smooth',
    block: 'center',
  })
  if (_0x539928.other_preferences.autoCaptcha) {
    setTimeout(_0x514fdd, 200)
  } else {
    const _0x33b538 = document.querySelector('#captcha')
    _0x2bde74(_0x33b538, 'X')
    _0x33b538.focus()
  }
}
function _0x43c15e() {
  _0x31f2b4('loadJourneyDetails')
  console.log('filling_journey_details')
  const _0x110818 = document.querySelector('app-jp-input form'),
    _0x3ab89c = _0x110818.querySelector('#origin > span > input')
  _0x3ab89c.value = _0x539928.journey_details.from
  _0x3ab89c.dispatchEvent(new Event('keydown'))
  _0x3ab89c.dispatchEvent(new Event('input'))
  const _0x3952be = _0x110818.querySelector('#destination > span > input')
  _0x3952be.value = _0x539928.journey_details.destination
  _0x3952be.dispatchEvent(new Event('keydown'))
  _0x3952be.dispatchEvent(new Event('input'))
  const _0x1949d7 = _0x110818.querySelector('#jDate > span > input')
  _0x1949d7.value = _0x539928.journey_details.date
    ? '' + _0x539928.journey_details.date.split('-').reverse().join('/')
    : ''
  _0x1949d7.dispatchEvent(new Event('keydown'))
  _0x1949d7.dispatchEvent(new Event('input'))
  const _0xe60d1b = _0x110818.querySelector('#journeyClass')
  _0xe60d1b.querySelector("div > div[role='button']").click()
  _0x5590db(300)
  ;[..._0xe60d1b.querySelectorAll('ul li')]
    .find(
      (_0x351280) =>
        _0x351280.innerText === _0x59a50e(_0x539928.journey_details.class)
    )
    ?.click()
  _0x5590db(300)
  const _0x5c5c4a = _0x110818.querySelector('#journeyQuota')
  _0x5c5c4a.querySelector("div > div[role='button']").click()
  ;[..._0x5c5c4a.querySelectorAll('ul li')]
    .find(
      (_0x209a75) =>
        _0x209a75.innerText === _0x335d32(_0x539928.journey_details.quota)
    )
    ?.click()
  _0x5590db(300)
  const _0xaa7b = _0x110818.querySelector(
    "button.search_btn.train_Search[type='submit']"
  )
  _0x5590db(300)
  console.log('filled_journey_details')
  _0xaa7b.click()
}
function _0x22b631() {
  console.log(
    '\uD83D\uDD04 कुछ गड़बड़ हुई, 300ms में फिर से कोशिश कर रहे हैं...'
  )
  setTimeout(_0x55d2f2, 300)
}
function _0x55d2f2() {
  _0x31f2b4('train-list')
  console.log('selectJourney शुरू हुआ (सही फ्लो के साथ)...')
  if (!_0x539928?.journey_details?.['train-no']) {
    return console.error('ट्रेन नंबर उपलब्ध नहीं है\u0964')
  }
  const _0x217257 = document.querySelector('#divMain > div > app-train-list')
  if (!_0x217257) {
    return (
      console.error('ट्रेन लिस्ट नहीं मिली\u0964 फिर से कोशिश कर रहे हैं...'),
      _0x22b631()
    )
  }
  const _0x1facbe = Array.from(
      _0x217257.querySelectorAll('.tbis-div app-train-avl-enq')
    ),
    _0x139b56 = _0x539928.journey_details['train-no'],
    _0x854b08 = _0x59a50e(_0x539928.journey_details.class),
    _0x1120cb = _0x1facbe.find((_0x5e4014) =>
      _0x5e4014
        .querySelector('div.train-heading')
        .innerText.trim()
        .includes(_0x139b56.split('-')[0])
    )
  if (!_0x1120cb) {
    return (
      _0x31f2b4('journey_selection_stopped.no_train'),
      console.error('दी गई ट्रेन नंबर लिस्ट में नहीं मिली\u0964')
    )
  }
  console.log('क्लास टैब के दोनों स्ट्रक्चर को ढूंढ रहे हैं...')
  const _0x3c3065 = Array.from(
      _0x1120cb.querySelectorAll('table tr td div.pre-avl')
    ).find(
      (_0x4e655a) =>
        _0x4e655a.querySelector('div').innerText.trim() === _0x854b08
    ),
    _0x3c3cd0 = Array.from(_0x1120cb.querySelectorAll('span')).find(
      (_0x1c1641) => _0x1c1641.innerText.trim() === _0x854b08
    ),
    _0xb8a914 = _0x3c3065 || _0x3c3cd0
  if (!_0xb8a914) {
    return (
      console.error(
        '\u274C ज़रूरी क्लास टैब नहीं मिला\u0964 शायद पेज का स्ट्रक्चर बदल गया है\u0964'
      ),
      _0x22b631()
    )
  }
  _0x28ed05(_0xb8a914)
  console.log(
    '\u2705 क्लास पर क्लिक किया: ' + _0x854b08 + '. अब लोडर का इंतज़ार...'
  )
  let _0x50ceb2 = false
  const _0x5812ac = new MutationObserver((_0x4c3549, _0x46f710) => {
    const _0x3ef3a1 = document.querySelector('#loaderP'),
      _0xdd4bd9 =
        _0x3ef3a1 && window.getComputedStyle(_0x3ef3a1).display !== 'none'
    !_0xdd4bd9 &&
      !_0x50ceb2 &&
      (console.log(
        'सिग्नल मिला! क्लास का लोडर हट गया है\u0964 अब तारीख ढूंढ रहे हैं...'
      ),
      (_0x50ceb2 = true))
    if (_0x50ceb2) {
      const _0xf192b4 = new Date(_0x539928.journey_details.date),
        _0x54c4fa =
          _0xf192b4.toDateString().split(' ')[0] +
          ', ' +
          _0xf192b4.toDateString().split(' ')[2] +
          ' ' +
          _0xf192b4.toDateString().split(' ')[1],
        _0x13dfee = Array.from(
          _0x1120cb.querySelectorAll('div div table td div.pre-avl')
        ).find(
          (_0x565fc5) =>
            _0x565fc5.querySelector('div').innerText.trim() === _0x54c4fa
        )
      _0x13dfee &&
        (console.log(
          'तारीख मिल गई: ' + _0x54c4fa + '. अब इस पर क्लिक कर रहे हैं\u0964'
        ),
        _0x46f710.disconnect(),
        _0x13dfee.click(),
        _0x5bc0ae(_0x1120cb))
    }
  })
  _0x5812ac.observe(_0x1120cb, {
    childList: true,
    subtree: true,
    attributes: true,
    characterData: true,
  })
}
function _0x5bc0ae(_0x3ac8a2) {
  console.log("'बुक नाउ' बटन के लिए लोडर हटने का इंतज़ार...")
  const _0x27bd7d = new MutationObserver((_0x199c71, _0x19cfc3) => {
    const _0x34c747 = document.querySelector('#loaderP'),
      _0x39c787 = (_0x3e1759) =>
        _0x3e1759 && window.getComputedStyle(_0x3e1759).display !== 'none'
    if (!_0x39c787(_0x34c747)) {
      console.log(
        "सिग्नल मिला! लोडर हट गया है\u0964 अब 'बुक नाउ' पर क्लिक करना सुरक्षित है\u0964"
      )
      _0x19cfc3.disconnect()
      _0x18d689(_0x3ac8a2)
    }
  })
  _0x27bd7d.observe(document.body, {
    childList: true,
    subtree: true,
  })
}
function _0x18d689(_0x2303cb) {
  const _0x10b6f8 = _0x2303cb.querySelector(
      'button.btnDefault.train_Search.ng-star-inserted'
    ),
    _0xaf99c1 =
      document.querySelector('#loaderP') &&
      window.getComputedStyle(document.querySelector('#loaderP')).display !==
        'none'
  if (
    _0xaf99c1 ||
    !_0x10b6f8 ||
    _0x10b6f8.disabled ||
    _0x10b6f8.classList.contains('disable-book')
  ) {
    console.error(
      "\u274C 'बुक नाउ' बटन क्लिक के लिए तैयार नहीं है\u0964 300ms में retry होगा..."
    )
    _0x22b631()
    return
  }
  console.log("\u2705 'बुक नाउ' बटन पर क्लिक कर रहे हैं!")
  _0x10b6f8.click()
}
async function _0xa1e3a3() {
  console.log('passenger_filling_started')
  if (_0x539928.journey_details.boarding?.length > 0) {
    const _0x127160 = [...document.getElementsByTagName('strong')].find(
      (_0x10da36) =>
        _0x10da36.innerText.includes(
          _0x539928.journey_details.from.split('-')[0].trim() + ' | '
        )
    )
    if (_0x127160) {
      _0x28ed05(_0x127160)
    }
    setTimeout(() => {
      const _0x30052a = [...document.getElementsByTagName('strong')].find(
        (_0x622fe5) =>
          _0x622fe5.innerText.includes(
            _0x539928.journey_details.boarding.split('-')[0].trim()
          )
      )
      if (_0x30052a) {
        _0x28ed05(_0x30052a)
      }
    }, 100)
  }
  const _0x4cb71d = document.querySelector('app-passenger-input')
  if (!_0x4cb71d) {
    return console.error('Passenger app element not found.')
  }
  for (
    let _0x1fb637 = 1;
    _0x1fb637 < _0x539928.passenger_details.length;
    _0x1fb637++
  ) {
    _0x28ed05(document.getElementsByClassName('prenext')[0])
  }
  for (
    let _0x343e65 = 0;
    _0x343e65 < (_0x539928.infant_details || []).length;
    _0x343e65++
  ) {
    _0x28ed05(document.getElementsByClassName('prenext')[2])
  }
  await new Promise((_0x3b5ee6) => setTimeout(_0x3b5ee6, 200))
  const _0x24b82c = [..._0x4cb71d.querySelectorAll('app-passenger')]
  _0x539928.passenger_details.forEach((_0x359c25, _0x353f34) => {
    if (!_0x24b82c[_0x353f34]) {
      return
    }
    const _0x2a38b2 = _0x24b82c[_0x353f34]
    _0x2bde74(_0x2a38b2.querySelector('p-autocomplete input'), _0x359c25.name)
    _0x2bde74(
      _0x2a38b2.querySelector("input[formcontrolname='passengerAge']"),
      _0x359c25.age
    )
    const _0x22c9ea = _0x2a38b2.querySelector(
      "select[formcontrolname='passengerGender']"
    )
    _0x22c9ea &&
      ((_0x22c9ea.value = _0x359c25.gender),
      _0x22c9ea.dispatchEvent(new Event('change')))
    const _0x3e35ec = _0x2a38b2.querySelector(
      "select[formcontrolname='passengerBerthChoice']"
    )
    if (_0x3e35ec) {
      _0x3e35ec.value = _0x359c25.berth
      _0x3e35ec.dispatchEvent(new Event('change'))
    }
    const _0x1df20f = _0x2a38b2.querySelector(
      "select[formcontrolname='passengerFoodChoice']"
    )
    _0x1df20f &&
      ((_0x1df20f.value = _0x359c25.food),
      _0x1df20f.dispatchEvent(new Event('change')))
  })
  _0x539928.other_preferences.mobileNumber &&
    _0x2bde74(
      _0x4cb71d.querySelector('input#mobileNumber'),
      _0x539928.other_preferences.mobileNumber
    )
  const _0x267516 = [
    ..._0x4cb71d.querySelectorAll(
      "p-radiobutton[formcontrolname='paymentType'] input"
    ),
  ].find(
    (_0x184982) =>
      _0x184982.value ===
      (_0x539928.other_preferences.paymentmethod.includes('UPI') ? '2' : '1')
  )
  if (_0x267516) {
    _0x28ed05(_0x267516)
  }
  const _0x3de813 = _0x4cb71d.querySelector('input#autoUpgradation')
  if (
    _0x3de813 &&
    _0x539928.other_preferences.autoUpgradation !== _0x3de813.checked
  ) {
    _0x28ed05(_0x3de813)
  }
  const _0x42e33f = _0x4cb71d.querySelector('input#confirmberths')
  if (
    _0x42e33f &&
    _0x539928.other_preferences.confirmberths !== _0x42e33f.checked
  ) {
    _0x28ed05(_0x42e33f)
  }
  const _0x2d0c10 = [
    ..._0x4cb71d.querySelectorAll(
      "p-radiobutton[formcontrolname='travelInsuranceOpted'] input"
    ),
  ].find(
    (_0x24d3b7) =>
      _0x24d3b7.value ===
      (_0x539928.travel_preferences.travelInsuranceOpted === 'yes'
        ? 'true'
        : 'false')
  )
  if (_0x2d0c10) {
    _0x28ed05(_0x2d0c10)
  }
  console.log(
    "सभी विवरण भर दिए गए हैं\u0964 अब सुरक्षित रूप से आगे बढ़ने के लिए 'जासूस' को तैनात कर रहे हैं\u0964"
  )
  const _0x3d307c = "button.train_Search.btnDefault[type='submit']",
    _0x2ef124 = '#loaderP'
  _0x2f6b0c(_0x3d307c, _0x2ef124)
}
function _0x2f6b0c(_0xbbcee8, _0x4c208d) {
  const _0x42c4f7 = document.querySelector(_0xbbcee8)
  if (!_0x42c4f7) {
    console.error('बटन नहीं मिला: ' + _0xbbcee8)
    return
  }
  console.log(
    'बटन पर क्लिक किया: ' +
      _0xbbcee8 +
      '\u0964 अब सर्वर प्रोसेसिंग का इंतज़ार...'
  )
  _0x42c4f7.click()
  let _0x54dd63 = false
  const _0x425ae2 = new MutationObserver((_0x50cfe3, _0x20f0cb) => {
    const _0x4c091c = document.querySelector(_0x4c208d),
      _0x22bdb3 = (_0x3682f5) =>
        _0x3682f5 && window.getComputedStyle(_0x3682f5).display !== 'none'
    !_0x54dd63 &&
      _0x22bdb3(_0x4c091c) &&
      (console.log('प्रोसेसिंग शुरू! लोडर दिख गया है\u0964'),
      (_0x54dd63 = true))
    if (_0x54dd63 && !_0x22bdb3(_0x4c091c)) {
      console.log(
        'सिग्नल मिला! प्रोसेसिंग पूरी\u0964 अब अगले पेज पर जाना सुरक्षित है\u0964'
      )
      _0x20f0cb.disconnect()
    }
  })
  _0x425ae2.observe(document.body, {
    childList: true,
    subtree: true,
  })
}
async function _0x2a7eca() {
  const _0x4d2463 = document.querySelector(
    'body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted'
  )
  if (window.location.href.includes('train-search')) {
    if (_0x4d2463 && _0x4d2463.innerText.trim().toUpperCase() === 'LOGOUT') {
      console.log('यूजर लॉगिन है\u0964 Keep-Alive पिंग शुरू कर रहे हैं...'),
        _0x33e28e(),
        console.log('अब यात्रा विवरण लोड कर रहे हैं\u0964'),
        _0x43c15e()
    } else {
      if (_0x4d2463 && _0x4d2463.innerText.trim().toUpperCase() === 'LOGIN') {
        console.log(
          'IRCTC पेज लोड हुआ\u0964 LOGIN बटन मिला\u0964 लॉगिन के लिए इंतज़ार...'
        )
        let _0x296e22 = document.getElementById('irctc-login-countdown-element')
        if (!_0x296e22) {
          _0x296e22 = document.createElement('div')
          _0x296e22.id = 'irctc-login-countdown-element'
          _0x296e22.style.cssText =
            '\n                    position: fixed; top: 3px; left: 50%;\n                    transform: translateX(-50%); z-index: 20000;\n                '
          _0x296e22.innerHTML =
            '\n                    <img id="irctc-countdown-gif" src="https://gifdb.com/images/high/red-timer-line-next-98aunmjvktlvnr2a.webp" style="width: 80px; height: 80px; display: block;">\n                '
          document.body.appendChild(_0x296e22)
        }
        const _0x2d5733 = setTimeout(async () => {
          if (_0x296e22 && _0x296e22.parentElement) {
            _0x296e22.remove()
          }
          _0x28ed05(_0x4d2463)
          await _0x148245()
        }, 10000)
      }
    }
  }
}
window.onload = function () {
  console.log('Content script loaded and window.onload triggered.')
  _0x1ac297()
  setInterval(() => _0x31f2b4('Keep listener alive.'), 15000)
  const _0x3f4523 = document.querySelector(
    'body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1'
  )
  _0x3f4523 &&
    new MutationObserver((_0x52aa81, _0x2797ad) => {
      if (
        _0x52aa81.some(
          (_0x50e371) =>
            _0x50e371.type === 'childList' &&
            [..._0x50e371.addedNodes].some(
              (_0x48011f) =>
                _0x48011f?.innerText?.trim().toUpperCase() === 'LOGOUT'
            )
        )
      ) {
        console.log('LOGOUT detected in header via MutationObserver.')
        _0x2797ad.disconnect()
        _0x43c15e()
      }
    }).observe(_0x3f4523, {
      childList: true,
      subtree: false,
    })
  _0x5c4a77()
  chrome.storage.local.get(null, (_0x25da3c) => {
    ;(_0x539928 = _0x25da3c),
      console.log('User data loaded from storage:', _0x539928),
      _0x502936(_0x539928),
      _0x2a7eca()
  })
}
function _0x1e30e8(_0x2dc71f) {
  function _0x50f8e5(_0x16da33) {
    if (typeof _0x16da33 === 'string') {
      return function (_0xbb066) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x16da33 / _0x16da33).length !== 1 || _0x16da33 % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0x50f8e5(++_0x16da33)
  }
  try {
    if (_0x2dc71f) {
      return _0x50f8e5
    } else {
      _0x50f8e5(0)
    }
  } catch (_0x5abe87) {}
}
