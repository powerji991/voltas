const _0x3c6100 = 'Version 1.8.4'

// Display version in the UI if element exists
function _0x3f77ad() {
  const _0x28e0ee = document.getElementById('versionContainer')
  if (_0x28e0ee) {
    _0x28e0ee.innerHTML = _0x3c6100
  }
}
document.getElementById('openPopupTab').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') })
})
;(function () {
  const _0x4482f3 = (function () {
    const _0x28629b = {
      OJetF: 'function *\\( *\\)',
      DNmeE: '\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
      LjxQO: function (_0x337c6f, _0x406898) {
        return _0x337c6f(_0x406898)
      },
      zWVWh: 'init',
      hpCqt: function (_0x8617dd, _0x4f206f) {
        return _0x8617dd + _0x4f206f
      },
      bWCrK: 'chain',
      Yzrxj: 'input',
      dUdVm: function (_0x507549, _0x116d75) {
        return _0x507549(_0x116d75)
      },
      YNbjN: function (_0x2a3b68) {
        return _0x2a3b68()
      },
      AqjGT: function (_0x3febeb, _0x14e479, _0x1d07b4) {
        return _0x3febeb(_0x14e479, _0x1d07b4)
      },
      OSjSg: function (_0x4bcfa7, _0xe21bba) {
        return _0x4bcfa7 === _0xe21bba
      },
      WormM: 'mGnet',
      HZycg: 'HSFlm',
      TxWSy: function (_0x2dcfc0, _0x5c8f60) {
        return _0x2dcfc0 !== _0x5c8f60
      },
      kUWDF: 'eWyru',
      bTEfh: 'BJvVf',
      MArGF: 'AaOzO',
    }
    let _0x1a0fe0 = true
    return function (_0x834206, _0x64343) {
      const _0xade046 = {
        UKPpa: _0x28629b.OJetF,
        aFoJq: _0x28629b.DNmeE,
        XZAgM: function (_0x6569bd, _0x5ad2e9) {
          return _0x28629b.LjxQO(_0x6569bd, _0x5ad2e9)
        },
        JeLFw: _0x28629b.zWVWh,
        lWWNF: function (_0x533663, _0x20b13f) {
          return _0x28629b.hpCqt(_0x533663, _0x20b13f)
        },
        aCMVC: _0x28629b.bWCrK,
        kbRta: function (_0x47c2a8, _0x1549f0) {
          return _0x28629b.hpCqt(_0x47c2a8, _0x1549f0)
        },
        nQEff: _0x28629b.Yzrxj,
        FplvZ: function (_0x3ac4ac, _0x5406de) {
          return _0x28629b.dUdVm(_0x3ac4ac, _0x5406de)
        },
        iAUOH: function (_0x561f70) {
          return _0x28629b.YNbjN(_0x561f70)
        },
        bqoRW: function (_0xde7f98, _0x4ea751, _0x17df66) {
          return _0x28629b.AqjGT(_0xde7f98, _0x4ea751, _0x17df66)
        },
        dLJTa: function (_0x583689, _0x1ecd44) {
          return _0x28629b.OSjSg(_0x583689, _0x1ecd44)
        },
        jKRYV: _0x28629b.WormM,
        kxCzv: _0x28629b.HZycg,
        uiIbR: function (_0x2ec9f9, _0x4c1637) {
          return _0x28629b.TxWSy(_0x2ec9f9, _0x4c1637)
        },
        iZhAs: _0x28629b.kUWDF,
      }
      if (_0x28629b.OSjSg(_0x28629b.bTEfh, _0x28629b.MArGF)) {
        OILYrB.bqoRW(_0x357920, this, function () {
          const _0x141d88 = new _0x5c94c4(OILYrB.UKPpa),
            _0x35b112 = new _0x30aa8a(OILYrB.aFoJq, 'i'),
            _0x283068 = OILYrB.XZAgM(_0x56fe46, OILYrB.JeLFw)
          !_0x141d88.test(OILYrB.lWWNF(_0x283068, OILYrB.aCMVC)) ||
          !_0x35b112.test(OILYrB.kbRta(_0x283068, OILYrB.nQEff))
            ? OILYrB.FplvZ(_0x283068, '0')
            : OILYrB.iAUOH(_0x361fd4)
        })()
      } else {
        const _0x5e25bb = _0x1a0fe0
          ? function () {
              if (_0xade046.dLJTa(_0xade046.jKRYV, _0xade046.kxCzv)) {
                OILYrB.XZAgM(_0x10adf5, '0')
              } else {
                if (_0x64343) {
                  if (_0xade046.uiIbR(_0xade046.iZhAs, _0xade046.iZhAs)) {
                    REXzfz.zQirK(_0x67fc97, 0)
                  } else {
                    const _0x31d481 = _0x64343.apply(_0x834206, arguments)
                    return (_0x64343 = null), _0x31d481
                  }
                }
              }
            }
          : function () {}
        return (_0x1a0fe0 = false), _0x5e25bb
      }
    }
  })()
  ;(function () {
    _0x4482f3(this, function () {
      const _0x118faf = new RegExp('function *\\( *\\)'),
        _0x8cd54b = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x2ba3b5 = _0x10fb14('init')
      !_0x118faf.test(_0x2ba3b5 + 'chain') ||
      !_0x8cd54b.test(_0x2ba3b5 + 'input')
        ? _0x2ba3b5('0')
        : _0x10fb14()
    })()
  })()
  const _0xf10e31 = setInterval(() => {
    const _0x235148 = document.getElementById('clearCheckbox'),
      _0x4ae351 = document.getElementById('irctc-login'),
      _0x3fbfa6 = document.getElementById('irctc-password')
    if (!_0x235148 || !_0x4ae351 || !_0x3fbfa6) {
      return
    }
    clearInterval(_0xf10e31)
    const _0x1a2acf = localStorage.getItem('irctcClearCheckbox')
    if (_0x1a2acf === 'checked') {
      _0x235148.checked = true
      _0x5bab7f()
    }
    _0x235148.addEventListener('change', function () {
      if (_0x235148.checked) {
        _0x5bab7f(), localStorage.setItem('irctcClearCheckbox', 'checked')
      } else {
        _0x4ae351.disabled = false
        _0x3fbfa6.disabled = false
        localStorage.setItem('irctcClearCheckbox', 'unchecked')
      }
    })
    function _0x5bab7f() {
      _0x54fc19(_0x4ae351),
        _0x54fc19(_0x3fbfa6),
        (_0x4ae351.disabled = true),
        (_0x3fbfa6.disabled = true)
    }
    function _0x54fc19(_0x2075da) {
      _0x2075da.value = ''
      _0x2075da.dispatchEvent(new Event('input', { bubbles: true }))
      _0x2075da.dispatchEvent(new Event('change', { bubbles: true }))
    }
  }, 300)
})()
;(function () {
  const _0x38b1ca = function () {
      const _0x2ff26e = {
        vaSIy: function (_0xa6e9fd) {
          return _0xa6e9fd()
        },
        nTFvx: 'irctcClearCheckbox',
        mnVVU: 'checked',
      }
      let _0x2d0b2f
      try {
        _0x2d0b2f = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0x4f8170) {
        _0x2d0b2f = window
      }
      return _0x2d0b2f
    },
    _0x53f827 = _0x38b1ca()
  _0x53f827.setInterval(_0x10fb14, 4000)
})()
document.addEventListener('DOMContentLoaded', async () => {
  await _0x3f77ad()
  try {
    const _0x5435b4 = await chrome.storage.local.get('licencekey')
    if (_0x5435b4 && _0x5435b4.licencekey) {
      const _0x2feaa5 = document.querySelector('#subscriber-key')
      if (_0x2feaa5) {
        _0x2feaa5.value = _0x5435b4.licencekey
      }
    }
  } catch (_0x4e8dfd) {
    console.error('Could not load license key', _0x4e8dfd)
  }
  chrome.storage.local.get(['plan_expiry'], (_0x35f87f) => {
    const _0x43eee1 = document.getElementById('UserPlanExpairy')
    if (_0x43eee1 && _0x35f87f.plan_expiry !== undefined) {
      if (_0x35f87f.plan_expiry) {
        _0x43eee1.textContent = _0x35f87f.plan_expiry
        const _0x59a695 = new Date(_0x35f87f.plan_expiry),
          _0x544506 = new Date()
        _0x43eee1.style.color = _0x544506 <= _0x59a695 ? 'green' : 'red'
      } else {
        ;(_0x43eee1.textContent = 'User Not Found'),
          (_0x43eee1.style.color = 'orange')
      }
    }
  })
  const _0x19eb1a = document.getElementById('submitBtn2autoClickCheckbox')
  if (_0x19eb1a) {
    chrome.storage.sync.get(
      ['submitBtn2autoClickEnabled'],
      function (_0x7514ee) {
        _0x19eb1a.checked = _0x7514ee.submitBtn2autoClickEnabled || false
      }
    )
    _0x19eb1a.addEventListener('change', function () {
      chrome.storage.sync.set({ submitBtn2autoClickEnabled: _0x19eb1a.checked })
    })
  }
  const _0x3d3197 = document.getElementById('cardexpiry')
  if (_0x3d3197) {
    _0x3d3197.addEventListener('input', function (_0xd75080) {
      let _0x5eb795 = _0xd75080.target.value.replace(/\D/g, '')
      if (_0x5eb795.length > 4) {
        _0x5eb795 = _0x5eb795.slice(0, 4)
      }
      if (_0x5eb795.length >= 3) {
        _0x5eb795 = _0x5eb795.slice(0, 2) + '/' + _0x5eb795.slice(2)
      }
      _0xd75080.target.value = _0x5eb795
    })
  }
})
function _0x10fb14(_0x272050) {
  function _0x1e5fa1(_0x43d215) {
    if (typeof _0x43d215 === 'string') {
      return function (_0x44531f) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x43d215 / _0x43d215).length !== 1 || _0x43d215 % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0x1e5fa1(++_0x43d215)
  }
  try {
    if (_0x272050) {
      return _0x1e5fa1
    } else {
      _0x1e5fa1(0)
    }
  } catch (_0x3d764e) {}
}
