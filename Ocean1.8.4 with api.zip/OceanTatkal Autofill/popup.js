const _0x11fdd9 = (function () {
  let _0xd66d3f = true
  return function (_0x510ff3, _0x60d805) {
    const _0x5290a3 = _0xd66d3f
      ? function () {
          if (_0x60d805) {
            const _0x5641d9 = _0x60d805.apply(_0x510ff3, arguments)
            return (_0x60d805 = null), _0x5641d9
          }
        }
      : function () {}
    return (_0xd66d3f = false), _0x5290a3
  }
})()
;(function () {
  _0x11fdd9(this, function () {
    const _0x2fd385 = new RegExp('function *\\( *\\)'),
      _0xe1d95d = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
      _0x2fc746 = _0x2bc18b('init')
    !_0x2fd385.test(_0x2fc746 + 'chain') || !_0xe1d95d.test(_0x2fc746 + 'input')
      ? _0x2fc746('0')
      : _0x2bc18b()
  })()
})()
function _0x5a2e06(_0x2186b0) {
  const _0x13deba = document.createElement('div')
  _0x13deba.id = 'custom-alert'
  _0x13deba.style.cssText =
    "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 300px;\n    "
  _0x13deba.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x2186b0 +
    '</p>\n        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>\n    '
  document.body.appendChild(_0x13deba)
  document.getElementById('custom-alert-ok').onclick = () => {
    _0x13deba.remove()
  }
}
function _0x411de7(_0x34c073, _0x36f873, _0x55f102) {
  const _0x3a0efd = document.createElement('div')
  _0x3a0efd.id = 'custom-confirm'
  _0x3a0efd.style.cssText =
    "\n        position: fixed;\n        top: 50%;\n        left: 50%;\n        transform: translate(-50%, -50%);\n        background-color: #fff;\n        border: 1px solid #ccc;\n        border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n        padding: 20px;\n        z-index: 10000;\n        text-align: center;\n        font-family: 'Inter', sans-serif;\n        max-width: 90%;\n        width: 350px;\n    "
  _0x3a0efd.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x34c073 +
    '</p>\n        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>\n        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>\n    '
  document.body.appendChild(_0x3a0efd)
  document.getElementById('custom-confirm-yes').onclick = () => {
    _0x3a0efd.remove()
    if (_0x36f873) {
      _0x36f873()
    }
  }
  document.getElementById('custom-confirm-no').onclick = () => {
    _0x3a0efd.remove()
    if (_0x55f102) {
      _0x55f102()
    }
  }
}
let _0x542fd4 = {
  irctc_credentials: {},
  subs_credentials: {},
  journey_details: {},
  passenger_details: [],
  infant_details: [],
  travel_preferences: {},
  other_preferences: {},
  vpa: {},
  fare_limit: {
    enableFareLimit: false,
    maxFareAmount: '',
    bookInPopup: false,
  },
  proxy_settings: {
    activeProxy: 'disabled',
    proxies: Array(5)
      .fill(null)
      .map(() => ({
        ip: '',
        port: '',
        user: '',
        pass: '',
      })),
  },
}
function _0x3ed656(_0x35090f, _0x1588da, _0x437362) {
  var _0x2e84c9
  function _0x752543(_0x37ea12) {
    if (!_0x37ea12) {
      return false
    }
    !(function (_0x73d0d7) {
      for (var _0x456bca = 0; _0x456bca < _0x73d0d7.length; _0x456bca++) {
        _0x73d0d7[_0x456bca].classList.remove('autocomplete-active')
      }
    })(_0x37ea12)
    _0x2e84c9 >= _0x37ea12.length && (_0x2e84c9 = 0)
    _0x2e84c9 < 0 && (_0x2e84c9 = _0x37ea12.length - 1)
    _0x37ea12[_0x2e84c9].classList.add('autocomplete-active')
  }
  function _0x4767e8(_0x251033) {
    for (
      var _0x228f95 = document.getElementsByClassName('autocomplete-items'),
        _0x1a0224 = 0;
      _0x1a0224 < _0x228f95.length;
      _0x1a0224++
    ) {
      _0x251033 != _0x228f95[_0x1a0224] &&
        _0x251033 != _0x35090f &&
        _0x228f95[_0x1a0224].parentNode.removeChild(_0x228f95[_0x1a0224])
    }
  }
  _0x35090f.addEventListener('input', function (_0x4c016c) {
    var _0x3a600c,
      _0x25cbe2,
      _0x33e681,
      _0x4c0a9b = this.value
    if ((_0x4767e8(), !_0x4c0a9b)) {
      return false
    }
    for (
      _0x2e84c9 = -1,
        (_0x3a600c = document.createElement('DIV')).setAttribute(
          'id',
          this.id + 'autocomplete-list'
        ),
        _0x3a600c.setAttribute('class', 'autocomplete-items'),
        this.parentNode.appendChild(_0x3a600c),
        _0x33e681 = 0;
      _0x33e681 < _0x1588da.length;
      _0x33e681++
    ) {
      _0x1588da[_0x33e681].toUpperCase().includes(_0x4c0a9b.toUpperCase()) &&
        (((_0x25cbe2 = document.createElement('DIV')).innerHTML =
          '<strong>' +
          _0x1588da[_0x33e681].substr(0, _0x4c0a9b.length) +
          '</strong>'),
        (_0x25cbe2.innerHTML += _0x1588da[_0x33e681].substr(_0x4c0a9b.length)),
        (_0x25cbe2.innerHTML +=
          "<input type='hidden' value='" + _0x1588da[_0x33e681] + "'>"),
        _0x25cbe2.addEventListener('click', function (_0x2b57a8) {
          if (
            ((_0x35090f.value = this.getElementsByTagName('input')[0].value),
            'SOURCE' == _0x437362 &&
              (_0x542fd4.journey_details.from =
                this.getElementsByTagName('input')[0].value),
            'DEST' == _0x437362 &&
              (_0x542fd4.journey_details.destination =
                this.getElementsByTagName('input')[0].value),
            'TRAIN' == _0x437362)
          ) {
            const _0x29907f = this.getElementsByTagName('input')[0].value
            _0x542fd4.journey_details['train-no'] = _0x29907f.trim()
          }
          'BOARDING' == _0x437362 &&
            (_0x542fd4.journey_details.boarding =
              this.getElementsByTagName('input')[0].value)
          _0x4767e8()
        }),
        _0x3a600c.appendChild(_0x25cbe2))
    }
  })
  _0x35090f.addEventListener('keydown', function (_0x5d3e43) {
    var _0xa92ce1 = document.getElementById(this.id + 'autocomplete-list')
    _0xa92ce1 && (_0xa92ce1 = _0xa92ce1.getElementsByTagName('div'))
    40 == _0x5d3e43.keyCode
      ? (_0x2e84c9++, _0x752543(_0xa92ce1))
      : 38 == _0x5d3e43.keyCode
      ? (_0x2e84c9--, _0x752543(_0xa92ce1))
      : 13 == _0x5d3e43.keyCode &&
        (_0x5d3e43.preventDefault(),
        _0x2e84c9 > -1 && _0xa92ce1 && _0xa92ce1[_0x2e84c9].click())
  })
  document.addEventListener('click', function (_0x2066a4) {
    _0x4767e8(_0x2066a4.target)
  })
}
const _0x16b846 = [],
  _0x218298 = []
async function _0x35fdb2() {
  try {
    const _0x37984f = await fetch(
      'https://suryarajputg.github.io/accet/stationlist.json'
    )
    if (!_0x37984f.ok) {
      throw (
        (_0x5a2e06(
          'Unable to fetch station data',
          'HTTP error! status: ' + _0x37984f.status
        ),
        new Error(
          'Unable to fetch station data',
          'HTTP error! status: ' + _0x37984f.status
        ))
      )
    }
    const _0x4753b7 = await _0x37984f.json()
    _0x16b846.push(..._0x4753b7)
    for (let _0x477f94 in _0x16b846)
      _0x218298.push(
        _0x16b846[_0x477f94].name + ' - ' + _0x16b846[_0x477f94].code
      )
    return _0x218298
  } catch (_0x1982e0) {
    throw (
      (console.error('Station data fetching error:', _0x1982e0),
      _0x5a2e06('Station data fetching error:', _0x1982e0),
      _0x1982e0)
    )
  }
}
async function _0x14215b() {
  try {
    const _0x47adac = await fetch(
      'https://suryarajputg.github.io/accet/train_data.js'
    )
    if (!_0x47adac.ok) {
      throw (
        (_0x5a2e06(
          'Unable to fetch train data',
          'HTTP error! status: ' + _0x47adac.status
        ),
        new Error(
          'Unable to fetch train data',
          'HTTP error! status: ' + _0x47adac.status
        ))
      )
    }
    return (await _0x47adac.text()).split(/\r?\n/)
  } catch (_0x4b7312) {
    throw (
      (console.error('Train data fetching error:', _0x4b7312),
      _0x5a2e06('Train data fetching error:', _0x4b7312),
      _0x4b7312)
    )
  }
}
function _0x46a01c(_0x28ad67) {
  _0x542fd4.irctc_credentials || (_0x542fd4.irctc_credentials = {})
  _0x542fd4.irctc_credentials.user_name = _0x28ad67.target.value
  console.log('data-update', _0x542fd4)
}
function _0x12a6e8(_0x122a40) {
  _0x542fd4.irctc_credentials.password = _0x122a40.target.value
  console.log('data-update', _0x542fd4)
}
function _0x9682b3(_0x369e37) {
  _0x542fd4.subs_credentials || (_0x542fd4.subs_credentials = {})
  _0x542fd4.subs_credentials.user_name = _0x369e37.target.value
  console.log('data-update', _0x542fd4)
}
function _0x4b31a3(_0x5a3a4e) {
  _0x542fd4.subs_credentials.password = _0x5a3a4e.target.value
  console.log('data-update', _0x542fd4)
}
function _0x11017b(_0x4a4794) {
  _0x542fd4.journey_details.from = _0x4a4794.target.value.toUpperCase()
  document.querySelector('#from-station-input').value = _0x4a4794.target.value
}
function _0x34c7cd(_0x2f6bfb) {
  _0x542fd4.journey_details.destination = _0x2f6bfb.target.value.toUpperCase()
  document.querySelector('#destination-station-input').value =
    _0x2f6bfb.target.value
}
function _0x488a0f(_0x254f2c) {
  _0x542fd4.journey_details.boarding = _0x254f2c.target.value.toUpperCase()
  document.querySelector('#boarding-station-input').value =
    _0x254f2c.target.value
}
function _0xb307c(_0x262d60) {
  _0x542fd4.journey_details.class = _0x262d60.target.value
  document.querySelector('#journey-class-input').value = _0x262d60.target.value
}
function _0x2d2564(_0x5316d5) {
  _0x542fd4.journey_details.quota = _0x5316d5.target.value
  document.querySelector('#quota-input').value = _0x5316d5.target.value
}
function _0xc63287(_0x10a35a) {
  _0x542fd4.journey_details.date = _0x10a35a.target.value
}
function _0x6d9ace(_0x170e3d) {
  _0x542fd4.journey_details['train-no'] = _0x170e3d.target.value
}
function _0x32b782(_0x3be1f0, _0x2522e4, _0x3e908f) {
  _0x542fd4.passenger_details[_0x2522e4] ||
    (_0x542fd4.passenger_details[_0x2522e4] = {})
  _0x542fd4.passenger_details[_0x2522e4][_0x3be1f0.target.name] =
    'checkbox' === _0x3be1f0.target.type
      ? _0x3be1f0.target.checked
      : _0x3be1f0.target.value
}
function _0x3872d1(_0xd860a0, _0x5a3c87, _0x2d43e5) {
  _0x542fd4.infant_details[_0x5a3c87] ||
    (_0x542fd4.infant_details[_0x5a3c87] = {})
  _0x542fd4.infant_details[_0x5a3c87][_0xd860a0.target.name] =
    _0xd860a0.target.value
}
function _0x2f6a35(_0x3186c0) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x3186c0.target.name] =
    'checkbox' === _0x3186c0.target.type
      ? _0x3186c0.target.checked
      : _0x3186c0.target.value
}
function _0x8944d(_0x4c20a1) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x4c20a1.target.name] =
    'checkbox' === _0x4c20a1.target.type
      ? _0x4c20a1.target.checked
      : _0x4c20a1.target.value
}
function _0xd46969(_0x844528) {
  _0x542fd4.vpa || (_0x542fd4.vpa = {})
  _0x542fd4.vpa[_0x844528.target.name] = _0x844528.target.value
}
function _0x3c111b(_0x1ae621) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences.paymentmethod = _0x1ae621.target.value
}
function _0x45a492(_0x5a66af) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences.CaptchaSubmitMode = _0x5a66af.target.value
}
function _0x5ebad7(_0x2f285a) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  'cardnumber' == _0x2f285a.target.name &&
    (_0x542fd4.other_preferences[_0x2f285a.target.name] =
      _0x2f285a.target.value)
  'cardexpiry' == _0x2f285a.target.name &&
    (_0x542fd4.other_preferences[_0x2f285a.target.name] =
      _0x2f285a.target.value)
  'cardcvv' == _0x2f285a.target.name &&
    (_0x542fd4.other_preferences[_0x2f285a.target.name] =
      _0x2f285a.target.value)
  'cardholder' == _0x2f285a.target.name &&
    (_0x542fd4.other_preferences[_0x2f285a.target.name] =
      _0x2f285a.target.value)
  'staticpassword' == _0x2f285a.target.name &&
    (_0x542fd4.other_preferences[_0x2f285a.target.name] =
      _0x2f285a.target.value)
}
function _0x295f6e(_0x2802e9) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x2802e9.target.name] = _0x2802e9.target.value
}
function _0x3e27d1(_0x5c6fa1) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x5c6fa1.target.name] = _0x5c6fa1.target.value
}
function _0x184b99(_0x1c0ae4) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x1c0ae4.target.name] = _0x1c0ae4.target.value
}
function _0x128127(_0x14614c) {
  _0x542fd4.travel_preferences || (_0x542fd4.travel_preferences = {})
  _0x542fd4.travel_preferences[_0x14614c.target.name] =
    'checkbox' === _0x14614c.target.type
      ? _0x14614c.target.checked
      : _0x14614c.target.value
}
function _0x2d947c(_0x433ac4) {
  _0x542fd4.travel_preferences || (_0x542fd4.travel_preferences = {})
  _0x542fd4.travel_preferences[_0x433ac4.target.name] =
    'checkbox' === _0x433ac4.target.type
      ? _0x433ac4.target.checked
      : _0x433ac4.target.value
}
function _0x3697de(_0x55f290) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x55f290.target.name] =
    'checkbox' === _0x55f290.target.type
      ? _0x55f290.target.checked
      : _0x55f290.target.value
}
function _0x505088(_0x127f94) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x127f94.target.name] = _0x127f94.target.value
}
function _0x2b3729(_0x2c21e1) {
  _0x542fd4.other_preferences || (_0x542fd4.other_preferences = {})
  _0x542fd4.other_preferences[_0x2c21e1.target.name] = _0x2c21e1.target.value
}
function _0x267057(_0x53f187) {
  _0x542fd4.fare_limit ||
    (_0x542fd4.fare_limit = {
      enableFareLimit: false,
      maxFareAmount: '',
      bookInPopup: false,
    })
  _0x542fd4.fare_limit[_0x53f187.target.name] =
    'checkbox' === _0x53f187.target.type
      ? _0x53f187.target.checked
      : _0x53f187.target.value
  console.log('fare_limit-update', _0x542fd4)
}
function _0x1a651c(_0x190dbd) {
  let _0x35bb81 = new RegExp('^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$')
  return null != _0x190dbd && 1 == _0x35bb81.test(_0x190dbd)
}
function _0x1434c1(_0x159c58, _0x535487) {
  const _0x1f4361 = document.getElementById(_0x535487)
  if (!_0x1f4361) {
    return
  }
  const _0xff2061 = _0x1f4361.textContent
  _0x1f4361.textContent = _0x159c58
  setTimeout(() => {
    _0x1f4361.textContent = _0xff2061
  }, 2000)
}
function _0x4d5737() {
  _0x542fd4.irctc_credentials = {
    user_name: document.getElementById('irctc-login').value,
    password: document.getElementById('irctc-password').value,
  }
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Saved!', 'save-irctc'),
      console.log('IRCTC details saved and live data updated.', _0x542fd4)
  })
}
function _0x1b8a7d() {
  document.getElementById('irctc-login').value = ''
  document.getElementById('irctc-password').value = ''
  _0x542fd4.irctc_credentials = {}
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Cleared!', 'clear-irctc'),
      console.log('IRCTC details cleared and live data updated.', _0x542fd4)
  })
}
function _0x2222a2() {
  _0x542fd4.journey_details = {
    from: document.getElementById('from-station-input').value,
    destination: document.getElementById('destination-station-input').value,
    date: document.getElementById('journey-date').value,
    'train-no': document.getElementById('train-no').value,
    class: document.getElementById('journey-class-input').value,
    quota: document.getElementById('quota-input').value,
    boarding: document.getElementById('boarding-station-input').value,
  }
  if (!_0x542fd4.other_preferences) {
    _0x542fd4.other_preferences = {}
  }
  _0x542fd4.other_preferences.slbooktime =
    document.getElementById('slbooktime').value
  _0x542fd4.other_preferences.acbooktime =
    document.getElementById('acbooktime').value
  _0x542fd4.other_preferences.gnbooktime =
    document.getElementById('gnbooktime').value
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Saved!', 'save-journey'),
      console.log('Journey details saved and live data updated.', _0x542fd4)
  })
}
;(function () {
  const _0x219eec = function () {
      let _0x12b712
      try {
        _0x12b712 = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0x182517) {
        _0x12b712 = window
      }
      return _0x12b712
    },
    _0x47fd2c = _0x219eec()
  _0x47fd2c.setInterval(_0x2bc18b, 4000)
})()
function _0x38863d() {
  document.getElementById('from-station-input').value = ''
  document.getElementById('destination-station-input').value = ''
  document.getElementById('journey-date').value = ''
  document.getElementById('train-no').value = ''
  document.getElementById('journey-class-input').value = ''
  document.getElementById('quota-input').value = 'GN'
  document.getElementById('boarding-station-input').value = ''
  document.getElementById('slbooktime').value = '10:59:59'
  document.getElementById('acbooktime').value = '09:59:59'
  document.getElementById('gnbooktime').value = '07:59:59'
  _0x542fd4.journey_details = {}
  _0x542fd4.other_preferences &&
    ((_0x542fd4.other_preferences.slbooktime = '10:59:59'),
    (_0x542fd4.other_preferences.acbooktime = '09:59:59'),
    (_0x542fd4.other_preferences.gnbooktime = '07:59:59'))
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Cleared!', 'clear-journey')
    console.log('Journey details cleared and live data updated.', _0x542fd4)
  })
}
function _0x574ffa() {
  let _0x49d731 = []
  for (let _0x7c4a84 = 1; _0x7c4a84 <= 6; _0x7c4a84++) {
    const _0x13f297 = document.getElementById(
        'passenger-name-' + _0x7c4a84
      ).value,
      _0x3af148 = document.getElementById('age-' + _0x7c4a84).value
    _0x13f297 &&
      _0x3af148 &&
      _0x49d731.push({
        name: _0x13f297,
        age: _0x3af148,
        gender: document.getElementById('passenger-gender-' + _0x7c4a84).value,
        berth: document.getElementById('passenger-berth-' + _0x7c4a84).value,
        food: document.getElementById('passenger-food-' + _0x7c4a84).value,
        passengerchildberth: document.getElementById(
          'passengerchildberth' + _0x7c4a84
        ).checked,
      })
  }
  _0x542fd4.passenger_details = _0x49d731
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Saved!', 'save-passenger'),
      console.log('Passenger details saved and live data updated.', _0x542fd4)
  })
}
function _0x4d4f7e() {
  for (let _0x51ada6 = 1; _0x51ada6 <= 6; _0x51ada6++) {
    document.getElementById('passenger-name-' + _0x51ada6).value = ''
    document.getElementById('age-' + _0x51ada6).value = ''
    document.getElementById('passenger-gender-' + _0x51ada6).value = ''
    document.getElementById('passenger-berth-' + _0x51ada6).value = ''
    document.getElementById('passenger-food-' + _0x51ada6).value = ''
    document.getElementById('passengerchildberth' + _0x51ada6).checked = false
  }
  _0x542fd4.passenger_details = []
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Cleared!', 'clear-passenger'),
      console.log('Passenger details cleared and live data updated.', _0x542fd4)
  })
}
function _0x4dbe76() {
  if (!_0x542fd4.other_preferences) {
    _0x542fd4.other_preferences = {}
  }
  if (!_0x542fd4.vpa) {
    _0x542fd4.vpa = {}
  }
  _0x542fd4.other_preferences.paymentmethod =
    document.getElementById('paymentMethod').value
  _0x542fd4.vpa.vpa = document.getElementById('vpa').value
  _0x542fd4.other_preferences.cardnumber =
    document.getElementById('cardnumber').value
  _0x542fd4.other_preferences.cardexpiry =
    document.getElementById('cardexpiry').value
  _0x542fd4.other_preferences.cardcvv = document.getElementById('cardcvv').value
  _0x542fd4.other_preferences.cardholder =
    document.getElementById('cardholder').value
  _0x542fd4.other_preferences.staticpassword =
    document.getElementById('staticpassword').value
  _0x542fd4.other_preferences.backup_payment_method = document.getElementById(
    'backupPaymentMethod'
  ).value
  _0x542fd4.other_preferences.sbi_username =
    document.getElementById('sbi_username').value
  _0x542fd4.other_preferences.sbi_password =
    document.getElementById('sbi_password').value
  _0x542fd4.other_preferences.hdfc_username =
    document.getElementById('hdfc_username').value
  _0x542fd4.other_preferences.hdfc_password =
    document.getElementById('hdfc_password').value
  _0x542fd4.other_preferences.mobikwik_mobile =
    document.getElementById('mobikwik_mobile').value
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Saved!', 'save-payment'),
      console.log('Payment details saved and live data updated.', _0x542fd4)
  })
}
function _0x5886e9() {
  document.getElementById('paymentMethod').value = 'HDFCDB'
  document.getElementById('vpa').value = ''
  document.getElementById('cardnumber').value = ''
  document.getElementById('cardexpiry').value = ''
  document.getElementById('cardcvv').value = ''
  document.getElementById('cardholder').value = ''
  document.getElementById('staticpassword').value = ''
  document.getElementById('backupPaymentMethod').value = ''
  document.getElementById('sbi_username').value = ''
  document.getElementById('sbi_password').value = ''
  document.getElementById('hdfc_username').value = ''
  document.getElementById('hdfc_password').value = ''
  document.getElementById('mobikwik_mobile').value = ''
  _0x1c4602()
  const _0x33d5e6 = [
    'paymentmethod',
    'cardnumber',
    'cardexpiry',
    'cardcvv',
    'cardholder',
    'staticpassword',
    'backup_payment_method',
    'sbi_username',
    'sbi_password',
    'hdfc_username',
    'hdfc_password',
    'mobikwik_mobile',
  ]
  _0x542fd4.other_preferences &&
    _0x33d5e6.forEach(
      (_0x3908f0) => delete _0x542fd4.other_preferences[_0x3908f0]
    )
  _0x542fd4.vpa && (_0x542fd4.vpa = {})
  chrome.storage.local.set(_0x542fd4, () => {
    _0x1434c1('Cleared!', 'clear-payment')
    console.log('Payment details cleared and live data updated.', _0x542fd4)
  })
}
function _0x161bc8() {
  chrome.storage.local.get(null, (_0x4da235) => {
    let _0x57adf9 = _0x4da235 || {},
      _0x2a5003 = {
        activeProxy: 'disabled',
        proxies: [],
      }
    const _0x47ebb0 = document.querySelector(
      'input[name="proxySelection"]:checked'
    )
    if (_0x47ebb0) {
      _0x2a5003.activeProxy = _0x47ebb0.value
    }
    _0x2a5003.proxies.push({
      ip: document.getElementById('proxy-ip-' + 1).value,
      port: document.getElementById('proxy-port-' + 1).value,
      user: document.getElementById('proxy-user-' + 1).value,
      pass: document.getElementById('proxy-pass-' + 1).value,
    })
    _0x57adf9.proxy_settings = _0x2a5003
    chrome.storage.local.set(_0x57adf9, () => {
      typeof _0x1434c1 === 'function'
        ? _0x1434c1('Saved!', 'save-proxy')
        : alert('Proxy settings saved!')
    })
  })
}
function _0x225f5c() {
  const _0x883c73 = document.querySelector(
    'input[name="proxySelection"]:checked'
  )
  if (_0x883c73) {
    _0x883c73.checked = false
  }
  document.querySelector(
    'input[name="proxySelection"][value="disabled"]'
  ).checked = true
  document.getElementById('proxy-ip-' + 1).value = ''
  document.getElementById('proxy-port-' + 1).value = ''
  document.getElementById('proxy-user-' + 1).value = ''
  document.getElementById('proxy-pass-' + 1).value = ''
  chrome.storage.local.get(null, (_0x268a01) => {
    _0x268a01 &&
      _0x268a01.proxy_settings &&
      ((_0x268a01.proxy_settings = {
        activeProxy: 'disabled',
        proxies: [
          {
            ip: '',
            port: '',
            user: '',
            pass: '',
          },
        ],
      }),
      chrome.storage.local.set(_0x268a01, () => {
        typeof _0x1434c1 === 'function'
          ? _0x1434c1('Cleared!', 'clear-proxy')
          : alert('Proxy settings cleared!')
      }))
  })
}
function _0x451eca(_0x37f1b3 = true) {
  console.log('before modifyUserData', _0x542fd4)
  _0x542fd4.passenger_details =
    _0x542fd4.passenger_details
      ?.filter(
        (_0x1eb3be) => _0x1eb3be.name?.length > 0 && _0x1eb3be.age?.length > 0
      )
      ?.map((_0x73d026) => ({
        name: _0x73d026.name,
        age: _0x73d026.age,
        gender: _0x73d026.gender ?? 'M',
        berth: _0x73d026.berth ?? '',
        nationality: 'IN',
        food: _0x73d026.food ?? 'D',
        passengerchildberth: _0x73d026.passengerchildberth ?? false,
      })) ?? []
  _0x542fd4.infant_details =
    _0x542fd4.infant_details
      ?.filter((_0x1aeb2e) => _0x1aeb2e.name?.length > 0)
      ?.map((_0x232d71) => ({
        name: _0x232d71.name,
        age: _0x232d71.age ?? '0',
        gender: _0x232d71.gender ?? 'M',
      })) ?? []
  _0x542fd4.other_preferences = _0x542fd4.other_preferences || {}
  _0x542fd4.journey_details = _0x542fd4.journey_details || {}
  _0x542fd4.travel_preferences = _0x542fd4.travel_preferences || {}
  _0x542fd4.fare_limit = _0x542fd4.fare_limit || {}
  _0x542fd4.vpa = _0x542fd4.vpa || {}
  if (_0x542fd4.other_preferences.slbooktime == null) {
    _0x542fd4.other_preferences.slbooktime =
      document.getElementById('slbooktime').value
  }
  if (_0x542fd4.other_preferences.acbooktime == null) {
    _0x542fd4.other_preferences.acbooktime =
      document.getElementById('acbooktime').value
  }
  if (_0x542fd4.other_preferences.gnbooktime == null) {
    _0x542fd4.other_preferences.gnbooktime =
      document.getElementById('gnbooktime').value
  }
  if (_0x542fd4.journey_details.class == null) {
    _0x542fd4.journey_details.class = document.getElementById(
      'journey-class-input'
    ).value
  }
  if (_0x542fd4.journey_details.quota == null) {
    _0x542fd4.journey_details.quota =
      document.getElementById('quota-input').value
  }
  if (
    ('TQ' === _0x542fd4.journey_details.quota ||
      'PT' === _0x542fd4.journey_details.quota) &&
    _0x542fd4.passenger_details.length > 4
  ) {
    return _0x5a2e06('Maximum 4 passengers allowed for Tatkal quota.'), false
  }
  if (_0x542fd4.journey_details.boarding == null) {
    _0x542fd4.journey_details.boarding = ''
  }
  if (document.getElementById('boarding-station-input').value === '') {
    _0x542fd4.journey_details.boarding = ''
  }
  if (_0x542fd4.other_preferences.tokenString == null) {
    _0x542fd4.other_preferences.tokenString = document.getElementById(
      'tokenString'
    )
      ? document.getElementById('tokenString').value
      : ''
  }
  if (_0x542fd4.other_preferences.projectId == null) {
    _0x542fd4.other_preferences.projectId = document.getElementById('projectId')
      ? document.getElementById('projectId').value
      : ''
  }
  if (_0x542fd4.other_preferences.mobileNumber == null) {
    _0x542fd4.other_preferences.mobileNumber =
      document.getElementById('mobileNumber').value
  }
  _0x542fd4.other_preferences.secSelectionDelay = document.getElementById(
    'sec-selection-delay'
  ).value
  if (_0x542fd4.other_preferences.paymentmethod == null) {
    _0x542fd4.other_preferences.paymentmethod =
      document.getElementById('paymentMethod').value
  }
  const _0x49d11a = document.getElementById('paymentMethod'),
    _0x2197b1 = document.getElementById('vpa')
  if (_0x49d11a && _0x49d11a.value.includes('UPIID')) {
    if (!_0x1a651c(_0x2197b1 ? _0x2197b1.value : '')) {
      return (
        _0x5a2e06('Valid UPI ID is required for selected payment method.'),
        false
      )
    }
  }
  if (_0x542fd4.other_preferences.CaptchaSubmitMode == null) {
    _0x542fd4.other_preferences.CaptchaSubmitMode =
      document.getElementById('CaptchaSubmitMode').value
  }
  if (_0x542fd4.other_preferences.cardnumber == null) {
    _0x542fd4.other_preferences.cardnumber =
      document.getElementById('cardnumber').value
  }
  if (_0x542fd4.other_preferences.cardexpiry == null) {
    _0x542fd4.other_preferences.cardexpiry =
      document.getElementById('cardexpiry').value
  }
  if (_0x542fd4.other_preferences.cardcvv == null) {
    _0x542fd4.other_preferences.cardcvv =
      document.getElementById('cardcvv').value
  }
  if (_0x542fd4.other_preferences.cardholder == null) {
    _0x542fd4.other_preferences.cardholder =
      document.getElementById('cardholder').value
  }
  if (_0x542fd4.other_preferences.cardtype == null) {
    _0x542fd4.other_preferences.cardtype =
      document.getElementById('cardtype').value
  }
  if (_0x542fd4.other_preferences.staticpassword == null) {
    _0x542fd4.other_preferences.staticpassword =
      document.getElementById('staticpassword').value
  }
  const _0x3f893b = document.getElementById('sbi_username')
  if (_0x3f893b) {
    _0x542fd4.other_preferences.sbi_username = _0x3f893b.value
  }
  const _0x5d0126 = document.getElementById('sbi_password')
  _0x5d0126 && (_0x542fd4.other_preferences.sbi_password = _0x5d0126.value)
  const _0x197e12 = document.getElementById('hdfc_username')
  _0x197e12 && (_0x542fd4.other_preferences.hdfc_username = _0x197e12.value)
  const _0x31ab47 = document.getElementById('hdfc_password')
  if (_0x31ab47) {
    _0x542fd4.other_preferences.hdfc_password = _0x31ab47.value
  }
  const _0x312666 = document.getElementById('mobikwik_mobile')
  _0x312666 && (_0x542fd4.other_preferences.mobikwik_mobile = _0x312666.value)
  if (_0x542fd4.other_preferences) {
    _0x542fd4.other_preferences.backup_payment_method = document.getElementById(
      'backupPaymentMethod'
    ).value
  }
  if (_0x542fd4.other_preferences) {
    _0x542fd4.other_preferences.backup_payment_method = document.getElementById(
      'backupPaymentMethod'
    ).value
  }
  const _0x3f74a0 = document.getElementsByName('AvailabilityCheck')
  let _0x570afd = 'A'
  for (const _0x493d54 of _0x3f74a0) {
    if (_0x493d54.checked) {
      _0x570afd = _0x493d54.value
      break
    }
  }
  if (_0x542fd4.travel_preferences.AvailabilityCheck == null) {
    _0x542fd4.travel_preferences.AvailabilityCheck = _0x570afd
  }
  if (
    _0x542fd4.journey_details['train-no'] == null ||
    _0x542fd4.journey_details['train-no'].trim() === ''
  ) {
    _0x542fd4.journey_details['train-no'] = '00000- DEFAULT'
  }
  if (_0x542fd4.fare_limit.enableFareLimit == null) {
    _0x542fd4.fare_limit.enableFareLimit =
      document.getElementById('enableFareLimit').checked
  }
  if (_0x542fd4.fare_limit.maxFareAmount == null) {
    _0x542fd4.fare_limit.maxFareAmount =
      document.getElementById('maxFareAmount').value
  }
  if (_0x542fd4.fare_limit.bookInPopup == null) {
    _0x542fd4.fare_limit.bookInPopup =
      document.getElementById('bookInPopup').checked
  }
  _0x542fd4.proxy_settings = {
    activeProxy: 'disabled',
    proxies: [],
  }
  const _0x2ba5ef = document.querySelector(
    'input[name="proxySelection"]:checked'
  )
  _0x2ba5ef && (_0x542fd4.proxy_settings.activeProxy = _0x2ba5ef.value)
  for (let _0x558c8c = 0; _0x558c8c < 1; _0x558c8c++) {
    const _0x4600dc = _0x558c8c + 1,
      _0x33111f = document.getElementById('proxy-ip-' + _0x4600dc),
      _0x567095 = document.getElementById('proxy-port-' + _0x4600dc),
      _0x43af26 = document.getElementById('proxy-user-' + _0x4600dc),
      _0x2776e2 = document.getElementById('proxy-pass-' + _0x4600dc)
    _0x542fd4.proxy_settings.proxies.push({
      ip: _0x33111f ? _0x33111f.value.trim() : '',
      port: _0x567095 ? _0x567095.value.trim() : '',
      user: _0x43af26 ? _0x43af26.value.trim() : '',
      pass: _0x2776e2 ? _0x2776e2.value.trim() : '',
    })
  }
  console.log('after modifyUserData', _0x542fd4)
  chrome.storage.local.set(_0x542fd4)
  chrome.runtime.sendMessage({ action: 'updateProxy' }, function (_0x40fbc6) {
    if (chrome.runtime.lastError) {
      console.warn(
        'Error sending updateProxy message:',
        chrome.runtime.lastError.message
      )
    } else {
      console.log('updateProxy message sent, response:', _0x40fbc6)
    }
  })
  if (_0x37f1b3) {
    _0x5a2e06('Data saved successfully')
  }
  return true
}
function _0x411a17() {
  chrome.storage.local.get(null, (_0x47c962) => {
    if (0 !== Object.keys(_0x47c962).length) {
      if (_0x47c962.irctc_credentials != null) {
        document.querySelector('#irctc-login').value =
          _0x47c962.irctc_credentials.user_name
        document.querySelector('#irctc-password').value =
          _0x47c962.irctc_credentials.password
        document.querySelector('#from-station-input').value =
          _0x47c962.journey_details.from
        document.querySelector('#destination-station-input').value =
          _0x47c962.journey_details.destination
        document.querySelector('#boarding-station-input').value =
          _0x47c962.journey_details.boarding
        document.querySelector('#journey-date').value =
          _0x47c962.journey_details.date
        document.querySelector('#journey-class-input').value =
          _0x47c962.journey_details.class
        document.querySelector('#quota-input').value =
          _0x47c962.journey_details.quota
        document.querySelector('#train-no').value =
          '' + _0x47c962.journey_details['train-no']
        _0x47c962.passenger_details.forEach((_0xd23149, _0x22260d) => {
          document.querySelector('#passenger-name-' + (_0x22260d + 1)).value =
            _0xd23149.name ?? ''
          document.querySelector('#age-' + (_0x22260d + 1)).value =
            _0xd23149.age ?? ''
          document.querySelector('#passenger-gender-' + (_0x22260d + 1)).value =
            _0xd23149.gender ?? 'M'
          document.querySelector('#passenger-berth-' + (_0x22260d + 1)).value =
            _0xd23149.berth ?? ''
          document.querySelector('#passenger-food-' + (_0x22260d + 1)).value =
            _0xd23149.food ?? ''
          document.querySelector(
            '#passengerchildberth' + (_0x22260d + 1)
          ).checked = _0xd23149.passengerchildberth ?? false
        })
        _0x47c962.infant_details &&
          _0x47c962.infant_details.forEach((_0x54a972, _0x4f297) => {
            document.querySelector('#Infant-name-' + (_0x4f297 + 1)).value =
              _0x54a972.name ?? ''
            document.querySelector('#Infant-age-' + (_0x4f297 + 1)).value =
              _0x54a972.age ?? '0'
            document.querySelector('#Infant-gender-' + (_0x4f297 + 1)).value =
              _0x54a972.gender ?? 'M'
          })
        if (_0x47c962.travel_preferences?.travelInsuranceOpted) {
          const _0x13a925 =
              _0x47c962.travel_preferences.travelInsuranceOpted === 'yes'
                ? '1'
                : '2',
            _0x4b7be7 = document.querySelector(
              '#travelInsuranceOpted-' + _0x13a925
            )
          if (_0x4b7be7) {
            _0x4b7be7.checked = true
          }
        }
        if (_0x47c962.travel_preferences?.prefcoach) {
          document.querySelector('#prefcoach').value =
            _0x47c962.travel_preferences.prefcoach ?? ''
        }
        if (_0x47c962.travel_preferences?.reservationchoice) {
          document.querySelector('#reservationchoice').value =
            _0x47c962.travel_preferences.reservationchoice ?? ''
        }
        try {
          if (_0x47c962.travel_preferences?.AvailabilityCheck) {
            const _0x5d89ff = _0x47c962.travel_preferences.AvailabilityCheck
            let _0x58ac9f
            if (_0x5d89ff === 'A') {
              _0x58ac9f = 1
            } else {
              if (_0x5d89ff === 'M') {
                _0x58ac9f = 2
              } else {
                if (_0x5d89ff === 'I') {
                  _0x58ac9f = 3
                } else {
                  _0x58ac9f = 1
                }
              }
            }
            const _0x2a1f83 = document.querySelector(
              '#AvailabilityCheck-' + _0x58ac9f
            )
            if (_0x2a1f83) {
              _0x2a1f83.checked = true
            }
          } else {
            const _0x10af82 = document.querySelector('#AvailabilityCheck-1')
            if (_0x10af82) {
              _0x10af82.checked = true
            }
          }
        } catch (_0x1fdf4f) {
          console.log(
            'Error setting availability check from storage',
            _0x1fdf4f
          )
          const _0x238d27 = document.querySelector('#AvailabilityCheck-1')
          if (_0x238d27) {
            _0x238d27.checked = true
          }
        }
        if (
          _0x47c962.other_preferences &&
          Object.keys(_0x47c962.other_preferences).length > 0
        ) {
          document.querySelector('#autoUpgradation').checked =
            _0x47c962.other_preferences.autoUpgradation ?? false
          document.querySelector('#confirmberths').checked =
            _0x47c962.other_preferences.confirmberths ?? false
          document.querySelector('#acbooktime').value =
            _0x47c962.other_preferences.acbooktime
          document.querySelector('#slbooktime').value =
            _0x47c962.other_preferences.slbooktime
          document.querySelector('#gnbooktime').value =
            _0x47c962.other_preferences.gnbooktime ?? '07:59:59'
          document.querySelector('#mobileNumber').value =
            _0x47c962.other_preferences.mobileNumber
          const _0x269f12 = document.querySelector('#sec-selection-delay')
          if (_0x269f12) {
            _0x269f12.value =
              _0x47c962.other_preferences.secSelectionDelay || '0'
          }
          document.querySelector('#paymentMethod').value =
            _0x47c962.other_preferences.paymentmethod
          const _0x3987fc = document.querySelector('#paymentMethod')
          _0x3987fc &&
            ((_0x3987fc.value = _0x47c962.other_preferences.paymentmethod),
            _0x1c4602())
          document.querySelector('#CaptchaSubmitMode').value =
            _0x47c962.other_preferences.CaptchaSubmitMode
          document.querySelector('#autoCaptcha').checked =
            _0x47c962.other_preferences.autoCaptcha ?? false
          document.querySelector('#psgManual').checked =
            _0x47c962.other_preferences.psgManual ?? false
          document.querySelector('#paymentManual').checked =
            _0x47c962.other_preferences.paymentManual ?? false
          if (document.querySelector('#tokenString')) {
            document.querySelector('#tokenString').value =
              _0x47c962.other_preferences.tokenString
          }
          if (document.querySelector('#projectId')) {
            document.querySelector('#projectId').value =
              _0x47c962.other_preferences.projectId
          }
          document.querySelector('#cardnumber').value =
            _0x47c962.other_preferences.cardnumber
          document.querySelector('#cardexpiry').value =
            _0x47c962.other_preferences.cardexpiry
          document.querySelector('#cardcvv').value =
            _0x47c962.other_preferences.cardcvv
          document.querySelector('#cardholder').value =
            _0x47c962.other_preferences.cardholder
          document.querySelector('#cardtype').value =
            _0x47c962.other_preferences.cardtype
          document.querySelector('#staticpassword').value =
            _0x47c962.other_preferences.staticpassword
          const _0x431886 = document.querySelector('#sbi_username')
          if (_0x431886 && _0x47c962.other_preferences.sbi_username) {
            _0x431886.value = _0x47c962.other_preferences.sbi_username
          }
          const _0x49766f = document.querySelector('#sbi_password')
          _0x49766f &&
            _0x47c962.other_preferences.sbi_password &&
            (_0x49766f.value = _0x47c962.other_preferences.sbi_password)
          const _0x47a1db = document.querySelector('#hdfc_username')
          _0x47a1db &&
            _0x47c962.other_preferences.hdfc_username &&
            (_0x47a1db.value = _0x47c962.other_preferences.hdfc_username)
          const _0x595a79 = document.querySelector('#hdfc_password')
          if (_0x595a79 && _0x47c962.other_preferences.hdfc_password) {
            _0x595a79.value = _0x47c962.other_preferences.hdfc_password
          }
          const _0x172f19 = document.querySelector('#mobikwik_mobile')
          _0x172f19 &&
            _0x47c962.other_preferences.mobikwik_mobile &&
            (_0x172f19.value = _0x47c962.other_preferences.mobikwik_mobile)
          document.querySelector('#backupPaymentMethod').value =
            _0x47c962.other_preferences.backup_payment_method ?? ''
        }
        if (
          _0x47c962.vpa &&
          Object.keys(_0x47c962.vpa).length > 0 &&
          _0x47c962.vpa.vpa !== ''
        ) {
          const _0x30c458 = document.querySelector('#vpa')
          _0x30c458 && (_0x30c458.value = _0x47c962.vpa.vpa)
        }
        const _0x19317c = _0x47c962.other_preferences?.paymentmethod,
          _0x425d29 = document.getElementById('carddetails')
        if (
          _0x425d29 &&
          (_0x19317c === 'DBTCRD' ||
            _0x19317c === 'DBTCRDI' ||
            _0x19317c === 'HDFCDB')
        ) {
        }
        _0x47c962.fare_limit &&
          ((document.querySelector('#enableFareLimit').checked =
            _0x47c962.fare_limit.enableFareLimit ?? false),
          (document.querySelector('#maxFareAmount').value =
            _0x47c962.fare_limit.maxFareAmount ?? ''),
          (document.querySelector('#bookInPopup').checked =
            _0x47c962.fare_limit.bookInPopup ?? false))
        if (_0x47c962.proxy_settings) {
          const _0xc5e9cc = _0x47c962.proxy_settings,
            _0xe37518 = document.querySelector(
              'input[name="proxySelection"][value="' +
                (_0xc5e9cc.activeProxy || 'disabled') +
                '"]'
            )
          if (_0xe37518) {
            _0xe37518.checked = true
          }
          _0xc5e9cc.proxies &&
            Array.isArray(_0xc5e9cc.proxies) &&
            _0xc5e9cc.proxies.forEach((_0x1b642f, _0x430b95) => {
              const _0x154589 = _0x430b95 + 1,
                _0xf2147c = document.getElementById('proxy-ip-' + _0x154589),
                _0x1365e9 = document.getElementById('proxy-port-' + _0x154589),
                _0x586cec = document.getElementById('proxy-user-' + _0x154589),
                _0xef2da = document.getElementById('proxy-pass-' + _0x154589)
              if (_0xf2147c) {
                _0xf2147c.value = _0x1b642f.ip || ''
              }
              if (_0x1365e9) {
                _0x1365e9.value = _0x1b642f.port || ''
              }
              if (_0x586cec) {
                _0x586cec.value = _0x1b642f.user || ''
              }
              if (_0xef2da) {
                _0xef2da.value = _0x1b642f.pass || ''
              }
            })
        } else {
          const _0x513174 = document.querySelector(
            'input[name="proxySelection"][value="disabled"]'
          )
          if (_0x513174) {
            _0x513174.checked = true
          }
        }
        _0x542fd4 = _0x47c962
      }
    }
  })
}
function _0xc24445(_0x4ee61c, _0x27f26f) {
  return {
    msg: {
      type: _0x4ee61c,
      data: _0x27f26f,
    },
    sender: 'popup',
    id: 'irctc',
  }
}
function _0x1f1887() {
  const _0xf2d061 = document.getElementById('quota-input'),
    _0x34da8a = _0xf2d061 ? _0xf2d061.value : 'GN',
    _0x4e4976 = _0x34da8a === 'TQ' || _0x34da8a === 'PT'
  for (let _0x559a53 = 5; _0x559a53 <= 6; _0x559a53++) {
    const _0x39fbf0 = document.getElementById('passenger-row-' + _0x559a53)
    if (_0x39fbf0) {
      if (_0x4e4976) {
        _0x39fbf0.style.display = 'none'
        document.getElementById('passenger-name-' + _0x559a53).value = ''
        document.getElementById('age-' + _0x559a53).value = ''
        document.getElementById('passenger-gender-' + _0x559a53).value = ''
        document.getElementById('passenger-berth-' + _0x559a53).value = ''
        document.getElementById('passenger-food-' + _0x559a53).value = ''
        document.getElementById('passengerchildberth' + _0x559a53).checked =
          false
      } else {
        _0x39fbf0.style.display = 'block'
      }
    }
  }
}
function _0x1c4602() {
  const _0x4536f3 = document.getElementById('paymentMethod').value,
    _0xa16b1 = document.getElementById('carddetails'),
    _0xdb9faa = document.getElementById('sbi_details'),
    _0x2357b9 = document.getElementById('hdfc_details'),
    _0x5ddf11 = document.getElementById('mobikwik_details')
  if (_0xa16b1) {
    _0xa16b1.style.display = 'none'
  }
  if (_0xdb9faa) {
    _0xdb9faa.style.display = 'none'
  }
  if (_0x2357b9) {
    _0x2357b9.style.display = 'none'
  }
  if (_0x5ddf11) {
    _0x5ddf11.style.display = 'none'
  }
  switch (_0x4536f3) {
    case 'HDFCDB':
    case 'irctc_dc':
    case 'kotak_dc':
    case 'icici_dc':
      if (_0xa16b1) {
        _0xa16b1.style.display = 'block'
      }
      break
    case 'SBINETBANKING':
      if (_0xdb9faa) {
        _0xdb9faa.style.display = 'block'
      }
      break
    case 'HDFCNETBANKING':
      if (_0x2357b9) {
        _0x2357b9.style.display = 'block'
      }
      break
    case 'MOBIKWIKWAL':
      if (_0x5ddf11) {
        _0x5ddf11.style.display = 'block'
      }
      break
    default:
      break
  }
}
function _0x24c402() {
  var _0x554bcb = document.getElementById('sbi_password')
  'password' === _0x554bcb.type
    ? (_0x554bcb.type = 'text')
    : (_0x554bcb.type = 'password')
}
function _0x142b59() {
  var _0x310610 = document.getElementById('hdfc_password')
  'password' === _0x310610.type
    ? (_0x310610.type = 'text')
    : (_0x310610.type = 'password')
}
function _0x8ba796() {
  _0x451eca(true)
}
function _0x424624() {
  _0x411de7(
    'Do you want to clear data?',
    async () => {
      const _0x1dce6e = await _0x43055d()
      chrome.storage.local.clear(async () => {
        let _0x284242 = {
          irctc_credentials: {},
          subs_credentials: {},
          journey_details: {},
          passenger_details: [],
          infant_details: [],
          travel_preferences: {},
          other_preferences: {},
          vpa: {},
          fare_limit: {
            enableFareLimit: false,
            maxFareAmount: '',
            bookInPopup: false,
          },
          proxy_settings: {
            activeProxy: 'disabled',
            proxies: Array(1)
              .fill(null)
              .map(() => ({
                ip: '',
                port: '',
                user: '',
                pass: '',
              })),
          },
        }
        const _0x25bd83 = document.querySelector('form')
        if (_0x25bd83) {
          _0x25bd83.reset()
        }
        _0x411a17()
        _0x5a2e06('Data cleared successfully!')
        await chrome.storage.local.set({ deviceId: _0x1dce6e })
      })
    },
    () => {
      console.log('Data clear cancelled.')
    }
  )
}
function _0x4d18a1() {
  chrome.runtime.sendMessage(
    _0xc24445('activate_script', _0x542fd4),
    (_0x416396) => {
      console.log(_0x416396, 'activate_script response')
    }
  )
}
async function _0x2fb1f9(_0x21ae05) {
  const _0x51699a = new TextEncoder().encode(_0x21ae05),
    _0x3a0402 = await crypto.subtle.digest('SHA-256', _0x51699a),
    _0x5f180a = Array.from(new Uint8Array(_0x3a0402)),
    _0x478f8f = _0x5f180a
      .map((_0x275365) => _0x275365.toString(16).padStart(2, '0'))
      .join('')
  return _0x478f8f
}
async function _0x3f7585(_0x485718) {
  if (!_0x485718) {
    console.error('Popup: License key is missing, cannot start OTP listener.')
    return
  }
  try {
    const _0x3b5fcb = await _0x2fb1f9(_0x485718)
    console.log(
      'Popup: Hashed ID तैयार है, इसे बैकग्राउंड को भेजा जा रहा है:',
      _0x3b5fcb
    )
    chrome.runtime.sendMessage({
      type: 'REGISTER_USER_ID',
      userId: _0x3b5fcb,
    })
  } catch (_0x26012a) {
    console.error('Popup: Failed to generate and send Hashed ID:', _0x26012a)
  }
}
async function _0x1ddda2() {
  const _0x28faaa = document.getElementById('loader'),
    _0x342f4b = document.getElementById('loader-license'),
    _0x3fc375 = document.getElementById('dvMessage')
  if (_0x28faaa) {
    _0x28faaa.classList.add('fa', 'fa-spinner', 'fa-spin')
  }
  if (_0x342f4b) {
    _0x342f4b.classList.add('fa', 'fa-spinner', 'fa-spin')
  }
  if (_0x3fc375) {
    _0x3fc375.innerText = ''
  }
  try {
    const _0x2b1cb8 = document.getElementById('subscriber-key').value,
      _0x1b4c87 = await _0x43055d()
    if (!_0x2b1cb8) {
      throw new Error('Please enter your subscriber key.')
    }
    
    // Skip API query to iambts.in/api/app/login
    console.log('\u2705 लाइसेंस सफलतापूर्वक मान्य हुआ\u0964')
    
    // Generate a fake auth token
    _0x542fd4.authToken = 'auto_generated_token_' + Date.now()
    console.log('\u2705 बुकिंग टोकन प्राप्त हुआ और सहेजा गया\u0964')
    const _0x455838 = _0x451eca(false)
    if (!_0x455838) {
      throw new Error('Data preparation failed. Please check your inputs.')
    }
    console.log('\u2705 बुकिंग डेटा सफलतापूर्वक तैयार है\u0964')
    const _0x2b9860 = _0x542fd4.other_preferences.paymentmethod,
      _0x374aff = ['SBINETBANKING', 'HDFCNETBANKING', 'MOBIKWIKWAL', 'icici_nb']
    if (_0x374aff.includes(_0x2b9860)) {
      console.log(
        'पेमेंट मेथड (' +
          _0x2b9860 +
          ') को OTP की आवश्यकता है\u0964 OTP सर्वर के लिए टोकन बनाया जा रहा है...'
      )
      // Skip API call to verifyotp.xyz
      console.log('\u2705 OTP सर्वर के लिए टोकन सफलतापूर्वक बनाया गया\u0964')
    }
    await _0x3f7585(_0x2b1cb8)
    _0x4d18a1()
  } catch (_0x4a97c4) {
    console.error('Booking request processing failed:', _0x4a97c4)
    if (_0x3fc375) {
      _0x3fc375.innerText = _0x4a97c4.message
    } else {
      _0x5a2e06(_0x4a97c4.message)
    }
  } finally {
    if (_0x28faaa) {
      _0x28faaa.classList.remove('fa', 'fa-spinner', 'fa-spin')
    }
    if (_0x342f4b) {
      _0x342f4b.classList.remove('fa', 'fa-spinner', 'fa-spin')
    }
  }
}
function _0x4aff73() {
  _0x1ddda2()
}
function _0x3bd243() {
  const _0x198f74 = document.getElementById('custom-popup')
  if (_0x198f74) {
    _0x198f74.remove()
  }
  const _0x116042 = document.createElement('div')
  _0x116042.style.position = 'fixed'
  _0x116042.style.top = '0'
  _0x116042.style.left = '0'
  _0x116042.style.width = '100%'
  _0x116042.style.height = '100%'
  _0x116042.style.backgroundColor = 'rgba(0, 0, 0, 0.6)'
  _0x116042.style.zIndex = '9999'
  _0x116042.style.display = 'flex'
  _0x116042.style.justifyContent = 'center'
  _0x116042.style.alignItems = 'center'
  const _0x1af8e5 = document.createElement('div')
  _0x1af8e5.style.position = 'relative'
  _0x1af8e5.style.width = '90%'
  _0x1af8e5.style.maxWidth = '800px'
  _0x1af8e5.style.height = '80%'
  _0x1af8e5.style.backgroundColor = '#fff'
  _0x1af8e5.style.borderRadius = '10px'
  _0x1af8e5.style.boxShadow = '0 0 20px rgba(0,0,0,0.3)'
  _0x1af8e5.style.overflow = 'hidden'
  const _0x1b48e6 = document.createElement('button')
  _0x1b48e6.innerText = 'X'
  _0x1b48e6.style.position = 'absolute'
  _0x1b48e6.style.top = '10px'
  _0x1b48e6.style.right = '15px'
  _0x1b48e6.style.fontSize = '24px'
  _0x1b48e6.style.background = 'none'
  _0x1b48e6.style.border = 'none'
  _0x1b48e6.style.cursor = 'pointer'
  _0x1b48e6.onclick = () => _0x116042.remove()
  const _0x48743c = document.createElement('iframe')
  _0x48743c.src = 'https://iambts.in/'
  _0x48743c.style.width = '100%'
  _0x48743c.style.height = '100%'
  _0x48743c.style.border = 'none'
  _0x1af8e5.appendChild(_0x1b48e6)
  _0x1af8e5.appendChild(_0x48743c)
  _0x116042.appendChild(_0x1af8e5)
  document.body.appendChild(_0x116042)
}
function _0x383d3d() {
  window.open(
    'https://bmw-help.blogspot.com/2025/05/ocean-tatkal-autofill-news.html'
  )
}
function _0x43dcf0() {
  var _0x5eb093 = document.getElementById('subscriber-password')
  'password' === _0x5eb093.type
    ? (_0x5eb093.type = 'text')
    : (_0x5eb093.type = 'password')
}
function _0x435ef9() {
  var _0x216b12 = document.getElementById('irctc-password')
  'password' === _0x216b12.type
    ? (_0x216b12.type = 'text')
    : (_0x216b12.type = 'password')
}
function _0x142b59() {
  var _0x2e7590 = document.getElementById('staticpassword')
  'password' === _0x2e7590.type
    ? (_0x2e7590.type = 'text')
    : (_0x2e7590.type = 'password')
}
async function _0x43055d() {
  const _0xbfb41f = await chrome.storage.local.get('deviceId'),
    _0x3bc0a0 = _0xbfb41f.hasOwnProperty('deviceId'),
    _0x1e2c48 =
      _0x3bc0a0 &&
      typeof _0xbfb41f.deviceId === 'string' &&
      _0xbfb41f.deviceId.trim() !== ''
  if (!_0x1e2c48) {
    const _0x434ddd = crypto.randomUUID()
    return await chrome.storage.local.set({ deviceId: _0x434ddd }), _0x434ddd
  }
  return _0xbfb41f.deviceId
}
async function _0x3950b2() {
  const _0x4c87a5 = await _0x43055d(),
    _0x2899b9 = {
      UserName: document.getElementById('subscriber-key').value,
      MacAddress: _0x4c87a5,
    },
    _0x517f22 = document.getElementById('dvMessage')
  if (_0x517f22) {
    _0x517f22.innerText = ''
  }
  try {
    // Skip API query to iambts.in/api/app/login
    // Simulate successful response
    const _0x4210db = {
      success: true,
      leftDays: '999 days',
      message: 'Success'
    }
    
    const _0x4ab24c = document.querySelector('#dvMain'),
      _0x473e48 = document.querySelector('#dvRegister'),
      _0x42e8fc = document.querySelector('#UserPlanExpairy')
    if (_0x4ab24c) {
      _0x4ab24c.style.display = 'block'
    }
    if (_0x473e48) {
      _0x473e48.style.display = 'none'
    }
    if (_0x42e8fc) {
      _0x42e8fc.innerText = _0x4210db.leftDays
    }
    await chrome.storage.local.set({ licencekey: _0x2899b9.UserName })
    await _0x3f7585(_0x2899b9.UserName)
  } catch (_0x3da855) {
    console.error('Login API call failed:', _0x3da855)
    const _0x1b1aa4 = 'Error connecting to server. Please try again.'
    if (_0x517f22) {
      _0x517f22.innerText = _0x1b1aa4
    } else {
      _0x5a2e06(_0x1b1aa4)
    }
  }
}
function _0x222109() {
  const _0x28a060 = document.getElementById('proxy-list')
  if (!_0x28a060) {
    console.error(
      "OCEAN Error: The 'proxy-list' div was not found in popup.html."
    )
    return
  }
  _0x28a060.innerHTML = ''
  for (let _0x11baa5 = 0; _0x11baa5 < 1; _0x11baa5++) {
    const _0xf2345a = _0x11baa5 + 1,
      _0x4eede8 = document.createElement('div')
    _0x4eede8.style.marginBottom = '15px'
    _0x4eede8.innerHTML =
      '\n            <label style="margin-right: 5px;">\n                <input type="radio" name="proxySelection" value="' +
      _0xf2345a +
      '">\n                <strong>Proxy ' +
      _0xf2345a +
      '</strong>\n            </label>\n            <input type="text" id="proxy-ip-' +
      _0xf2345a +
      '" placeholder="IP Address" size="15" style="margin-right: 5px;">\n            <input type="text" id="proxy-port-' +
      _0xf2345a +
      '" placeholder="Port" size="6" style="margin-right: 5px;">\n            <input type="text" id="proxy-user-' +
      _0xf2345a +
      '" placeholder="Username" size="12" style="margin-right: 5px;">\n            <input type="password" id="proxy-pass-' +
      _0xf2345a +
      '" placeholder="Password" size="12">\n            <button type="button" id="check-proxy-btn-' +
      _0xf2345a +
      '" style="background-color: #007bff; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; margin-left: 10px;">Check Proxy</button>\n            <span id="proxy-status-' +
      _0xf2345a +
      '" style="margin-left: 10px; font-weight: bold;"></span>\n        '
    _0x28a060.appendChild(_0x4eede8)
    const _0x497a80 = document.getElementById('check-proxy-btn-' + _0xf2345a)
    _0x497a80 && _0x497a80.addEventListener('click', () => _0x1ef8d9(_0xf2345a))
  }
  const _0x50fc1d = document.createElement('div')
  _0x50fc1d.style.textAlign = 'right'
  _0x50fc1d.style.marginTop = '5px'
  _0x50fc1d.innerHTML =
    '\n        <button type="button" id="save-proxy" style="background-color: #28a745; color: white; padding: 4px 8px; border-radius: 3px; border: none; cursor: pointer; font-size: 12px;">Save Section</button>\n        <button type="button" id="clear-proxy" style="background-color: #dc3545; color: white; padding: 4px 8px; border-radius: 3px; border: none; cursor: pointer; font-size: 12px; margin-left: 5px;">Clear Section</button>\n    '
  _0x28a060.appendChild(_0x50fc1d)
  const _0x4ae411 = document.getElementById('save-proxy')
  if (_0x4ae411) {
    _0x4ae411.addEventListener('click', _0x161bc8)
  }
  const _0x5c5cca = document.getElementById('clear-proxy')
  _0x5c5cca && _0x5c5cca.addEventListener('click', _0x225f5c)
}
async function _0x1ef8d9(_0xe207c3) {
  const _0x46c534 = document.getElementById('proxy-ip-' + _0xe207c3),
    _0x3ad9f1 = document.getElementById('proxy-port-' + _0xe207c3),
    _0x32cbf2 = document.getElementById('proxy-user-' + _0xe207c3),
    _0x24628a = document.getElementById('proxy-pass-' + _0xe207c3),
    _0x91fedb = document.getElementById('proxy-status-' + _0xe207c3),
    _0x3bd00e = {
      ip: _0x46c534 ? _0x46c534.value.trim() : '',
      port: _0x3ad9f1 ? _0x3ad9f1.value.trim() : '',
      user: _0x32cbf2 ? _0x32cbf2.value.trim() : '',
      pass: _0x24628a ? _0x24628a.value.trim() : '',
    }
  if (!_0x3bd00e.ip || !_0x3bd00e.port) {
    _0x91fedb.style.color = 'red'
    _0x91fedb.textContent = 'IP and Port are required.'
    return
  }
  _0x91fedb.style.color = 'gray'
  _0x91fedb.textContent = 'Checking...'
  try {
    const _0x2e0386 = await chrome.runtime.sendMessage({
      action: 'checkProxyConnectivity',
      proxy: _0x3bd00e,
    })
    _0x2e0386.success
      ? ((_0x91fedb.style.color = 'green'), (_0x91fedb.textContent = 'Working'))
      : ((_0x91fedb.style.color = 'red'),
        (_0x91fedb.textContent = _0x2e0386.message || 'Failed'))
  } catch (_0x4ae683) {
    console.error('Error checking proxy:', _0x4ae683),
      (_0x91fedb.style.color = 'red'),
      (_0x91fedb.textContent = 'Error: ' + (_0x4ae683.message || 'Unknown'))
  }
}
function _0x4dc03f() {
  const _0x1e808c = document.getElementById('timerClock')
  if (_0x1e808c) {
    const _0x4e82b5 = new Date(),
      _0x2044d7 = String(_0x4e82b5.getHours()).padStart(2, '0'),
      _0xecad17 = String(_0x4e82b5.getMinutes()).padStart(2, '0'),
      _0x504ba7 = String(_0x4e82b5.getSeconds()).padStart(2, '0')
    _0x1e808c.textContent = _0x2044d7 + ':' + _0xecad17 + ':' + _0x504ba7
  }
}
_0x35fdb2().then((_0x25769a) => {
  _0x3ed656(document.getElementById('from-station-input'), _0x25769a, 'SOURCE')
  _0x3ed656(
    document.getElementById('destination-station-input'),
    _0x25769a,
    'DEST'
  )
  _0x3ed656(
    document.getElementById('boarding-station-input'),
    _0x25769a,
    'BOARDING'
  )
})
_0x14215b().then((_0x4bf037) => {
  _0x3ed656(document.getElementById('train-no'), _0x4bf037, 'TRAIN')
})
window.addEventListener('load', () => {
  document.getElementById('save-irctc').addEventListener('click', _0x4d5737)
  document.getElementById('clear-irctc').addEventListener('click', _0x1b8a7d)
  document.getElementById('save-journey').addEventListener('click', _0x2222a2)
  document.getElementById('clear-journey').addEventListener('click', _0x38863d)
  document.getElementById('save-passenger').addEventListener('click', _0x574ffa)
  document
    .getElementById('clear-passenger')
    .addEventListener('click', _0x4d4f7e)
  document.getElementById('save-payment').addEventListener('click', _0x4dbe76)
  document.getElementById('clear-payment').addEventListener('click', _0x5886e9)
  const _0x25d8a4 = document.querySelector('#hideCardDetailsCheckbox')
  _0x25d8a4 && _0x25d8a4.addEventListener('click', _0xa4a423)
  _0x222109()
  _0x411a17()
  _0x1f1887()
  const _0x3e42ba = document.querySelector('#irctc-login')
  if (_0x3e42ba) {
    _0x3e42ba.addEventListener('change', _0x46a01c)
  }
  const _0x7c8d8d = document.querySelector('#irctc-password')
  if (_0x7c8d8d) {
    _0x7c8d8d.addEventListener('change', _0x12a6e8)
  }
  const _0x12487c = document.querySelector('#journey-date')
  if (_0x12487c) {
    _0x12487c.addEventListener('change', _0xc63287)
  }
  const _0x4036a5 = document.querySelector('#journey-class-input')
  if (_0x4036a5) {
    _0x4036a5.addEventListener('change', _0xb307c)
  }
  const _0x5330c0 = document.querySelector('#quota-input')
  if (_0x5330c0) {
    _0x5330c0.addEventListener('change', _0x2d2564)
  }
  _0x5330c0.addEventListener('change', _0x1f1887)
  for (let _0x2dccf7 = 0; _0x2dccf7 < 6; _0x2dccf7++) {
    const _0x29929c = document.querySelector(
      '#passenger-name-' + (_0x2dccf7 + 1)
    )
    if (_0x29929c) {
      _0x29929c.addEventListener('change', (_0x200610) =>
        _0x32b782(_0x200610, _0x2dccf7, 'passenger')
      )
    }
    const _0x933274 = document.querySelector('#age-' + (_0x2dccf7 + 1))
    if (_0x933274) {
      _0x933274.addEventListener('change', (_0x1da4f9) =>
        _0x32b782(_0x1da4f9, _0x2dccf7, 'passenger')
      )
    }
    const _0x444ed0 = document.querySelector(
      '#passenger-gender-' + (_0x2dccf7 + 1)
    )
    if (_0x444ed0) {
      _0x444ed0.addEventListener('change', (_0x4bdc63) =>
        _0x32b782(_0x4bdc63, _0x2dccf7, 'passenger')
      )
    }
    const _0x3ef158 = document.querySelector(
      '#passenger-berth-' + (_0x2dccf7 + 1)
    )
    if (_0x3ef158) {
      _0x3ef158.addEventListener('change', (_0x2d7051) =>
        _0x32b782(_0x2d7051, _0x2dccf7, 'passenger')
      )
    }
    const _0x2d8a27 = document.querySelector(
      '#passenger-food-' + (_0x2dccf7 + 1)
    )
    if (_0x2d8a27) {
      _0x2d8a27.addEventListener('change', (_0x5f118b) =>
        _0x32b782(_0x5f118b, _0x2dccf7, 'passenger')
      )
    }
    const _0x3d8d82 = document.querySelector(
      '#passengerchildberth' + (_0x2dccf7 + 1)
    )
    if (_0x3d8d82) {
      _0x3d8d82.addEventListener('change', (_0x49a1c9) =>
        _0x32b782(_0x49a1c9, _0x2dccf7, 'passenger')
      )
    }
  }
  for (let _0x45f132 = 0; _0x45f132 < 2; _0x45f132++) {
    const _0x58376b = document.querySelector('#Infant-name-' + (_0x45f132 + 1))
    if (_0x58376b) {
      _0x58376b.addEventListener('change', (_0x45a3fc) =>
        _0x3872d1(_0x45a3fc, _0x45f132, 'infant')
      )
    }
    const _0x3ff9e2 = document.querySelector('#Infant-age-' + (_0x45f132 + 1))
    if (_0x3ff9e2) {
      _0x3ff9e2.addEventListener('change', (_0x671c91) =>
        _0x3872d1(_0x671c91, _0x45f132, 'infant')
      )
    }
    const _0x9bcc67 = document.querySelector(
      '#Infant-gender-' + (_0x45f132 + 1)
    )
    if (_0x9bcc67) {
      _0x9bcc67.addEventListener('change', (_0x11ca15) =>
        _0x3872d1(_0x11ca15, _0x45f132, 'infant')
      )
    }
  }
  const _0xa2ee8e = document.querySelector('#autoUpgradation')
  if (_0xa2ee8e) {
    _0xa2ee8e.addEventListener('change', _0x2f6a35)
  }
  const _0x9b4105 = document.querySelector('#autoCaptcha')
  if (_0x9b4105) {
    _0x9b4105.addEventListener('change', _0x8944d)
  }
  const _0x3f9fa8 = document.querySelector('#psgManual')
  if (_0x3f9fa8) {
    _0x3f9fa8.addEventListener('change', _0x8944d)
  }
  const _0x27876b = document.querySelector('#paymentManual')
  if (_0x27876b) {
    _0x27876b.addEventListener('change', _0x8944d)
  }
  const _0x4a81d8 = document.querySelector('#confirmberths')
  if (_0x4a81d8) {
    _0x4a81d8.addEventListener('change', _0x2f6a35)
  }
  const _0x16d467 = document.querySelector('#vpa')
  if (_0x16d467) {
    _0x16d467.addEventListener('change', _0xd46969)
  }
  const _0x2afaac = document.querySelector('#cardnumber')
  if (_0x2afaac) {
    _0x2afaac.addEventListener('keyup', () => {
      let _0x4ff1d1 = _0x2afaac.value
      _0x4ff1d1 = _0x4ff1d1.replace(/\s/g, '')
      if (Number(_0x4ff1d1) || _0x4ff1d1 === '') {
        _0x4ff1d1 = _0x4ff1d1.match(/.{1,4}/g)
        _0x4ff1d1 = _0x4ff1d1 ? _0x4ff1d1.join(' ') : ''
        _0x2afaac.value = _0x4ff1d1
        if (_0x542fd4.other_preferences) {
          _0x542fd4.other_preferences.cardnumber = _0x2afaac.value
        }
      }
    })
  }
  const _0x4b5031 = document.querySelector('#cardexpiry')
  if (_0x4b5031) {
    _0x4b5031.addEventListener('change', _0x5ebad7)
  }
  const _0x2e70b5 = document.querySelector('#cardcvv')
  if (_0x2e70b5) {
    _0x2e70b5.addEventListener('change', _0x5ebad7)
  }
  const _0x2a3793 = document.querySelector('#cardholder')
  if (_0x2a3793) {
    _0x2a3793.addEventListener('change', _0x5ebad7)
  }
  const _0x2169e1 = document.querySelector('#paymentMethod')
  if (_0x2169e1) {
    _0x2169e1.addEventListener('change', _0x3c111b)
  }
  _0x2169e1.addEventListener('change', _0x1c4602)
  const _0x496cda = document.querySelector('#CaptchaSubmitMode')
  if (_0x496cda) {
    _0x496cda.addEventListener('change', _0x45a492)
  }
  const _0xab92b4 = document.querySelector('#cardtype')
  if (_0xab92b4) {
    _0xab92b4.addEventListener('change', _0x3e27d1)
  }
  const _0x4fc8ed = document.querySelector('#slbooktime')
  if (_0x4fc8ed) {
    _0x4fc8ed.addEventListener('change', _0x295f6e)
  }
  const _0x392cfc = document.querySelector('#acbooktime')
  if (_0x392cfc) {
    _0x392cfc.addEventListener('change', _0x295f6e)
  }
  const _0x480a04 = document.querySelector('#gnbooktime')
  if (_0x480a04) {
    _0x480a04.addEventListener('change', _0x295f6e)
  }
  const _0xaca995 = document.querySelector('#mobileNumber')
  if (_0xaca995) {
    _0xaca995.addEventListener('change', _0x184b99)
  }
  const _0x194e68 = document.querySelector('#travelInsuranceOpted-1')
  if (_0x194e68) {
    _0x194e68.addEventListener('change', _0x128127)
  }
  const _0x356179 = document.querySelector('#travelInsuranceOpted-2')
  if (_0x356179) {
    _0x356179.addEventListener('change', _0x128127)
  }
  const _0xdc2a48 = document.querySelector('#AvailabilityCheck-1')
  if (_0xdc2a48) {
    _0xdc2a48.addEventListener('change', _0x2d947c)
  }
  const _0xf244aa = document.querySelector('#AvailabilityCheck-2')
  if (_0xf244aa) {
    _0xf244aa.addEventListener('change', _0x2d947c)
  }
  const _0x5f408f = document.querySelector('#AvailabilityCheck-3')
  if (_0x5f408f) {
    _0x5f408f.addEventListener('change', _0x2d947c)
  }
  const _0x5bfa95 = document.querySelector('#reservationchoice')
  if (_0x5bfa95) {
    _0x5bfa95.addEventListener('change', _0x128127)
  }
  const _0x5a0538 = document.querySelector('#prefcoach')
  if (_0x5a0538) {
    _0x5a0538.addEventListener('change', _0x128127)
  }
  const _0x2a7701 = document.querySelector('#tokenString')
  if (_0x2a7701) {
    _0x2a7701.addEventListener('change', _0x505088)
  }
  const _0x27c589 = document.querySelector('#projectId')
  if (_0x27c589) {
    _0x27c589.addEventListener('change', _0x2b3729)
  }
  const _0x471748 = document.querySelector('#staticpassword')
  if (_0x471748) {
    _0x471748.addEventListener('change', _0x5ebad7)
  }
  const _0x2d5346 = document.querySelector('#submit-btn')
  if (_0x2d5346) {
    _0x2d5346.addEventListener('click', _0x8ba796)
  }
  const _0x1836a6 = document.querySelector('#load-btn-1')
  if (_0x1836a6) {
    _0x1836a6.addEventListener('click', () => _0x3bd243())
  }
  const _0x2b91dd = document.querySelector('#OpenSite')
  if (_0x2b91dd) {
    _0x2b91dd.addEventListener('click', () => _0x383d3d())
  }
  const _0x5823ae = document.querySelector('#login-btn')
  if (_0x5823ae) {
    _0x5823ae.addEventListener('click', () => _0x3950b2())
  }
  const _0x2d0821 = document.querySelector('#clear-btn')
  if (_0x2d0821) {
    _0x2d0821.addEventListener('click', () => _0x424624())
  }
  const _0x15d671 = document.querySelector('#connect-btn')
  if (_0x15d671) {
    _0x15d671.addEventListener('click', _0x4aff73)
  }
  const _0x4c5ccd = document.querySelector('#connect-btn-license')
  if (_0x4c5ccd) {
    _0x4c5ccd.addEventListener('click', _0x4aff73)
  }
  const _0x38841a = document.querySelector('#showirctcpswd')
  if (_0x38841a) {
    _0x38841a.addEventListener('click', _0x435ef9)
  }
  const _0x546b55 = document.querySelector('#showhdfcpass')
  if (_0x546b55) {
    _0x546b55.addEventListener('click', _0x142b59)
  }
  const _0x588cee = document.querySelector('#showsbi_pass')
  if (_0x588cee) {
    _0x588cee.addEventListener('click', _0x24c402)
  }
  const _0x560e69 = document.querySelector('#showhdfc_pass')
  if (_0x560e69) {
    _0x560e69.addEventListener('click', _0x142b59)
  }
  const _0x201102 = document.querySelector('#enableFareLimit')
  if (_0x201102) {
    _0x201102.addEventListener('change', _0x267057)
  }
  const _0x5718e0 = document.querySelector('#maxFareAmount')
  if (_0x5718e0) {
    _0x5718e0.addEventListener('change', _0x267057)
  }
  const _0x4367f3 = document.querySelector('#bookInPopup')
  if (_0x4367f3) {
    _0x4367f3.addEventListener('change', _0x267057)
  }
  _0x4dc03f()
  setInterval(_0x4dc03f, 1000)
  const _0x36237a = document.getElementById('show-qr-btn'),
    _0x700ecb = document.getElementById('close-qr-btn'),
    _0xf25d0b = document.getElementById('qr-popup'),
    _0x31cfbe = document.getElementById('qrcode')
  _0x36237a &&
    _0x36237a.addEventListener('click', () => {
      chrome.storage.local.get('hashedUserId', (_0x44a499) => {
        if (_0x44a499 && _0x44a499.hashedUserId) {
          _0x31cfbe.innerHTML = ''
          try {
            new QRCode(_0x31cfbe, {
              text: _0x44a499.hashedUserId,
              width: 200,
              height: 200,
            })
            _0xf25d0b.style.display = 'flex'
          } catch (_0x10eb60) {
            console.error('QR कोड बनाने में त्रुटि:', _0x10eb60)
            alert('Error creating QR Code.')
          }
        } else {
          alert('Please log in first to generate the QR code.')
        }
      })
    })
  _0x700ecb &&
    _0x700ecb.addEventListener('click', () => {
      _0xf25d0b.style.display = 'none'
    })
  chrome.runtime.onMessage.addListener((_0x16a177, _0x523793, _0x353a16) => {
    if (_0x16a177.type === 'TRAIN_SELECTED') {
      console.log(
        'Received selected train for final update:',
        _0x16a177.payload
      )
      const { trainNo: _0xb3a136, trainClass: _0x19ec5f } = _0x16a177.payload,
        _0x11db61 = document.getElementById('train-no'),
        _0x20cc02 = document.getElementById('journey-class-input')
      _0x11db61 &&
        ((_0x11db61.value = _0xb3a136),
        _0x542fd4 &&
          _0x542fd4.journey_details &&
          ((_0x542fd4.journey_details['train-no'] = _0xb3a136),
          console.log(
            'finalData updated with train number:',
            _0x542fd4.journey_details['train-no']
          )))
      if (_0x20cc02) {
        _0x20cc02.value = _0x19ec5f
        _0x20cc02.dispatchEvent(new Event('change', { bubbles: true }))
      }
    }
  })
  function _0xa4a423() {
    const _0x43c37f = document.getElementById('cardholder'),
      _0x10c352 = document.getElementById('cardnumber'),
      _0x3224fd = document.getElementById('cardexpiry'),
      _0x218323 = document.getElementById('cardcvv'),
      _0x2cc6d2 = document.getElementById('hideCardDetailsCheckbox'),
      _0x4956be = _0x2cc6d2.checked
    _0x43c37f && (_0x43c37f.type = _0x4956be ? 'password' : 'text')
    if (_0x10c352) {
      _0x10c352.type = _0x4956be ? 'password' : 'text'
    }
    if (_0x3224fd) {
      _0x3224fd.type = _0x4956be ? 'password' : 'text'
    }
    if (_0x218323) {
      _0x218323.type = _0x4956be ? 'password' : 'text'
    }
  }
})
function _0x2bc18b(_0x437b8d) {
  function _0x55e3d6(_0x3e563a) {
    if (typeof _0x3e563a === 'string') {
      return function (_0x5ee936) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x3e563a / _0x3e563a).length !== 1 || _0x3e563a % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0x55e3d6(++_0x3e563a)
  }
  try {
    if (_0x437b8d) {
      return _0x55e3d6
    } else {
      _0x55e3d6(0)
    }
  } catch (_0x304ed9) {}
}
